// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Definition Validator
// =============================================================================
// Structural validation for `WorkflowDefinition`s before execution. Runs
// ahead of every execute / dry-run so a malformed definition never reaches
// the planner / executor.
//
// Checks (see `validate`):
//   - `metadata` present with `id`, `name`, `version`
//   - `steps` array non-empty
//   - every step has a unique `id`
//   - every `dependsOn` reference points to an existing step
//   - no circular dependencies (topological sort succeeds)
//   - every step's `provider` is in the set of registered providers
//   - `inputs` / `outputs` are declared (at least an empty record)
//
// Sprint 13+14 spec requirements covered:
//   - Validate-before-execute so definition errors are surfaced as
//     `ValidationResult` rather than runtime crashes
//   - Cycle detection via topological sort (Kahn's algorithm)
//   - Provider-registration awareness (passed in via constructor)
//   - Input-shape validation (`validateInputs`) for the caller-supplied
//     inputs
//   - Lightweight JSON-Schema-style `validateAgainstSchema` for required
//     fields (full JSON-Schema is out of scope for Sprint 13+14)
// =============================================================================

import type {
  WorkflowDefinition,
  WorkflowInput,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Standard validation result envelope. */
export interface ValidationResult {
  valid: boolean
  errors: string[]
}

/**
 * Minimal JSON-Schema-like shape consumed by `validateAgainstSchema`. We
 * only check `required` field presence; deeper validation is out of scope
 * for Sprint 13+14.
 */
export interface SimpleSchema {
  required?: string[]
  properties?: Record<string, unknown>
}

/**
 * Validates `WorkflowDefinition` instances. Stateless across validations;
 * safe to call concurrently. The set of registered provider names is
 * supplied at construction so the validator can flag references to
 * providers that are not yet registered with the runtime.
 */
export class WorkflowValidator {
  /**
   * @param registeredProviders Provider names known to the runtime at the
   *                            time of validation. Steps referencing a
   *                            provider not in this set are flagged.
   */
  constructor(private readonly registeredProviders: Set<string>) {}

  /**
   * Run the full structural validation suite (see file header for the
   * complete checklist).
   */
  validate(definition: WorkflowDefinition): ValidationResult {
    const errors: string[] = []

    // --- metadata ---------------------------------------------------------
    if (
      !definition.metadata ||
      typeof definition.metadata !== 'object' ||
      definition.metadata === null
    ) {
      errors.push('workflow.metadata is missing or not an object')
    } else {
      const m = definition.metadata
      if (typeof m.id !== 'string' || m.id.length === 0) {
        errors.push('workflow.metadata.id is missing or empty')
      }
      if (typeof m.name !== 'string' || m.name.length === 0) {
        errors.push('workflow.metadata.name is missing or empty')
      }
      if (typeof m.version !== 'string' || m.version.length === 0) {
        errors.push('workflow.metadata.version is missing or empty')
      }
    }

    // --- version ----------------------------------------------------------
    if (typeof definition.version !== 'string' || definition.version.length === 0) {
      errors.push('workflow.version is missing or empty')
    }

    // --- inputs / outputs -------------------------------------------------
    if (
      typeof definition.inputs !== 'object' ||
      definition.inputs === null ||
      Array.isArray(definition.inputs)
    ) {
      errors.push('workflow.inputs must be a record')
    }
    if (
      typeof definition.outputs !== 'object' ||
      definition.outputs === null ||
      Array.isArray(definition.outputs)
    ) {
      errors.push('workflow.outputs must be a record')
    }

    // --- steps non-empty --------------------------------------------------
    if (!Array.isArray(definition.steps) || definition.steps.length === 0) {
      errors.push('workflow.steps must be a non-empty array')
      // Cannot run downstream checks without steps.
      return { valid: false, errors }
    }

    // --- step ids unique + provider registered ----------------------------
    const ids = new Set<string>()
    for (const step of definition.steps) {
      if (typeof step.id !== 'string' || step.id.length === 0) {
        errors.push(`step has missing or empty id`)
        continue
      }
      if (ids.has(step.id)) {
        errors.push(`step id "${step.id}" is not unique`)
      } else {
        ids.add(step.id)
      }
      if (
        typeof step.provider !== 'string' ||
        step.provider.length === 0
      ) {
        errors.push(`step "${step.id}" has missing or empty provider`)
      } else if (!this.registeredProviders.has(step.provider)) {
        errors.push(
          `step "${step.id}" references unknown provider "${step.provider}"`,
        )
      }
      // Inputs / outputs declared as records (allow empty).
      if (
        typeof step.inputs !== 'object' ||
        step.inputs === null ||
        Array.isArray(step.inputs)
      ) {
        errors.push(`step "${step.id}".inputs must be a record`)
      }
      if (
        typeof step.outputs !== 'object' ||
        step.outputs === null ||
        Array.isArray(step.outputs)
      ) {
        errors.push(`step "${step.id}".outputs must be a record`)
      }
    }

    // --- dependsOn references exist ---------------------------------------
    for (const step of definition.steps) {
      if (!Array.isArray(step.dependsOn)) {
        errors.push(`step "${step.id}".dependsOn must be an array`)
        continue
      }
      for (const dep of step.dependsOn) {
        if (typeof dep !== 'string' || dep.length === 0) {
          errors.push(
            `step "${step.id}" has a non-string or empty dependsOn entry`,
          )
          continue
        }
        if (!ids.has(dep)) {
          errors.push(
            `step "${step.id}" depends on unknown step "${dep}"`,
          )
        }
      }
    }

    // --- no cycles (topological sort) -------------------------------------
    const cycleError = this.detectCycle(definition.steps)
    if (cycleError) {
      errors.push(cycleError)
    }

    return { valid: errors.length === 0, errors }
  }

  /**
   * Validate caller-supplied inputs against the workflow's declared input
   * schema. Reports missing required inputs and (best-effort) type
   * mismatches.
   */
  validateInputs(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
  ): ValidationResult {
    const errors: string[] = []
    const declared = definition.inputs ?? {}
    for (const [name, spec] of Object.entries(declared)) {
      const s = spec as WorkflowInput
      const present = Object.prototype.hasOwnProperty.call(inputs, name)
      if (!present) {
        if (s.required) {
          errors.push(`required input "${name}" was not supplied`)
        } else if (s.default !== undefined) {
          // Defaults are applied by the orchestrator; nothing to validate.
        }
        continue
      }
      const value = inputs[name]
      if (!this.matchesType(value, s.type)) {
        errors.push(
          `input "${name}" does not match declared type "${s.type}"`,
        )
      }
    }
    return { valid: errors.length === 0, errors }
  }

  /**
   * Lightweight JSON-Schema-style validation: checks that every key in
   * `schema.required` is present on `definition` (or its `metadata`).
   * Full JSON-Schema (types, formats, conditionals) is out of scope for
   * Sprint 13+14.
   *
   * @param definition The workflow definition to validate.
   * @param schema     A minimal schema with `required` field names.
   */
  validateAgainstSchema(
    definition: WorkflowDefinition,
    schema: SimpleSchema,
  ): ValidationResult {
    const errors: string[] = []
    if (!schema.required || schema.required.length === 0) {
      return { valid: true, errors }
    }
    // Treat the definition as a flat record (metadata nested under .metadata).
    const flat: Record<string, unknown> = {
      version: definition.version,
      inputs: definition.inputs,
      outputs: definition.outputs,
      steps: definition.steps,
      checkpoints: definition.checkpoints,
      ...(definition.policies ? { policies: definition.policies } : {}),
      ...(definition.metadata ? { metadata: definition.metadata } : {}),
    }
    for (const field of schema.required) {
      if (!Object.prototype.hasOwnProperty.call(flat, field)) {
        errors.push(`schema-required field "${field}" is missing`)
      }
    }
    return { valid: errors.length === 0, errors }
  }

  /**
   * Run a topological sort (Kahn's algorithm) over the steps. Returns an
   * error string if a cycle is detected, or `null` if the DAG is acyclic.
   *
   * Exposed as a separate method so the orchestrator can reuse the same
   * sort to plan execution order.
   */
  detectCycle(steps: WorkflowStepDefinition[]): string | null {
    const idToStep = new Map<string, WorkflowStepDefinition>()
    const indegree = new Map<string, number>()
    const adjacency = new Map<string, string[]>()
    for (const s of steps) {
      idToStep.set(s.id, s)
      indegree.set(s.id, 0)
      adjacency.set(s.id, [])
    }
    for (const s of steps) {
      for (const dep of s.dependsOn) {
        if (!idToStep.has(dep)) {
          // Already reported by the dependsOn-existence check above.
          continue
        }
        adjacency.get(dep)!.push(s.id)
        indegree.set(s.id, (indegree.get(s.id) ?? 0) + 1)
      }
    }
    const queue: string[] = []
    for (const [id, deg] of indegree.entries()) {
      if (deg === 0) queue.push(id)
    }
    let visited = 0
    while (queue.length > 0) {
      const id = queue.shift()!
      visited += 1
      for (const next of adjacency.get(id) ?? []) {
        indegree.set(next, (indegree.get(next) ?? 0) - 1)
        if (indegree.get(next) === 0) queue.push(next)
      }
    }
    if (visited < steps.length) {
      const stuck = [...indegree.entries()]
        .filter(([, deg]) => deg > 0)
        .map(([id]) => id)
      logger.warn(
        { stuck },
        'workflow definition contains a cycle',
      )
      return `circular dependency detected among steps: ${stuck.join(', ')}`
    }
    return null
  }

  /**
   * Best-effort runtime type check for input validation. Treats `object`
   * as "any non-primitive" (array or plain object).
   */
  private matchesType(value: unknown, type: WorkflowInput['type']): boolean {
    switch (type) {
      case 'string':
        return typeof value === 'string'
      case 'number':
        return typeof value === 'number'
      case 'boolean':
        return typeof value === 'boolean'
      case 'object':
        return (
          typeof value === 'object' && value !== null
        )
      default:
        return true
    }
  }
}
