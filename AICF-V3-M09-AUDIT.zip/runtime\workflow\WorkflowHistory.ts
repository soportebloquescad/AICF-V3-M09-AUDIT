// =============================================================================
// AICF V3 — Sprint 7 (RC34.1) — WorkflowHistory
// =============================================================================
// Records workflow execution history: execution ID, workflow ID, status,
// duration, step results, timestamps.
//
// In-memory only; designed for future persistence.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * A single workflow execution history entry.
 */
export interface WorkflowHistoryEntry {
  readonly executionId: string
  readonly workflowId: string
  readonly status: 'running' | 'completed' | 'failed' | 'cancelled'
  readonly startedAt: string
  readonly completedAt: string | null
  readonly durationMs: number
  readonly stepCount: number
  readonly stepsCompleted: number
  readonly stepsFailed: number
  readonly error: string | null
}

/**
 * Records workflow execution history.
 *
 * Each execution is stored as a WorkflowHistoryEntry. The history supports
 * lookup by execution ID, by workflow ID, and listing all executions.
 */
export class WorkflowHistory {
  private readonly entries: WorkflowHistoryEntry[] = []
  private readonly byExecution = new Map<string, WorkflowHistoryEntry>()
  private readonly maxEntries: number
  private readonly log = logger.child({ component: 'WorkflowHistory' })

  constructor(maxEntries: number = 500) {
    this.maxEntries = maxEntries
  }

  /**
   * Records the start of a workflow execution.
   */
  recordStart(executionId: string, workflowId: string, stepCount: number): void {
    const entry: WorkflowHistoryEntry = {
      executionId,
      workflowId,
      status: 'running',
      startedAt: new Date().toISOString(),
      completedAt: null,
      durationMs: 0,
      stepCount,
      stepsCompleted: 0,
      stepsFailed: 0,
      error: null,
    }
    this.entries.push(entry)
    this.byExecution.set(executionId, entry)
    if (this.entries.length > this.maxEntries) {
      const removed = this.entries.shift()
      if (removed) this.byExecution.delete(removed.executionId)
    }
    this.log.info({ executionId, workflowId }, 'WorkflowHistory: execution started')
  }

  /**
   * Records the completion of a workflow execution.
   */
  recordCompletion(
    executionId: string,
    status: 'completed' | 'failed' | 'cancelled',
    stepsCompleted: number,
    stepsFailed: number,
    error?: string,
  ): void {
    const existing = this.byExecution.get(executionId)
    if (!existing) {
      this.log.warn({ executionId }, 'WorkflowHistory: execution not found for completion')
      return
    }

    const completedAt = new Date().toISOString()
    const durationMs = new Date(completedAt).getTime() - new Date(existing.startedAt).getTime()
    const updated: WorkflowHistoryEntry = {
      ...existing,
      status,
      completedAt,
      durationMs,
      stepsCompleted,
      stepsFailed,
      error: error ?? null,
    }

    // Replace in array and map
    const idx = this.entries.findIndex((e) => e.executionId === executionId)
    if (idx >= 0) this.entries[idx] = updated
    this.byExecution.set(executionId, updated)

    this.log.info(
      { executionId, status, durationMs, stepsCompleted, stepsFailed },
      'WorkflowHistory: execution completed',
    )
  }

  /**
   * Returns a history entry by execution ID.
   */
  get(executionId: string): WorkflowHistoryEntry | null {
    return this.byExecution.get(executionId) ?? null
  }

  /**
   * Returns all history entries for a workflow ID.
   */
  getByWorkflow(workflowId: string): WorkflowHistoryEntry[] {
    return this.entries.filter((e) => e.workflowId === workflowId)
  }

  /**
   * Returns all history entries (newest last).
   */
  list(): WorkflowHistoryEntry[] {
    return [...this.entries]
  }

  /**
   * Returns the total number of executions.
   */
  count(): number {
    return this.entries.length
  }

  /**
   * Returns statistics: total, completed, failed, cancelled, average duration.
   */
  getStats(): {
    total: number
    completed: number
    failed: number
    cancelled: number
    averageDurationMs: number
  } {
    const total = this.entries.length
    if (total === 0) {
      return { total: 0, completed: 0, failed: 0, cancelled: 0, averageDurationMs: 0 }
    }
    let completed = 0
    let failed = 0
    let cancelled = 0
    let durationSum = 0
    let durationCount = 0
    for (const e of this.entries) {
      if (e.status === 'completed') completed++
      else if (e.status === 'failed') failed++
      else if (e.status === 'cancelled') cancelled++
      if (e.durationMs > 0) {
        durationSum += e.durationMs
        durationCount++
      }
    }
    return {
      total,
      completed,
      failed,
      cancelled,
      averageDurationMs: durationCount > 0 ? Math.round(durationSum / durationCount) : 0,
    }
  }

  /**
   * Clears all history.
   */
  clear(): void {
    this.entries.length = 0
    this.byExecution.clear()
  }
}

// --- Global singleton ---
const GLOBAL_WORKFLOW_HISTORY_KEY = '__AICF_WORKFLOW_HISTORY__'

export function getGlobalWorkflowHistory(): WorkflowHistory {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_WORKFLOW_HISTORY_KEY]) {
    g[GLOBAL_WORKFLOW_HISTORY_KEY] = new WorkflowHistory()
  }
  return g[GLOBAL_WORKFLOW_HISTORY_KEY] as WorkflowHistory
}
