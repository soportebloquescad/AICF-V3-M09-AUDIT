// =============================================================================
// AICF V3 — RuntimeResponseCache Tests (Sprint 2 Production Runtime)
// =============================================================================
// Validates the in-memory LRU cache used by the Cache pipeline stage.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import {
  RuntimeResponseCache,
  computeCacheKey,
  resetRuntimeResponseCache,
} from '../RuntimeResponseCache'
import type { RuntimeResponse } from '../../contracts/RuntimeResponse'

function makeResponse(overrides: Partial<RuntimeResponse> = {}): RuntimeResponse {
  return {
    ok: true,
    requestId: 'req-test',
    correlationId: 'corr-test',
    durationMs: 10,
    content: 'Hello',
    model: 'groq-llama-3.3-70b',
    provider: 'litellm',
    usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
    ...overrides,
  }
}

describe('RuntimeResponseCache', () => {
  let cache: RuntimeResponseCache

  beforeEach(() => {
    resetRuntimeResponseCache()
    cache = new RuntimeResponseCache()
  })

  it('returns null for a missing key (miss)', () => {
    const result = cache.get('nonexistent')
    expect(result).toBeNull()
    expect(cache.stats().misses).toBe(1)
    expect(cache.stats().hits).toBe(0)
  })

  it('stores and retrieves a response (hit)', () => {
    const key = 'chat|groq|user:hi|{}'
    const response = makeResponse()
    cache.set(key, response)

    const result = cache.get(key)
    expect(result).not.toBeNull()
    expect(result!.ok).toBe(true)
    expect(result!.content).toBe('Hello')
    expect(result!.model).toBe('groq-llama-3.3-70b')
    expect(result!.cached).toBe(true)
    expect(cache.stats().hits).toBe(1)
  })

  it('regenerates requestId + correlationId on cache hit (per-request correlation)', () => {
    const key = 'chat|groq|user:hi|{}'
    cache.set(key, makeResponse({ requestId: 'original-req' }))

    const result = cache.get(key)!
    expect(result.requestId).not.toBe('original-req')
    expect(result.requestId).toMatch(/^cache-/)
    expect(result.durationMs).toBe(0)
  })

  it('evicts the oldest entry when MAX_ENTRIES is exceeded (LRU)', () => {
    const smallCache = new RuntimeResponseCache()
    // Fill beyond capacity (256). We test LRU by checking that the first
    // inserted key is evicted after 256 subsequent unique inserts.
    for (let i = 0; i < 260; i++) {
      smallCache.set(`key-${i}`, makeResponse({ content: `content-${i}` }))
    }
    // The first 4 entries (key-0 .. key-3) should have been evicted.
    expect(smallCache.get('key-0')).toBeNull()
    expect(smallCache.get('key-3')).toBeNull()
    // The most recent entries should still be present.
    expect(smallCache.get('key-259')).not.toBeNull()
    expect(smallCache.get('key-256')).not.toBeNull()
  })

  it('re-promotes an entry on access (LRU recency)', () => {
    cache.set('a', makeResponse({ content: 'A' }))
    cache.set('b', makeResponse({ content: 'B' }))

    // Access 'a' — promotes it to most-recently-used.
    cache.get('a')

    const stats = cache.stats()
    expect(stats.hits).toBe(1)
    expect(stats.size).toBe(2)
  })

  it('clear() empties the cache + resets stats', () => {
    cache.set('k', makeResponse())
    cache.get('k')
    expect(cache.size()).toBe(1)

    cache.clear()
    expect(cache.size()).toBe(0)
    expect(cache.stats().hits).toBe(0)
    expect(cache.stats().misses).toBe(0)
  })

  it('reports hit rate', () => {
    cache.set('k', makeResponse())
    cache.get('k') // hit
    cache.get('missing') // miss
    cache.get('k') // hit

    const stats = cache.stats()
    expect(stats.hits).toBe(2)
    expect(stats.misses).toBe(1)
    expect(stats.hitRate).toBeCloseTo(2 / 3, 5)
  })
})

describe('computeCacheKey', () => {
  it('produces the same key for identical inputs', () => {
    const key1 = computeCacheKey({
      operation: 'chat',
      model: 'groq-llama-3.3-70b',
      messages: [{ role: 'user', content: 'hi' }],
      parameters: { temperature: 0.7 },
    })
    const key2 = computeCacheKey({
      operation: 'chat',
      model: 'groq-llama-3.3-70b',
      messages: [{ role: 'user', content: 'hi' }],
      parameters: { temperature: 0.7 },
    })
    expect(key1).toBe(key2)
  })

  it('produces different keys for different messages', () => {
    const key1 = computeCacheKey({
      operation: 'chat',
      model: 'groq',
      messages: [{ role: 'user', content: 'hi' }],
    })
    const key2 = computeCacheKey({
      operation: 'chat',
      model: 'groq',
      messages: [{ role: 'user', content: 'bye' }],
    })
    expect(key1).not.toBe(key2)
  })

  it('produces different keys for different operations', () => {
    const key1 = computeCacheKey({ operation: 'chat', model: 'groq' })
    const key2 = computeCacheKey({ operation: 'models', model: 'groq' })
    expect(key1).not.toBe(key2)
  })

  it('produces different keys for different parameters', () => {
    const key1 = computeCacheKey({
      operation: 'chat',
      model: 'groq',
      messages: [{ role: 'user', content: 'hi' }],
      parameters: { temperature: 0.7 },
    })
    const key2 = computeCacheKey({
      operation: 'chat',
      model: 'groq',
      messages: [{ role: 'user', content: 'hi' }],
      parameters: { temperature: 0.9 },
    })
    expect(key1).not.toBe(key2)
  })

  it('handles null messages + null parameters', () => {
    const key = computeCacheKey({ operation: 'status' })
    expect(key).toBe('status|||')
  })
})
