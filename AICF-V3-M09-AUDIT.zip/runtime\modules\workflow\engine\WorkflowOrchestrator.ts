// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Orchestrator
// =============================================================================
// Topological-step runner for `WorkflowDefinition`s. The orchestrator:
//   1. Validates the definition (delegated to `WorkflowValidator`).
//   2. Validates the caller-supplied inputs.
//   3. Resolves step inputs / configs against the runtime variables.
//   4. Topologically sorts the steps (throws on cycles).
//   5. Executes each step in order via `StepExecutorService`.
//   6. Saves checkpoints at the step ids declared in `definition.checkpoints`.
//   7. On failure: runs `CompensationHandler` and emits `workflow.failed`.
//   8. On success: emits `workflow.completed` and returns a `WorkflowResult`.
//
// Sprint 13+14 spec requirements covered:
//   - Topological execution with cycle detection
//   - Checkpoint persistence for pause / resume / replay
//   - Saga-pattern compensation on failure
//   - Dry-run preview (token / cost / duration estimates WITHOUT calling AI)
//   - Structured workflow lifecycle events
// =============================================================================

import type {
  WorkflowDefinition,
  WorkflowExecution,
  WorkflowContext,
  WorkflowResult,
  WorkflowStepDefinition,
  WorkflowArtifactRef,
  DryRunResult,
  Checkpoint,
  TokenUsage,
  WorkflowMetrics,
} from '@/lib/runtime/contracts/workflow'
import {
  createPendingExecution,
  createCompletedResult,
  createFailedResult,
} from '@/lib/runtime/contracts/workflow'
import type {
  IEventBus,
  IArtifactStorage,
  IWorkflowStateStore,
} from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'
import type { StepExecutorService } from '../steps/StepExecutor'
import type { WorkflowValidator } from './WorkflowValidator'
import type { CompensationHandler } from './CompensationHandler'
import type { ContextManager } from '../context/ContextManager'

/** Heuristic per-step-type token cost estimate for dry-run. */
const DRY_RUN_TOKENS_PER_STEP: Record<string, number> = {
  chat: 1500,
  generate: 8000,
  validate: 50,
  transform: 100,
  conditional: 10,
  action: 200,
}

/** Heuristic per-step-type duration estimate (ms) for dry-run. */
const DRY_RUN_DURATION_PER_STEP: Record<string, number> = {
  chat: 2500,
  generate: 12000,
  validate: 50,
  transform: 100,
  conditional: 10,
  action: 500,
}

/** Heuristic per-step-type cost (per token multiplier) for dry-run. */
const DRY_RUN_COST_PER_STEP: Record<string, number> = {
  chat: 0.000002,
  generate: 0.000003,
  validate: 0,
  transform: 0,
  conditional: 0,
  action: 0,
}

/**
 * Runs a `WorkflowDefinition` topologically. One orchestrator instance can
 * be reused across many executions; per-execution state lives in the
 * `WorkflowExecution` envelope, not on the orchestrator.
 */
export class WorkflowOrchestrator {
  constructor(
    private readonly stepExecutor: StepExecutorService,
    private readonly eventBus: IEventBus,
    private readonly validator: WorkflowValidator,
    private readonly compensationHandler: CompensationHandler,
    private readonly contextManager: ContextManager,
    private readonly artifactStorage: IArtifactStorage,
    private readonly stateStore?: IWorkflowStateStore,
  ) {}

  /**
   * Execute a workflow definition to completion (or terminal failure).
   *
   * Lifecycle:
   *   1. Validate definition + inputs (return early on validation failure).
   *   2. Topologically sort steps (throws on cycles).
   *   3. Emit `workflow.started`.
   *   4. For each step in order:
   *        a. Execute via `StepExecutorService`.
   *        b. Update the execution envelope + per-step records.
   *        c. Persist the latest step record to the state store.
   *        d. Persist any artifacts via `IArtifactStorage`.
   *        e. Save a checkpoint if the step id is in `definition.checkpoints`.
   *        f. Update the runtime context with cost / token deltas.
   *        g. Bind step outputs back into the variables for downstream steps.
   *   5. On step failure (after retries): run `CompensationHandler`,
   *      emit `workflow.failed`, return a failed `WorkflowResult`.
   *   6. On success: emit `workflow.completed`, return a completed
   *      `WorkflowResult`.
   */
  async execute(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<WorkflowResult> {
    const startWall = Date.now()

    // --- validate ----------------------------------------------------
    const defResult = this.validator.validate(definition)
    if (!defResult.valid) {
      logger.error(
        { workflowId: definition.metadata.id, errors: defResult.errors },
        'workflow definition validation failed',
      )
      return createFailedResult({
        executionId: ctx.executionId,
        workflowId: definition.metadata.id,
        error: `definition validation failed: ${defResult.errors.join('; ')}`,
        metrics: this.emptyMetrics(),
        durationMs: Date.now() - startWall,
        correlationId: ctx.correlationId,
      })
    }
    const inputResult = this.validator.validateInputs(definition, inputs)
    if (!inputResult.valid) {
      logger.error(
        { workflowId: definition.metadata.id, errors: inputResult.errors },
        'workflow input validation failed',
      )
      return createFailedResult({
        executionId: ctx.executionId,
        workflowId: definition.metadata.id,
        error: `input validation failed: ${inputResult.errors.join('; ')}`,
        metrics: this.emptyMetrics(),
        durationMs: Date.now() - startWall,
        correlationId: ctx.correlationId,
      })
    }

    // --- topological sort --------------------------------------------
    let sortedSteps: WorkflowStepDefinition[]
    try {
      sortedSteps = this.topologicalSort(definition.steps)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'cycle detection error'
      return createFailedResult({
        executionId: ctx.executionId,
        workflowId: definition.metadata.id,
        error: message,
        metrics: this.emptyMetrics(),
        durationMs: Date.now() - startWall,
        correlationId: ctx.correlationId,
      })
    }

    // --- build execution envelope ------------------------------------
    const execution: WorkflowExecution = createPendingExecution(
      definition.metadata.id,
      definition.version,
      inputs,
      ctx.correlationId,
      ctx.dryRun,
      sortedSteps.map((s) => s.id),
    )
    // Attach step definitions for the compensation handler.
    execution.inputs = {
      ...execution.inputs,
      __workflow_steps: sortedSteps,
    }
    execution.status = 'running'
    execution.updatedAt = Date.now()
    if (this.stateStore) {
      await this.stateStore.saveExecution(execution)
    }

    // --- emit workflow.started ---------------------------------------
    await this.eventBus.publish({
      type: 'workflow.started',
      timestamp: Date.now(),
      level: 'info',
      executionId: execution.executionId,
      correlationId: execution.correlationId,
      data: {
        workflowId: definition.metadata.id,
        workflowVersion: definition.version,
        stepCount: sortedSteps.length,
      },
    })

    // --- execute steps in order --------------------------------------
    const artifacts: WorkflowArtifactRef[] = []
    let variables: Record<string, unknown> = { ...ctx.variables, inputs }
    let currentCtx = ctx
    let failedStepId: string | null = null
    let failureError: string | null = null

    for (const step of sortedSteps) {
      // Update variables on the context (so step executors see upstream outputs).
      currentCtx = this.contextManager.updateVariables(currentCtx, variables)

      const stepExec = execution.steps[step.id]
      if (stepExec) {
        stepExec.status = 'running'
        stepExec.startedAt = Date.now()
        stepExec.attempts += 1
      }

      const result = await this.stepExecutor.execute(
        step,
        execution,
        currentCtx,
      )

      // Update the step record.
      const updatedStepExec = execution.steps[step.id]
      if (updatedStepExec) {
        updatedStepExec.durationMs = result.durationMs
        updatedStepExec.output = result.output
        if (result.ok) {
          updatedStepExec.status = 'completed'
          updatedStepExec.completedAt = Date.now()
        } else {
          updatedStepExec.status = 'failed'
          updatedStepExec.completedAt = Date.now()
          updatedStepExec.error = result.error
        }
        // Track artifact ids produced by this step.
        for (const art of result.artifacts) {
          updatedStepExec.artifacts.push(art.id)
        }
      }

      // Persist artifacts.
      for (const art of result.artifacts) {
        await this.artifactStorage.save(art)
        artifacts.push({
          id: art.id,
          stepId: step.id,
          name: art.name,
          type: art.type,
          sizeBytes: art.sizeBytes,
        })
      }

      // Update cost / tokens on the context.
      if (result.tokensUsed || result.cost) {
        currentCtx = {
          ...currentCtx,
          cost: currentCtx.cost + (result.cost ?? 0),
          tokens: {
            promptTokens:
              currentCtx.tokens.promptTokens +
              (result.tokensUsed?.promptTokens ?? 0),
            completionTokens:
              currentCtx.tokens.completionTokens +
              (result.tokensUsed?.completionTokens ?? 0),
            totalTokens:
              currentCtx.tokens.totalTokens +
              (result.tokensUsed?.totalTokens ?? 0),
          },
        }
      }

      // Bind step outputs back into variables for downstream steps.
      for (const [producedName, varName] of Object.entries(step.outputs)) {
        if (Object.prototype.hasOwnProperty.call(result.output, producedName)) {
          variables[varName] = result.output[producedName]
        }
      }

      // Persist step state.
      if (this.stateStore && updatedStepExec) {
        await this.stateStore.updateStepExecution(
          execution.executionId,
          step.id,
          updatedStepExec,
        )
      }

      // Checkpoint?
      if (definition.checkpoints.includes(step.id)) {
        const cp: Checkpoint = {
          id: `cp-${execution.executionId}-${step.id}`,
          stepId: step.id,
          savedAt: Date.now(),
          state: this.contextManager.snapshot(currentCtx),
        }
        execution.checkpoints.push(cp)
        if (this.stateStore) {
          await this.stateStore.saveCheckpoint(execution.executionId, cp)
        }
        await this.eventBus.publish({
          type: 'workflow.checkpoint',
          timestamp: Date.now(),
          level: 'info',
          executionId: execution.executionId,
          stepId: step.id,
          correlationId: execution.correlationId,
          data: { checkpointId: cp.id },
        })
      }

      // Stop the run on failure.
      if (!result.ok) {
        failedStepId = step.id
        failureError = result.error ?? 'step failed'
        break
      }
    }

    // --- terminal handling -------------------------------------------
    execution.updatedAt = Date.now()
    execution.completedAt = Date.now()

    if (failedStepId !== null) {
      execution.status = 'compensating'
      if (this.stateStore) await this.stateStore.saveExecution(execution)
      await this.compensationHandler.compensate(
        execution,
        failedStepId,
        currentCtx,
      )
      execution.status = 'failed'
      execution.error = failureError ?? undefined
      if (this.stateStore) await this.stateStore.saveExecution(execution)

      await this.eventBus.publish({
        type: 'workflow.failed',
        timestamp: Date.now(),
        level: 'error',
        executionId: execution.executionId,
        correlationId: execution.correlationId,
        data: { failedStepId, error: failureError },
      })

      return createFailedResult({
        executionId: execution.executionId,
        workflowId: definition.metadata.id,
        error: failureError ?? 'workflow failed',
        metrics: this.buildMetrics(execution, sortedSteps.length, currentCtx),
        durationMs: Date.now() - startWall,
        correlationId: ctx.correlationId,
        artifacts,
      })
    }

    // --- success: bind outputs from declared from-step ----------------
    const outputs = this.bindOutputs(definition, variables)
    execution.status = 'completed'
    execution.outputs = outputs
    if (this.stateStore) await this.stateStore.saveExecution(execution)

    await this.eventBus.publish({
      type: 'workflow.completed',
      timestamp: Date.now(),
      level: 'info',
      executionId: execution.executionId,
      correlationId: execution.correlationId,
      data: {
        workflowId: definition.metadata.id,
        outputs: Object.keys(outputs),
      },
    })

    return createCompletedResult({
      executionId: execution.executionId,
      workflowId: definition.metadata.id,
      outputs,
      artifacts,
      metrics: this.buildMetrics(execution, sortedSteps.length, currentCtx),
      durationMs: Date.now() - startWall,
      correlationId: ctx.correlationId,
    })
  }

  /**
   * Dry-run preview: estimate tokens / cost / duration WITHOUT calling AI.
   * Uses per-step-type heuristics; the actual execution may diverge
   * (especially for `'generate'` steps where the underlying generator
   * controls token consumption).
   */
  async dryRun(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<DryRunResult> {
    const defResult = this.validator.validate(definition)
    const inputResult = this.validator.validateInputs(definition, inputs)
    const warnings: string[] = []

    let canExecute = defResult.valid && inputResult.valid
    if (!defResult.valid) {
      warnings.push(`definition invalid: ${defResult.errors.join('; ')}`)
    }
    if (!inputResult.valid) {
      warnings.push(`inputs invalid: ${inputResult.errors.join('; ')}`)
    }

    let sortedSteps: WorkflowStepDefinition[] = []
    try {
      sortedSteps = this.topologicalSort(definition.steps)
    } catch (err) {
      canExecute = false
      const message = err instanceof Error ? err.message : 'cycle'
      warnings.push(message)
    }

    const tokenUsage: TokenUsage = {
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
    }
    let estimatedCost = 0
    let estimatedDurationMs = 0
    const providerSelection: Record<string, string> = {}

    for (const step of sortedSteps) {
      const tokens = DRY_RUN_TOKENS_PER_STEP[step.type] ?? 250
      const cost = tokens * (DRY_RUN_COST_PER_STEP[step.type] ?? 0)
      const duration = DRY_RUN_DURATION_PER_STEP[step.type] ?? 1000
      tokenUsage.promptTokens += Math.floor(tokens * 0.6)
      tokenUsage.completionTokens += Math.floor(tokens * 0.4)
      tokenUsage.totalTokens += tokens
      estimatedCost += cost
      estimatedDurationMs += duration
      providerSelection[step.id] = step.provider
    }

    if (ctx.dryRun) {
      warnings.push('ctx.dryRun is true; this preview is also a dry run')
    }

    return {
      canExecute,
      estimatedTokens: tokenUsage,
      estimatedCost,
      estimatedDurationMs,
      stepsPlanned: sortedSteps.map((s) => s.id),
      providerSelection,
      warnings,
    }
  }

  /**
   * Topologically sort `steps` by `dependsOn`. Throws if a cycle is
   * detected. The result is a stable order: among steps with no remaining
   * dependencies, the original array order is preserved.
   */
  topologicalSort(steps: WorkflowStepDefinition[]): WorkflowStepDefinition[] {
    const idToStep = new Map<string, WorkflowStepDefinition>()
    const indegree = new Map<string, number>()
    const adjacency = new Map<string, string[]>()
    for (const s of steps) {
      if (idToStep.has(s.id)) {
        throw new Error(`duplicate step id: ${s.id}`)
      }
      idToStep.set(s.id, s)
      indegree.set(s.id, 0)
      adjacency.set(s.id, [])
    }
    for (const s of steps) {
      for (const dep of s.dependsOn) {
        if (!idToStep.has(dep)) {
          throw new Error(`step "${s.id}" depends on unknown step "${dep}"`)
        }
        adjacency.get(dep)!.push(s.id)
        indegree.set(s.id, (indegree.get(s.id) ?? 0) + 1)
      }
    }

    // Seed the queue in original order (stable sort).
    const queue: string[] = []
    for (const s of steps) {
      if ((indegree.get(s.id) ?? 0) === 0) queue.push(s.id)
    }

    const out: WorkflowStepDefinition[] = []
    while (queue.length > 0) {
      const id = queue.shift()!
      const step = idToStep.get(id)
      if (step) out.push(step)
      for (const next of adjacency.get(id) ?? []) {
        indegree.set(next, (indegree.get(next) ?? 0) - 1)
        if ((indegree.get(next) ?? 0) === 0) queue.push(next)
      }
    }

    if (out.length !== steps.length) {
      const stuck = [...indegree.entries()]
        .filter(([, deg]) => (deg ?? 0) > 0)
        .map(([id]) => id)
      throw new Error(
        `circular dependency detected among steps: ${stuck.join(', ')}`,
      )
    }

    return out
  }

  /**
   * Bind the workflow's declared outputs from the resolved variables.
   * Each `WorkflowOutput.fromStep` is informational; we look up the
   * output by its declared `name` in `variables` (since step outputs
   * were bound back into `variables` during execution).
   */
  private bindOutputs(
    definition: WorkflowDefinition,
    variables: Record<string, unknown>,
  ): Record<string, unknown> {
    const outputs: Record<string, unknown> = {}
    for (const [name, spec] of Object.entries(definition.outputs)) {
      if (Object.prototype.hasOwnProperty.call(variables, name)) {
        outputs[name] = variables[name]
      }
    }
    return outputs
  }

  /** Build `WorkflowMetrics` from the terminal execution envelope. */
  private buildMetrics(
    execution: WorkflowExecution,
    stepsTotal: number,
    ctx: WorkflowContext,
  ): WorkflowMetrics {
    let retries = 0
    let failures = 0
    let completed = 0
    const providerLatency: Record<string, number> = {}
    for (const stepExec of Object.values(execution.steps)) {
      retries += Math.max(0, stepExec.attempts - 1)
      if (stepExec.status === 'failed') failures += 1
      if (stepExec.status === 'completed') completed += 1
      if (stepExec.durationMs) {
        // Provider attribution: track by stepId as a proxy when no
        // explicit provider was attached.
        providerLatency[stepExec.stepId] =
          (providerLatency[stepExec.stepId] ?? 0) + stepExec.durationMs
      }
    }
    return {
      executionTimeMs: Date.now() - execution.startedAt,
      tokenUsage: { ...ctx.tokens },
      providerLatency,
      cost: ctx.cost,
      retries,
      failures,
      successRate: stepsTotal > 0 ? completed / stepsTotal : 0,
      stepsExecuted: Object.keys(execution.steps).length,
      stepsTotal,
    }
  }

  /** Zero-metrics helper for early-return failure paths. */
  private emptyMetrics(): WorkflowMetrics {
    return {
      executionTimeMs: 0,
      tokenUsage: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
      providerLatency: {},
      cost: 0,
      retries: 0,
      failures: 0,
      successRate: 0,
      stepsExecuted: 0,
      stepsTotal: 0,
    }
  }
}
