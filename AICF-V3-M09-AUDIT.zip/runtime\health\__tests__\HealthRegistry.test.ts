// =============================================================================
// AICF V3 — HealthRegistry Tests (Sprint 17: Runtime Foundation Consolidation)
// =============================================================================
// Tests for the centralized per-module health registry:
//   - getStatus()         → 'unknown' for unregistered; latest report otherwise
//   - set()               → updates status, lastCheck, uptime
//   - getAllStatuses()    → all reports
//   - getUnhealthy/...    → filter helpers (one per status)
//   - checkAll()          → active probing via module.health()
//
// Uses a real ModuleRegistry (auto-stubs localization/assets/reports). Mock
// modules with health() methods are registered via registerWithMetadata so
// checkAll() can iterate them. No `any`.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { HealthRegistry } from '../HealthRegistry'
import type { HealthStatus } from '../HealthRegistry'
import { ModuleRegistry } from '@/lib/runtime/registry/ModuleRegistry'
import type { RuntimeModule, ModuleHealth } from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'

/**
 * Builds minimal PluginMetadata for a test module.
 */
function makeMockMetadata(
  id: string,
  capabilities: string[] = [],
  opts?: { version?: string; priority?: number; deps?: string[] },
): PluginMetadata {
  return {
    id,
    name: id,
    description: `mock ${id}`,
    author: 'test',
    version: opts?.version || '1.0.0',
    mission: 'TEST',
    priority: opts?.priority ?? 10,
    dependencies: opts?.deps || [],
    capabilities,
    contracts: createVersionedContract('1.0.0', 'compatible'),
  }
}

/**
 * Builds a mock RuntimeModule with a configurable health() result.
 */
function makeHealthModule(
  id: string,
  healthStatus: ModuleHealth['status'] = 'healthy',
  opts?: { ready?: boolean; deps?: string[] },
): RuntimeModule {
  const startupTime = new Date().toISOString()
  const ready = opts?.ready ?? true
  return {
    name: id,
    version: '1.0.0',
    async initialize() {},
    isReady: () => ready,
    getStatus: () => ({ name: id, ready, version: '1.0.0' }),
    async health(): Promise<ModuleHealth> {
      return {
        ready,
        status: healthStatus,
        startupTime,
        dependencies: opts?.deps || [],
        version: '1.0.0',
        lastInitialization: startupTime,
      }
    },
  }
}

describe('HealthRegistry (Sprint 17)', () => {
  let registry: ModuleRegistry
  let health: HealthRegistry

  beforeEach(() => {
    registry = new ModuleRegistry()
    health = new HealthRegistry(registry)
  })

  // -------------------------------------------------------------------------
  // getStatus()
  // -------------------------------------------------------------------------
  describe('getStatus()', () => {
    it("returns 'unknown' for an unregistered module", () => {
      const report = health.getStatus('never-seen')
      expect(report.status).toBe('unknown')
      expect(report.moduleId).toBe('never-seen')
      expect(report.lastCheck).toBeNull()
      expect(report.uptime).toBe(0)
      expect(report.dependencies).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // set()
  // -------------------------------------------------------------------------
  describe('set()', () => {
    it('updates the status and records lastCheck', () => {
      health.set('foo', 'healthy')
      const report = health.getStatus('foo')
      expect(report.status).toBe('healthy')
      expect(report.lastCheck).not.toBeNull()
    })

    it('records lastError when provided', () => {
      health.set('foo', 'failed', 'boom')
      const report = health.getStatus('foo')
      expect(report.status).toBe('failed')
      expect(report.lastError).toBe('boom')
    })
  })

  // -------------------------------------------------------------------------
  // getAllStatuses()
  // -------------------------------------------------------------------------
  describe('getAllStatuses()', () => {
    it('returns all tracked module statuses', () => {
      health.set('a', 'healthy')
      health.set('b', 'failed')
      const all = health.getAllStatuses()
      expect(all.length).toBe(2)
      const ids = all.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['a', 'b'])
    })

    it('returns empty when nothing has been set', () => {
      expect(health.getAllStatuses()).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // status filters
  // -------------------------------------------------------------------------
  describe('status filters', () => {
    beforeEach(() => {
      health.set('h1', 'healthy')
      health.set('h2', 'healthy')
      health.set('d1', 'degraded')
      health.set('f1', 'failed')
      health.set('i1', 'initializing')
      health.set('u1', 'unknown')
    })

    it('getUnhealthy() returns only failed modules', () => {
      const result = health.getUnhealthy()
      expect(result.length).toBe(1)
      expect(result[0].moduleId).toBe('f1')
    })

    it('getDegraded() returns only degraded modules', () => {
      const result = health.getDegraded()
      expect(result.length).toBe(1)
      expect(result[0].moduleId).toBe('d1')
    })

    it('getHealthy() returns only healthy modules', () => {
      const result = health.getHealthy()
      expect(result.length).toBe(2)
      const ids = result.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['h1', 'h2'])
    })

    it('getInitializing() returns only initializing modules', () => {
      const result = health.getInitializing()
      expect(result.length).toBe(1)
      expect(result[0].moduleId).toBe('i1')
    })

    it('getUnknown() returns only unknown modules', () => {
      const result = health.getUnknown()
      expect(result.length).toBe(1)
      expect(result[0].moduleId).toBe('u1')
    })
  })

  // -------------------------------------------------------------------------
  // checkAll()
  // -------------------------------------------------------------------------
  describe('checkAll()', () => {
    it('calls health() on every registered module and updates statuses', async () => {
      // Register two real modules with metadata so getEntries() returns them.
      const healthyMeta = makeMockMetadata('healthy-mod', ['capA'])
      const degradedMeta = makeMockMetadata('degraded-mod', ['capB'])
      registry.registerWithMetadata(
        'workflow',
        makeHealthModule('healthy-mod', 'healthy', { ready: true }),
        healthyMeta,
      )
      registry.registerWithMetadata(
        'generation',
        makeHealthModule('degraded-mod', 'degraded', { ready: true }),
        degradedMeta,
      )

      const reports = await health.checkAll()

      // Both modules should have been probed.
      const healthy = reports.find((r) => r.moduleId === 'healthy-mod')
      const degraded = reports.find((r) => r.moduleId === 'degraded-mod')
      expect(healthy).toBeDefined()
      expect(healthy?.status).toBe('healthy')
      expect(degraded).toBeDefined()
      expect(degraded?.status).toBe('degraded')
    })

    it('marks a module failed when its health() throws', async () => {
      const throwingModule: RuntimeModule = {
        name: 'throwing-mod',
        version: '1.0.0',
        async initialize() {},
        isReady: () => false,
        getStatus: () => ({ name: 'throwing-mod', ready: false, version: '1.0.0' }),
        async health(): Promise<ModuleHealth> {
          throw new Error('health probe exploded')
        },
      }
      registry.registerWithMetadata(
        'workflow',
        throwingModule,
        makeMockMetadata('throwing-mod', ['capX']),
      )

      const reports = await health.checkAll()
      const report = reports.find((r) => r.moduleId === 'throwing-mod')
      expect(report).toBeDefined()
      expect(report?.status).toBe('failed')
      expect(report?.lastError).toBe('health probe exploded')
    })

    it('returns empty array when no modules are registered with metadata', async () => {
      // Fresh registry: only auto-stubs (localization/assets/reports) which
      // are NOT registered with metadata, so getEntries() is empty.
      const reports = await health.checkAll()
      expect(reports).toEqual([])
    })
  })
})
