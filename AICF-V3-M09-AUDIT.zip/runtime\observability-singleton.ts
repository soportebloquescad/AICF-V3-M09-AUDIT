// =============================================================================
// AICF V3 — Observability Singleton (Sprint 22: PR 2 — Observability subscribers)
// =============================================================================
// Process-level singleton that wires the three Sprint 22 event subscribers
// (AuditSubscriber, MetricsSubscriber, DashboardSubscriber) to the global
// RuntimeEventBus. This is the ONE place where the observability subscribers
// are instantiated + registered for the runtime's lifetime.
//
// Exports:
//   - getAuditProvider()        → InMemoryAuditProvider (singleton)
//   - getMetricsRegistry()      → MetricsRegistry (singleton)
//   - getMetricsSubscriber()    → MetricsSubscriber (singleton)
//   - getDashboardSubscriber()  → DashboardSubscriber (singleton)
//
// Idempotent: the wiring block runs exactly once per process; subsequent
// calls to any getter return the cached instance.
//
// BRIDGE NOTE: the RuntimeEventBus dispatches RuntimeEvent (not envelopes)
// to its on()/onAll() handlers. `publishEnvelope()` wraps the envelope as
// `event.data.envelope`. This module installs a thin bridge per subscriber
// that extracts the envelope from the RuntimeEvent and forwards it to
// subscriber.onEvent(). Errors in the bridge are caught + logged so a
// faulty subscriber can never break the bus delivery path.
// =============================================================================

import type { RuntimeEventEnvelope } from './events/EventMetadata'
import type { RuntimeEvent } from './events/RuntimeEvents'
import { getGlobalEventBus } from './services/RuntimeService'
import { InMemoryAuditProvider, type AuditProvider } from './audit/AuditProvider'
import { MetricsRegistry } from './metrics/MetricsRegistry'
import {
  AuditSubscriber,
  MetricsSubscriber,
  DashboardSubscriber,
  type EventSubscriber,
} from './subscribers'
import { logger } from '@/lib/ai/logger'

// -----------------------------------------------------------------------------
// Singleton slots (created lazily on first access)
// -----------------------------------------------------------------------------
let auditProvider: InMemoryAuditProvider | null = null
let metricsRegistry: MetricsRegistry | null = null
let auditSubscriber: AuditSubscriber | null = null
let metricsSubscriber: MetricsSubscriber | null = null
let dashboardSubscriber: DashboardSubscriber | null = null
/** True once the wiring block has run (idempotency guard). */
let observabilityWired = false

/**
 * Runtime type guard: returns true iff `value` looks like a
 * RuntimeEventEnvelope (version '1.0' + non-null metadata object).
 *
 * The bus dispatches both envelope-backed events (via publishEnvelope) and
 * plain RuntimeEvents (via emit/emitEvent). Only the former should reach
 * the observability subscribers.
 */
function isRuntimeEventEnvelope(value: unknown): value is RuntimeEventEnvelope<unknown> {
  if (typeof value !== 'object' || value === null) return false
  const env = value as Record<string, unknown>
  if (env.version !== '1.0') return false
  const meta = env.metadata
  if (typeof meta !== 'object' || meta === null) return false
  return true
}

/**
 * Extracts the envelope (if any) from a RuntimeEvent produced by
 * `publishEnvelope()`. Returns undefined for plain RuntimeEvents that
 * don't carry an envelope.
 */
function extractEnvelope(event: RuntimeEvent): RuntimeEventEnvelope<unknown> | undefined {
  const raw = event.data?.envelope
  return isRuntimeEventEnvelope(raw) ? raw : undefined
}

/**
 * Registers a subscriber with the global EventBus. The bridge extracts the
 * envelope from each RuntimeEvent and forwards it to `subscriber.onEvent()`.
 *
 * Best-effort: any error thrown by the subscriber or the bridge is caught
 * and logged. (The bus also catches handler errors, so this is a belt-and-
 * braces guard — the subscriber's own onEvent already wraps in try/catch.)
 */
function registerSubscriber(subscriber: EventSubscriber): void {
  const bus = getGlobalEventBus()
  bus.onAll(async (event) => {
    // Skip until the subscriber is initialized.
    if (!subscriber.isReady()) return
    const envelope = extractEnvelope(event)
    if (!envelope) return
    try {
      await subscriber.onEvent(envelope)
    } catch (err) {
      logger.error(
        {
          subscriber: subscriber.name,
          eventId: envelope.metadata.eventId,
          error: err instanceof Error ? err.message : String(err),
        },
        'observability-singleton: subscriber.onEvent threw (swallowed)',
      )
    }
  })
}

/**
 * Wires the observability stack: creates the singletons, initializes the
 * subscribers, and registers them with the global EventBus. Idempotent —
 * the wiring block runs exactly once per process.
 */
function wireObservability(): void {
  if (observabilityWired) return
  observabilityWired = true

  // 1. Create the singletons (in dependency order).
  auditProvider = new InMemoryAuditProvider()
  metricsRegistry = new MetricsRegistry()
  auditSubscriber = new AuditSubscriber(auditProvider)
  metricsSubscriber = new MetricsSubscriber(metricsRegistry)
  dashboardSubscriber = new DashboardSubscriber()

  // 2. Initialize the subscribers (flips ready flags; no async work).
  //    Use void + Promise.allSettled so a thrown initialize() never blocks
  //    the wiring — best-effort.
  void Promise.allSettled([
    auditSubscriber.initialize(),
    metricsSubscriber.initialize(),
    dashboardSubscriber.initialize(),
  ]).then((results) => {
    for (const r of results) {
      if (r.status === 'rejected') {
        logger.error(
          { error: r.reason instanceof Error ? r.reason.message : String(r.reason) },
          'observability-singleton: subscriber initialize() rejected',
        )
      }
    }
  })

  // 3. Register all three subscribers with the global EventBus via the
  //    envelope-bridge. Each subscriber's onEvent() is itself best-effort.
  registerSubscriber(auditSubscriber)
  registerSubscriber(metricsSubscriber)
  registerSubscriber(dashboardSubscriber)

  logger.info(
    {
      audit: auditSubscriber.name,
      metrics: metricsSubscriber.name,
      dashboard: dashboardSubscriber.name,
    },
    'observability-singleton: wired 3 subscribers to the global EventBus',
  )
}

/**
 * Returns the singleton InMemoryAuditProvider. Triggers wiring on first call.
 */
export function getAuditProvider(): AuditProvider {
  wireObservability()
  // wireObservability() guarantees auditProvider is non-null.
  return auditProvider as InMemoryAuditProvider
}

/**
 * Returns the singleton MetricsRegistry. Triggers wiring on first call.
 */
export function getMetricsRegistry(): MetricsRegistry {
  wireObservability()
  return metricsRegistry as MetricsRegistry
}

/**
 * Returns the singleton MetricsSubscriber. Triggers wiring on first call.
 */
export function getMetricsSubscriber(): MetricsSubscriber {
  wireObservability()
  return metricsSubscriber as MetricsSubscriber
}

/**
 * Returns the singleton DashboardSubscriber. Triggers wiring on first call.
 */
export function getDashboardSubscriber(): DashboardSubscriber {
  wireObservability()
  return dashboardSubscriber as DashboardSubscriber
}

/**
 * Returns the singleton AuditSubscriber (mainly for tests). Triggers wiring
 * on first call.
 *
 * @internal
 */
export function getAuditSubscriber(): AuditSubscriber {
  wireObservability()
  return auditSubscriber as AuditSubscriber
}

/**
 * Resets the observability singletons (for tests). Does NOT touch the
 * global EventBus — callers that want a fully clean state should also call
 * `_resetGlobalBootstrap()` from runtime-service.
 *
 * @internal
 */
export function _resetObservabilitySingleton(): void {
  auditProvider = null
  metricsRegistry = null
  auditSubscriber = null
  metricsSubscriber = null
  dashboardSubscriber = null
  observabilityWired = false
}
