// =============================================================================
// AICF V3 — Business Contracts Barrel (Épica 2 — AI Factory Core)
// =============================================================================
// Re-exports every Business-layer contract + factory so callers can do
//   import { createJobRequest, createBusinessContext, type JobResponse }
//     from '@/lib/runtime/business/contracts'
//
// Type-only exports use `export type`; runtime exports (factories) use
// `export`.
// =============================================================================

export type { JobRequest, JobType } from './JobRequest'
export { createJobRequest } from './JobRequest'

export type { JobResponse, JobStatus, JobArtifact, JobMetrics } from './JobResponse'
export { createJobResponse } from './JobResponse'

export type { BusinessContext } from './BusinessContext'
export { createBusinessContext } from './BusinessContext'

export type { Capability } from './Capability'
export { createCapability } from './Capability'

export type {
  ExecutionResult,
  ExecutionArtifact,
  ExecutionMetrics,
} from './ExecutionResult'
export { createSuccessResult, createFailedResult } from './ExecutionResult'
