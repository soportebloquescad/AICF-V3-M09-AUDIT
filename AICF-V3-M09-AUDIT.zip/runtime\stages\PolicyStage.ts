// =============================================================================
// AICF V3 — Policy Stage (Sprint 21: emits PolicyStarted/PolicyCompleted)
// =============================================================================
// Evaluates the request against Content Intelligence policy rules.
// If policy denies the request, sets response.ok = false.
//
// Sprint 21: when an EventBus is provided (optional 2nd arg), the stage
// emits:
//   - PolicyStarted  (before evaluatePolicy)
//   - PolicyCompleted (after evaluatePolicy, with allowed/reason)
// Emission is best-effort — wrapped in try/catch, never throws, never blocks
// the pipeline.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { ContentIntelligenceModule } from '../contracts/ModuleInterfaces'
import type { RuntimeEventBus } from '../events/RuntimeEventBus'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import { logger } from '@/lib/ai/logger'

/**
 * Best-effort: emits an envelope-wrapped EDA event. Wraps in try/catch so
 * emission failures never propagate to the pipeline.
 */
async function emitBestEffort(
  eventBus: RuntimeEventBus | undefined,
  type: 'PolicyStarted' | 'PolicyCompleted',
  opts: {
    correlationId: string
    requestId: string
    operation: string
    stageOrder: number
    durationMs?: number
    payload: Record<string, unknown>
  },
): Promise<void> {
  if (!eventBus) return
  try {
    const meta = createEventMetadata({
      correlationId: opts.correlationId,
      requestId: opts.requestId,
      operation: opts.operation,
      pipelineStage: 'Policy',
      stageOrder: opts.stageOrder,
      durationMs: opts.durationMs,
    })
    await eventBus.publishEnvelope(createEnvelope(meta, opts.payload), type)
  } catch (err) {
    logger.debug(
      { type, error: err instanceof Error ? err.message : String(err) },
      'Policy stage: event emission failed (best-effort)',
    )
  }
}

/**
 * Creates the Policy stage.
 * @param ciModule - Content Intelligence module (M08). If null, stage is a pass-through.
 * @param eventBus - Optional. When set, emits PolicyStarted/PolicyCompleted events.
 */
export function createPolicyStage(
  ciModule: ContentIntelligenceModule | null,
  eventBus?: RuntimeEventBus,
): PipelineStage {
  return createPipelineStage('Policy', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const requestId = ctx.request.requestId
    const correlationId = ctx.request.correlationId
    const operation = ctx.request.operation

    await emitBestEffort(eventBus, 'PolicyStarted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 4,
      payload: { requestId, operation },
    })

    const started = Date.now()

    if (!ciModule || typeof ciModule.isReady !== 'function' || !ciModule.isReady() || typeof ciModule.evaluatePolicy !== 'function') {
      logger.debug('Policy stage: CI module not ready or incomplete, skipping')

      await emitBestEffort(eventBus, 'PolicyCompleted', {
        correlationId,
        requestId,
        operation,
        stageOrder: 5,
        durationMs: Date.now() - started,
        payload: { requestId, allowed: true, reason: 'ci-module-not-ready' },
      })

      return ctx
    }

    const decision = await ciModule.evaluatePolicy(ctx)

    if (!decision.allowed) {
      const next = cloneRuntimeContext(ctx)
      next.response = {
        ...next.response,
        ok: false,
        error: `Policy denied: ${decision.reason || 'no reason provided'}`,
        errorCode: 'POLICY_DENIED',
      }
      next.errors = [...next.errors, { stage: 'Policy', message: decision.reason || 'denied' }]
      logger.warn(
        { requestId: ctx.request.requestId, violations: decision.violations },
        'Policy: request denied',
      )

      await emitBestEffort(eventBus, 'PolicyCompleted', {
        correlationId,
        requestId,
        operation,
        stageOrder: 5,
        durationMs: Date.now() - started,
        payload: {
          requestId,
          allowed: false,
          reason: decision.reason || 'denied',
        },
      })

      return next
    }

    logger.debug({ requestId: ctx.request.requestId }, 'Policy: request allowed')

    await emitBestEffort(eventBus, 'PolicyCompleted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 5,
      durationMs: Date.now() - started,
      payload: {
        requestId,
        allowed: true,
        reason: decision.reason || 'allowed',
      },
    })

    return ctx
  })
}
