// =============================================================================
// AICF V3 — Premium RC51 — StudentExperience
// =============================================================================
// Adds gamification and personalization to courses.
// =============================================================================

import type { CourseResult } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

export interface StudentExperienceData {
  progress: { totalLessons: number; estimatedHours: number; modules: Array<{ title: string; lessons: number; xp: number }> }
  badges: Badge[]
  xpTotal: number
  achievements: Achievement[]
  streakConfig: { dailyGoal: number; rewardPerDay: number }
  bookmarks: string[]
  notes: string[]
}

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  condition: string
}

export interface Achievement {
  id: string
  name: string
  description: string
  xp: number
}

export class StudentExperience {
  private readonly log = logger.child({ component: 'StudentExperience' })

  generate(course: CourseResult): StudentExperienceData {
    this.log.info({ courseId: course.id }, 'StudentExperience: generating')

    const moduleProgress = course.modules.map((m, i) => ({
      title: m.title,
      lessons: course.lessons.filter(l => l.moduleId === m.id).length,
      xp: 100 * (i + 1),
    }))

    return {
      progress: {
        totalLessons: course.lessons.length,
        estimatedHours: Math.ceil(course.totalWordCount / 200 / 60),
        modules: moduleProgress,
      },
      badges: [
        { id: 'first-lesson', name: 'First Steps', description: 'Complete your first lesson', icon: '🎯', condition: 'Complete 1 lesson' },
        { id: 'module-master', name: 'Module Master', description: 'Complete an entire module', icon: '🏅', condition: 'Complete all lessons in a module' },
        { id: 'quiz-whiz', name: 'Quiz Whiz', description: 'Pass a quiz with 100%', icon: '🧠', condition: 'Score 100% on any quiz' },
        { id: 'course-complete', name: 'Course Champion', description: 'Complete the entire course', icon: '🏆', condition: 'Complete all modules' },
        { id: 'streak-7', name: 'Week Warrior', description: 'Study 7 days in a row', icon: '🔥', condition: '7-day streak' },
        { id: 'exercise-pro', name: 'Exercise Pro', description: 'Complete 10 exercises', icon: '💪', condition: 'Complete 10 exercises' },
      ],
      xpTotal: moduleProgress.reduce((sum, m) => sum + m.xp, 0) + 500,
      achievements: [
        { id: 'ach-1', name: 'Quick Learner', description: 'Complete first module in under 1 hour', xp: 50 },
        { id: 'ach-2', name: 'Deep Diver', description: 'Complete all exercises', xp: 100 },
        { id: 'ach-3', name: 'Perfectionist', description: 'Pass all quizzes on first try', xp: 150 },
        { id: 'ach-4', name: 'Course Graduate', description: 'Complete the entire course', xp: 200 },
      ],
      streakConfig: { dailyGoal: 2, rewardPerDay: 50 },
      bookmarks: [],
      notes: [],
    }
  }
}
