// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Course Template
// =============================================================================
// Template loader for the "course" content category. Wraps the declarative
// `course.workflow.json` definition (authored under the workflow module) as
// an `ITemplate`, providing self-describing metadata, lazy loading from disk
// (with a minimal fallback when the JSON file is missing), and input
// validation for the course-generation surface.
//
// Sprint 13+14 spec requirements covered:
//   - Self-describing `name` / `version` / `description`
//   - `load()` returns a fully-formed `WorkflowDefinition` ready to execute
//   - `validate(inputs)` lets callers check inputs before invoking the engine
//   - Robust disk loading via `fs.readFileSync` with a minimal default
//     workflow fallback (keeps the module bootable in test/CI environments
//     where the JSON file may not yet be present)
// =============================================================================

import { readFileSync } from 'fs'
import { resolve as resolvePath } from 'path'

import type { ITemplate } from '@/lib/runtime/interfaces'
import type {
  WorkflowDefinition,
  WorkflowMetadata,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Relative path to the course workflow JSON definition. */
const TEMPLATE_PATH = resolvePath(
  __dirname,
  '..',
  '..',
  'workflow',
  'templates',
  'course.workflow.json',
)

/**
 * Course workflow template. Loads `course.workflow.json` from the workflow
 * module's templates directory and exposes it via the `ITemplate` contract.
 */
export class CourseTemplate implements ITemplate {
  public readonly name = 'course'
  public readonly version = '1.0.0'
  public readonly description =
    'Generates a complete course with outline, modules, and lessons from a topic.'

  /**
   * Load the course workflow definition. Reads the JSON template from disk;
   * on any read/parse failure, falls back to a minimal but valid default
   * workflow so callers can still proceed (with a logged warning).
   */
  public async load(): Promise<WorkflowDefinition> {
    try {
      const raw = readFileSync(TEMPLATE_PATH, 'utf-8')
      const parsed = JSON.parse(raw) as WorkflowDefinition
      return parsed
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.warn(
        { template: this.name, path: TEMPLATE_PATH, error: message },
        'CourseTemplate: falling back to default workflow',
      )
      return defaultCourseWorkflow()
    }
  }

  /**
   * Validate caller-supplied inputs against the template's required schema.
   * The course template requires a non-empty `topic` string.
   */
  public validate(inputs: Record<string, unknown>): {
    valid: boolean
    errors: string[]
  } {
    const errors: string[] = []
    const topic = inputs['topic']
    if (typeof topic !== 'string' || topic.trim().length === 0) {
      errors.push('input "topic" is required and must be a non-empty string')
    }
    if (
      inputs['modules'] !== undefined &&
      typeof inputs['modules'] !== 'number'
    ) {
      errors.push('input "modules", when provided, must be a number')
    }
    if (
      inputs['level'] !== undefined &&
      inputs['level'] !== 'beginner' &&
      inputs['level'] !== 'intermediate' &&
      inputs['level'] !== 'advanced'
    ) {
      errors.push(
        'input "level", when provided, must be one of beginner|intermediate|advanced',
      )
    }
    return { valid: errors.length === 0, errors }
  }
}

/**
 * Build a minimal but valid `WorkflowDefinition` for the course template.
 * Used only as a fallback when the JSON file cannot be read or parsed.
 */
function defaultCourseWorkflow(): WorkflowDefinition {
  const now = Date.now()
  const metadata: WorkflowMetadata = {
    id: 'course-generation',
    name: 'Course Generation Workflow (fallback)',
    version: '1.0.0',
    description:
      'Minimal fallback course generation workflow (used when JSON template is unavailable).',
    author: 'AICF V3 generation module',
    createdAt: now,
    updatedAt: now,
    tags: ['course', 'education', 'generation', 'fallback'],
    category: 'course',
  }
  const generateStep: WorkflowStepDefinition = {
    id: 'generate-course',
    name: 'Generate Course',
    type: 'generate',
    provider: 'course-generator',
    config: {},
    inputs: { topic: '$.inputs.topic' },
    outputs: { course: 'course' },
    dependsOn: [],
    retries: 1,
    timeout: 120_000,
  }
  return {
    metadata,
    version: '1.0.0',
    inputs: {
      topic: {
        name: 'topic',
        type: 'string',
        required: true,
        description: 'The course topic',
      },
    },
    outputs: {
      course: {
        name: 'course',
        type: 'object',
        description: 'The generated course',
        fromStep: 'generate-course',
      },
    },
    steps: [generateStep],
    checkpoints: [],
    policies: {
      maxRetries: 3,
      timeoutMs: 120_000,
      maxCost: 0.5,
      maxTokens: 50_000,
    },
  }
}
