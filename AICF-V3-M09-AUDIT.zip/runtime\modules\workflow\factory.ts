// =============================================================================
// AICF V3 — Workflow Module Factory (Sprint 13+14)
// =============================================================================
// Wires all Workflow Runtime Module components together via DI.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { IGenerator } from '@/lib/runtime/interfaces'
import { InMemoryEventBus as EventBus } from './events/EventBus'
import { VariableResolver } from './context/VariableResolver'
import { ContextManager } from './context/ContextManager'
import { WorkflowValidator } from './engine/WorkflowValidator'
import { CompensationHandler } from './engine/CompensationHandler'
import { WorkflowOrchestrator } from './engine/WorkflowOrchestrator'
import { WorkflowEngine } from './engine/WorkflowEngine'
import { StepRegistry } from './steps/StepRegistry'
import { StepExecutorService } from './steps/StepExecutor'
import { ChatProvider } from './steps/providers/ChatProvider'
import { GenerationProvider } from './steps/providers/GenerationProvider'
import { ValidationProvider } from './steps/providers/ValidationProvider'
import { TransformationProvider } from './steps/providers/TransformationProvider'
import { ConditionalProvider } from './steps/providers/ConditionalProvider'
import { InMemoryWorkflowStateStore } from './state/WorkflowStateStore'
import { ExecutionCheckpointManager } from './state/ExecutionCheckpoint'
import { RuntimeRecovery } from './recovery/RuntimeRecovery'
import { TraceStorage } from './trace/TraceStorage'
import { InMemoryArtifactStorage } from './artifacts/ArtifactStorage'
import { ArtifactRegistry } from './artifacts/ArtifactRegistry'
import { MetricsCollector } from './metrics/MetricsCollector'
import { RuntimeHealth } from './health/RuntimeHealth'
import { ExecutionCache } from './cache/ExecutionCache'
import { PromptCache } from './cache/PromptCache'
import { EmbeddingCache } from './cache/EmbeddingCache'
import { SecretsResolver } from './secrets/SecretsResolver'
import { PolicyMiddleware } from './policies/PolicyMiddleware'
import { HookRegistry } from './hooks/BeforeStepHook'
import { CapabilityRegistry } from './registry/CapabilityRegistry'
import { ExecutionPolicy } from './governance/ExecutionPolicy'
import { ApprovalPolicy } from './governance/ApprovalPolicy'
import { QuotaPolicy } from './governance/QuotaPolicy'
import { BudgetPolicy } from './governance/BudgetPolicy'
import { SecurityPolicy } from './governance/SecurityPolicy'
import { FeatureFlags } from './features/FeatureFlags'
import { ExecutionQueue } from './queue/ExecutionQueue'
import { Scheduler } from './queue/Scheduler'
import { WorkflowModule } from './WorkflowModule'
import { logger } from '@/lib/ai/logger'

/**
 * Dependencies for creating a Workflow Module.
 */
export interface CreateWorkflowModuleDeps {
  /** AI adapter (for the ChatProvider). Required. */
  aiAdapter: AIAdapter

  /** Optional generator (for the GenerationProvider). */
  generator?: IGenerator

  /** Optional pre-built event bus (auto-created if missing). */
  eventBus?: EventBus

  /** Optional pre-built state store (auto-created if missing). */
  stateStore?: InMemoryWorkflowStateStore

  /** Optional pre-built artifact storage (auto-created if missing). */
  artifactStorage?: InMemoryArtifactStorage

  /** Optional feature flags (auto-created if missing). */
  featureFlags?: FeatureFlags

  /** Optional external health checks (e.g., LiteLLM, n8n, Docker, DB). */
  externalHealthChecks?: Record<string, () => Promise<{ healthy: boolean; latencyMs?: number; details?: Record<string, unknown>; error?: string }>>
}

/**
 * The fully-wired Workflow Module bundle.
 */
export interface CreatedWorkflowModule {
  module: WorkflowModule
  engine: WorkflowEngine
  orchestrator: WorkflowOrchestrator
  eventBus: EventBus
  stepRegistry: StepRegistry
  stepExecutor: StepExecutorService
  validator: WorkflowValidator
  compensationHandler: CompensationHandler
  contextManager: ContextManager
  variableResolver: VariableResolver
  stateStore: InMemoryWorkflowStateStore
  checkpointManager: ExecutionCheckpointManager
  recovery: RuntimeRecovery
  traceStorage: TraceStorage
  artifactStorage: InMemoryArtifactStorage
  artifactRegistry: ArtifactRegistry
  metricsCollector: MetricsCollector
  runtimeHealth: RuntimeHealth
  executionCache: ExecutionCache
  promptCache: PromptCache
  embeddingCache: EmbeddingCache
  secretsResolver: SecretsResolver
  policyMiddleware: PolicyMiddleware
  hookRegistry: HookRegistry
  capabilityRegistry: CapabilityRegistry
  featureFlags: FeatureFlags
  executionQueue: ExecutionQueue
  scheduler: Scheduler
  providers: {
    chat: ChatProvider
    generation: GenerationProvider
    validation: ValidationProvider
    transformation: TransformationProvider
    conditional: ConditionalProvider
  }
}

/**
 * Creates a fully-wired Workflow Module with all components.
 * Every component is constructed here (no `new` inside the modules themselves).
 */
export function createWorkflowModule(deps: CreateWorkflowModuleDeps): CreatedWorkflowModule {
  const eventBus = deps.eventBus || new EventBus()
  const stateStore = deps.stateStore || new InMemoryWorkflowStateStore()
  const artifactStorage = deps.artifactStorage || new InMemoryArtifactStorage()
  const featureFlags = deps.featureFlags || new FeatureFlags()

  // Context
  const variableResolver = new VariableResolver()
  const contextManager = new ContextManager()

  // Trace
  const traceStorage = new TraceStorage(10000, eventBus)

  // Artifacts
  const artifactRegistry = new ArtifactRegistry(artifactStorage)

  // Metrics
  const metricsCollector = new MetricsCollector(eventBus)

  // Cache
  const executionCache = new ExecutionCache({ defaultTtlMs: 60000 })
  const promptCache = new PromptCache()
  const embeddingCache = new EmbeddingCache()

  // Secrets
  const secretsResolver = new SecretsResolver()

  // Hooks
  const hookRegistry = new HookRegistry()

  // Policies
  const policies = [
    new ExecutionPolicy(),
    new ApprovalPolicy(),
    new QuotaPolicy(50000, 0.50),
    new BudgetPolicy(100, metricsCollector),
    new SecurityPolicy(),
  ]
  const policyMiddleware = new PolicyMiddleware(policies)

  // Capability registry
  const capabilityRegistry = new CapabilityRegistry()

  // Step providers
  const chatProvider = new ChatProvider(deps.aiAdapter)
  const generationProvider = deps.generator
    ? new GenerationProvider(deps.generator)
    : new GenerationProvider({} as IGenerator) // no-op generator if not provided
  const validationProvider = new ValidationProvider()
  const transformationProvider = new TransformationProvider()
  const conditionalProvider = new ConditionalProvider()

  // Register providers in capability registry
  capabilityRegistry.registerProvider(chatProvider)
  capabilityRegistry.registerProvider(generationProvider)
  capabilityRegistry.registerProvider(validationProvider)
  capabilityRegistry.registerProvider(transformationProvider)
  capabilityRegistry.registerProvider(conditionalProvider)

  // Step registry
  const stepRegistry = new StepRegistry()

  // Step executor
  const stepExecutor = new StepExecutorService(stepRegistry, eventBus, variableResolver)

  // Validator (with registered provider names)
  const registeredProviderNames = new Set<string>(['chat', 'generate', 'validate', 'transform', 'conditional'])
  const validator = new WorkflowValidator(registeredProviderNames)

  // Compensation handler
  const compensationHandler = new CompensationHandler(eventBus, stepExecutor as unknown as import('@/lib/runtime/interfaces').IStepExecutor)

  // Orchestrator
  const orchestrator = new WorkflowOrchestrator(
    stepExecutor,
    eventBus,
    validator,
    compensationHandler,
    contextManager,
    artifactStorage,
    stateStore,
  )

  // Engine
  const engine = new WorkflowEngine(orchestrator, stateStore)

  // Checkpoint manager
  const checkpointManager = new ExecutionCheckpointManager(stateStore)

  // Recovery
  const recovery = new RuntimeRecovery(stateStore, engine, eventBus)

  // Health
  const runtimeHealth = new RuntimeHealth(metricsCollector, undefined, (deps.externalHealthChecks || {}) as unknown as Record<string, () => Promise<import("./health/RuntimeHealth").HealthCheck>>)

  // Queue
  const executionQueue = new ExecutionQueue(stateStore, { maxConcurrency: 1 })

  // Scheduler (empty but ready)
  const scheduler = new Scheduler()

  // Module
  const workflowModule = new WorkflowModule(engine)

  logger.info(
    {
      providers: capabilityRegistry.listCapabilities(),
      features: featureFlags.list(),
    },
    'WorkflowModule: created with all components wired',
  )

  return {
    module: workflowModule,
    engine,
    orchestrator,
    eventBus,
    stepRegistry,
    stepExecutor,
    validator,
    compensationHandler,
    contextManager,
    variableResolver,
    stateStore,
    checkpointManager,
    recovery,
    traceStorage,
    artifactStorage,
    artifactRegistry,
    metricsCollector,
    runtimeHealth,
    executionCache,
    promptCache,
    embeddingCache,
    secretsResolver,
    policyMiddleware,
    hookRegistry,
    capabilityRegistry,
    featureFlags,
    executionQueue,
    scheduler,
    providers: {
      chat: chatProvider,
      generation: generationProvider,
      validation: validationProvider,
      transformation: transformationProvider,
      conditional: conditionalProvider,
    },
  }
}
