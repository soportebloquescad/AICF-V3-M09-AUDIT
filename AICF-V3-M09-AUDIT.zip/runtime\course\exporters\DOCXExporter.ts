// =============================================================================
// AICF V3 — DOCX Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a DOCX-compatible HTML document. Microsoft
// Word can open HTML files that carry the Office XML namespaces and Word-
// specific CSS hints, and will then save the result as a real .docx file.
//
// The output is a complete HTML document that includes:
//   - The Office namespaces on the <html> root
//     (xmlns:o="urn:schemas-microsoft-com:office:office", plus w and m)
//   - Word-specific <meta> tags (ProgId, WordDocument, etc.)
//   - An embedded Word-compatible style sheet (mso-* styles, page size,
//     margins, font defaults)
//   - A Word section break with page size + margin declarations
//
// The exporter NEVER generates or modifies content — it only re-formats the
// supplied Markdown into the HTML vocabulary Word understands. Metadata is
// projected into document properties and the visible header.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { escapeHtml, markdownToHtml } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by DOCXExporter.export(). */
export type DocxExportMetadata = Record<string, unknown>

/** Page size preset (all dimensions in points; 1 inch = 72 pt). */
export interface DocxPageSetup {
  /** Page width in points. */
  width: number
  /** Page height in points. */
  height: number
  /** Top margin in points. */
  marginTop: number
  /** Bottom margin in points. */
  marginBottom: number
  /** Left margin in points. */
  marginLeft: number
  /** Right margin in points. */
  marginRight: number
}

const DEFAULT_PAGE: DocxPageSetup = {
  width: 612, // 8.5 in
  height: 792, // 11 in
  marginTop: 72,
  marginBottom: 72,
  marginLeft: 90,
  marginRight: 90,
}

/**
 * DOCXExporter — transforms Markdown to a Word-compatible HTML document.
 */
export class DOCXExporter {
  /**
   * Transform `content` (Markdown) into a Word-compatible HTML string.
   *
   * @param content  Markdown source text.
   * @param metadata Optional metadata: { title, author, description, language, subject, ... }.
   * @returns A complete HTML document carrying Office namespaces.
   */
  export(content: string, metadata?: DocxExportMetadata): string {
    const meta = metadata ?? {}
    const title = asString(meta.title, asString(meta.topic, 'Exported Document'))
    const author = asString(meta.author, '')
    const description = asString(meta.description, '')
    const subject = asString(meta.subject, '')
    const language = asString(meta.language, 'en').toLowerCase()
    const generator = asString(meta.generator, 'AICF V3 DOCXExporter')
    const page = this.resolvePageSetup(meta.pageSetup)

    const bodyHtml = markdownToHtml(content ?? '')
    const css = this.buildCss(page)
    const headerBlock = this.buildDocumentHeader(title, author, description, meta)

    return [
      '<!DOCTYPE html>',
      '<html xmlns:o="urn:schemas-microsoft-com:office:office"',
      '      xmlns:w="urn:schemas-microsoft-com:office:word"',
      '      xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"',
      '      xmlns="http://www.w3.org/TR/REC-html40">',
      '<head>',
      '  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />',
      '  <meta name="ProgId" content="Word.Document" />',
      '  <meta name="Generator" content="' + escapeHtml(generator) + '" />',
      '  <meta name="Originator" content="Microsoft Word 15" />',
      '  <meta name="Microsoft Office Theme" content="Office" />',
      '  <!--[if gte mso 9]>',
      '  <xml>',
      '    <w:WordDocument>',
      '      <w:View>Print</w:View>',
      '      <w:Zoom>100</w:Zoom>',
      '      <w:DoNotOptimizeForBrowser/>',
      '    </w:WordDocument>',
      '  </xml>',
      '  <![endif]-->',
      `  <title>${escapeHtml(title)}</title>`,
      this.buildDocumentProperties(title, author, description, subject, generator),
      '  <style>',
      css,
      '  </style>',
      '</head>',
      `<body lang="${escapeHtml(language)}" xml:lang="${escapeHtml(language)}">`,
      `  <div class="WordSection1" style="page-size: ${page.width}pt ${page.height}pt;`,
      `       margin-top: ${page.marginTop}pt; margin-right: ${page.marginRight}pt;`,
      `       margin-bottom: ${page.marginBottom}pt; margin-left: ${page.marginLeft}pt;`,
      '       mso-page-orientation: portrait;">',
      headerBlock,
      '    <div class="content">',
      bodyHtml,
      '    </div>',
      '  </div>',
      '</body>',
      '</html>',
      '',
    ].join('\n')
  }

  // -------------------------------------------------------------------------
  // Internal helpers
  // -------------------------------------------------------------------------

  private resolvePageSetup(raw: unknown): DocxPageSetup {
    if (!raw || typeof raw !== 'object') return DEFAULT_PAGE
    const obj = raw as Record<string, unknown>
    const merge = (key: keyof DocxPageSetup, fallback: number): number => {
      const v = obj[key]
      const n = typeof v === 'number' ? v : Number(v)
      return Number.isFinite(n) && n > 0 ? n : fallback
    }
    return {
      width: merge('width', DEFAULT_PAGE.width),
      height: merge('height', DEFAULT_PAGE.height),
      marginTop: merge('marginTop', DEFAULT_PAGE.marginTop),
      marginBottom: merge('marginBottom', DEFAULT_PAGE.marginBottom),
      marginLeft: merge('marginLeft', DEFAULT_PAGE.marginLeft),
      marginRight: merge('marginRight', DEFAULT_PAGE.marginRight),
    }
  }

  private buildDocumentProperties(
    title: string,
    author: string,
    description: string,
    subject: string,
    generator: string,
  ): string {
    const lines: string[] = []
    lines.push('  <!--[if gte mso 9]>')
    lines.push('  <xml>')
    lines.push('    <o:DocumentProperties>')
    lines.push('      <o:Title>' + escapeHtml(title) + '</o:Title>')
    if (author) {
      lines.push('      <o:Author>' + escapeHtml(author) + '</o:Author>')
      lines.push('      <o:LastAuthor>' + escapeHtml(author) + '</o:LastAuthor>')
    }
    if (subject) {
      lines.push('      <o:Subject>' + escapeHtml(subject) + '</o:Subject>')
    }
    if (description) {
      lines.push('      <o:Description>' + escapeHtml(description) + '</o:Description>')
    }
    lines.push('      <o:Creator>' + escapeHtml(generator) + '</o:Creator>')
    lines.push('      <o:Created>' + new Date().toISOString() + '</o:Created>')
    lines.push('    </o:DocumentProperties>')
    lines.push('  </xml>')
    lines.push('  <![endif]-->')
    return lines.join('\n')
  }

  private buildDocumentHeader(
    title: string,
    author: string,
    description: string,
    meta: DocxExportMetadata,
  ): string {
    const lines: string[] = []
    lines.push('    <p class="MsoTitle" style="text-align: left;">')
    lines.push('      <span style="font-size: 28pt; font-weight: bold; color: #1e3a8a;">' + escapeHtml(title) + '</span>')
    lines.push('    </p>')
    if (author) {
      lines.push('    <p class="MsoSubtitle" style="margin: 0 0 4pt 0;">')
      lines.push('      <span style="font-size: 11pt; color: #475569;">By ' + escapeHtml(author) + '</span>')
      lines.push('    </p>')
    }
    if (description) {
      lines.push('    <p class="MsoNormal" style="margin: 0 0 12pt 0; font-style: italic; color: #475569;">')
      lines.push('      ' + escapeHtml(description))
      lines.push('    </p>')
    }
    // Optional extra metadata rendered as a small table
    const knownKeys = new Set([
      'title', 'author', 'description', 'language', 'generator', 'topic',
      'subject', 'pageSetup',
    ])
    const extraEntries = Object.entries(meta).filter(([k]) => !knownKeys.has(k))
    if (extraEntries.length > 0) {
      lines.push('    <table class="MsoNormal" style="border-collapse: collapse; margin-bottom: 12pt; font-size: 10pt;">')
      for (const [k, v] of extraEntries) {
        const value = typeof v === 'string' ? v : safeStringify(v)
        lines.push('      <tr>')
        lines.push('        <td style="border: 1pt solid #cbd5e1; padding: 4pt 8pt; background: #f1f5f9; font-weight: bold; color: #475569;">' + escapeHtml(k) + '</td>')
        lines.push('        <td style="border: 1pt solid #cbd5e1; padding: 4pt 8pt;">' + escapeHtml(value) + '</td>')
        lines.push('      </tr>')
      }
      lines.push('    </table>')
    }
    // Horizontal rule separator
    lines.push('    <p class="MsoNormal" style="border-top: 1pt solid #cbd5e1; margin: 0 0 12pt 0; font-size: 1pt;">&nbsp;</p>')
    return lines.join('\n')
  }

  private buildCss(page: DocxPageSetup): string {
    return [
      '    /* Word document defaults */',
      '    @page WordSection1 {',
      `      size: ${page.width}pt ${page.height}pt;`,
      `      margin: ${page.marginTop}pt ${page.marginRight}pt ${page.marginBottom}pt ${page.marginLeft}pt;`,
      '      mso-page-orientation: portrait;',
      '    }',
      '    div.WordSection1 { page: WordSection1; }',
      '    p.MsoNormal, li.MsoNormal, div.MsoNormal {',
      '      margin: 0 0 8pt 0;',
      '      mso-pagination: widow-orphan;',
      "      font-family: 'Calibri', 'Arial', sans-serif;",
      '      font-size: 11pt;',
      '      color: #0f172a;',
      '    }',
      '    p.MsoTitle {',
      '      margin: 0 0 12pt 0;',
      "      font-family: 'Calibri Light', 'Calibri', sans-serif;",
      '      font-size: 28pt;',
      '      color: #1e3a8a;',
      '      font-weight: bold;',
      '    }',
      '    h1, h2, h3, h4, h5, h6 {',
      '      mso-pagination: widow-orphan;',
      "      font-family: 'Calibri Light', 'Calibri', sans-serif;",
      '      color: #1e3a8a;',
      '      page-break-after: avoid;',
      '    }',
      '    h1 { font-size: 20pt; margin: 18pt 0 6pt 0; font-weight: bold; }',
      '    h2 { font-size: 16pt; margin: 14pt 0 6pt 0; font-weight: bold; }',
      '    h3 { font-size: 14pt; margin: 12pt 0 4pt 0; font-weight: bold; }',
      '    h4 { font-size: 12pt; margin: 10pt 0 4pt 0; font-weight: bold; }',
      '    h5, h6 { font-size: 11pt; margin: 8pt 0 4pt 0; font-weight: bold; }',
      '    a { color: #2563eb; text-decoration: underline; }',
      '    ul, ol { margin: 0 0 8pt 0; mso-pagination: widow-orphan; }',
      '    li { margin: 2pt 0; }',
      '    pre {',
      "      font-family: 'Consolas', 'Courier New', monospace;",
      '      font-size: 10pt;',
      '      background: #f1f5f9;',
      '      border: 1pt solid #cbd5e1;',
      '      padding: 8pt;',
      '      white-space: pre-wrap;',
      '      mso-pagination: widow-orphan;',
      '    }',
      '    code {',
      "      font-family: 'Consolas', 'Courier New', monospace;",
      '      font-size: 10pt;',
      '    }',
      '    p :not(pre) > code {',
      '      background: #f1f5f9;',
      '      padding: 1pt 3pt;',
      '    }',
      '    blockquote {',
      '      margin: 8pt 0;',
      '      padding: 4pt 12pt;',
      '      border-left: 3pt solid #2563eb;',
      '      color: #475569;',
      '      font-style: italic;',
      '    }',
      '    hr {',
      '      border: none;',
      '      border-top: 1pt solid #cbd5e1;',
      '      margin: 12pt 0;',
      '    }',
      '    table { border-collapse: collapse; }',
      '    th, td {',
      '      border: 1pt solid #cbd5e1;',
      '      padding: 4pt 8pt;',
      '    }',
      '    th { background: #f1f5f9; font-weight: bold; }',
    ].join('\n')
  }
}

// -------------------------------------------------------------------------
// Small input-narrowing helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function safeStringify(value: unknown): string {
  if (value === null) return 'null'
  if (value === undefined) return 'undefined'
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return String(value)
  }
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}
