// =============================================================================
// AICF V3 — Provider Registry (Sprint 16: Multi Provider)
// =============================================================================
// Registry for AI providers. Only 'litellm' is active by default, but the
// structure supports openai, openrouter, groq, gemini, ollama, claude,
// azure, and custom providers without modifying the Runtime.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import { logger } from '@/lib/ai/logger'

/**
 * A provider adapter — wraps an AIAdapter with a provider name.
 */
export interface ProviderAdapter {
  /** Provider name (e.g., 'litellm', 'openai'). */
  readonly name: string

  /** The AI adapter instance. */
  readonly adapter: AIAdapter

  /** Whether this provider is available. */
  isAvailable(): boolean
}

/**
 * Configuration for the ProviderRegistry.
 */
export interface ProviderRegistryConfig {
  /** The active provider (default: 'litellm'). */
  active: string

  /** Fallback providers (tried in order if the active provider fails). */
  fallback: string[]
}

/**
 * Registry for AI providers.
 * Supports multiple providers with an active provider + fallback chain.
 *
 * Sprint 16: only 'litellm' is active. The structure allows switching to
 * any other provider by changing the `active` config — no code changes.
 */
export class ProviderRegistry {
  private readonly providers = new Map<string, ProviderAdapter>()
  private activeProvider: string
  private fallbackChain: string[]

  constructor(config: ProviderRegistryConfig = { active: 'litellm', fallback: [] }) {
    this.activeProvider = config.active
    this.fallbackChain = [...config.fallback]
  }

  /**
   * Registers a provider.
   */
  register(adapter: ProviderAdapter): void {
    this.providers.set(adapter.name, adapter)
    logger.info({ provider: adapter.name }, 'ProviderRegistry: provider registered')
  }

  /**
   * Unregisters a provider.
   */
  unregister(name: string): void {
    this.providers.delete(name)
    if (this.activeProvider === name) {
      this.activeProvider = this.fallbackChain[0] || 'litellm'
    }
  }

  /**
   * Gets a provider by name.
   */
  get(name: string): ProviderAdapter | null {
    return this.providers.get(name) || null
  }

  /**
   * Gets the active provider.
   */
  getActive(): ProviderAdapter | null {
    return this.providers.get(this.activeProvider) || null
  }

  /**
   * Sets the active provider.
   */
  setActive(name: string): void {
    if (!this.providers.has(name)) {
      throw new Error(`ProviderRegistry: provider '${name}' is not registered`)
    }
    this.activeProvider = name
    logger.info({ active: name }, 'ProviderRegistry: active provider changed')
  }

  /**
   * Gets the fallback chain.
   */
  getFallback(): string[] {
    return [...this.fallbackChain]
  }

  /**
   * Sets the fallback chain.
   */
  setFallback(providers: string[]): void {
    this.fallbackChain = [...providers]
  }

  /**
   * Returns all registered provider names.
   */
  list(): string[] {
    return Array.from(this.providers.keys())
  }

  /**
   * Returns the active provider name.
   */
  getActiveName(): string {
    return this.activeProvider
  }

  /**
   * Returns a serializable snapshot (for the API).
   */
  snapshot(): {
    providers: Array<{ name: string; available: boolean }>
    active: string
    fallback: string[]
  } {
    return {
      providers: Array.from(this.providers.entries()).map(([name, adapter]) => ({
        name,
        available: adapter.isAvailable(),
      })),
      active: this.activeProvider,
      fallback: [...this.fallbackChain],
    }
  }
}

/**
 * Default provider names supported by the registry.
 */
export const SUPPORTED_PROVIDERS = [
  'litellm',
  'openai',
  'openrouter',
  'groq',
  'gemini',
  'ollama',
  'claude',
  'azure',
  'custom',
] as const
