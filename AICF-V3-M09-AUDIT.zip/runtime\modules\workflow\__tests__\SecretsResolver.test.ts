// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — SecretsResolver Tests
// =============================================================================
// Tests for SecretsResolver. Verifies env source resolution, plain-value
// passthrough, has() safety, registerSource() for new backends, throws on
// unknown sources, and listSources() diagnostics.
// =============================================================================
import { describe, it, expect, beforeEach, afterEach } from 'bun:test'
import { SecretsResolver } from '../secrets/SecretsResolver'

describe('SecretsResolver', () => {
  let resolver: SecretsResolver
  const originalEnv = { ...process.env }

  beforeEach(() => {
    resolver = new SecretsResolver()
    process.env = { ...originalEnv }
  })

  afterEach(() => {
    // Restore env to avoid leaking state between test files.
    process.env = originalEnv
  })

  it('resolve ${env:KEY} from process.env', async () => {
    process.env['AICF_TEST_KEY'] = 'secret-value-123'
    const value = await resolver.resolve('${env:AICF_TEST_KEY}')
    expect(value).toBe('secret-value-123')
  })

  it('resolve plain values (no ${} prefix) unchanged', async () => {
    expect(await resolver.resolve('hello-world')).toBe('hello-world')
    expect(await resolver.resolve('sk-abc123xyz')).toBe('sk-abc123xyz')
  })

  it('has() returns true for existing keys, false for missing', async () => {
    process.env['AICF_HAS_KEY'] = 'present'
    expect(await resolver.has('${env:AICF_HAS_KEY}')).toBe(true)
    expect(await resolver.has('${env:AICF_DEFINITELY_MISSING}')).toBe(false)
    // Plain values are always considered resolvable.
    expect(await resolver.has('plaintext')).toBe(true)
  })

  it('registerSource adds a new source', async () => {
    const store = new Map<string, string>([['vault-key', 'vault-secret']])
    resolver.registerSource('vault', async (key) => store.get(key) ?? null)
    expect(await resolver.resolve('${vault:vault-key}')).toBe('vault-secret')
    // The 'env' default source is still registered.
    expect(resolver.listSources()).toContain('env')
    expect(resolver.listSources()).toContain('vault')
  })

  it('resolve throws for unknown source', async () => {
    await expect(resolver.resolve('${unknown:key}')).rejects.toThrow(
      /unknown secret source/,
    )
  })

  it('resolve throws when env key is missing', async () => {
    await expect(
      resolver.resolve('${env:AICF_DEFINITELY_MISSING_KEY_XYZ}'),
    ).rejects.toThrow(/secret not found/)
  })

  it('listSources returns registered sources', () => {
    const sources = resolver.listSources()
    expect(sources).toContain('env')
    expect(sources.length).toBeGreaterThanOrEqual(1)
    // After registering a new source, it should appear.
    resolver.registerSource('docker-secrets', async () => null)
    const updated = resolver.listSources()
    expect(updated).toContain('docker-secrets')
  })
})
