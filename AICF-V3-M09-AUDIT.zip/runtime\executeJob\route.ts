// =============================================================================
// AICF V3 — POST /api/runtime/executeJob (Épica 3 — Educational Factory)
// =============================================================================
// Executes a Business-layer JobRequest through the RuntimeService.
//
// Body shape:
//   {
//     jobType: string,                      // e.g. 'generateCourse'
//     input: Record<string, unknown>,       // topic, level, modules, etc.
//     metadata?: {
//       correlationId?: string,
//       requestId?: string,
//       userId?: string,
//       workspaceId?: string,
//       projectId?: string,
//       locale?: string,
//       priority?: number,
//     },
//   }
//
// Returns a JobResponse:
//   {
//     jobId: string,
//     status: 'completed' | 'failed',
//     output?: Record<string, unknown>,
//     error?: string,
//     startedAt: string,
//     completedAt: string,
//     durationMs: number,
//     artifacts?: JobArtifact[],
//     metrics?: JobMetrics,
//   }
//
// The endpoint uses the shared RuntimeSingleton — the four Educational
// Factory modules (Course, Presentation, Quiz, Document) are registered
// there at boot. 30s timeout on every job.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getRuntimeService, getRuntimeInitError } from '@/lib/runtime/runtime-singleton'
import { createJobRequest } from '@/lib/runtime/business/contracts/JobRequest'
import { RuntimeError } from '@/lib/runtime/errors/RuntimeError'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

const executeJobSchema = z.object({
  jobType: z.string().min(1),
  input: z.record(z.string(), z.unknown()).optional(),
  metadata: z
    .object({
      correlationId: z.string().optional(),
      requestId: z.string().optional(),
      userId: z.string().optional(),
      workspaceId: z.string().optional(),
      projectId: z.string().optional(),
      locale: z.string().optional(),
      priority: z.number().optional(),
    })
    .optional(),
})

export async function POST(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/api/runtime/executeJob', method: 'POST' })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const parsed = executeJobSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten() },
      { status: 422 },
    )
  }

  try {
    const service = await getRuntimeService()

    if (!service) {
      const initError = getRuntimeInitError()
      return NextResponse.json(
        {
          error: 'Runtime not available',
          code: 'RUNTIME_INIT_FAILED',
          details: initError ? { initError } : undefined,
        },
        { status: 503 },
      )
    }

    const jobRequest = createJobRequest(
      // The JobType union is narrower than string — cast through `unknown`
      // to accept the user-supplied value while still passing strict TS.
      parsed.data.jobType as unknown as Parameters<typeof createJobRequest>[0],
      parsed.data.input ?? {},
      parsed.data.metadata,
    )

    // 30s timeout on the job
    const timeoutMs = 30_000
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(
        () => reject(new RuntimeError('Job execution timed out', 'TIMEOUT', undefined, 504)),
        timeoutMs,
      )
    })

    const response = await Promise.race([service.executeJob(jobRequest), timeoutPromise])

    reqLogger.info(
      {
        jobId: response.jobId,
        jobType: parsed.data.jobType,
        status: response.status,
        durationMs: response.durationMs,
      },
      'executeJob completed',
    )

    return NextResponse.json(response, { status: response.status === 'failed' ? 500 : 200 })
  } catch (err) {
    if (err instanceof RuntimeError) {
      reqLogger.warn(
        { code: err.code, module: err.module, message: err.message },
        'executeJob failed (RuntimeError)',
      )
      return NextResponse.json(
        { error: err.message, code: err.code, module: err.module },
        { status: err.statusCode },
      )
    }

    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'executeJob failed (unexpected)',
    )
    return NextResponse.json(
      { error: 'Job execution failed', message: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    )
  }
}

/**
 * GET — returns the list of job types the Educational Factory can execute
 * (useful for discovery + dashboard rendering).
 */
export async function GET() {
  try {
    const service = await getRuntimeService()
    if (!service) {
      return NextResponse.json(
        { error: 'Runtime not available', code: 'RUNTIME_INIT_FAILED' },
        { status: 503 },
      )
    }
    const registry = service.getBusinessModuleRegistry()
    const capabilities = registry.listCapabilities()
    const modules = registry.list().map((m) => ({
      id: m.name,
      version: m.version,
      capabilities: m.getCapabilities().map((c) => c.name),
    }))
    return NextResponse.json({ capabilities, modules })
  } catch (err) {
    return NextResponse.json(
      { error: 'Discovery failed', message: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    )
  }
}
