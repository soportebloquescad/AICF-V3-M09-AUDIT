// =============================================================================
// AICF V3 — Epica 8 — Exercise Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Exercise, Lesson, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class ExerciseBuilder implements EngineContract {
  readonly name = 'exercise-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('ExerciseBuilder: invalid input — expected Lesson[]')
    }
    const lessons = input as Lesson[]
    const exercises: Exercise[] = []
    for (const lesson of lessons) {
      if (this.opts.aiAdapter) {
        try {
          exercises.push(await this.buildWithAI(lesson))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'ExerciseBuilder: AI failed, using fallback')
        }
      }
      exercises.push(this.buildDeterministic(lesson))
    }
    return exercises
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(lesson: Lesson): Promise<Exercise> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are an exercise designer. Create a practical exercise with question, context, expected answer, hints (string[]), and rubricCriteria (string[]). Respond as JSON.',
        },
        {
          role: 'user',
          content: `Lesson: ${lesson.title}\nModule: ${lesson.moduleTitle}\nObjectives: ${lesson.learningObjectives.join('; ')}\nBloom: ${lesson.bloomLevel}\n\nCreate a ${lesson.bloomLevel === 'Remember' ? 'quiz' : 'practice'} exercise at ${lesson.bloomLevel === 'Remember' ? 'easy' : 'medium'} difficulty. Return JSON: { "question": string, "context": string, "expectedAnswer": string, "hints": string[], "rubricCriteria": string[] }`,
        },
      ],
      temperature: 0.5,
      maxTokens: 2048,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { question?: string; context?: string; expectedAnswer?: string; hints?: string[]; rubricCriteria?: string[] }
    return this.assembleExercise(
      lesson,
      {
        question: parsed.question ?? `Apply the concepts from "${lesson.title}".`,
        context: parsed.context ?? `Based on the lesson "${lesson.title}".`,
        expectedAnswer: parsed.expectedAnswer ?? `A complete answer demonstrating understanding of ${lesson.title}.`,
        hints: parsed.hints ?? [],
        rubricCriteria: parsed.rubricCriteria ?? ['Accuracy', 'Depth', 'Clarity'],
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(lesson: Lesson): Exercise {
    const difficulty: Exercise['difficulty'] = lesson.bloomLevel === 'Remember' ? 'easy' : lesson.bloomLevel === 'Create' ? 'hard' : 'medium'
    const type: Exercise['type'] = lesson.bloomLevel === 'Remember' ? 'quiz' : lesson.bloomLevel === 'Apply' ? 'practice' : 'writing'
    const parsed = {
      question: `Based on the lesson "${lesson.title}", ${lesson.bloomLevel === 'Remember' ? 'list and define the key concepts covered' : lesson.bloomLevel === 'Apply' ? `apply the key concepts to a real scenario related to ${lesson.moduleTitle}` : `analyze how the concepts from "${lesson.title}" relate to broader themes in ${lesson.moduleTitle}`}. Provide a structured response that demonstrates your understanding.`,
      context: `You have just completed the lesson "${lesson.title}" which covers ${lesson.keyTakeaways.join(', ')}. The lesson targets Bloom's ${lesson.bloomLevel} level. Use the content and examples from the lesson to inform your answer.`,
      expectedAnswer: `A strong answer should: (1) demonstrate clear understanding of the key concepts from "${lesson.title}"; (2) ${lesson.bloomLevel === 'Remember' ? 'accurately recall definitions and relationships' : lesson.bloomLevel === 'Apply' ? 'apply concepts to a concrete, realistic scenario with specific details' : 'provide thoughtful analysis with supporting evidence'}; (3) organize the response logically with clear structure; (4) connect the lesson material to the broader context of ${lesson.moduleTitle}.`,
      hints: [
        `Review the learning objectives: ${lesson.learningObjectives.join('; ')}`,
        `Consider the key takeaways: ${lesson.keyTakeaways.join('; ')}`,
        `Structure your answer with an introduction, body, and conclusion`,
        `Use specific examples to illustrate your points`,
      ],
      rubricCriteria: [
        'Accuracy of concept recall and application',
        'Depth of understanding demonstrated',
        'Clarity and organization of response',
        'Use of specific examples and evidence',
        'Connection to broader module themes',
      ],
    }
    return this.assembleExercise(lesson, parsed, 'runtime-adapter', 'deterministic-fallback', type, difficulty)
  }

  private assembleExercise(
    lesson: Lesson,
    parsed: { question: string; context: string; expectedAnswer: string; hints: string[]; rubricCriteria: string[] },
    provider: Provider,
    model: string,
    type: Exercise['type'] = 'practice',
    difficulty: Exercise['difficulty'] = 'medium',
  ): Exercise {
    const now = new Date().toISOString()
    return {
      id: makeId('ex'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      type,
      difficulty,
      question: parsed.question,
      context: parsed.context,
      expectedAnswer: parsed.expectedAnswer,
      hints: parsed.hints,
      rubricCriteria: parsed.rubricCriteria,
    }
  }
}
