// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Execution Queue (with persistence)
// =============================================================================
// Array-backed FIFO queue of `WorkflowExecution` envelopes with optional
// persistence to an `IWorkflowStateStore`. The queue is the coordination
// point between the workflow engine (producer) and the worker pool
// (consumer); `maxConcurrency` caps the number of simultaneously running
// executions.
//
// Sprint 13+14 spec requirements covered:
//   - enqueue / dequeue / peek / size / clear
//   - listPending / listByStatus (delegated to the state store)
//   - markRunning / markCompleted / markFailed (persisted)
//   - Persistence: every enqueue / markRunning / markCompleted / markFailed
//     call stateStore.saveExecution with the updated envelope
//   - maxConcurrency enforcement is the consumer's responsibility (the
//     queue exposes `runningCount` / `maxConcurrency` for inspection)
// =============================================================================

import type {
  WorkflowExecution,
  ExecutionStatus,
} from '@/lib/runtime/contracts/workflow'
import type { IWorkflowStateStore } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/** Options for constructing an `ExecutionQueue`. */
export interface ExecutionQueueOptions {
  /** Maximum concurrent running executions. Default 1. */
  maxConcurrency?: number
}

/**
 * FIFO execution queue with state-store persistence. The in-memory array
 * is the working queue; the state store is the durable record of every
 * execution that has ever been enqueued.
 *
 * `enqueue` writes to BOTH the in-memory queue AND the state store. The
 * `mark*` methods update the in-memory queue's status tracking AND persist
 * the new status to the state store. `listPending` / `listByStatus` read
 * from the state store (single source of truth for cross-process queries).
 */
export class ExecutionQueue {
  /** In-memory FIFO queue of pending executions. */
  private readonly pending: WorkflowExecution[] = []
  /** Currently-running execution ids (capped by `maxConcurrency`). */
  private readonly running = new Set<string>()
  /** All executions ever enqueued (in-memory index for quick lookup). */
  private readonly index = new Map<string, WorkflowExecution>()
  /** Maximum concurrent running executions. */
  private readonly maxConcurrency: number

  /**
   * @param stateStore Durable state store; every enqueue / mark* call
   *                   persists the updated envelope here.
   * @param opts       Optional `maxConcurrency` override.
   */
  constructor(
    private readonly stateStore: IWorkflowStateStore,
    opts: ExecutionQueueOptions = {},
  ) {
    this.maxConcurrency = opts.maxConcurrency ?? 1
  }

  /**
   * Enqueue an execution. Persists to the state store. Deep-clones the
   * input so the caller's reference cannot mutate the queue's record.
   */
  async enqueue(execution: WorkflowExecution): Promise<void> {
    const clone = deepClone(execution)
    this.pending.push(clone)
    this.index.set(execution.executionId, clone)
    await this.stateStore.saveExecution(clone)
    logger.debug(
      { executionId: execution.executionId, queueSize: this.pending.length },
      'ExecutionQueue: enqueued',
    )
  }

  /**
   * Dequeue the next pending execution (FIFO). Returns null when the
   * queue is empty. Does NOT mark the execution as running — the caller
   * is expected to call `markRunning` after dequeue.
   */
  dequeue(): WorkflowExecution | null {
    const next = this.pending.shift()
    return next ?? null
  }

  /** Peek at the next pending execution without removing it. */
  peek(): WorkflowExecution | null {
    return this.pending[0] ?? null
  }

  /** Number of pending executions in the in-memory queue. */
  size(): number {
    return this.pending.length
  }

  /** Number of currently-running executions. */
  runningCount(): number {
    return this.running.size
  }

  /** Whether the queue can accept another running execution. */
  hasCapacity(): boolean {
    return this.running.size < this.maxConcurrency
  }

  /** The configured max concurrency. */
  max(): number {
    return this.maxConcurrency
  }

  /**
   * List executions in non-terminal states, read from the state store.
   */
  async listPending(): Promise<WorkflowExecution[]> {
    return this.stateStore.listPending()
  }

  /**
   * List executions in a specific status, read from the state store.
   */
  async listByStatus(
    status: ExecutionStatus,
  ): Promise<WorkflowExecution[]> {
    return this.stateStore.listByStatus(status)
  }

  /**
   * Mark an execution as `running`. Removes it from the running set on
   * terminal transition. Persists the new status to the state store.
   */
  async markRunning(executionId: string): Promise<void> {
    const exec = this.index.get(executionId)
    if (!exec) {
      logger.warn(
        { executionId },
        'ExecutionQueue.markRunning: execution not in queue index',
      )
      return
    }
    exec.status = 'running'
    exec.updatedAt = Date.now()
    this.running.add(executionId)
    await this.stateStore.saveExecution(exec)
    logger.debug(
      { executionId, running: this.running.size },
      'ExecutionQueue: marked running',
    )
  }

  /**
   * Mark an execution as `completed`. Removes it from the running set.
   * Persists the new status to the state store.
   */
  async markCompleted(executionId: string): Promise<void> {
    const exec = this.index.get(executionId)
    if (!exec) {
      logger.warn(
        { executionId },
        'ExecutionQueue.markCompleted: execution not in queue index',
      )
      return
    }
    exec.status = 'completed'
    exec.completedAt = Date.now()
    exec.updatedAt = Date.now()
    this.running.delete(executionId)
    await this.stateStore.saveExecution(exec)
    logger.debug(
      { executionId },
      'ExecutionQueue: marked completed',
    )
  }

  /**
   * Mark an execution as `failed` with the given error message. Removes
   * it from the running set. Persists the new status to the state store.
   */
  async markFailed(executionId: string, error: string): Promise<void> {
    const exec = this.index.get(executionId)
    if (!exec) {
      logger.warn(
        { executionId },
        'ExecutionQueue.markFailed: execution not in queue index',
      )
      return
    }
    exec.status = 'failed'
    exec.error = error
    exec.completedAt = Date.now()
    exec.updatedAt = Date.now()
    this.running.delete(executionId)
    await this.stateStore.saveExecution(exec)
    logger.debug(
      { executionId, error },
      'ExecutionQueue: marked failed',
    )
  }

  /** Clear the in-memory queue. Does NOT delete persisted state. */
  clear(): void {
    this.pending.length = 0
    this.running.clear()
    this.index.clear()
    logger.debug('ExecutionQueue: cleared in-memory state')
  }
}

// ----- Helpers --------------------------------------------------------------

/** Deep-clone a JSON-serializable value. */
function deepClone<T>(value: T): T {
  if (
    typeof globalThis !== 'undefined' &&
    typeof (globalThis as { structuredClone?: unknown }).structuredClone ===
      'function'
  ) {
    try {
      return (globalThis as { structuredClone: (v: T) => T }).structuredClone(
        value,
      )
    } catch {
      // fall through
    }
  }
  return JSON.parse(JSON.stringify(value)) as T
}
