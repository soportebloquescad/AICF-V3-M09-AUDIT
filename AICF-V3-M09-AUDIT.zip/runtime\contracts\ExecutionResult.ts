// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — ExecutionResult (Universal)
// =============================================================================
// The universal result of executing any artifact-generating module.
//
// Every module (course, slides, quiz, document, research) returns an
// ExecutionResult. It carries:
//   - success flag
//   - output (the primary ArtifactPackage, or null on failure)
//   - error (when success === false)
//   - metrics (tokens, cost, duration)
//   - artifacts (all packages produced, including the primary)
//
// DISTINCTION: There is also a business-layer ExecutionResult in
// `runtime/business/contracts/ExecutionResult.ts`. That contract is the
// return value of `BusinessModule.executeJob()` and uses `Record<string,
// unknown>` for output. THIS contract (in `runtime/contracts/`) is the
// universal artifact-layer result with typed `ArtifactPackage` output.
// They serve different layers and are NOT duplicates.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { ArtifactPackage } from './ArtifactPackage'

/**
 * Resource consumption metrics for a single execution.
 */
export interface ExecutionMetrics {
  /** Total tokens consumed (prompt + completion). */
  tokensTotal: number

  /** Prompt tokens consumed. */
  tokensPrompt: number

  /** Completion tokens consumed. */
  tokensCompletion: number

  /** Estimated USD cost. */
  estimatedCost: number

  /** Wall-clock duration in milliseconds. */
  durationMs: number

  /** Number of AI provider calls made. */
  providerCalls: number

  /** Whether the result was served from cache. */
  cacheHit: boolean
}

/**
 * The universal result of executing an artifact-generating module.
 *
 * Produced by all artifact modules. Carries the primary output package,
 * any secondary artifacts, metrics, and error info.
 */
export interface ExecutionResult {
  /** Whether the execution succeeded. */
  success: boolean

  /** The primary output artifact (null on failure). */
  output: ArtifactPackage | null

  /** Error message (when success === false). */
  error: string | null

  /** Resource consumption metrics. */
  metrics: ExecutionMetrics

  /** All artifacts produced (including the primary output). */
  artifacts: ArtifactPackage[]
}

/**
 * Factory: creates an empty ExecutionMetrics (all zeros).
 */
export function createEmptyMetrics(): ExecutionMetrics {
  return {
    tokensTotal: 0,
    tokensPrompt: 0,
    tokensCompletion: 0,
    estimatedCost: 0,
    durationMs: 0,
    providerCalls: 0,
    cacheHit: false,
  }
}

/**
 * Factory: creates a successful ExecutionResult.
 *
 * @example
 * const r = createSuccessExecutionResult(pkg, metrics)
 */
export function createSuccessExecutionResult(
  output: ArtifactPackage,
  metrics?: Partial<ExecutionMetrics>,
): ExecutionResult {
  return {
    success: true,
    output,
    error: null,
    metrics: { ...createEmptyMetrics(), ...metrics },
    artifacts: [output],
  }
}

/**
 * Factory: creates a failed ExecutionResult.
 *
 * @example
 * const r = createFailedExecutionResult('LLM timeout')
 */
export function createFailedExecutionResult(
  error: string,
  metrics?: Partial<ExecutionMetrics>,
): ExecutionResult {
  return {
    success: false,
    output: null,
    error,
    metrics: { ...createEmptyMetrics(), ...metrics },
    artifacts: [],
  }
}
