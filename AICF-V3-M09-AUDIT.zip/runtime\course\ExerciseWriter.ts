// =============================================================================
// AICF V3 — Épica 6 — Exercise Writer
// =============================================================================
import { ContentGenerator, type GeneratedContent } from './ContentGenerator'

export class ExerciseWriter {
  constructor(private readonly opts: { contentGenerator: ContentGenerator }) {}

  async writeExercise(input: {
    topic: string
    lessonTitle: string
    type: 'quiz' | 'coding' | 'writing' | 'discussion'
    difficulty: string
    locale: string
  }): Promise<GeneratedContent> {
    return this.opts.contentGenerator.generateExercise(input)
  }

  async writeExercises(input: {
    topic: string
    lessons: string[]
    type: 'quiz' | 'coding' | 'writing' | 'discussion'
    difficulty: string
    locale: string
  }): Promise<GeneratedContent[]> {
    const results: GeneratedContent[] = []
    for (const lessonTitle of input.lessons) {
      results.push(await this.writeExercise({ ...input, lessonTitle }))
    }
    return results
  }
}
