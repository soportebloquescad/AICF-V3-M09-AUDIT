// =============================================================================
// AICF V3 — Sprint 13+14 — Observability Module — Logger Provider
// =============================================================================
// Provides named child loggers backed by the central pino logger
// (`@/lib/ai/logger`). Each named logger binds its `name` into every log
// line so downstream consumers (the dev dashboard, the /health endpoint,
// log aggregators) can filter by module / subsystem without parsing message
// text.
//
// In addition to delegating to pino, the provider keeps an in-memory ring
// buffer of the last 1000 log entries so the /health endpoint can surface
// recent log activity without parsing log files.
//
// Sprint 13+14 spec requirements covered:
//   - `Logger` interface: info / warn / error / debug, each taking a message
//     and optional structured data
//   - `getLogger(name)` returns a child logger bound to that name (cached)
//   - `setLevel(level)` adjusts the level on the base logger AND every cached
//     child (so dynamic re-configuration propagates)
//   - `getLogHistory()` returns the in-memory ring buffer (max 1000 entries)
//   - `clearHistory()` wipes the ring buffer
//
// Design notes:
//   - The `Logger` interface is intentionally narrower than pino's full API
//     (no `trace` / `fatal` / `child` / `flush`): the observability surface
//     only needs the four standard levels. Callers needing richer pino
//     behavior can reach the underlying logger via `getBaseLogger()`.
//   - History entries store `data` as `unknown` (not `any`); consumers must
//     narrow before use. This satisfies the strict-no-`any` constraint.
//   - Ring buffer eviction uses `shift()` which is O(n) on a 1000-element
//     array — acceptable for a 1000-entry cap, but if the cap grows we should
//     switch to a circular buffer.
// =============================================================================

import type { Logger as PinoLogger } from 'pino'
import { logger as defaultBaseLogger } from '@/lib/ai/logger'

/** Log severity levels exposed by the observability `Logger` interface. */
export type LogLevel = 'info' | 'warn' | 'error' | 'debug'

/**
 * A single entry in the in-memory log history ring buffer. The `data`
 * field is `unknown` because callers may pass arbitrary structured data;
 * consumers must narrow before use.
 */
export interface LogEntry {
  /** Epoch ms when the entry was recorded. */
  timestamp: number
  /** Severity level. */
  level: LogLevel
  /** Logger name (module / subsystem). */
  name: string
  /** Free-text message. */
  message: string
  /** Optional structured data payload. */
  data?: unknown
}

/**
 * Narrow logger interface implemented by every named logger returned from
 * `LoggerProvider.getLogger`. Each method takes a human-readable message
 * and an optional structured-data payload.
 */
export interface Logger {
  info(message: string, data?: unknown): void
  warn(message: string, data?: unknown): void
  error(message: string, data?: unknown): void
  debug(message: string, data?: unknown): void
}

/** Maximum number of entries retained in the in-memory ring buffer. */
const MAX_HISTORY = 1000

/**
 * Provides named child loggers backed by a pino base logger. Construct
 * with the singleton pino logger from `@/lib/ai/logger` (or a custom
 * pino instance for testing).
 */
export class LoggerProvider {
  /** The pino base logger (root). Child loggers are derived via `child()`. */
  private readonly baseLogger: PinoLogger
  /** Cache of named child pino loggers keyed by name. */
  private readonly children = new Map<string, PinoLogger>()
  /** Cache of named loggers (the public `Logger` wrappers) keyed by name. */
  private readonly loggers = new Map<string, Logger>()
  /** In-memory ring buffer of recent log entries (newest at the end). */
  private readonly history: LogEntry[] = []
  /** Current level (mirrors what's set on the base logger). */
  private currentLevel: LogLevel = 'info'

  constructor(baseLogger: PinoLogger = defaultBaseLogger) {
    this.baseLogger = baseLogger
  }

  /**
   * Return a named child logger. The same instance is returned on subsequent
   * calls with the same name (cached). The name is bound into every log
   * line via pino's `child({ name })` mechanism.
   */
  getLogger(name: string): Logger {
    const existing = this.loggers.get(name)
    if (existing !== undefined) return existing
    const child = this.baseLogger.child({ name })
    this.children.set(name, child)
    const logger = this.wrapLogger(child, name)
    this.loggers.set(name, logger)
    return logger
  }

  /**
   * Set the level on the base logger AND every cached child. Pino
   * propagates level changes from root to children automatically, but we
   * set it explicitly on each child as a defensive measure (older pino
   * versions / custom transports sometimes don't propagate cleanly).
   */
  setLevel(level: LogLevel): void {
    this.currentLevel = level
    this.baseLogger.level = level
    for (const child of this.children.values()) {
      child.level = level
    }
  }

  /** Return the current global log level. */
  getLevel(): LogLevel {
    return this.currentLevel
  }

  /** Return a copy of the in-memory log history (newest entries last). */
  getLogHistory(): LogEntry[] {
    return [...this.history]
  }

  /** Clear the in-memory log history. */
  clearHistory(): void {
    this.history.length = 0
  }

  /** Direct accessor for the underlying pino base logger. */
  getBaseLogger(): PinoLogger {
    return this.baseLogger
  }

  // ----- Internal helpers ---------------------------------------------------

  /**
   * Wrap a pino child logger in the narrow `Logger` interface, while
   * pushing every emit into the in-memory ring buffer.
   */
  private wrapLogger(child: PinoLogger, name: string): Logger {
    const push = (
      level: LogLevel,
      message: string,
      data?: unknown,
    ): void => {
      this.pushHistory(level, name, message, data)
      if (data !== undefined) {
        child[level]({ data }, message)
      } else {
        child[level](message)
      }
    }
    return {
      info: (m, d) => push('info', m, d),
      warn: (m, d) => push('warn', m, d),
      error: (m, d) => push('error', m, d),
      debug: (m, d) => push('debug', m, d),
    }
  }

  /**
   * Append a new entry to the ring buffer, evicting the oldest entry if
   * the buffer is at capacity.
   */
  private pushHistory(
    level: LogLevel,
    name: string,
    message: string,
    data?: unknown,
  ): void {
    const entry: LogEntry = {
      timestamp: Date.now(),
      level,
      name,
      message,
    }
    if (data !== undefined) entry.data = data
    this.history.push(entry)
    while (this.history.length > MAX_HISTORY) {
      this.history.shift()
    }
  }
}
