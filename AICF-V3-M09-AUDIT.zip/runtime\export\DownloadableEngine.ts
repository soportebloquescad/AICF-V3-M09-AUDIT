// =============================================================================
// AICF V3 — Sprint 11B — DownloadableEngine
// =============================================================================
// Single responsibility: generate downloadable study materials.
//
// Generates per module:
//   - Study guide (HTML, printable to PDF)
//   - Exercises (HTML, printable to PDF)
//   - Solutions (HTML, printable to PDF)
//   - Cheat sheet (HTML, printable to PDF)
//
// REUSES: LessonEngine (deep content), ExerciseEngine (exercises),
// LocaleContext (local examples), ThemePreset (styling).
// No dependencies on BFF or Runtime M09.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import type { LocaleContext } from '../locale/CountryEngine'
import { LessonEngine, type DeepLesson } from '../lesson/LessonEngine'
import { logger } from '@/lib/ai/logger'

export interface DownloadableResult {
  name: string
  content: string
  mimeType: string
}

export class DownloadableEngine {
  private readonly log = logger.child({ component: 'DownloadableEngine' })
  private readonly lessonEngine = new LessonEngine()

  generateStudyGuide(opts: {
    topic: string
    moduleIndex: number
    locale: LocaleContext
    theme: ThemePreset
  }): DownloadableResult {
    const { topic, moduleIndex, locale, theme } = opts
    const lesson = this.lessonEngine.generate({ topic, moduleIndex, lessonIndex: 0, locale })
    const html = this.wrapPrintableHtml(`Study Guide — Module ${moduleIndex}: ${topic}`, lesson.content, theme, this.buildStudyGuideBody(lesson))
    this.log.info({ topic, moduleIndex }, 'DownloadableEngine: study guide generated')
    return { name: `guia-estudio-modulo-${moduleIndex}.html`, content: html, mimeType: 'text/html' }
  }

  generateExercises(opts: {
    topic: string
    moduleIndex: number
    locale: LocaleContext
    theme: ThemePreset
  }): DownloadableResult {
    const { topic, moduleIndex, locale, theme } = opts
    const lesson = this.lessonEngine.generate({ topic, moduleIndex, lessonIndex: 0, locale })
    const html = this.wrapPrintableHtml(`Exercises — Module ${moduleIndex}: ${topic}`, lesson.content, theme, this.buildExercisesBody(lesson))
    this.log.info({ topic, moduleIndex }, 'DownloadableEngine: exercises generated')
    return { name: `ejercicios-modulo-${moduleIndex}.html`, content: html, mimeType: 'text/html' }
  }

  generateSolutions(opts: {
    topic: string
    moduleIndex: number
    locale: LocaleContext
    theme: ThemePreset
  }): DownloadableResult {
    const { topic, moduleIndex, locale, theme } = opts
    const lesson = this.lessonEngine.generate({ topic, moduleIndex, lessonIndex: 0, locale })
    const html = this.wrapPrintableHtml(`Solutions — Module ${moduleIndex}: ${topic}`, lesson.content, theme, this.buildSolutionsBody(lesson))
    this.log.info({ topic, moduleIndex }, 'DownloadableEngine: solutions generated')
    return { name: `soluciones-modulo-${moduleIndex}.html`, content: html, mimeType: 'text/html' }
  }

  generateCheatSheet(opts: {
    topic: string
    moduleIndex: number
    locale: LocaleContext
    theme: ThemePreset
  }): DownloadableResult {
    const { topic, moduleIndex, locale, theme } = opts
    const lesson = this.lessonEngine.generate({ topic, moduleIndex, lessonIndex: 0, locale })
    const html = this.wrapPrintableHtml(`Cheat Sheet — ${topic}`, lesson.content, theme, this.buildCheatSheetBody(topic, lesson))
    this.log.info({ topic, moduleIndex }, 'DownloadableEngine: cheat sheet generated')
    return { name: `cheat-sheet-modulo-${moduleIndex}.html`, content: html, mimeType: 'text/html' }
  }

  // --- Body builders -------------------------------------------------------

  private buildStudyGuideBody(lesson: DeepLesson): string {
    return `
      <h2>Learning Objectives</h2>
      <ul>${lesson.learningObjectives.map((o) => `<li>${this.escape(o)}</li>`).join('')}</ul>
      <h2>Content</h2>
      <div>${this.markdownToHtml(lesson.content)}</div>
      <h2>Examples</h2>
      ${lesson.examples.map((ex) => `<div class="example"><h3>${this.escape(ex.title)}</h3><p>${this.escape(ex.description)}</p>${ex.code ? `<pre><code>${this.escape(ex.code)}</code></pre>` : ''}</div>`).join('')}
      <h2>References</h2>
      <ul>${lesson.references.map((r) => `<li><a href="${this.escape(r.url)}">${this.escape(r.title)}</a> — ${this.escape(r.publisher)}</li>`).join('')}</ul>
    `
  }

  private buildExercisesBody(lesson: DeepLesson): string {
    const ex = lesson.exercise
    return `
      <h2>${this.escape(ex.title)}</h2>
      <p><strong>Difficulty:</strong> ${this.escape(ex.difficulty)} | <strong>Estimated time:</strong> ${ex.estimatedMinutes} minutes</p>
      <h3>Instructions</h3>
      <ol>${ex.instructions.map((i) => `<li>${this.escape(i)}</li>`).join('')}</ol>
      <h3>Hints</h3>
      <ul>${ex.hints.map((h) => `<li>${this.escape(h)}</li>`).join('')}</ul>
      <h3>Steps</h3>
      <div class="steps">${ex.steps.map((s) => `<div class="step"><h4>Step ${s.number}: ${this.escape(s.title)}</h4><p>${this.escape(s.description)}</p>${s.code ? `<pre><code>${this.escape(s.code)}</code></pre>` : ''}</div>`).join('')}</div>
    `
  }

  private buildSolutionsBody(lesson: DeepLesson): string {
    const ex = lesson.exercise
    return `
      <h2>Solutions — ${this.escape(ex.title)}</h2>
      <h3>Step-by-step Solution</h3>
      <div class="steps">${ex.steps.map((s) => `<div class="step"><h4>Step ${s.number}: ${this.escape(s.title)}</h4><p>${this.escape(s.description)}</p>${s.code ? `<pre><code>${this.escape(s.code)}</code></pre>` : ''}</div>`).join('')}</div>
      <h3>Example Code</h3>
      ${ex.exampleCode ? `<pre><code>${this.escape(ex.exampleCode)}</code></pre>` : '<p>No example code provided.</p>'}
      <h3>Evaluation Rubric</h3>
      <table class="rubric"><thead><tr><th>Criterion</th><th>Weight</th><th>Description</th></tr></thead><tbody>${ex.rubric.map((r) => `<tr><td>${this.escape(r.name)}</td><td><strong>${r.weight}%</strong></td><td>${this.escape(r.description)}</td></tr>`).join('')}</tbody></table>
    `
  }

  private buildCheatSheetBody(topic: string, lesson: DeepLesson): string {
    return `
      <h2>Quick Reference: ${this.escape(topic)}</h2>
      <div class="cheat-grid">
        <div class="cheat-card"><h3>Key Objectives</h3><ul>${lesson.learningObjectives.slice(0, 3).map((o) => `<li>${this.escape(o)}</li>`).join('')}</ul></div>
        <div class="cheat-card"><h3>Key Examples</h3><ul>${lesson.examples.slice(0, 3).map((e) => `<li>${this.escape(e.title)}</li>`).join('')}</ul></div>
        <div class="cheat-card"><h3>Case Study</h3><p>${this.escape(lesson.caseStudy.title)}</p><p><em>${this.escape(lesson.caseStudy.takeaway)}</em></p></div>
        <div class="cheat-card"><h3>Quiz Highlights</h3><ul>${lesson.quiz.slice(0, 3).map((q) => `<li>${this.escape(q.question)} <strong>Answer: ${String.fromCharCode(65 + q.correctIndex)}</strong></li>`).join('')}</ul></div>
      </div>
    `
  }

  // --- HTML wrapper --------------------------------------------------------

  private wrapPrintableHtml(title: string, _content: string, theme: ThemePreset, body: string): string {
    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderBaseCss(theme)
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escape(title)}</title>
  <style>
    ${themeCss}
    @page { margin: 2cm; }
    body { max-width: 800px; margin: 0 auto; padding: 2rem; }
    h1, h2, h3 { color: var(--color-primary); }
    .example { background: var(--color-surface); border-left: 4px solid var(--color-accent); padding: 1rem; margin: 1rem 0; border-radius: 0 var(--radius) var(--radius) 0; }
    .example pre { background: var(--color-background); border: 1px solid var(--color-border); padding: 0.5rem; overflow-x: auto; font-size: 0.85rem; }
    .steps .step { padding: 0.5rem 0; border-bottom: 1px solid var(--color-border); }
    .steps .step h4 { color: var(--color-accent); margin: 0 0 0.3rem; }
    .rubric { width: 100%; border-collapse: collapse; margin: 1rem 0; }
    .rubric th { background: var(--color-primary); color: var(--color-primary-fg); padding: 0.5rem; text-align: left; }
    .rubric td { padding: 0.5rem; border-bottom: 1px solid var(--color-border); }
    .cheat-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; }
    .cheat-card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1rem; }
    .cheat-card h3 { margin: 0 0 0.5rem; font-size: 0.95rem; }
    @media print { .no-print { display: none; } }
  </style>
</head>
<body>
  <h1>${this.escape(title)}</h1>
  ${body}
</body>
</html>`
  }

  private markdownToHtml(md: string): string {
    return md
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>[\s\S]+<\/li>)/, '<ul>$1</ul>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>')
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }
}

let singleton: DownloadableEngine | null = null
export function getDownloadableEngine(): DownloadableEngine {
  if (!singleton) singleton = new DownloadableEngine()
  return singleton
}
export function resetDownloadableEngine(): void { singleton = null }
