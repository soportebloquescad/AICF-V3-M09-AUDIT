// =============================================================================
// AICF V3 — Epica 7 — Audit Trail
// =============================================================================
import { logger } from '@/lib/ai/logger'

export type AuditAction =
  | 'course.create'
  | 'course.start'
  | 'course.complete'
  | 'course.fail'
  | 'stage.start'
  | 'stage.complete'
  | 'stage.fail'
  | 'stage.retry'
  | 'engine.register'
  | 'engine.health'
  | 'publish.execute'
  | 'publish.rollback'
  | 'recovery.checkpoint'
  | 'recovery.resume'
  | 'quality.validate'
  | 'cost.record'
  | 'user.action'

export interface AuditRecord {
  id: string
  correlationId: string
  courseId?: string
  stage?: string
  action: AuditAction
  actor: string
  detail: string
  metadata: Record<string, unknown>
  severity: 'info' | 'warn' | 'error'
  recordedAt: string
}

class AuditTrailImpl {
  private readonly records = new Map<string, AuditRecord>()
  private readonly maxRecords = 10_000

  record(input: {
    correlationId: string
    courseId?: string
    stage?: string
    action: AuditAction
    actor: string
    detail: string
    metadata?: Record<string, unknown>
    severity?: 'info' | 'warn' | 'error'
  }): AuditRecord {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const record: AuditRecord = {
      id: `audit-${ts}-${rand}`,
      correlationId: input.correlationId,
      courseId: input.courseId,
      stage: input.stage,
      action: input.action,
      actor: input.actor,
      detail: input.detail,
      metadata: input.metadata ?? {},
      severity: input.severity ?? 'info',
      recordedAt: new Date().toISOString(),
    }
    this.records.set(record.id, record)
    if (this.records.size > this.maxRecords) {
      const oldest = Array.from(this.records.keys()).sort()[0]
      if (oldest) this.records.delete(oldest)
    }
    logger.info({ auditId: record.id, action: record.action, severity: record.severity }, 'AuditTrail: recorded')
    return record
  }

  getByCorrelationId(correlationId: string): AuditRecord[] {
    return Array.from(this.records.values())
      .filter((r) => r.correlationId === correlationId)
      .sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }

  getByCourse(courseId: string): AuditRecord[] {
    return Array.from(this.records.values())
      .filter((r) => r.courseId === courseId)
      .sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }

  getByAction(action: AuditAction): AuditRecord[] {
    return Array.from(this.records.values())
      .filter((r) => r.action === action)
      .sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }

  getRecent(limit: number = 100): AuditRecord[] {
    return Array.from(this.records.values())
      .sort((a, b) => b.recordedAt.localeCompare(a.recordedAt))
      .slice(0, limit)
  }

  getByStage(stage: string): AuditRecord[] {
    return Array.from(this.records.values())
      .filter((r) => r.stage === stage)
      .sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }

  getErrors(): AuditRecord[] {
    return Array.from(this.records.values())
      .filter((r) => r.severity === 'error')
      .sort((a, b) => b.recordedAt.localeCompare(a.recordedAt))
  }

  size(): number {
    return this.records.size
  }

  clear(): void {
    this.records.clear()
  }
}

export const auditTrail = new AuditTrailImpl()
