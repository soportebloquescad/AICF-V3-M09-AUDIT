// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Artifact Contract
// =============================================================================
// Defines the artifact envelope produced by workflow steps, with full
// lineage tracking. Artifacts are the durable outputs of a workflow run:
// generated courses, presentations, quizzes, documents, raw text/JSON, etc.
//
// Sprint 13+14 spec requirements covered:
//   - Strongly-typed artifact categories (`ArtifactType`)
//   - Content addressing via SHA-256 `hash` + `sizeBytes`
//   - External storage via `contentRef` for large artifacts
//   - Full lineage: parent / children / generator / execution / prompt hash /
//     model / provider — enabling provenance graphs and reproducibility
//
// Artifacts are referenced (by id) from both `WorkflowExecution.StepExecution`
// and `WorkflowResult`. The full body lives here.
// =============================================================================

/** MIME-type default for each artifact type. */
const DEFAULT_MIME: Record<ArtifactType, string> = {
  text: 'text/plain',
  json: 'application/json',
  markdown: 'text/markdown',
  html: 'text/html',
  binary: 'application/octet-stream',
  course: 'application/vnd.aicf.course+json',
  presentation: 'application/vnd.aicf.presentation+json',
  quiz: 'application/vnd.aicf.quiz+json',
  document: 'application/vnd.aicf.document+json',
}

/**
 * Categorized artifact kinds. The product-specific types (`course`,
 * `presentation`, `quiz`, `document`) carry richer schemas in their
 * respective generators; the generic types (`text`, `json`, `markdown`,
 * `html`, `binary`) cover raw intermediate artifacts.
 */
export type ArtifactType =
  | 'text'
  | 'json'
  | 'markdown'
  | 'html'
  | 'binary'
  | 'course'
  | 'presentation'
  | 'quiz'
  | 'document'

/**
 * Provenance graph for an artifact. Enables "show me what produced this"
 * and "regenerate from the same prompt" workflows.
 */
export interface ArtifactLineage {
  /** Parent artifact id, if this artifact was derived from another. */
  parentArtifact?: string
  /** Child artifact ids produced from this artifact. */
  children: string[]
  /** Generator / provider name that produced the artifact. */
  generator: string
  /** Execution id that produced the artifact. */
  workflowExecution: string
  /** SHA-256 hash of the prompt that produced the artifact, if applicable. */
  promptHash?: string
  /** Model name that produced the artifact, if applicable. */
  model?: string
  /** Provider name that produced the artifact, if applicable. */
  provider?: string
}

/**
 * The full artifact envelope. Persisted by the repository and surfaced via
 * the runtime API.
 */
export interface WorkflowArtifact {
  /** Unique artifact id. */
  id: string
  /** Execution id that produced the artifact. */
  executionId: string
  /** Producing step id. */
  stepId: string
  /** Human-readable artifact name. */
  name: string
  /** Categorized artifact type. */
  type: ArtifactType
  /** MIME type (defaults per `ArtifactType`, overridable). */
  mimeType: string
  /** Inline content (string). Use `contentRef` for large bodies. */
  content: string
  /** External storage reference (e.g. S3 key, blob URL) for large artifacts. */
  contentRef?: string
  /** Content size in bytes. */
  sizeBytes: number
  /** SHA-256 hash of `content` (content-addressed identity). */
  hash: string
  /** Provenance graph. */
  lineage: ArtifactLineage
  /** Epoch ms when the artifact was created. */
  createdAt: number
  /** Optional free-form metadata. */
  metadata?: Record<string, unknown>
}

/**
 * Compute a SHA-256 hash of a string using the Web Crypto API.
 * Returns a hex-encoded digest. Falls back to a non-cryptographic
 * FNV-1a hash when `crypto.subtle` is unavailable (e.g. older Node
 * without webcrypto), with a `'fnv1a:'` prefix to make the fallback
 * unambiguous.
 */
async function computeHash(input: string): Promise<string> {
  // Browser / modern Node (>=15) path.
  const cryptoRef: Crypto | undefined =
    typeof globalThis !== 'undefined'
      ? (globalThis as { crypto?: Crypto }).crypto
      : undefined
  if (cryptoRef?.subtle) {
    const data = new TextEncoder().encode(input)
    const digest = await cryptoRef.subtle.digest('SHA-256', data)
    const bytes = new Uint8Array(digest)
    let hex = ''
    for (let i = 0; i < bytes.length; i += 1) {
      hex += bytes[i].toString(16).padStart(2, '0')
    }
    return hex
  }
  // FNV-1a fallback (non-cryptographic).
  let hash = 0x811c9dc5
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i)
    // FNV prime (32-bit).
    hash = Math.imul(hash, 0x01000193)
  }
  return `fnv1a:${(hash >>> 0).toString(16)}`
}

/**
 * Factory: creates a `WorkflowArtifact` from inline content.
 * Computes `hash` and `sizeBytes` automatically and resolves the
 * default MIME type for the given `type`.
 *
 * @param executionId Execution id producing the artifact.
 * @param stepId      Producing step id.
 * @param name        Human-readable artifact name.
 * @param type        Categorized artifact type.
 * @param content     Inline string content.
 * @param lineage     Optional lineage. When omitted, a minimal lineage
 *                    (no parent, no children, generator=`stepId`) is built.
 * @param opts        Optional overrides: `id`, `mimeType`, `contentRef`,
 *                    `metadata`, `createdAt`.
 */
export async function createArtifact(
  executionId: string,
  stepId: string,
  name: string,
  type: ArtifactType,
  content: string,
  lineage?: Partial<ArtifactLineage>,
  opts?: {
    id?: string
    mimeType?: string
    contentRef?: string
    metadata?: Record<string, unknown>
    createdAt?: number
  },
): Promise<WorkflowArtifact> {
  const sizeBytes =
    typeof TextEncoder !== 'undefined'
      ? new TextEncoder().encode(content).length
      : content.length
  const hash = await computeHash(content)
  const createdAt = opts?.createdAt ?? Date.now()
  const fullLineage: ArtifactLineage = {
    children: lineage?.children ?? [],
    generator: lineage?.generator ?? stepId,
    workflowExecution: executionId,
    ...(lineage?.parentArtifact !== undefined
      ? { parentArtifact: lineage.parentArtifact }
      : {}),
    ...(lineage?.promptHash !== undefined ? { promptHash: lineage.promptHash } : {}),
    ...(lineage?.model !== undefined ? { model: lineage.model } : {}),
    ...(lineage?.provider !== undefined ? { provider: lineage.provider } : {}),
  }
  const id =
    opts?.id ?? `art-${createdAt}-${Math.random().toString(36).slice(2, 10)}`
  return {
    id,
    executionId,
    stepId,
    name,
    type,
    mimeType: opts?.mimeType ?? DEFAULT_MIME[type],
    content,
    ...(opts?.contentRef !== undefined ? { contentRef: opts.contentRef } : {}),
    sizeBytes,
    hash,
    lineage: fullLineage,
    createdAt,
    ...(opts?.metadata !== undefined ? { metadata: opts.metadata } : {}),
  }
}
