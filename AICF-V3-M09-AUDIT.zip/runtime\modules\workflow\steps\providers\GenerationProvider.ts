// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Provider
// =============================================================================
// Provider that fulfills the `'generate'` capability by delegating to an
// injected `IGenerator` (CourseGenerator, PresentationGenerator, etc.).
// Wraps the generator's `GeneratorOutput` into the uniform
// `StepExecutionResult` envelope so the executor can flow it through
// without type gymnastics.
//
// Sprint 13+14 spec requirements covered:
//   - `IProvider` interface compliance
//   - Reads `contentType` / `topic` / `modules` / `level` from the step
//     input
//   - Returns `output: { content, modules, outline, title, description }`,
//     `artifacts`, `tokensUsed`, `cost`
// =============================================================================

import type {
  IProvider,
  ProviderCapability,
  ProviderManifest,
  StepExecutionResult,
  IGenerator,
  GeneratorInput,
  GeneratorType,
} from '@/lib/runtime/interfaces'
import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/**
 * Provider that fulfills the `'generate'` capability by delegating to an
 * injected `IGenerator`. Thread-safe across executions.
 */
export class GenerationProvider implements IProvider {
  readonly name: string
  readonly capabilities: ProviderCapability[] = ['generate']
  private ready = false

  /**
   * @param generator The content generator to delegate to.
   * @param name      Optional provider display name. Defaults to
   *                  `'generate'`.
   */
  constructor(
    private readonly generator: IGenerator,
    name = 'generate',
  ) {
    this.name = name
  }

  /** Initialize the provider. Marks itself ready. */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug(
      { provider: this.name, generator: this.generator.name },
      'generation provider initialized',
    )
  }

  /** Whether `initialize` has been called. */
  isReady(): boolean {
    return this.ready
  }

  /** Self-describing manifest for the registry / UI. */
  getManifest(): ProviderManifest {
    return {
      name: this.name,
      version: '1.0.0',
      capabilities: [...this.capabilities],
      config: { generator: this.generator.name, generatorType: this.generator.generatorType },
      description: `Generation provider wrapping generator "${this.generator.name}"`,
    }
  }

  /**
   * Execute the `'generate'` capability.
   *
   * Input shape (read from `input`):
   *   - `contentType`: `'course' | 'presentation' | 'quiz' | 'document'`
   *     (falls back to the generator's declared type)
   *   - `topic`: `string` (required)
   *   - `level`: `'beginner' | 'intermediate' | 'advanced'` (optional)
   *   - `modules`: `number` (optional)
   *   - `audience`: `string` (optional)
   *   - `language`: `string` (optional, falls back to `ctx.locale`)
   *   - `format`: `'markdown' | 'docx' | 'pdf' | 'pptx'` (optional)
   *   - `metadata`: `Record<string, unknown>` (optional)
   */
  async execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    if (capability !== 'generate') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `generation provider cannot handle capability "${capability}"`,
      }
    }

    const topic =
      typeof input.topic === 'string' && input.topic.length > 0
        ? input.topic
        : ''
    if (!topic) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: 'input.topic is required for generation',
      }
    }

    const contentType = this.extractContentType(
      input.contentType,
      this.generator.generatorType,
    )
    if (!this.generator.canHandle(contentType)) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `generator "${this.generator.name}" cannot handle contentType "${contentType}"`,
      }
    }

    const generatorInput: GeneratorInput = {
      topic,
      contentType,
      ...(this.isLevel(input.level) ? { level: input.level } : {}),
      ...(typeof input.modules === 'number' ? { modules: input.modules } : {}),
      ...(typeof input.audience === 'string' ? { audience: input.audience } : {}),
      ...(typeof input.language === 'string'
        ? { language: input.language }
        : { language: ctx.locale }),
      ...(this.isFormat(input.format) ? { format: input.format } : {}),
      ...(this.isPlainObject(input.metadata)
        ? { metadata: input.metadata }
        : {}),
    }

    try {
      const out = await this.generator.generate(generatorInput, ctx)
      if (!out.ok) {
        return {
          ok: false,
          output: {},
          artifacts: out.artifacts ?? [],
          durationMs: 0,
          error: out.error ?? 'generation failed',
        }
      }

      return {
        ok: true,
        output: {
          content: out.content,
          ...(Array.isArray(out.modules) ? { modules: out.modules } : {}),
          ...(typeof out.outline === 'string' ? { outline: out.outline } : {}),
          ...(typeof out.title === 'string' ? { title: out.title } : {}),
          ...(typeof out.description === 'string'
            ? { description: out.description }
            : {}),
        },
        artifacts: out.artifacts ?? [],
        durationMs: 0,
        ...(out.tokensUsed ? { tokensUsed: out.tokensUsed } : {}),
        ...(typeof out.cost === 'number' ? { cost: out.cost } : {}),
        ...(out.provider ? { provider: out.provider } : {}),
        ...(out.model ? { model: out.model } : {}),
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'unknown generator error'
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: message,
      }
    }
  }

  /** Coerce `raw` into a `GeneratorType`, falling back to `defaultType`. */
  private extractContentType(
    raw: unknown,
    defaultType: GeneratorType,
  ): GeneratorType {
    if (
      raw === 'course' ||
      raw === 'presentation' ||
      raw === 'quiz' ||
      raw === 'document'
    ) {
      return raw
    }
    return defaultType
  }

  /** Level type guard. */
  private isLevel(
    v: unknown,
  ): v is 'beginner' | 'intermediate' | 'advanced' {
    return v === 'beginner' || v === 'intermediate' || v === 'advanced'
  }

  /** Format type guard. */
  private isFormat(
    v: unknown,
  ): v is 'markdown' | 'docx' | 'pdf' | 'pptx' {
    return v === 'markdown' || v === 'docx' || v === 'pdf' || v === 'pptx'
  }

  /** Plain-object guard. */
  private isPlainObject(v: unknown): v is Record<string, unknown> {
    if (typeof v !== 'object' || v === null) return false
    if (Array.isArray(v)) return false
    return true
  }
}
