// =============================================================================
// AICF V3 — Sprint 13+14 — Execution Checkpoint Manager (Batch C2)
// =============================================================================
// Manages `Checkpoint` snapshots for resumable workflow executions. A
// checkpoint captures the full execution envelope at a point in time so
// that, after a crash or a deliberate pause, the execution can be
// restored to its last checkpoint and resumed.
//
// Sprint 13+14 spec requirements covered:
//   - `saveCheckpoint(execution, stepId)` — snapshot the execution,
//     persist via the state store, return the checkpoint
//   - `loadLatestCheckpoint(executionId)` — most recent checkpoint
//   - `restoreFromCheckpoint(executionId)` — reconstruct the execution
//     envelope from the latest checkpoint
//   - `listCheckpoints(executionId)` — all checkpoints in save order
//
// Design notes:
//   - The checkpoint's `state` field carries the full serialized
//     execution envelope under a well-known key (`__execution__`). This
//     makes `restoreFromCheckpoint` a simple extraction. The `Checkpoint`
//     contract types `state` as `Record<string, unknown>` so we use type
//     guards to narrow on restore.
//   - `saveCheckpoint` persists the checkpoint via
//     `stateStore.saveCheckpoint` AND appends it to the execution's
//     `checkpoints` array (then re-saves the envelope) so the
//     denormalized view on the envelope stays in sync with the
//     checkpoint map. This matches how `WorkflowEngine.resume` reads
//     `exec.checkpoints[exec.checkpoints.length - 1]`.
//   - Checkpoint ids are unique within an execution: `<execId>#<seq>`.
// =============================================================================

import type {
  WorkflowExecution,
  Checkpoint,
} from '@/lib/runtime/contracts/workflow'
import type { IWorkflowStateStore } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/** Well-known key under which the full execution snapshot is stored. */
const EXECUTION_SNAPSHOT_KEY = '__execution__'

/**
 * Type guard: narrows an unknown `state` payload to a `WorkflowExecution`
 * snapshot. Validates the structural minimum (executionId, status,
 * steps, startedAt) so a corrupt or partial snapshot is rejected
 * cleanly rather than causing a downstream crash.
 */
function isExecutionSnapshot(value: unknown): value is WorkflowExecution {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  return (
    typeof v.executionId === 'string' &&
    typeof v.workflowId === 'string' &&
    typeof v.status === 'string' &&
    typeof v.startedAt === 'number' &&
    typeof v.updatedAt === 'number' &&
    typeof v.correlationId === 'string' &&
    typeof v.dryRun === 'boolean' &&
    typeof v.steps === 'object' &&
    v.steps !== null
  )
}

/**
 * Manages checkpoint lifecycle for a single execution (or many — the
 * manager is stateless across executions; all state lives in the
 * `IWorkflowStateStore`).
 *
 * Construct one manager per runtime; share it across executions.
 */
export class ExecutionCheckpointManager {
  constructor(private readonly stateStore: IWorkflowStateStore) {}

  /**
   * Create a checkpoint capturing the current execution state, persist
   * it via the state store, append it to the execution's `checkpoints`
   * array, and return the checkpoint.
   *
   * @param execution  The execution to snapshot. NOT mutated in place —
   *                   a deep clone of the envelope is embedded in the
   *                   checkpoint's `state` so later mutations to the
   *                   caller's reference do not corrupt the snapshot.
   * @param stepId     The step id at which the checkpoint is captured.
   * @returns          The persisted checkpoint (deep-cloned, safe to
   *                   retain).
   */
  async saveCheckpoint(
    execution: WorkflowExecution,
    stepId: string,
  ): Promise<Checkpoint> {
    const seq = execution.checkpoints.length
    const checkpoint: Checkpoint = {
      id: `${execution.executionId}#${seq}`,
      stepId,
      savedAt: Date.now(),
      // Embed a deep clone of the full execution envelope so the
      // snapshot is immune to later mutations of the caller's
      // reference. We use JSON round-trip because the envelope is
      // JSON-serializable by contract (cheaper than structuredClone
      // for large envelopes and equally safe here).
      state: {
        [EXECUTION_SNAPSHOT_KEY]: JSON.parse(
          JSON.stringify(execution),
        ) as WorkflowExecution,
      },
    }

    // Persist the checkpoint in the store's separate checkpoint map.
    await this.stateStore.saveCheckpoint(execution.executionId, checkpoint)

    // Keep the execution envelope's denormalized `checkpoints` array
    // in sync with the checkpoint map, then re-save the envelope so a
    // later `loadExecution` reflects the new checkpoint. We mutate the
    // caller's `execution` reference here intentionally — the caller
    // passed it in to be checkpointed, so updating its `checkpoints`
    // array is the expected side effect.
    execution.checkpoints.push(checkpoint)
    execution.updatedAt = Date.now()
    await this.stateStore.saveExecution(execution)

    logger.debug(
      {
        executionId: execution.executionId,
        checkpointId: checkpoint.id,
        stepId,
        seq,
      },
      'ExecutionCheckpointManager: checkpoint saved',
    )

    // Return a clone so the caller can retain it without risk of the
    // store mutating it later.
    return JSON.parse(JSON.stringify(checkpoint)) as Checkpoint
  }

  /**
   * Load the most recent checkpoint for an execution, or `null` if the
   * execution has no checkpoints.
   */
  async loadLatestCheckpoint(
    executionId: string,
  ): Promise<Checkpoint | null> {
    const list = await this.stateStore.loadCheckpoints(executionId)
    if (list.length === 0) return null
    return list[list.length - 1]
  }

  /**
   * Reconstruct a `WorkflowExecution` from the latest checkpoint's
   * embedded snapshot. Returns `null` if the execution has no
   * checkpoints, or if the latest checkpoint's snapshot is missing /
   * corrupt (logged at warn).
   *
   * The returned execution is a deep clone of the snapshot — callers
   * can mutate it freely without affecting the persisted checkpoint.
   */
  async restoreFromCheckpoint(
    executionId: string,
  ): Promise<WorkflowExecution | null> {
    const latest = await this.loadLatestCheckpoint(executionId)
    if (!latest) {
      logger.debug(
        { executionId },
        'ExecutionCheckpointManager: no checkpoint to restore from',
      )
      return null
    }
    const snapshot = latest.state[EXECUTION_SNAPSHOT_KEY]
    if (!isExecutionSnapshot(snapshot)) {
      logger.warn(
        { executionId, checkpointId: latest.id },
        'ExecutionCheckpointManager: checkpoint snapshot missing or corrupt',
      )
      return null
    }
    // Deep clone so the caller cannot mutate the persisted snapshot.
    const restored = JSON.parse(JSON.stringify(snapshot)) as WorkflowExecution
    logger.debug(
      {
        executionId,
        checkpointId: latest.id,
        stepId: latest.stepId,
        status: restored.status,
      },
      'ExecutionCheckpointManager: execution restored from checkpoint',
    )
    return restored
  }

  /**
   * List all checkpoints for an execution, in save order. Returns an
   * empty array if the execution has no checkpoints.
   */
  async listCheckpoints(executionId: string): Promise<Checkpoint[]> {
    return this.stateStore.loadCheckpoints(executionId)
  }
}
