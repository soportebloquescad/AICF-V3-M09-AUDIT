// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Execution Contract
// =============================================================================
// Defines the *mutable* execution state of a running workflow instance:
//   - High-level `ExecutionStatus` (lifecycle of the whole run)
//   - Per-step `StepExecution` records (lifecycle of each node)
//   - `Checkpoint` snapshots enabling pause / resume / replay
//   - A serializable `WorkflowExecution` envelope tying it all together
//
// Sprint 13+14 spec requirements covered:
//   - Resumable executions via checkpoints
//   - Per-step retry tracking (`attempts`, `error`)
//   - Saga-compensation lifecycle (`'compensating'` status + `'compensated'`
//     step status)
//   - Dry-run flag carried through the execution envelope
//   - Correlation id for distributed tracing
//
// IMPORTANT: `WorkflowExecution.steps` is modeled as a `Record` (NOT a `Map`)
// so the envelope is JSON-serializable end-to-end. A `Map` would require a
// custom reviver; we avoid that to keep persistence and telemetry simple.
// =============================================================================

/** Lifecycle status of an entire workflow execution. */
export type ExecutionStatus =
  | 'pending'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'compensating'

/** Lifecycle status of a single step within an execution. */
export type StepExecutionStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'skipped'
  | 'compensated'

/**
 * Per-step execution record. Updated in place by the executor as the
 * step progresses through its lifecycle.
 */
export interface StepExecution {
  /** Step id (matches `WorkflowStepDefinition.id`). */
  stepId: string
  /** Current lifecycle status. */
  status: StepExecutionStatus
  /** Epoch ms when the step started running. */
  startedAt?: number
  /** Epoch ms when the step reached a terminal state. */
  completedAt?: number
  /** Elapsed wall-clock time in milliseconds (set on completion). */
  durationMs?: number
  /** Number of execution attempts (incremented on each retry). */
  attempts: number
  /** Last error message (set when `status === 'failed'`). */
  error?: string
  /** Step-produced outputs (logical name → value). */
  output?: Record<string, unknown>
  /** Artifact ids produced by this step (see `WorkflowArtifact`). */
  artifacts: string[]
}

/**
 * A serialized snapshot of execution state captured at a checkpoint.
 * Enables pause / resume and replay-after-failure.
 */
export interface Checkpoint {
  /** Unique checkpoint id. */
  id: string
  /** Step id at which the checkpoint was captured. */
  stepId: string
  /** Epoch ms when the checkpoint was saved. */
  savedAt: number
  /** Serialized execution state at the checkpoint point. */
  state: Record<string, unknown>
}

/**
 * The full execution envelope. Persisted by the repository, surfaced via
 * the runtime API, and consumed by the UI / audit layer.
 */
export interface WorkflowExecution {
  /** Unique execution id. */
  executionId: string
  /** Workflow id (matches `WorkflowMetadata.id`). */
  workflowId: string
  /** Workflow version that was executed (matches `WorkflowDefinition.version`). */
  workflowVersion: string
  /** Current lifecycle status. */
  status: ExecutionStatus
  /** Per-step records, keyed by step id. */
  steps: Record<string, StepExecution>
  /** Resolved inputs supplied to the run. */
  inputs: Record<string, unknown>
  /** Final outputs (set on completion). */
  outputs?: Record<string, unknown>
  /** Saved checkpoints, in save order. */
  checkpoints: Checkpoint[]
  /** Epoch ms when the execution was created. */
  startedAt: number
  /** Epoch ms of the most recent state mutation. */
  updatedAt: number
  /** Epoch ms when the execution reached a terminal state. */
  completedAt?: number
  /** Terminal error message (set when `status === 'failed'`). */
  error?: string
  /** Cross-service correlation id for distributed tracing. */
  correlationId: string
  /** Whether this is a dry-run execution (no side-effects). */
  dryRun: boolean
}

/**
 * Factory: creates a fresh `WorkflowExecution` in the `'pending'` state,
 * with every declared step initialized to `'pending'` and `attempts: 0`.
 *
 * @param workflowId      Workflow id being executed.
 * @param workflowVersion Workflow version being executed.
 * @param inputs          Resolved caller-supplied inputs.
 * @param correlationId   Cross-service correlation id.
 * @param dryRun          Whether this is a dry-run execution.
 * @param stepIds         Declared step ids (used to pre-seed `steps`).
 */
export function createPendingExecution(
  workflowId: string,
  workflowVersion: string,
  inputs: Record<string, unknown>,
  correlationId: string,
  dryRun: boolean,
  stepIds: string[] = [],
): WorkflowExecution {
  const now = Date.now()
  const steps: Record<string, StepExecution> = {}
  for (const stepId of stepIds) {
    steps[stepId] = {
      stepId,
      status: 'pending',
      attempts: 0,
      artifacts: [],
    }
  }
  return {
    executionId: `exec-${now}-${Math.random().toString(36).slice(2, 10)}`,
    workflowId,
    workflowVersion,
    status: 'pending',
    steps,
    inputs,
    checkpoints: [],
    startedAt: now,
    updatedAt: now,
    correlationId,
    dryRun,
  }
}
