// =============================================================================
// AICF V3 — Sprint 13+14 — Observability Module — Metrics Collector
// =============================================================================
// Aggregates runtime metrics across ALL modules (workflow, generation, content
// intelligence, infrastructure, etc.). Distinct from the workflow module's
// `MetricsCollector` (which only tracks per-execution / per-step / per-provider
// workflow metrics), this collector is the global rollup surface: counters,
// histograms (latency distributions), and gauges (instantaneous values).
//
// Sprint 13+14 spec requirements covered:
//   - Counter / Histogram / Gauge primitives keyed by string name
//   - `getHistogram` returns count + min/max/mean + p50/p95/p99 percentiles
//   - `snapshot()` produces a JSON-serializable view for the /health endpoint
//   - `reset()` clears all metrics (useful for tests and warm-restart)
//   - Standard metric names published as a constant for cross-module consistency
//
// Design notes:
//   - All maps are private; access is exclusively through the public API so
//     callers cannot mutate raw buffers.
//   - Histogram values are stored in insertion order; percentile lookups sort
//     a copy each call. For high-volume histograms this is O(n log n) per
//     query — acceptable for a read-mostly observability surface.
//   - No `any` is used anywhere; data shapes are typed via interfaces and
//     narrowed with `typeof` guards at consumer boundaries.
// =============================================================================

/**
 * Aggregate stats computed from a histogram's raw value buffer.
 * `count` is the number of recorded values; `min`/`max`/`mean` are the
 * obvious; `p50`/`p95`/`p99` are the 50th/95th/99th percentiles.
 */
export interface HistogramStats {
  count: number
  min: number
  max: number
  mean: number
  p50: number
  p95: number
  p99: number
}

/**
 * Standard metric names used across the runtime. Centralizing these here
 * prevents typo drift between producers and consumers. Producers SHOULD use
 * these constants when recording; consumers MAY read arbitrary names.
 */
export const STANDARD_METRICS = Object.freeze({
  WORKFLOW_EXECUTIONS_TOTAL: 'workflow.executions.total',
  WORKFLOW_EXECUTIONS_SUCCESS: 'workflow.executions.success',
  WORKFLOW_EXECUTIONS_FAILED: 'workflow.executions.failed',
  WORKFLOW_DURATION_MS: 'workflow.duration.ms',
  STEP_DURATION_MS: 'step.duration.ms',
  PROVIDER_LATENCY_MS: 'provider.latency.ms',
  TOKENS_USED_TOTAL: 'tokens.used.total',
  COST_TOTAL: 'cost.total',
  ARTIFACTS_CREATED: 'artifacts.created',
} as const)

/** Convenience type alias for the standard metric name union. */
export type StandardMetricName =
  (typeof STANDARD_METRICS)[keyof typeof STANDARD_METRICS]

/** Empty-histogram stats (returned when no values have been recorded). */
const EMPTY_HISTOGRAM: HistogramStats = Object.freeze({
  count: 0,
  min: 0,
  max: 0,
  mean: 0,
  p50: 0,
  p95: 0,
  p99: 0,
})

/**
 * Global metrics collector. Thread-safety is not a concern (single-threaded
 * Node event loop); concurrent async producers may safely call
 * `incrementCounter` / `recordHistogram` / `setGauge` from any async context.
 */
export class ObservabilityMetricsCollector {
  /** Monotonically increasing counters keyed by metric name. */
  private readonly counters = new Map<string, number>()
  /** Raw latency / value buffers keyed by metric name. */
  private readonly histograms = new Map<string, number[]>()
  /** Instantaneous gauge values keyed by metric name. */
  private readonly gauges = new Map<string, number>()

  // ----- Write API ----------------------------------------------------------

  /**
   * Increment a counter by `value` (default 1). Creates the counter on
   * first use.
   */
  incrementCounter(name: string, value = 1): void {
    if (!Number.isFinite(value)) return
    this.counters.set(name, (this.counters.get(name) ?? 0) + value)
  }

  /**
   * Record a single observation into a histogram buffer. Creates the
   * histogram on first use. Non-finite values are silently dropped.
   */
  recordHistogram(name: string, value: number): void {
    if (!Number.isFinite(value)) return
    let arr = this.histograms.get(name)
    if (arr === undefined) {
      arr = []
      this.histograms.set(name, arr)
    }
    arr.push(value)
  }

  /**
   * Set a gauge to an absolute value. Gauges represent instantaneous
   * measurements (queue depth, active connections, cache size, etc.).
   */
  setGauge(name: string, value: number): void {
    if (!Number.isFinite(value)) return
    this.gauges.set(name, value)
  }

  // ----- Read API -----------------------------------------------------------

  /** Return the current value of a counter (0 if never recorded). */
  getCounter(name: string): number {
    return this.counters.get(name) ?? 0
  }

  /** Return aggregate stats for a histogram (empty stats if never recorded). */
  getHistogram(name: string): HistogramStats {
    const arr = this.histograms.get(name)
    if (arr === undefined || arr.length === 0) {
      return { ...EMPTY_HISTOGRAM }
    }
    return computeHistogramStats(arr)
  }

  /** Return the current gauge value (0 if never set). */
  getGauge(name: string): number {
    return this.gauges.get(name) ?? 0
  }

  // ----- Bulk operations ----------------------------------------------------

  /**
   * Return the number of distinct metric names currently tracked
   * (counters + histograms + gauges). Used by the module status surface.
   */
  getMetricCount(): number {
    return this.counters.size + this.histograms.size + this.gauges.size
  }

  /**
   * Produce a JSON-serializable snapshot of all metrics. The returned object
   * has no `Map` instances and is safe to embed in an HTTP response.
   */
  snapshot(): Record<string, unknown> {
    const counters: Record<string, number> = {}
    for (const [k, v] of this.counters.entries()) counters[k] = v

    const histograms: Record<string, HistogramStats> = {}
    for (const [k, arr] of this.histograms.entries()) {
      histograms[k] = computeHistogramStats(arr)
    }

    const gauges: Record<string, number> = {}
    for (const [k, v] of this.gauges.entries()) gauges[k] = v

    return {
      timestamp: Date.now(),
      counters,
      histograms,
      gauges,
      metricCount: this.getMetricCount(),
    }
  }

  /** Clear all counters, histograms, and gauges. */
  reset(): void {
    this.counters.clear()
    this.histograms.clear()
    this.gauges.clear()
  }
}

// ----- Helpers --------------------------------------------------------------

/**
 * Compute aggregate stats from a non-empty array of numbers. Sorts a copy
 * so the caller's buffer is not mutated.
 */
function computeHistogramStats(values: number[]): HistogramStats {
  const n = values.length
  if (n === 0) {
    return { ...EMPTY_HISTOGRAM }
  }
  // Sort a copy so we don't mutate the original insertion-order buffer.
  const sorted = [...values].sort((a, b) => a - b)
  let sum = 0
  for (const v of sorted) sum += v
  return {
    count: n,
    min: sorted[0],
    max: sorted[n - 1],
    mean: sum / n,
    p50: percentile(sorted, 0.5),
    p95: percentile(sorted, 0.95),
    p99: percentile(sorted, 0.99),
  }
}

/**
 * Look up the `q`-th quantile (0 <= q <= 1) in a pre-sorted ascending array.
 * Uses the "nearest rank" method (rounding up) which matches common
 * observability tooling (Prometheus, OpenTelemetry default).
 */
function percentile(sorted: number[], q: number): number {
  const n = sorted.length
  if (n === 0) return 0
  if (n === 1) return sorted[0]
  // Nearest-rank: index = ceil(q * n) - 1, clamped to [0, n-1].
  const idx = Math.min(n - 1, Math.max(0, Math.ceil(q * n) - 1))
  return sorted[idx]
}
