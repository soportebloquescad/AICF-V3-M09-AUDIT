// =============================================================================
// AICF V3 — POST /api/chat
// =============================================================================
// Route Handler for chat completions.
//
// Architecture:
//   React → POST /api/chat → AIService → LiteLLMAdapter → LiteLLM → Provider
//
// The route handler ONLY:
//   1. Validates the request (Zod)
//   2. Calls AIService
//   3. Returns the response
//
// It contains NO business logic and NO direct LiteLLM calls.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { AIService } from '@/lib/ai/AIService'
import { AIAdapterError } from '@/lib/ai/AIAdapter'
import { chatRequestSchema, chatResponseSchema } from '@/lib/ai/schemas/chat'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

/**
 * POST /api/chat
 *
 * Body:
 *   {
 *     "model": "groq-llama-3.3-70b",
 *     "messages": [{ "role": "user", "content": "Hello" }],
 *     "temperature": 0.7,
 *     "maxTokens": 1024
 *   }
 *
 * Response:
 *   {
 *     "content": "Hello! How can I help you?",
 *     "model": "groq-llama-3.3-70b",
 *     "provider": "litellm",
 *     "usage": { "promptTokens": 10, "completionTokens": 8, "totalTokens": 18 },
 *     "durationMs": 523
 *   }
 */
export async function POST(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/api/chat', method: 'POST' })

  // 1. Parse body
  let body: unknown
  try {
    body = await request.json()
  } catch {
    reqLogger.warn('Invalid JSON body')
    return NextResponse.json(
      { error: 'Invalid JSON body' },
      { status: 400 },
    )
  }

  // 2. Validate with Zod
  const parsed = chatRequestSchema.safeParse(body)
  if (!parsed.success) {
    reqLogger.warn({ errors: parsed.error.flatten() }, 'Request validation failed')
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten() },
      { status: 422 },
    )
  }

  // 3. Call AIService (never calls LiteLLM directly)
  const service = new AIService()
  try {
    reqLogger.info({ model: parsed.data.model }, 'Calling AIService.chat')

    const result = await service.chat({
      model: parsed.data.model,
      messages: parsed.data.messages,
      temperature: parsed.data.temperature,
      maxTokens: parsed.data.maxTokens,
      topP: parsed.data.topP,
      stop: parsed.data.stop,
      stream: parsed.data.stream,
    })

    // 4. Validate response shape
    const validated = chatResponseSchema.safeParse(result)
    if (!validated.success) {
      reqLogger.error({ errors: validated.error.flatten() }, 'Response validation failed')
      return NextResponse.json(
        { error: 'Internal response validation error' },
        { status: 500 },
      )
    }

    reqLogger.info({ model: result.model, durationMs: result.durationMs }, 'Chat completed')

    return NextResponse.json(validated.data)
  } catch (err) {
    // 5. Handle typed errors — never expose stack traces
    if (err instanceof AIAdapterError) {
      reqLogger.warn(
        { code: err.code, statusCode: err.statusCode, message: err.message },
        'AI adapter error',
      )
      return NextResponse.json(
        { error: err.message, code: err.code },
        { status: err.statusCode },
      )
    }

    // Unknown errors — log full detail, return generic message
    reqLogger.error(
      { err: err instanceof Error ? err.message : String(err) },
      'Unexpected error in /api/chat',
    )
    return NextResponse.json(
      { error: 'An unexpected error occurred' },
      { status: 500 },
    )
  }
}

/**
 * GET /api/chat — returns available models.
 */
export async function GET() {
  const reqLogger = logger.child({ endpoint: '/api/chat', method: 'GET' })

  try {
    const service = new AIService()
    const models = await service.models()
    reqLogger.info({ count: models.length }, 'Models retrieved')
    return NextResponse.json({ models })
  } catch (err) {
    if (err instanceof AIAdapterError) {
      return NextResponse.json(
        { error: err.message, code: err.code },
        { status: err.statusCode },
      )
    }
    reqLogger.error(
      { err: err instanceof Error ? err.message : String(err) },
      'Unexpected error listing models',
    )
    return NextResponse.json(
      { error: 'An unexpected error occurred' },
      { status: 500 },
    )
  }
}
