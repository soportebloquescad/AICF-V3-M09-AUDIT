// =============================================================================
// AICF V3 — RuntimeAdapter Tests (Sprint 4: Fallback Rule)
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { RuntimeAdapter } from '@/lib/ai/RuntimeAdapter'
import { AIAdapterError } from '@/lib/ai/AIAdapter'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'
import { RuntimeService } from '@/lib/runtime/services/RuntimeService'
import type { RuntimeResponse } from '@/lib/runtime/contracts/RuntimeResponse'

/** Mock AIAdapter for testing. */
class MockAdapter implements AIAdapter {
  chatCalled = false
  modelsCalled = false

  async chat(request: ChatRequest): Promise<ChatResponse> {
    this.chatCalled = true
    return {
      content: 'Mock response',
      model: request.model,
      provider: 'mock',
      usage: { promptTokens: 10, completionTokens: 5, totalTokens: 15 },
      durationMs: 42,
    }
  }

  async models(): Promise<AIModel[]> {
    this.modelsCalled = true
    return [{ id: 'mock-model', provider: 'mock' }]
  }

  async health(): Promise<AIHealth> {
    return { healthy: true, provider: 'mock' }
  }
}

describe('RuntimeAdapter', () => {
  it('should implement AIAdapter interface', () => {
    const adapter = new RuntimeAdapter({ fallback: new MockAdapter() })

    expect(typeof adapter.chat).toBe('function')
    expect(typeof adapter.models).toBe('function')
    expect(typeof adapter.health).toBe('function')
  })

  it('should return a response from the fallback when no modules are wired', async () => {
    const mock = new MockAdapter()
    const adapter = new RuntimeAdapter({ fallback: mock })

    const result = await adapter.chat({
      model: 'groq-llama-3.3-70b',
      messages: [{ role: 'user', content: 'Hello' }],
    })

    expect(result.content).toBe('Mock response')
    expect(result.provider).toBe('mock')
    expect(mock.chatCalled).toBe(true)
  })

  it('should return models from the fallback', async () => {
    const mock = new MockAdapter()
    const adapter = new RuntimeAdapter({ fallback: mock })

    const models = await adapter.models()

    expect(models.length).toBe(1)
    expect(models[0].id).toBe('mock-model')
    expect(mock.modelsCalled).toBe(true)
  })

  it('should report health including fallback', async () => {
    const adapter = new RuntimeAdapter({ fallback: new MockAdapter() })

    const health = await adapter.health()

    expect(health.healthy).toBe(true)
    expect(health.provider).toBe('runtime')
  })
})

// =============================================================================
// Sprint 4 — Fallback Rule Tests
// =============================================================================
// Fallback to LiteLLMAdapter ONLY when the Runtime is unavailable.
// Functional errors (response.ok === false) must throw AIAdapterError,
// NOT silently fall back. This prevents masking Runtime issues.
// =============================================================================

/**
 * A RuntimeService mock that returns a controlled response.
 */
class MockRuntimeService extends RuntimeService {
  private readonly mockResponse: RuntimeResponse
  private readonly shouldThrow: boolean

  constructor(opts: { response?: RuntimeResponse; shouldThrow?: boolean }) {
    super()
    this.mockResponse = opts.response || {
      ok: true,
      requestId: 'req-mock',
      correlationId: 'corr-mock',
      durationMs: 10,
      content: 'Runtime pipeline response',
      model: 'runtime-model',
      provider: 'runtime',
      usage: { promptTokens: 10, completionTokens: 20, totalTokens: 30 },
    }
    this.shouldThrow = opts.shouldThrow ?? false
  }

  async initialize(): Promise<void> {
    // no-op
  }

  async execute(): Promise<RuntimeResponse> {
    if (this.shouldThrow) {
      throw new Error('Runtime execute failed — Runtime unavailable')
    }
    return this.mockResponse
  }
}

describe('RuntimeAdapter Sprint 4 — Fallback Rule', () => {
  it('returns the pipeline response when Runtime succeeds', async () => {
    const mock = new MockAdapter()
    const service = new MockRuntimeService({
      response: {
        ok: true,
        requestId: 'req-1',
        correlationId: 'corr-1',
        durationMs: 15,
        content: 'Pipeline success',
        model: 'runtime-model',
        provider: 'runtime',
        usage: { promptTokens: 5, completionTokens: 10, totalTokens: 15 },
      },
    })
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    const result = await adapter.chat({
      model: 'test-model',
      messages: [{ role: 'user', content: 'hi' }],
    })

    expect(result.content).toBe('Pipeline success')
    expect(result.provider).toBe('runtime')
    // Fallback was NOT called
    expect(mock.chatCalled).toBe(false)
  })

  it('falls back to LiteLLMAdapter when RuntimeService.execute() throws', async () => {
    const mock = new MockAdapter()
    const service = new MockRuntimeService({ shouldThrow: true })
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    const result = await adapter.chat({
      model: 'test-model',
      messages: [{ role: 'user', content: 'hi' }],
    })

    // Fallback was called because Runtime threw
    expect(mock.chatCalled).toBe(true)
    expect(result.content).toBe('Mock response')
    expect(result.provider).toBe('mock')
  })

  it('throws AIAdapterError when pipeline returns functional error (response.ok=false)', async () => {
    const mock = new MockAdapter()
    const service = new MockRuntimeService({
      response: {
        ok: false,
        requestId: 'req-2',
        correlationId: 'corr-2',
        durationMs: 5,
        error: 'Stage Validation failed: model is required',
        errorCode: 'VALIDATION_ERROR',
      },
    })
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    await expect(
      adapter.chat({
        model: 'test-model',
        messages: [{ role: 'user', content: 'hi' }],
      }),
    ).rejects.toThrow(AIAdapterError)

    // Fallback was NOT called — functional errors don't trigger fallback
    expect(mock.chatCalled).toBe(false)
  })

  it('throws AIAdapterError when pipeline returns ok=true but no content', async () => {
    const mock = new MockAdapter()
    const service = new MockRuntimeService({
      response: {
        ok: true,
        requestId: 'req-3',
        correlationId: 'corr-3',
        durationMs: 5,
        content: undefined,
      },
    })
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    await expect(
      adapter.chat({
        model: 'test-model',
        messages: [{ role: 'user', content: 'hi' }],
      }),
    ).rejects.toThrow(AIAdapterError)

    expect(mock.chatCalled).toBe(false)
  })

  it('falls back when Runtime initialization throws', async () => {
    const mock = new MockAdapter()
    // Create a service that throws on initialize
    class InitFailService extends MockRuntimeService {
      async initialize(): Promise<void> {
        throw new Error('Runtime init failed')
      }
    }
    const service = new InitFailService({})
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    const result = await adapter.chat({
      model: 'test-model',
      messages: [{ role: 'user', content: 'hi' }],
    })

    // Fallback was called because Runtime init failed
    expect(mock.chatCalled).toBe(true)
    expect(result.content).toBe('Mock response')
  })

  it('includes the pipeline error message in the thrown AIAdapterError', async () => {
    const mock = new MockAdapter()
    const service = new MockRuntimeService({
      response: {
        ok: false,
        requestId: 'req-4',
        correlationId: 'corr-4',
        durationMs: 5,
        error: 'Module not registered for createCourse',
        errorCode: 'MODULE_NOT_FOUND',
      },
    })
    const adapter = new RuntimeAdapter({ fallback: mock, runtimeService: service })

    try {
      await adapter.chat({
        model: 'test-model',
        messages: [{ role: 'user', content: 'hi' }],
      })
      expect.unreachable('Should have thrown')
    } catch (err) {
      expect(err).toBeInstanceOf(AIAdapterError)
      const adapterErr = err as AIAdapterError
      expect(adapterErr.message).toContain('Module not registered')
    }
  })
})
