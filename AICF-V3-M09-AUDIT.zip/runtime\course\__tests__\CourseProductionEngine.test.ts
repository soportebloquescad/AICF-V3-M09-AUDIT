// =============================================================================
// AICF V3 — Épica 6 — Course Production Engine Tests
// =============================================================================
import { describe, test, expect } from 'bun:test'
import { CourseJobStore, computeRequestHash, isValidTransition, STAGE_ORDER } from '../CourseJobStore'
import { CourseArtifactRegistry } from '../CourseArtifactRegistry'
import { ResearchEngine } from '../ResearchEngine'
import { KnowledgeBase } from '../KnowledgeBase'
import { CourseMemory } from '../CourseMemory'
import { CourseMemoryManager } from '../CourseMemoryManager'
import { PromptOrchestrator } from '../PromptOrchestrator'
import { ContentGenerator } from '../ContentGenerator'
import { AgentCoordinator } from '../AgentCoordinator'
import { ConsistencyEngine } from '../ConsistencyEngine'
import { AssetGenerator } from '../AssetGenerator'
import { ExportEngine } from '../ExportEngine'
import { QualityGates } from '../QualityGates'

// ---------------------------------------------------------------------------
// ResearchEngine
// ---------------------------------------------------------------------------
describe('ResearchEngine', () => {
  test('research returns 5+ key facts', async () => {
    const engine = new ResearchEngine({ aiAdapter: null })
    const result = await engine.research('Marketing Digital', 'es-PE')
    expect(result.keyFacts.length).toBeGreaterThanOrEqual(5)
  })

  test('research sources have confidence 0.5-0.95', async () => {
    const engine = new ResearchEngine({ aiAdapter: null })
    const result = await engine.research('Test Topic', 'en-US')
    for (const s of result.sources) {
      expect(s.confidence).toBeGreaterThanOrEqual(0.5)
      expect(s.confidence).toBeLessThanOrEqual(0.95)
    }
  })

  test('research provider is runtime-adapter', async () => {
    const engine = new ResearchEngine({ aiAdapter: null })
    const result = await engine.research('Test', 'en-US')
    for (const s of result.sources) {
      expect(s.provider).toBe('runtime-adapter')
    }
  })

  test('validateSource returns valid for non-empty content', async () => {
    const engine = new ResearchEngine({ aiAdapter: null })
    const result = await engine.research('Test', 'en-US')
    const validation = await engine.validateSource(result.sources[0])
    expect(validation.valid).toBe(true)
  })

  test('deterministic mode produces same output for same input', async () => {
    const engine = new ResearchEngine({ aiAdapter: null })
    const r1 = await engine.research('Same Topic', 'en-US')
    const r2 = await engine.research('Same Topic', 'en-US')
    expect(r1.keyFacts).toEqual(r2.keyFacts)
  })
})

// ---------------------------------------------------------------------------
// KnowledgeBase
// ---------------------------------------------------------------------------
describe('KnowledgeBase', () => {
  test('store + retrieve round-trip', async () => {
    const kb = new KnowledgeBase({ courseId: 'test-1' })
    await kb.store({ courseId: 'test-1', key: 'fact-1', value: 'Test fact', type: 'fact', confidence: 0.8, source: { id: 's1', title: 'Source', content: 'content', confidence: 0.8, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' } })
    const entry = await kb.retrieve('fact-1')
    expect(entry).not.toBeNull()
    expect(entry?.value).toBe('Test fact')
  })

  test('search by substring', async () => {
    const kb = new KnowledgeBase({ courseId: 'test-2' })
    await kb.store({ courseId: 'test-2', key: 'term:marketing', value: 'Marketing is the process of promoting products', type: 'definition', confidence: 0.9, source: { id: 's', title: 'S', content: 'c', confidence: 0.9, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' } })
    const results = await kb.search('Marketing')
    expect(results.length).toBeGreaterThanOrEqual(1)
  })

  test('listByType filters correctly', async () => {
    const kb = new KnowledgeBase({ courseId: 'test-3' })
    await kb.store({ courseId: 'test-3', key: 'f1', value: 'v1', type: 'fact', confidence: 0.8, source: { id: 's', title: 'S', content: 'c', confidence: 0.8, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' } })
    await kb.store({ courseId: 'test-3', key: 'd1', value: 'v2', type: 'definition', confidence: 0.8, source: { id: 's', title: 'S', content: 'c', confidence: 0.8, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' } })
    const facts = await kb.listByType('fact')
    expect(facts.length).toBe(1)
  })

  test('export returns all entries', async () => {
    const kb = new KnowledgeBase({ courseId: 'test-4' })
    await kb.store({ courseId: 'test-4', key: 'k1', value: 'v1', type: 'fact', confidence: 0.8, source: { id: 's', title: 'S', content: 'c', confidence: 0.8, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' } })
    const exported = await kb.export()
    expect(Object.keys(exported).length).toBe(1)
  })
})

// ---------------------------------------------------------------------------
// ContentGenerator
// ---------------------------------------------------------------------------
describe('ContentGenerator', () => {
  const promptOrchestrator = new PromptOrchestrator()
  const generator = new ContentGenerator({ aiAdapter: null, promptOrchestrator })

  test('generateCourse produces content (fallback)', async () => {
    const result = await generator.generateCourse({ topic: 'Marketing Digital', level: 'intermediate', moduleCount: 5, locale: 'en' })
    expect(result.wordCount).toBeGreaterThan(100)
    expect(result.content).toContain('Marketing Digital')
  })

  test('generateLesson produces 500+ words (fallback)', async () => {
    const result = await generator.generateLesson({ topic: 'Marketing', moduleTitle: 'Module 1', lessonTitle: 'Lesson 1', level: 'intermediate', bloomLevel: 'Understand', length: 'standard', locale: 'en' })
    expect(result.wordCount).toBeGreaterThanOrEqual(100)
  })

  test('deterministic mode is deterministic', async () => {
    const r1 = await generator.generateCourse({ topic: 'Test', level: 'beginner', moduleCount: 3, locale: 'en' })
    const r2 = await generator.generateCourse({ topic: 'Test', level: 'beginner', moduleCount: 3, locale: 'en' })
    expect(r1.content).toBe(r2.content)
  })
})

// ---------------------------------------------------------------------------
// AgentCoordinator
// ---------------------------------------------------------------------------
describe('AgentCoordinator', () => {
  test('coordinate runs agents sequentially', async () => {
    const coord = new AgentCoordinator({ aiAdapter: null })
    coord.registerAgent({
      name: 'test-agent',
      async execute(input) {
        return { agentName: 'test-agent', result: { received: true }, durationMs: 1, success: true }
      },
    })
    const result = await coord.coordinate({ topic: 'Test', locale: 'en', level: 'intermediate', audience: 'learners', moduleCount: 3, context: {} })
    expect(result.outputs.length).toBe(1)
    expect(result.outputs[0].agentName).toBe('test-agent')
    expect(result.outputs[0].success).toBe(true)
  })

  test('listAgents returns registered names', () => {
    const coord = new AgentCoordinator({ aiAdapter: null })
    coord.registerAgent({ name: 'a1', async execute() { return { agentName: 'a1', result: {}, durationMs: 0, success: true } } })
    coord.registerAgent({ name: 'a2', async execute() { return { agentName: 'a2', result: {}, durationMs: 0, success: true } } })
    expect(coord.listAgents()).toEqual(['a1', 'a2'])
  })
})

// ---------------------------------------------------------------------------
// ExportEngine
// ---------------------------------------------------------------------------
describe('ExportEngine', () => {
  const engine = new ExportEngine()

  test('exportAll produces 11 formats', () => {
    const results = engine.exportAll({ content: '# Test\n\nContent here.', metadata: { title: 'Test' } })
    expect(results.length).toBe(11)
  })

  test('each format is non-empty', () => {
    const results = engine.exportAll({ content: '# Test\n\nContent.' })
    for (const r of results) {
      expect(r.content.length).toBeGreaterThan(0)
    }
  })

  test('markdown passthrough preserves content', () => {
    const result = engine.export({ content: '# Hello World\n\nThis is content.', format: 'markdown' })
    expect(result.content).toContain('# Hello World')
  })

  test('HTML export has DOCTYPE', () => {
    const result = engine.export({ content: '# Test', format: 'html' })
    expect(result.content).toContain('<!DOCTYPE')
  })

  test('JSON export parses successfully', () => {
    const result = engine.export({ content: '# Test', format: 'json', metadata: { title: 'Test' } })
    expect(() => JSON.parse(result.content)).not.toThrow()
  })
})

// ---------------------------------------------------------------------------
// QualityGates
// ---------------------------------------------------------------------------
describe('QualityGates', () => {
  const gates = new QualityGates()

  test('validate returns score 0-100', async () => {
    const result = await gates.validate({ courseMd: '# Test\n\nContent.', wordCount: 100, estimatedTokens: 200, budget: 1.0 })
    expect(result.score).toBeGreaterThanOrEqual(0)
    expect(result.score).toBeLessThanOrEqual(100)
  })

  test('pedagogical has 13 fields', async () => {
    const result = await gates.validate({ courseMd: '# Test', wordCount: 100, estimatedTokens: 200, budget: 1.0 })
    const pedKeys = Object.keys(result.pedagogical).filter((k) => k !== 'issues')
    expect(pedKeys.length).toBe(13)
  })

  test('technical has 11 fields', async () => {
    const result = await gates.validate({ courseMd: '# Test', wordCount: 100, estimatedTokens: 200, budget: 1.0 })
    const techKeys = Object.keys(result.technical).filter((k) => k !== 'issues')
    expect(techKeys.length).toBe(11)
  })
})

// ---------------------------------------------------------------------------
// CourseMemoryManager
// ---------------------------------------------------------------------------
describe('CourseMemoryManager', () => {
  test('saveState + loadState round-trip', async () => {
    const mgr = new CourseMemoryManager({ courseId: 'test-1' })
    await mgr.saveState('research', { facts: 5 })
    const state = await mgr.loadState()
    expect(state).not.toBeNull()
    expect(state?.facts).toBe(5)
  })

  test('canResume returns true after checkpoint', async () => {
    const mgr = new CourseMemoryManager({ courseId: 'test-2' })
    expect(await mgr.canResume()).toBe(false)
    await mgr.saveState('research', {})
    expect(await mgr.canResume()).toBe(true)
  })
})

// ---------------------------------------------------------------------------
// CourseJobStore
// ---------------------------------------------------------------------------
describe('CourseJobStore', () => {
  test('create + get round-trip', async () => {
    await CourseJobStore.clear()
    const job = await CourseJobStore.create({
      title: 'Test', locale: 'es-PE', country: 'Peru', audience: 'Emprendedores', level: 'Intermedio',
      objective: 'Test', certification: { finalExam: true, rubrics: false, certificate: false, badges: false, finalProject: false },
      contentTypes: ['presentation'], premiumLevel: 'Standard', model: 'Auto', budget: 0, mode: 'Balanceado', modules: 3,
    })
    const fetched = await CourseJobStore.get(job.id)
    expect(fetched).not.toBeNull()
    expect(fetched?.request.title).toBe('Test')
  })

  test('computeRequestHash is deterministic', () => {
    const req = { title: 'Test', locale: 'es-PE', country: 'Peru', audience: 'All', level: 'Intermedio' as const, objective: '', certification: { finalExam: false, rubrics: false, certificate: false, badges: false, finalProject: false }, contentTypes: [] as never[], premiumLevel: 'Standard' as const, model: 'Auto' as const, budget: 0, mode: 'Balanceado' as const }
    expect(computeRequestHash(req)).toBe(computeRequestHash(req))
  })

  test('isValidTransition pending → running is valid', () => {
    expect(isValidTransition('pending', 'running')).toBe(true)
  })

  test('STAGE_ORDER has 10 stages', () => {
    expect(STAGE_ORDER.length).toBe(10)
  })
})

// ---------------------------------------------------------------------------
// Other modules
// ---------------------------------------------------------------------------
describe('PromptOrchestrator', () => {
  test('build produces system + user prompts', () => {
    const po = new PromptOrchestrator()
    const result = po.build('curriculum', { topic: 'Test', moduleCount: 5, level: 'intermediate' })
    expect(result.system.length).toBeGreaterThan(0)
    expect(result.user.length).toBeGreaterThan(0)
  })

  test('listTemplates returns 8 templates', () => {
    const po = new PromptOrchestrator()
    expect(po.listTemplates().length).toBe(8)
  })
})

describe('ConsistencyEngine', () => {
  test('validate returns score 0-100', async () => {
    const engine = new ConsistencyEngine()
    const result = await engine.validate({ content: '# Test\n\nContent about testing.' })
    expect(result.score).toBeGreaterThanOrEqual(0)
    expect(result.score).toBeLessThanOrEqual(100)
  })
})

describe('AssetGenerator', () => {
  test('generateAll produces 9 assets', async () => {
    const gen = new AssetGenerator()
    const assets = await gen.generateAll({ title: 'Test', description: 'Test description' })
    expect(assets.length).toBe(9)
  })

  test('SVG asset contains <svg> tag', async () => {
    const gen = new AssetGenerator()
    const asset = await gen.generate({ type: 'svg', title: 'Test', description: 'Test' })
    expect(asset.content).toContain('<svg')
  })
})
