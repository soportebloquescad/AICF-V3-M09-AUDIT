// =============================================================================
// AICF V3 — Business Capability Registry (Épica 2 — AI Factory Core, B6)
// =============================================================================
// Indexes Capability descriptors (B1) by name and by module id. This is
// SEPARATE from the Runtime-layer CapabilityRegistry — the Business layer
// is a new tier and uses structured Capability objects (with input/output
// schemas + version) rather than plain string capability lists.
//
// Operations:
//   - register(moduleId, capability)         → index a capability for a module.
//   - unregister(moduleId)                   → drop every capability owned by moduleId.
//   - getCapability(name)                    → fetch a Capability by name (or null).
//   - getModuleForCapability(name)           → fetch the moduleId that owns a capability (or null).
//   - listCapabilities()                     → every registered Capability.
//   - listByModule(moduleId)                 → every Capability owned by moduleId.
//
// Resolution rules:
//   - A capability name is owned by AT MOST ONE module. If a second module
//     tries to register the same name, the registry throws (do NOT silently
//     overwrite — conflicts indicate a manifest bug).
//   - unregister(moduleId) drops every capability owned by that module.
//
// No `any`.
// =============================================================================

import type { Capability } from '../contracts/Capability'
import { logger } from '@/lib/ai/logger'

/**
 * In-memory registry that indexes Capability descriptors by name + by
 * module id.
 *
 * @example
 * const caps = new BusinessCapabilityRegistry()
 * caps.register('course', createCapability('createCourse', 'Generate a course'))
 * caps.register('course', createCapability('exportCourse', 'Export a course'))
 * caps.register('quiz', createCapability('createQuiz', 'Generate a quiz'))
 *
 * caps.getCapability('createCourse')          // → Capability
 * caps.getModuleForCapability('createCourse') // → 'course'
 * caps.listByModule('course')                 // → [createCourse, exportCourse]
 */
export class BusinessCapabilityRegistry {
  /** Capability name → Capability descriptor. */
  private readonly byName = new Map<string, Capability>()
  /** Capability name → module id that owns it. */
  private readonly nameToModule = new Map<string, string>()
  /** Module id → set of capability names owned by that module. */
  private readonly moduleToNames = new Map<string, Set<string>>()

  /**
   * Registers a capability for a module. Throws if the capability name is
   * already owned by a different module (use unregister() first to
   * re-assign).
   */
  register(moduleId: string, capability: Capability): void {
    const existingOwner = this.nameToModule.get(capability.name)
    if (existingOwner !== undefined && existingOwner !== moduleId) {
      const msg =
        `BusinessCapabilityRegistry: capability '${capability.name}' is already ` +
        `owned by module '${existingOwner}' — refusing to reassign to '${moduleId}'`
      logger.error({ moduleId, capability: capability.name, existingOwner }, msg)
      throw new Error(msg)
    }

    this.byName.set(capability.name, capability)
    this.nameToModule.set(capability.name, moduleId)

    let names = this.moduleToNames.get(moduleId)
    if (!names) {
      names = new Set<string>()
      this.moduleToNames.set(moduleId, names)
    }
    names.add(capability.name)

    logger.debug(
      { moduleId, capability: capability.name, version: capability.version },
      'BusinessCapabilityRegistry: capability registered',
    )
  }

  /**
   * Drops every capability owned by moduleId. No-op if the module owns
   * nothing.
   */
  unregister(moduleId: string): void {
    const names = this.moduleToNames.get(moduleId)
    if (!names) return
    for (const name of names) {
      this.byName.delete(name)
      this.nameToModule.delete(name)
    }
    this.moduleToNames.delete(moduleId)
    logger.debug({ moduleId, count: names.size }, 'BusinessCapabilityRegistry: module unregistered')
  }

  /**
   * Returns the Capability with the given name (or null).
   */
  getCapability(name: string): Capability | null {
    return this.byName.get(name) ?? null
  }

  /**
   * Returns the module id that owns the given capability (or null).
   */
  getModuleForCapability(name: string): string | null {
    return this.nameToModule.get(name) ?? null
  }

  /**
   * Returns every registered Capability (insertion order).
   */
  listCapabilities(): Capability[] {
    return Array.from(this.byName.values())
  }

  /**
   * Returns every Capability owned by moduleId (insertion order). Returns
   * an empty array if the module owns nothing.
   */
  listByModule(moduleId: string): Capability[] {
    const names = this.moduleToNames.get(moduleId)
    if (!names) return []
    const out: Capability[] = []
    for (const name of names) {
      const cap = this.byName.get(name)
      if (cap) out.push(cap)
    }
    return out
  }

  /**
   * Returns the list of registered module ids (insertion order). Useful for
   * diagnostics + tests.
   */
  listModuleIds(): string[] {
    return Array.from(this.moduleToNames.keys())
  }

  /**
   * Clears every registration. Mainly for tests.
   */
  clear(): void {
    this.byName.clear()
    this.nameToModule.clear()
    this.moduleToNames.clear()
  }
}
