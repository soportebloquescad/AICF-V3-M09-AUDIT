// =============================================================================
// AICF V3 — Real Module Interfaces
// =============================================================================
// Interfaces for the 6 Runtime modules. These replace the stubs in
// ModuleRegistry. Each module defines its contract without implementation.
// =============================================================================

import type { ChatMessage, ChatUsage, AIModel } from '@/lib/ai/AIAdapter'
import type { RuntimeContext } from '../contracts/RuntimeContext'

// --- Content Intelligence (M08) -------------------------------------------

export interface PolicyDecision {
  allowed: boolean
  reason?: string
  violations?: string[]
}

export interface ProviderRoute {
  provider: string
  model: string
  strategy?: string
}

export interface ContentIntelligenceModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Evaluate request against policy rules. */
  evaluatePolicy(ctx: RuntimeContext): Promise<PolicyDecision>

  /** Select the best provider+model for the request. */
  selectProvider(ctx: RuntimeContext): Promise<ProviderRoute>

  /** Check budget limits. */
  checkBudget(ctx: RuntimeContext): Promise<boolean>
}

// --- Real Generation (M21) -------------------------------------------------

export interface GenerationResult {
  content: string
  model: string
  provider: string
  usage: ChatUsage | null
  durationMs: number
  cached: boolean
}

export interface RealGenerationModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Generate a chat completion. */
  generate(ctx: RuntimeContext): Promise<GenerationResult>

  /** List available models. */
  listModels(): Promise<AIModel[]>
}

// --- Workflow (M04 / n8n) -------------------------------------------------

export interface WorkflowResult {
  ok: boolean
  data?: Record<string, unknown>
  error?: string
  executionId?: string
}

export interface WorkflowModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Execute a workflow by ID. */
  execute(workflowId: string, input: Record<string, unknown>): Promise<WorkflowResult>

  /** List available workflows. */
  list(): Promise<Array<{ id: string; name: string }>>
}

// --- Localization ----------------------------------------------------------

export interface LocalizationModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Translate content to target language. */
  translate(content: string, targetLanguage: string): Promise<string>

  /** Detect the language of content. */
  detectLanguage(content: string): Promise<string>
}

// --- Assets (M06 / M22) ----------------------------------------------------

export interface AssetResult {
  type: string
  name: string
  content: string | Record<string, unknown>
}

export interface AssetsModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Generate an asset (HTML, Markdown, JSON, etc.). */
  generate(type: string, data: Record<string, unknown>): Promise<AssetResult>

  /** List available asset types. */
  listTypes(): string[]
}

// --- Reports (M22) ---------------------------------------------------------

export interface ReportResult {
  type: string
  content: Record<string, unknown>
}

export interface ReportsModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Generate a report from Runtime context. */
  generate(ctx: RuntimeContext): Promise<ReportResult>
}

// --- Infrastructure (M18) --------------------------------------------------

export interface InfrastructureHealth {
  healthy: boolean
  connectors?: Record<string, unknown>
}

export interface InfrastructureModule {
  readonly name: string
  readonly version: string
  isReady(): boolean

  /** Initialize the infrastructure (connectors, etc.). */
  initialize(): Promise<void>

  /** Perform a chat completion via Infrastructure → LiteLLM. */
  completion(request: {
    model: string
    messages: ChatMessage[]
    temperature?: number
    maxTokens?: number
  }): Promise<{
    content: string
    model: string
    provider: string
    usage: ChatUsage | null
    durationMs: number
  }>

  /** List available models via Infrastructure → LiteLLM. */
  models(): Promise<AIModel[]>

  /** Check infrastructure health. */
  health(): Promise<InfrastructureHealth>

  /** Shutdown infrastructure connections. */
  shutdown(): Promise<void>
}
