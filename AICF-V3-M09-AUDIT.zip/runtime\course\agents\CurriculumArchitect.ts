// =============================================================================
// AICF V3 — Curriculum Architect Agent
// =============================================================================
// Designs the module and lesson structure for the course. Produces a
// list of modules, each with a title, summary, and ordered list of
// lessons. The LessonWriter, ExerciseWriter, and SlideGenerator all
// consume this curriculum to align their outputs.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, clamp, elapsedMs, errorToString, extractJSON, normalizeLevel, readContext } from './agentUtils'

export interface CurriculumArchitectDeps {
  aiAdapter: AIAdapter | null
}

interface LessonRef {
  title: string
}

interface ModuleRef {
  title: string
  summary: string
  lessons: LessonRef[]
}

interface CurriculumPayload {
  modules: ModuleRef[]
}

// Curated progression themes. Each module maps to one theme so that
// the deterministic fallback produces a coherent course arc rather
// than generic filler.
const MODULE_THEMES = [
  { title: 'Foundations', summary: 'Introduces the core vocabulary, history, and motivating problems.' },
  { title: 'Core Principles', summary: 'Establishes the fundamental concepts and mental models.' },
  { title: 'Practical Methods', summary: 'Covers the standard workflows and techniques used in practice.' },
  { title: 'Applied Techniques', summary: 'Deepens the methods with real-world scenarios and constraints.' },
  { title: 'Advanced Concepts', summary: 'Explores advanced topics that build on the foundations.' },
  { title: 'Integration', summary: 'Shows how the pieces combine into end-to-end solutions.' },
  { title: 'Specialized Topics', summary: 'Surveys specialized areas relevant to the audience.' },
  { title: 'Industry Context', summary: 'Connects the material to industry standards and expectations.' },
  { title: 'Emerging Trends', summary: 'Examines where the field is heading and why it matters.' },
  { title: 'Case Studies', summary: 'Walks through representative case studies end to end.' },
  { title: 'Evaluation and Critique', summary: 'Develops critical judgment through evaluation exercises.' },
  { title: 'Capstone Synthesis', summary: 'Integrates all prior modules into a capstone-level view.' },
] as const

const LESSON_LABELS = ['Introduction', 'Core Concepts', 'Applied Practice', 'Recap and Synthesis'] as const

export class CurriculumArchitect implements Agent {
  public readonly name = 'curriculum-architect'

  constructor(private readonly deps: CurriculumArchitectDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const research = readContext<{ topic?: string; summary?: string }>(input.context, 'research')
      const design = readContext<{ bloomLevels?: string[] }>(input.context, 'design')
      const moduleCount = clamp(Math.floor(input.moduleCount) || 4, 1, MODULE_THEMES.length)
      const ai = this.deps.aiAdapter
      const aiResult = await callAI(ai, buildPrompt(input, moduleCount, research, design), {
        systemPrompt:
          'You are a curriculum architect. Respond with valid JSON only, no prose.',
        temperature: 0.4,
        maxTokens: 2000,
      })

      let curriculum: CurriculumPayload
      if (aiResult.ok && aiResult.content) {
        const parsed = extractJSON<Partial<CurriculumPayload>>(aiResult.content)
        if (parsed && Array.isArray(parsed.modules) && parsed.modules.length > 0) {
          curriculum = coerceCurriculum(parsed, input, moduleCount)
        } else {
          curriculum = fallbackCurriculum(input, moduleCount)
        }
      } else {
        curriculum = fallbackCurriculum(input, moduleCount)
      }

      return {
        agentName: this.name,
        result: { curriculum },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function buildPrompt(
  input: AgentInput,
  moduleCount: number,
  research: { topic?: string; summary?: string } | null,
  design: { bloomLevels?: string[] } | null,
): string {
  const summary = research?.summary ?? '(no research summary available)'
  const bloom = design?.bloomLevels?.join(', ') ?? '(no design available)'
  return [
    `Design a curriculum for a course on "${input.topic}".`,
    `Audience: ${input.audience}. Level: ${input.level}. Locale: ${input.locale}.`,
    `Number of modules required: ${moduleCount}.`,
    `Research summary: ${summary}`,
    `Target Bloom levels: ${bloom}`,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "modules": [`,
    `    {`,
    `      "title": string,`,
    `      "summary": string,`,
    `      "lessons": [{ "title": string }, ...]   // 3-5 lessons per module`,
    `    }`,
    `  ]`,
    `}`,
  ].join('\n')
}

function coerceCurriculum(
  parsed: Partial<CurriculumPayload>,
  input: AgentInput,
  moduleCount: number,
): CurriculumPayload {
  const modules: ModuleRef[] = []
  for (const raw of parsed.modules ?? []) {
    if (!raw || typeof raw !== 'object') continue
    const title = typeof raw.title === 'string' && raw.title.length > 0 ? raw.title : ''
    const summary = typeof raw.summary === 'string' ? raw.summary : ''
    const lessons: LessonRef[] = []
    if (Array.isArray(raw.lessons)) {
      for (const ls of raw.lessons) {
        if (ls && typeof ls === 'object' && typeof ls.title === 'string' && ls.title.length > 0) {
          lessons.push({ title: ls.title })
        }
      }
    }
    if (title && lessons.length > 0) {
      modules.push({ title, summary, lessons })
    }
  }
  if (modules.length === 0) {
    return fallbackCurriculum(input, moduleCount)
  }
  // Trim or pad to the requested module count.
  if (modules.length > moduleCount) {
    modules.length = moduleCount
  }
  return { modules }
}

function fallbackCurriculum(input: AgentInput, moduleCount: number): CurriculumPayload {
  const topic = input.topic
  const level = normalizeLevel(input.level)
  const modules: ModuleRef[] = []
  for (let i = 0; i < moduleCount; i++) {
    const theme = MODULE_THEMES[i % MODULE_THEMES.length]
    const moduleTitle = `Module ${i + 1}: ${theme.title}`
    const summary = `${theme.summary} Specifically, this module grounds ${topic} for ${input.audience} at the ${level} level.`
    const lessons: LessonRef[] = LESSON_LABELS.map((label) => ({
      title: `${label}: ${theme.title} in ${topic}`,
    }))
    modules.push({ title: moduleTitle, summary, lessons })
  }
  return { modules }
}
