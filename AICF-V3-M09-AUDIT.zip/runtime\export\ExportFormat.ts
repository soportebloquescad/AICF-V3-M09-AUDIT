// =============================================================================
// AICF V3 — Sprint 11C — Canonical ExportFormat type
// =============================================================================
// Single shared definition of export formats supported across the Runtime.
// This is the CANONICAL type — module-local ExportFormat types should
// reference this or be compatible with it.
//
// This type is a superset of all format unions used across the codebase:
//   - CourseRequest: markdown, pdf, pptx, docx, html
//   - ExportManager: zip, markdown, json, docx, html, slides-html
//   - ExportEngine: markdown, html, docx, pdf, pptx, json, scorm12, scorm2004, xapi, moodle, canvas
//   - ReportsModule: json, markdown, csv
// =============================================================================

export type ExportFormat =
  // Documents
  | 'html'
  | 'pdf'
  | 'docx'
  | 'markdown'
  | 'json'
  | 'csv'
  // Presentations
  | 'pptx'
  | 'slides-html'
  | 'revealjs'
  // LMS
  | 'scorm'
  | 'scorm12'
  | 'scorm2004'
  | 'xapi'
  | 'moodle'
  | 'canvas'
  // Resources
  | 'zip'
  | 'xlsx'
  // Marketing
  | 'landing'
  | 'certificate'

/**
 * The set of all supported export formats (useful for validation).
 */
export const ALL_EXPORT_FORMATS: readonly ExportFormat[] = [
  'html', 'pdf', 'docx', 'markdown', 'json', 'csv',
  'pptx', 'slides-html', 'revealjs',
  'scorm', 'scorm12', 'scorm2004', 'xapi', 'moodle', 'canvas',
  'zip', 'xlsx',
  'landing', 'certificate',
] as const

/**
 * Type guard: checks if a string is a valid ExportFormat.
 */
export function isExportFormat(value: string): value is ExportFormat {
  return (ALL_EXPORT_FORMATS as readonly string[]).includes(value)
}