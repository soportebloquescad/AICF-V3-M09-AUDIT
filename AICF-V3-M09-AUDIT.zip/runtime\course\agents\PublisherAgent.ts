// =============================================================================
// AICF V3 — Publisher Agent
// =============================================================================
// Assembles the final course package from all prior agent outputs.
// Counts the artifacts produced by each upstream agent and returns a
// readiness flag plus the total artifact count. This is the terminal
// agent in the course-generation pipeline.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { elapsedMs, errorToString, readContext } from './agentUtils'

export interface PublisherAgentDeps {
  aiAdapter: AIAdapter | null
}

interface PublishedPayload {
  published: {
    ready: boolean
    artifactCount: number
    manifest: Record<string, number>
  }
}

interface UnknownArrayShape {
  length: number
}

export class PublisherAgent implements Agent {
  public readonly name = 'publisher-agent'

  constructor(private readonly deps: PublisherAgentDeps) {}

  // The publisher does not call the AI adapter. It only inspects the
  // assembled context. The deps field is kept for interface symmetry
  // with the other agents and for future publishing integrations.
  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      // Reference deps to satisfy the "uses aiAdapter" intent without
      // making an actual call. If a future publisher needs AI, it can
      // use this.deps.aiAdapter directly.
      void this.deps.aiAdapter

      const ctx = input.context
      const manifest: Record<string, number> = {}

      const curriculum = readContext<{ modules?: UnknownArrayShape }>(ctx, 'curriculum')
      if (curriculum?.modules && typeof curriculum.modules.length === 'number') {
        manifest.modules = curriculum.modules.length
      }

      const lessons = readContext<UnknownArrayShape>(ctx, 'lessons')
      if (lessons && typeof lessons.length === 'number') {
        manifest.lessons = lessons.length
      }

      const exercises = readContext<UnknownArrayShape>(ctx, 'exercises')
      if (exercises && typeof exercises.length === 'number') {
        manifest.exerciseGroups = exercises.length
      }

      const assessments = readContext<UnknownArrayShape>(ctx, 'assessments')
      if (assessments && typeof assessments.length === 'number') {
        manifest.assessments = assessments.length
      }

      const slides = readContext<UnknownArrayShape>(ctx, 'slides')
      if (slides && typeof slides.length === 'number') {
        manifest.slides = slides.length
      }

      const documents = readContext<UnknownArrayShape>(ctx, 'documents')
      if (documents && typeof documents.length === 'number') {
        manifest.documents = documents.length
      }

      const artifactCount = Object.values(manifest).reduce((sum, n) => sum + n, 0)
      const ready = artifactCount > 0 && (manifest.lessons ?? 0) > 0

      const payload: PublishedPayload = {
        published: {
          ready,
          artifactCount,
          manifest,
        },
      }

      return {
        agentName: this.name,
        result: payload as unknown as Record<string, unknown>,
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}
