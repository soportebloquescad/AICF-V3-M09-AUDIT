// =============================================================================
// AICF V3 — Épica 6 — Production Engine
// =============================================================================
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { ResearchEngine, type ResearchResult } from './ResearchEngine'
import { KnowledgeBase } from './KnowledgeBase'
import { CourseMemoryManager } from './CourseMemoryManager'
import { PromptOrchestrator } from './PromptOrchestrator'
import { ContentGenerator, type GeneratedContent } from './ContentGenerator'
import { AgentCoordinator } from './AgentCoordinator'
import { ConsistencyEngine, type ConsistencyResult } from './ConsistencyEngine'
import { AssetGenerator, type GeneratedAsset } from './AssetGenerator'
import { ExportEngine, type ExportResult } from './ExportEngine'
import { QualityGates, type QualityGateResult } from './QualityGates'
import { logger } from '@/lib/ai/logger'

export interface ProductionRequest {
  topic: string
  locale: string
  level: string
  audience: string
  moduleCount: number
  courseId: string
}

export interface ProductionResult {
  courseId: string
  status: 'completed' | 'partial' | 'failed'
  research: ResearchResult | null
  knowledgeEntries: number
  courseContent: GeneratedContent | null
  agentOutputs: Array<{ agentName: string; success: boolean; durationMs: number }>
  consistency: ConsistencyResult | null
  assets: GeneratedAsset[]
  exports: ExportResult[]
  quality: QualityGateResult | null
  wordCount: number
  traceability: Array<{ source: string; confidence: number; content: string }>
  durationMs: number
  error?: string
}

export class ProductionEngine {
  async run(request: ProductionRequest): Promise<ProductionResult> {
    const startMs = Date.now()
    const { topic, locale, level, audience, moduleCount, courseId } = request
    logger.info({ courseId, topic, locale, level, moduleCount }, 'ProductionEngine: starting')

    let aiAdapter: AIAdapter | null = null
    try {
      const { RuntimeAdapter } = await import('@/lib/ai/RuntimeAdapter')
      aiAdapter = new RuntimeAdapter()
    } catch { aiAdapter = null }

    const researchEngine = new ResearchEngine({ aiAdapter })
    const knowledgeBase = new KnowledgeBase({ courseId })
    const memoryManager = new CourseMemoryManager({ courseId })
    const promptOrchestrator = new PromptOrchestrator()
    const contentGenerator = new ContentGenerator({ aiAdapter, promptOrchestrator })
    const agentCoordinator = new AgentCoordinator({ aiAdapter })
    const consistencyEngine = new ConsistencyEngine()
    const assetGenerator = new AssetGenerator()
    const exportEngine = new ExportEngine()
    const qualityGates = new QualityGates()

    const traceability: ProductionResult['traceability'] = []

    try {
      // 1. Research
      const research = await researchEngine.research(topic, locale, 'standard')
      for (const fact of research.keyFacts) {
        await knowledgeBase.store({
          courseId, key: `fact:${fact.slice(0, 50)}`, value: fact, type: 'fact', confidence: 0.8,
          source: { id: 'research', title: 'Research', content: fact, confidence: 0.8, provider: 'runtime-adapter', retrievedAt: new Date(), hash: '', type: 'memory' },
        })
        traceability.push({ source: 'research-engine', confidence: 0.8, content: fact })
      }
      await memoryManager.saveState('research', { facts: research.keyFacts.length })

      // 2. Knowledge Base
      const knowledgeEntries = (await knowledgeBase.listAll()).length
      await memoryManager.saveState('knowledge-base', { entries: knowledgeEntries })

      // 3. Content Generation
      const courseContent = await contentGenerator.generateCourse({ topic, level, moduleCount, locale: locale.split('-')[0] ?? 'en', knowledgeContext: await knowledgeBase.export() })
      await memoryManager.saveState('content-generation', { wordCount: courseContent.wordCount })

      // 4. Multi-Agent Coordination
      const agentResult = await agentCoordinator.coordinate({ topic, locale, level, audience, moduleCount, context: { research, knowledge: await knowledgeBase.export() } })
      const agentOutputs = agentResult.outputs.map((o) => ({ agentName: o.agentName, success: o.success, durationMs: o.durationMs }))
      await memoryManager.saveState('multi-agent', { agents: agentOutputs.length })

      // 5. Consistency
      const consistency = await consistencyEngine.validate({ content: courseContent.content })
      await memoryManager.saveState('consistency', { score: consistency.score })

      // 6. Asset Generation — EPIC 10: pass topic for topic-aware SVG/Mermaid
      const assets = await assetGenerator.generateAll({ title: topic, description: courseContent.title, topic })
      await memoryManager.saveState('assets', { count: assets.length })

      // 7. Quality Gates
      const quality = await qualityGates.validate({ courseMd: courseContent.content, wordCount: courseContent.wordCount, estimatedTokens: courseContent.wordCount * 2, budget: 1.0 })
      await memoryManager.saveState('quality-gates', { passed: quality.passed, score: quality.score })

      // 8. Export Engine
      const exports = exportEngine.exportAll({ content: courseContent.content, metadata: { topic, locale, level, moduleCount, wordCount: courseContent.wordCount } })
      await memoryManager.saveState('export', { formats: exports.length })

      const status: ProductionResult['status'] = quality.passed ? 'completed' : 'partial'
      logger.info({ courseId, status, wordCount: courseContent.wordCount, assets: assets.length, exports: exports.length, quality: quality.score, durationMs: Date.now() - startMs }, 'ProductionEngine: completed')

      return { courseId, status, research, knowledgeEntries, courseContent, agentOutputs, consistency, assets, exports, quality, wordCount: courseContent.wordCount, traceability, durationMs: Date.now() - startMs }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      logger.error({ courseId, error: msg }, 'ProductionEngine: failed')
      return { courseId, status: 'failed', research: null, knowledgeEntries: 0, courseContent: null, agentOutputs: [], consistency: null, assets: [], exports: [], quality: null, wordCount: 0, traceability, durationMs: Date.now() - startMs, error: msg }
    }
  }
}
