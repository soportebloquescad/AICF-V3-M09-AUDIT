// =============================================================================
// AICF V3 — Épica 6 — Quality Gates
// =============================================================================
export interface PedagogicalResult {
  bloom: number
  cefr: number
  addie: number
  backwardDesign: number
  readability: number
  length: number
  repetition: number
  plagiarism: number
  citations: number
  coverage: number
  difficulty: number
  timeEstimate: number
  tokenBudget: number
  issues: string[]
}

export interface TechnicalResult {
  jsonValid: boolean
  markdownValid: boolean
  mermaidValid: boolean
  svgValid: boolean
  plantumlValid: boolean
  linksValid: boolean
  imagesValid: boolean
  htmlValid: boolean
  docxValid: boolean
  pdfValid: boolean
  scormValid: boolean
  issues: string[]
}

export interface QualityGateResult {
  passed: boolean
  score: number
  pedagogical: PedagogicalResult
  technical: TechnicalResult
  issues: string[]
}

export class QualityGates {
  async validate(input: {
    courseMd: string
    quizJson?: string
    presentationHtml?: string
    svgContent?: string
    mermaidContent?: string
    wordCount: number
    estimatedTokens: number
    budget: number
  }): Promise<QualityGateResult> {
    const pedIssues: string[] = []
    const techIssues: string[] = []

    // Pedagogical
    const bloomVerbs = ['define', 'describe', 'explain', 'apply', 'analyze', 'evaluate', 'create', 'identify', 'compare', 'design']
    const bloomCount = bloomVerbs.reduce((count, verb) => count + (input.courseMd.toLowerCase().match(new RegExp(`\\b${verb}`, 'g')) ?? []).length, 0)
    const bloom = Math.min(100, 40 + bloomCount * 3)

    const sentences = input.courseMd.split(/[.!?]+/).filter((s) => s.trim().length > 0)
    const words = input.courseMd.split(/\s+/).filter(Boolean)
    const avgSentenceLen = sentences.length > 0 ? words.length / sentences.length : 0
    const readability = Math.max(0, Math.min(100, 100 - Math.abs(avgSentenceLen - 20) * 2))

    const addieMarkers = ['analysis', 'design', 'development', 'implementation', 'evaluation', 'analyze', 'design', 'develop', 'implement', 'evaluate']
    const addieCount = addieMarkers.reduce((c, m) => c + (input.courseMd.toLowerCase().includes(m) ? 1 : 0), 0)
    const addie = Math.min(100, addieCount * 20)

    const hasObjectives = /objectives?|learning outcomes?|goals?/i.test(input.courseMd)
    const hasAssessment = /assessment|quiz|exercise|evaluation/i.test(input.courseMd)
    const hasContent = words.length > 500
    const backwardDesign = (hasObjectives ? 33 : 0) + (hasAssessment ? 33 : 0) + (hasContent ? 34 : 0)

    const cefr = Math.min(100, 50 + (avgSentenceLen < 25 ? 20 : 0) + (words.length > 1000 ? 20 : 0) + 10)

    const length = input.wordCount >= 3000 ? 100 : input.wordCount >= 1000 ? 70 : input.wordCount >= 500 ? 40 : 20
    if (input.wordCount < 3000) pedIssues.push(`Word count (${input.wordCount}) is below recommended minimum (3000)`)

    const paragraphs = input.courseMd.split(/\n\n+/).filter((p) => p.trim().length > 20)
    const seen = new Set<string>()
    let repeats = 0
    for (const p of paragraphs) {
      const key = p.trim().toLowerCase().slice(0, 100)
      if (seen.has(key)) repeats++
      seen.add(key)
    }
    const repetition = Math.max(0, 100 - repeats * 15)

    const longStrings = input.courseMd.match(/(.{200,})\1/g) ?? []
    const plagiarism = Math.max(0, 100 - longStrings.length * 20)

    const hasCitations = /references?|bibliography|\[\d+\]|\(Author,?\s*\d{4}\)/i.test(input.courseMd)
    const citations = hasCitations ? 80 : 40
    if (!hasCitations) pedIssues.push('No citations or references section found')

    const moduleTitles = input.courseMd.match(/^##\s+.+$/gm) ?? []
    const coveredModules = moduleTitles.length
    const coverage = Math.min(100, 50 + coveredModules * 10)

    const difficulty = Math.min(100, 60 + (bloom > 60 ? 20 : 0) + (readability > 60 ? 20 : 0))

    const timeEstimate = Math.min(100, Math.max(40, Math.round(input.wordCount / 200)))

    const tokenBudget = input.budget > 0 && input.estimatedTokens > 0
      ? Math.min(100, (input.budget * 1000) / input.estimatedTokens * 100)
      : 100
    if (input.budget > 0 && input.estimatedTokens > input.budget * 1000) {
      pedIssues.push(`Estimated tokens (${input.estimatedTokens}) exceed budget (${input.budget * 1000})`)
    }

    // Technical
    let jsonValid = true
    if (input.quizJson) {
      try { JSON.parse(input.quizJson) } catch { jsonValid = false; techIssues.push('Quiz JSON is invalid') }
    }

    const codeBlocks = (input.courseMd.match(/```/g) ?? []).length
    const markdownValid = codeBlocks % 2 === 0
    if (!markdownValid) techIssues.push('Unbalanced code blocks in Markdown')

    const mermaidValid = !input.mermaidContent || /^(graph |sequenceDiagram|classDiagram|flowchart|stateDiagram)/m.test(input.mermaidContent)
    if (!mermaidValid) techIssues.push('Invalid Mermaid syntax')

    const svgValid = !input.svgContent || (input.svgContent.includes('<svg') && input.svgContent.includes('</svg>'))
    if (!svgValid) techIssues.push('Invalid SVG: missing <svg> tags')

    const plantumlValid = !input.courseMd.includes('@startuml') || input.courseMd.includes('@enduml')
    if (!plantumlValid) techIssues.push('PlantUML: @startuml without @enduml')

    const links = input.courseMd.match(/\[([^\]]+)\]\(([^)]+)\)/g) ?? []
    const linksValid = links.every((l) => /\]\(https?:\/\/.+/.test(l))
    if (!linksValid && links.length > 0) techIssues.push('Some markdown links have invalid URLs')

    const images = input.courseMd.match(/!\[([^\]]*)\]\(([^)]+)\)/g) ?? []
    const imagesValid = images.every((i) => /\]\(https?:\/\/.+|!\[.+]\(.+\)/.test(i))
    if (!imagesValid && images.length > 0) techIssues.push('Some image references are invalid')

    const htmlValid = !input.presentationHtml || (input.presentationHtml.includes('<html') || input.presentationHtml.includes('<!DOCTYPE'))
    if (!htmlValid) techIssues.push('Presentation HTML is missing DOCTYPE or <html> tag')

    const docxValid = true
    const pdfValid = true
    const scormValid = true

    const pedScore = (bloom + cefr + addie + backwardDesign + readability + length + repetition + plagiarism + citations + coverage + difficulty + timeEstimate + tokenBudget) / 13
    const techScore = (jsonValid ? 100 : 0) + (markdownValid ? 100 : 0) + (mermaidValid ? 100 : 0) + (svgValid ? 100 : 0) + (plantumlValid ? 100 : 0) + (linksValid ? 100 : 0) + (imagesValid ? 100 : 0) + (htmlValid ? 100 : 0) + (docxValid ? 100 : 0) + (pdfValid ? 100 : 0) + (scormValid ? 100 : 0)
    const techScoreAvg = techScore / 11

    const score = Math.round(pedScore * 0.6 + techScoreAvg * 0.4)
    const allIssues = [...pedIssues, ...techIssues]
    const hasHighSeverity = allIssues.some((i) => i.includes('exceed') || i.includes('invalid') || i.includes('missing'))
    const passed = score >= 70 && !hasHighSeverity

    return {
      passed,
      score,
      pedagogical: { bloom, cefr, addie, backwardDesign, readability, length, repetition, plagiarism, citations, coverage, difficulty, timeEstimate, tokenBudget, issues: pedIssues },
      technical: { jsonValid, markdownValid, mermaidValid, svgValid, plantumlValid, linksValid, imagesValid, htmlValid, docxValid, pdfValid, scormValid, issues: techIssues },
      issues: allIssues,
    }
  }
}
