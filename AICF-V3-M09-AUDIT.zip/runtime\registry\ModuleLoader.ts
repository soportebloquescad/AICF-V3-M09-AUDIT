// =============================================================================
// AICF V3 — Sprint 6 (RC33) — ModuleLoader
// =============================================================================
// Registers the 8 core modules into RuntimeModuleRegistry.
//
// This is the SINGLE place where the 8 core modules are described and
// registered. New modules can be added here without modifying any other file.
//
// The loader does NOT create instances — that happens in
// RuntimeModuleRegistry.initializeAll() via the factory functions.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { ModuleDescriptor } from './ModuleDescriptor'
import type { RuntimeModuleRegistry } from './RuntimeModuleRegistry'
import { getContentEngine } from '@/lib/content-intelligence/ContentEngine'
import { getGlobalArtifactRegistry } from '../artifacts/ArtifactRegistry'
import { CheckpointEngine } from '../checkpoint/CheckpointEngine'
import { WorkerRegistry } from '../workers/WorkerRegistry'
import { ExportManager } from '../export/ExportManager'
import { getGlobalCourseMetrics } from '../metrics/CourseMetrics'
import { CoursePipeline } from '../pipeline/CoursePipeline'
import { getGlobalWorkflowRegistry } from '../workflow/WorkflowRegistry'
import { getGlobalWorkflowEventBus } from '../workflow/WorkflowEventBus'
import { getGlobalWorkflowHistory } from '../workflow/WorkflowHistory'
import { AIService } from '@/lib/ai/AIService'
import { logger } from '@/lib/ai/logger'

/**
 * The 8 core module descriptors.
 */
const CORE_MODULE_DESCRIPTORS: ModuleDescriptor[] = [
  {
    id: 'm08-content-intelligence',
    name: 'Content Intelligence (M08)',
    version: '1.0.0',
    description: 'AI decision engine: provider routing, model selection, policy evaluation',
    capabilities: ['policy', 'routing', 'model-selection', 'decision-plan'],
    dependencies: [],
    priority: 10,
    factory: () => getContentEngine(),
  },
  {
    id: 'm18-infrastructure',
    name: 'Infrastructure (M18)',
    version: '1.0.0',
    description: 'AI execution engine: receives DecisionPlan, calls LiteLLM',
    capabilities: ['chat-completion', 'models', 'health', 'execute-with-plan'],
    dependencies: ['m08-content-intelligence'],
    priority: 20,
    factory: () => ({
      name: 'Infrastructure (M18)',
      version: '1.0.0',
      async executeWithPlan(plan: { model: string; temperature: number; maxTokens: number; topP: number; stop: readonly string[] }, messages: Array<{ role: string; content: string }>) {
        const service = new AIService()
        return service.chat({
          model: plan.model,
          messages: messages as never,
          temperature: plan.temperature,
          maxTokens: plan.maxTokens,
          topP: plan.topP,
          stop: plan.stop.length > 0 ? [...plan.stop] : undefined,
        })
      },
      async health() {
        const service = new AIService()
        return service.health()
      },
    }),
  },
  {
    id: 'artifact-registry',
    name: 'Artifact Registry',
    version: '1.0.0',
    description: 'In-memory artifact storage with global singleton',
    capabilities: ['register', 'get', 'list', 'findByCourse', 'findByType'],
    dependencies: [],
    priority: 30,
    factory: () => getGlobalArtifactRegistry(),
  },
  {
    id: 'checkpoint-engine',
    name: 'Checkpoint Engine',
    version: '1.0.0',
    description: 'Per-stage checkpoints for pipeline resume',
    capabilities: ['save', 'load', 'list', 'resume'],
    dependencies: [],
    priority: 30,
    factory: () => new CheckpointEngine(),
  },
  {
    id: 'worker-registry',
    name: 'Worker Registry',
    version: '1.0.0',
    description: 'Pipeline worker registration and dispatch',
    capabilities: ['register', 'get', 'list', 'health'],
    dependencies: [],
    priority: 30,
    factory: () => new WorkerRegistry(),
  },
  {
    id: 'export-manager',
    name: 'Export Manager',
    version: '1.0.0',
    description: 'ZIP, Markdown, JSON export via archiver',
    capabilities: ['exportZip', 'exportJson', 'exportMarkdown'],
    dependencies: [],
    priority: 30,
    factory: () => new ExportManager(),
  },
  {
    id: 'course-metrics',
    name: 'Course Metrics',
    version: '1.0.0',
    description: 'Course generation metrics: quality, duration, tokens',
    capabilities: ['record', 'getSnapshot', 'count'],
    dependencies: [],
    priority: 30,
    factory: () => getGlobalCourseMetrics(),
  },
  {
    id: 'workflow-registry',
    name: 'Workflow Registry',
    version: '1.0.0',
    description: 'Workflow definition registration and execution dispatch',
    capabilities: ['register', 'get', 'list', 'execute'],
    dependencies: ['m08-content-intelligence'],
    priority: 40,
    factory: () => getGlobalWorkflowRegistry(),
  },
  {
    id: 'workflow-event-bus',
    name: 'Workflow Event Bus',
    version: '1.0.0',
    description: 'Workflow lifecycle events: started, stepStarted, stepCompleted, completed, failed',
    capabilities: ['emit', 'subscribe', 'history'],
    dependencies: [],
    priority: 35,
    factory: () => getGlobalWorkflowEventBus(),
  },
  {
    id: 'workflow-history',
    name: 'Workflow History',
    version: '1.0.0',
    description: 'Execution history: status, duration, step results',
    capabilities: ['record', 'get', 'list', 'stats'],
    dependencies: [],
    priority: 35,
    factory: () => getGlobalWorkflowHistory(),
  },
  {
    id: 'course-pipeline',
    name: 'Course Pipeline',
    version: '1.0.0',
    description: '17-stage course generation orchestrator',
    capabilities: ['execute', 'generate'],
    dependencies: ['m08-content-intelligence', 'artifact-registry', 'checkpoint-engine', 'export-manager', 'course-metrics'],
    priority: 50,
    factory: () => new CoursePipeline(),
  },
]

let loaded = false

/**
 * Registers all 8 core modules into the given RuntimeModuleRegistry.
 */
export function loadCoreModules(registry: RuntimeModuleRegistry): void {
  if (loaded) return
  loaded = true

  for (const descriptor of CORE_MODULE_DESCRIPTORS) {
    registry.register(descriptor)
  }

  logger.info(
    { count: CORE_MODULE_DESCRIPTORS.length, ids: CORE_MODULE_DESCRIPTORS.map((d) => d.id) },
    'ModuleLoader: core modules registered',
  )
}

/**
 * Resets the loaded flag (for tests).
 * @internal
 */
export function _resetModuleLoader(): void {
  loaded = false
}
