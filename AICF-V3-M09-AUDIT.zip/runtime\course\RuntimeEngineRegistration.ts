// =============================================================================
// AICF V3 — Epica 8 — Runtime Engine Registration
// =============================================================================
// Registers all 19 Epica 7+8 engines into an EngineRegistry. The AIFactory
// calls this once during construction to wire the full pipeline.
// =============================================================================
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { EngineRegistry } from './EngineRegistry'
import { ResearchEngine } from './ResearchEngine'
import { createResearchSource } from './ResearchSource'
import { CurriculumBuilder } from './CurriculumBuilder'
import { ModulePlanner } from './ModulePlanner'
import { LessonPlanner } from './LessonPlanner'
import { LessonWriterEngine } from './LessonWriterEngine'
import { ExerciseBuilder } from './ExerciseBuilder'
import { QuizBuilder } from './QuizBuilder'
import { AssessmentBuilder } from './AssessmentBuilder'
import { CaseStudyBuilder } from './CaseStudyBuilder'
import { ChecklistBuilder } from './ChecklistBuilder'
import { TemplateBuilder } from './TemplateBuilder'
import { SlideBuilder } from './SlideBuilder'
import { GuideBuilder } from './GuideBuilder'
import { CourseOrchestrator } from './CourseOrchestrator'
import { QualityAssurance } from './QualityAssurance'
import { prePublishValidators } from './PrePublishValidators'
import { rubricSystem } from './RubricSystem'
import { publishingEngine } from './PublishingEngine'
import { costEngine } from './CostEngine'
import type { CourseRequest, KnowledgePack, CourseResult, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

function nowIso(): string {
  return new Date().toISOString()
}

// -----------------------------------------------------------------------------
// Adapter that wraps the Epica 6 ResearchEngine to implement EngineContract
// and produce a KnowledgePack.
// -----------------------------------------------------------------------------
class ResearchEngineAdapter implements EngineContract {
  readonly name = 'research-engine'
  private readonly researchEngine: ResearchEngine
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {
    this.researchEngine = new ResearchEngine(opts)
  }

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (typeof input !== 'object' || input === null) {
      throw new Error('ResearchEngineAdapter: invalid input — expected { courseRequest }')
    }
    const obj = input as { courseRequest?: CourseRequest }
    if (!obj.courseRequest) {
      throw new Error('ResearchEngineAdapter: courseRequest is required')
    }
    const req = obj.courseRequest
    const result = await this.researchEngine.research(req.topic, req.locale, req.researchDepth)
    const sources = result.sources.map((s) => ({
      id: s.id,
      title: s.title,
      url: s.url,
      content: s.content,
      confidence: s.confidence,
      provider: 'runtime-adapter' as Provider,
      retrievedAt: s.retrievedAt.toISOString(),
      hash: s.hash,
      type: s.type,
    }))
    const now = nowIso()
    const pack: KnowledgePack = {
      id: makeId('kp'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider: 'runtime-adapter',
      model: 'deterministic-fallback',
      runtimeVersion: RUNTIME_VERSION,
      topic: req.topic,
      summary: result.summary,
      sources,
      keyFacts: result.keyFacts,
      gaps: result.gaps,
      confidence: result.confidence,
      depth: req.researchDepth,
      courseRequestId: req.id,
    }
    return pack
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as { courseRequest?: unknown }
    return typeof obj.courseRequest === 'object' && obj.courseRequest !== null
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { engine: this.name } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }
}

// -----------------------------------------------------------------------------
// Adapter that wraps the PrePublishValidators singleton.
// -----------------------------------------------------------------------------
class PrePublishValidatorsEngine implements EngineContract {
  readonly name = 'pre-publish-validators'
  private healthy = false

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (typeof input !== 'object' || input === null) {
      throw new Error('PrePublishValidatorsEngine: invalid input — expected CourseResult')
    }
    const course = input as CourseResult
    return prePublishValidators.validate(course)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    return typeof obj.id === 'string' && Array.isArray(obj.lessons)
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { validators: 8 } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }
}

// -----------------------------------------------------------------------------
// Adapter that wraps the RubricSystem singleton.
// -----------------------------------------------------------------------------
class RubricSystemEngine implements EngineContract {
  readonly name = 'rubric-system'
  private healthy = false

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (typeof input !== 'object' || input === null) {
      throw new Error('RubricSystemEngine: invalid input — expected { content, metadata }')
    }
    const obj = input as { content?: string; metadata?: Record<string, unknown> }
    if (typeof obj.content !== 'string' || typeof obj.metadata !== 'object' || obj.metadata === null) {
      throw new Error('RubricSystemEngine: content (string) and metadata (object) are required')
    }
    return rubricSystem.evaluate(obj.content, {
      topic: String(obj.metadata.topic ?? 'unknown'),
      level: String(obj.metadata.level ?? 'intermediate'),
      locale: String(obj.metadata.locale ?? 'en'),
      audience: String(obj.metadata.audience ?? 'learners'),
      expectedWordCount: typeof obj.metadata.expectedWordCount === 'number' ? obj.metadata.expectedWordCount : undefined,
      moduleCount: typeof obj.metadata.moduleCount === 'number' ? obj.metadata.moduleCount : undefined,
      lessonCount: typeof obj.metadata.lessonCount === 'number' ? obj.metadata.lessonCount : undefined,
    })
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as { content?: unknown; metadata?: unknown }
    return typeof obj.content === 'string' && typeof obj.metadata === 'object' && obj.metadata !== null
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { criteria: 8 } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }
}

// -----------------------------------------------------------------------------
// Adapter that wraps the PublishingEngine singleton.
// -----------------------------------------------------------------------------
class PublishingEngineEngine implements EngineContract {
  readonly name = 'publishing-engine'
  private healthy = false

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (typeof input !== 'object' || input === null) {
      throw new Error('PublishingEngineEngine: invalid input — expected CourseResult')
    }
    const course = input as CourseResult
    if (!course.zipBuffer) {
      return { skipped: true, reason: 'No ZIP buffer available for publishing' }
    }
    return publishingEngine.publish({
      target: 'api',
      destination: 'https://api.aicf.example.com/v1/courses',
      options: { apiKey: 'internal', courseId: course.id },
      payload: {
        courseId: course.id,
        title: course.title,
        zipBuffer: course.zipBuffer,
        manifest: { version: course.version, topic: course.topic, modules: course.modules.length },
      },
    })
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    return typeof obj.id === 'string'
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { targets: publishingEngine.getSupportedTargets().length } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }
}

// -----------------------------------------------------------------------------
// Adapter that wraps the CostEngine singleton.
// -----------------------------------------------------------------------------
class CostEngineEngine implements EngineContract {
  readonly name = 'cost-engine'
  private healthy = false

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (typeof input !== 'object' || input === null) {
      throw new Error('CostEngineEngine: invalid input — expected { correlationId } or { courseId }')
    }
    const obj = input as { correlationId?: string; courseId?: string }
    if (obj.correlationId) return costEngine.getByCorrelationId(obj.correlationId)
    if (obj.courseId) return costEngine.getByCourseId(obj.courseId)
    return costEngine.list()
  }

  validate(input: unknown): boolean {
    return typeof input === 'object' && input !== null
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { records: costEngine.size() } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }
}

// -----------------------------------------------------------------------------
// Main registration function: registers all 19 engines.
// -----------------------------------------------------------------------------
export function registerCourseEngines(registry: EngineRegistry, aiAdapter: AIAdapter | null): void {
  const engines: EngineContract[] = [
    // 1. Research (adapter wrapping Epica 6 ResearchEngine)
    new ResearchEngineAdapter({ aiAdapter }),
    // 2-13. The 12 builders
    new CurriculumBuilder({ aiAdapter }),
    new ModulePlanner({ aiAdapter }),
    new LessonPlanner({ aiAdapter }),
    new LessonWriterEngine({ aiAdapter }),
    new ExerciseBuilder({ aiAdapter }),
    new QuizBuilder({ aiAdapter }),
    new AssessmentBuilder({ aiAdapter }),
    new CaseStudyBuilder({ aiAdapter }),
    new ChecklistBuilder({ aiAdapter }),
    new TemplateBuilder({ aiAdapter }),
    new SlideBuilder({ aiAdapter }),
    new GuideBuilder({ aiAdapter }),
    // 14. Course orchestrator (registered but typically invoked via AIFactory)
    new CourseOrchestrator({ aiAdapter, engineRegistry: registry }),
    // 15. Quality assurance
    new QualityAssurance({ aiAdapter }),
    // 16-19. Adapters wrapping Epica 7 singletons
    new PrePublishValidatorsEngine(),
    new RubricSystemEngine(),
    new PublishingEngineEngine(),
    new CostEngineEngine(),
  ]

  for (const engine of engines) {
    registry.register(engine.name, engine)
  }
  logger.info({ count: engines.length, names: engines.map((e) => e.name) }, 'RuntimeEngineRegistration: registered all engines')
}

export {
  ResearchEngineAdapter,
  PrePublishValidatorsEngine,
  RubricSystemEngine,
  PublishingEngineEngine,
  CostEngineEngine,
}

// Re-export for consumers
export { createResearchSource }
