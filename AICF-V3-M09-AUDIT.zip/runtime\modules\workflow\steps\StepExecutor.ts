// =============================================================================
// AICF V3 — Sprint 13+14 — Step Executor Service
// =============================================================================
// Orchestrates the execution of a single workflow step. The orchestrator
// delegates each step to this service, which:
//   1. Resolves `{{var}}` placeholders in the step's `config` and `inputs`
//      against the per-execution variable bindings.
//   2. Evaluates `step.condition` (if present) and short-circuits with a
//      `'skipped'` result when the condition is falsy.
//   3. Looks up the registered `IStepExecutor` for `step.type` in the
//      `StepRegistry`.
//   4. Runs the executor with retries + exponential backoff (per-step
//      `retries`) and a hard timeout (per-step `timeout`).
//   5. Emits `step.started` / `step.completed` / `step.failed` /
//      `step.retrying` events through the injected `IEventBus`.
//
// Sprint 13+14 spec requirements covered:
//   - Variable resolution before dispatch (engine never sees raw placeholders)
//   - Conditional step execution (`step.condition`)
//   - Per-step timeout via `AbortController` + race
//   - Per-step retries with exponential backoff
//   - Structured step lifecycle events for observability
// =============================================================================

import type {
  WorkflowExecution,
  WorkflowStepDefinition,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import type {
  IEventBus,
  IStepExecutor,
  StepExecutionContext,
  StepExecutionResult,
} from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'
import type { StepRegistry } from './StepRegistry'
import type { VariableResolver } from '../context/VariableResolver'

/** Default base delay (ms) for exponential backoff between retries. */
const DEFAULT_BACKOFF_BASE_MS = 200
/** Default cap (ms) for exponential backoff between retries. */
const DEFAULT_BACKOFF_CAP_MS = 5_000

/**
 * Orchestrates single-step execution. Stateless across executions; safe
 * to call concurrently.
 *
 * Note on `IStepExecutor` compatibility: this service exposes
 * `execute(step, execution, ctx)` (per the Sprint 13+14 spec) rather than
 * `execute(context: StepExecutionContext)` (the `IStepExecutor` contract
 * shape). The two signatures are intentionally different — the service
 * is the orchestrator's entry point, while `IStepExecutor` is the
 * per-provider dispatch shape. Use `stepExecutorAsIStepExecutor(service)`
 * (see `index.ts`) to adapt a `StepExecutorService` into an
 * `IStepExecutor` for consumers like the `CompensationHandler`.
 */
export class StepExecutorService {
  constructor(
    private readonly registry: StepRegistry,
    private readonly eventBus: IEventBus,
    private readonly variableResolver: VariableResolver,
  ) {}

  /**
   * Whether the registry has an executor for `stepType`. Convenience
   * method so callers (e.g. adapters wrapping this service as an
   * `IStepExecutor`) can satisfy the `canHandle` interface.
   */
  canHandle(stepType: string): boolean {
    return this.registry.get(stepType) !== null
  }

  /**
   * Adapter-friendly entry point: takes a `StepExecutionContext` and
   * delegates to `execute(step, execution, ctx)`. Used by the
   * `stepExecutorAsIStepExecutor` adapter so the `CompensationHandler`
   * (which expects an `IStepExecutor`) can drive this service.
   */
  async executeWithContext(
    context: StepExecutionContext,
  ): Promise<StepExecutionResult> {
    return this.execute(context.step, context.execution, context.ctx)
  }

  /**
   * Execute a single workflow step.
   *
   * @returns A `StepExecutionResult`. `ok === false` indicates the step
   *          failed (after exhausting retries); `output` may still contain
   *          partial data depending on the executor.
   */
  async execute(
    step: WorkflowStepDefinition,
    execution: WorkflowExecution,
    ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    // --- resolve variables in step config ----------------------------
    // `step.config` is `Record<string, unknown>` — we resolve placeholders
    // in-place so the executor sees fully-materialized values.
    // `step.inputs` is `Record<string, string>` (logical-name → source
    // expression) — we leave it as the original string bindings because
    // (a) the contract types forbid `unknown` values here, and
    // (b) the per-provider executor wrapper resolves them against
    //     `ctx.variables` on its own (see `providerAsExecutor`).
    const resolvedConfig = this.variableResolver.resolve(
      step.config,
      ctx.variables,
    ) as Record<string, unknown>

    // --- evaluate condition (skip if falsy) --------------------------
    if (step.condition) {
      const condResult = this.evaluateCondition(step.condition, ctx.variables)
      if (!condResult) {
        logger.debug(
          { executionId: execution.executionId, stepId: step.id },
          'step condition evaluated false; skipping',
        )
        return {
          ok: true,
          output: {},
          artifacts: [],
          durationMs: 0,
        }
      }
    }

    // --- locate executor ---------------------------------------------
    const executor = this.registry.get(step.type)
    if (!executor) {
      const error = `no executor registered for step type "${step.type}"`
      logger.error(
        { executionId: execution.executionId, stepId: step.id, stepType: step.type },
        error,
      )
      await this.emitStepFailed(execution, step, error, 0)
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error,
      }
    }

    // --- emit step.started -------------------------------------------
    await this.eventBus.publish({
      type: 'step.started',
      timestamp: Date.now(),
      level: 'info',
      executionId: execution.executionId,
      stepId: step.id,
      correlationId: execution.correlationId,
      data: { stepType: step.type, provider: step.provider },
    })

    // --- build context for the executor ------------------------------
    // Note: `step.inputs` is preserved as the original string bindings
    // (the executor wrapper resolves them); only `step.config` is
    // pre-resolved here for executors that read config directly.
    const stepContext: StepExecutionContext = {
      execution,
      step: { ...step, config: resolvedConfig },
      ctx,
      variables: ctx.variables,
      artifacts: [],
    }

    // --- run with retries --------------------------------------------
    const result = await this.executeWithRetries(
      stepContext.step,
      executor,
      stepContext,
      step.retries,
    )

    // --- emit terminal event -----------------------------------------
    if (result.ok) {
      await this.eventBus.publish({
        type: 'step.completed',
        timestamp: Date.now(),
        level: 'info',
        executionId: execution.executionId,
        stepId: step.id,
        correlationId: execution.correlationId,
        data: {
          durationMs: result.durationMs,
          tokensUsed: result.tokensUsed,
          cost: result.cost,
        },
      })
    } else {
      await this.emitStepFailed(execution, step, result.error ?? 'unknown error', 0)
    }

    return result
  }

  /**
   * Retry loop with exponential backoff. Retries up to `maxRetries` times
   * on failure; each retry waits `min(cap, base * 2^attempt)` ms before
   * re-invoking the executor.
   *
   * Per-step `timeout` (if declared) is enforced via `Promise.race` with
   * an `AbortController`-driven timeout promise. On timeout the step is
   * considered failed (and retried if any retries remain).
   */
  async executeWithRetries(
    step: WorkflowStepDefinition,
    executor: IStepExecutor,
    context: StepExecutionContext,
    maxRetries: number,
  ): Promise<StepExecutionResult> {
    let attempt = 0
    while (true) {
      attempt += 1
      const start = Date.now()
      try {
        const result = await this.runWithTimeout(executor, context, step.timeout)
        const durationMs = Date.now() - start
        return { ...result, durationMs: result.durationMs || durationMs }
      } catch (err) {
        const message =
          err instanceof Error ? err.message : 'unknown step error'
        const durationMs = Date.now() - start
        logger.warn(
          {
            executionId: context.execution.executionId,
            stepId: step.id,
            attempt,
            err: message,
            durationMs,
          },
          'step attempt failed',
        )

        if (attempt > maxRetries) {
          return {
            ok: false,
            output: {},
            artifacts: [],
            durationMs,
            error: message,
          }
        }

        // Emit retrying event.
        await this.eventBus.publish({
          type: 'step.retrying',
          timestamp: Date.now(),
          level: 'warn',
          executionId: context.execution.executionId,
          stepId: step.id,
          correlationId: context.execution.correlationId,
          data: { attempt, maxRetries, error: message },
        })

        // Exponential backoff with cap.
        const delay = Math.min(
          DEFAULT_BACKOFF_CAP_MS,
          DEFAULT_BACKOFF_BASE_MS * Math.pow(2, attempt - 1),
        )
        await this.sleep(delay)
      }
    }
  }

  /**
   * Run a single attempt of `executor.execute(context)`, optionally racing
   * against a timeout. On timeout the promise rejects with a timeout
   * error; the underlying executor is given an `AbortSignal` via the
   * context (if it inspects `step.config.__abortSignal`).
   */
  private async runWithTimeout(
    executor: IStepExecutor,
    context: StepExecutionContext,
    timeoutMs: number | undefined,
  ): Promise<StepExecutionResult> {
    if (timeoutMs === undefined || timeoutMs <= 0) {
      return executor.execute(context)
    }

    const controller = new AbortController()
    const timeoutPromise = new Promise<StepExecutionResult>((_, reject) => {
      const t = setTimeout(() => {
        controller.abort()
        reject(new Error(`step timed out after ${timeoutMs}ms`))
      }, timeoutMs)
      // Allow the Node process to exit even if the timer is pending.
      if (typeof t === 'object' && 'unref' in t && typeof t.unref === 'function') {
        ;(t as { unref: () => void }).unref()
      }
    })

    // Inject the abort signal into the step config so cooperative
    // executors can short-circuit.
    const wrappedContext: StepExecutionContext = {
      ...context,
      step: {
        ...context.step,
        config: { ...context.step.config, __abortSignal: controller.signal },
      },
    }

    return Promise.race([
      executor.execute(wrappedContext),
      timeoutPromise,
    ])
  }

  /**
   * Evaluate a condition expression against the variable bindings. The
   * condition language is intentionally minimal: the expression is
   * resolved as a `{{...}}` placeholder and the resolved value is coerced
   * to boolean.
   *
   * Supported syntaxes:
   *   - `"true"` / `"false"` literals
   *   - `"{{someVar}}"` — truthiness of the resolved value
   *   - `"{{someVar}} == 'foo'"` — best-effort equality (string compare)
   *
   * Anything that cannot be evaluated is treated as falsy.
   */
  private evaluateCondition(
    condition: string,
    variables: Record<string, unknown>,
  ): boolean {
    // First, resolve placeholders.
    const resolved = this.variableResolver.resolveString(condition, variables)

    // Equality check: "X == Y" or "X != Y"
    const eqMatch = /^(.+?)\s*(==|!=)\s*(.+)$/.exec(resolved)
    if (eqMatch) {
      const left = eqMatch[1].trim().replace(/^['"]|['"]$/g, '')
      const op = eqMatch[2]
      const right = eqMatch[3].trim().replace(/^['"]|['"]$/g, '')
      return op === '==' ? left === right : left !== right
    }

    // Boolean literals.
    if (resolved === 'true') return true
    if (resolved === 'false' || resolved === '') return false

    // Truthiness of the resolved value.
    return resolved !== 'false' && resolved !== '0' && resolved.length > 0
  }

  /** Emit a `step.failed` event with the given error. */
  private async emitStepFailed(
    execution: WorkflowExecution,
    step: WorkflowStepDefinition,
    error: string,
    attempts: number,
  ): Promise<void> {
    await this.eventBus.publish({
      type: 'step.failed',
      timestamp: Date.now(),
      level: 'error',
      executionId: execution.executionId,
      stepId: step.id,
      correlationId: execution.correlationId,
      data: { error, attempts },
    })
  }

  /** Promise-based sleep helper. */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }
}
