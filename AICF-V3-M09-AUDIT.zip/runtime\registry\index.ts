export { ModuleRegistry } from './ModuleRegistry'
