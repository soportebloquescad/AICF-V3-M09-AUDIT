// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Metrics Collector
// =============================================================================
// Aggregates per-execution, per-step, and per-provider metrics for the
// workflow runtime. Subscribes to the EventBus on construction so that
// workflow lifecycle events are auto-recorded; callers can also invoke the
// explicit `recordExecution` / `recordStep` / `recordProvider` methods.
//
// Sprint 13+14 spec requirements covered:
//   - Per-execution metrics (duration, tokens, cost, provider, model, success)
//   - Per-step metrics (duration, tokens, cost, provider, success)
//   - Per-provider metrics (calls, success/failure, avg latency, tokens, cost)
//   - Aggregate metrics across all executions
//   - Serializable snapshot for the /health endpoint
// =============================================================================

import type { IEventBus } from '@/lib/runtime/interfaces'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Metrics for a single workflow execution. */
export interface ExecutionMetrics {
  executionId: string
  durationMs: number
  tokensUsed: number
  cost: number
  provider: string
  model: string
  success: boolean
  stepCount: number
}

/** Per-provider aggregated metrics. */
export interface ProviderMetrics {
  provider: string
  totalCalls: number
  successCount: number
  failureCount: number
  avgLatencyMs: number
  totalTokens: number
  totalCost: number
}

/** Aggregate metrics across all executions observed by this collector. */
export interface AggregateMetrics {
  totalExecutions: number
  successfulExecutions: number
  failedExecutions: number
  successRate: number
  totalTokens: number
  totalCost: number
  avgExecutionMs: number
  providerMetrics: Record<string, ProviderMetrics>
}

/** Inputs for `recordExecution`. */
export interface ExecutionMetricsInput {
  durationMs: number
  tokensUsed: number
  cost: number
  provider: string
  model: string
  success: boolean
}

/** Inputs for `recordStep`. */
export interface StepMetricsInput {
  durationMs: number
  tokensUsed: number
  cost: number
  provider: string
  success: boolean
}

/** Internal accumulator for per-provider latency (used to compute averages). */
interface ProviderAccumulator {
  provider: string
  totalCalls: number
  successCount: number
  failureCount: number
  totalLatencyMs: number
  totalTokens: number
  totalCost: number
}

/**
 * Collects workflow + provider metrics. Construct with an `IEventBus` to
 * enable auto-recording from workflow lifecycle events; the collector
 * subscribes to `workflow.started`, `workflow.completed`, `workflow.failed`,
 * `step.started`, `step.completed`, `step.failed`, `generation.completed`,
 * and `provider.selected`.
 */
export class MetricsCollector {
  /** Per-execution metrics keyed by executionId. */
  private readonly executions = new Map<string, ExecutionMetrics>()
  /** Per-step metrics keyed by `${executionId}::${stepId}`. */
  private readonly steps = new Map<string, StepMetricsInput & { executionId: string; stepId: string }>()
  /** Per-provider accumulators keyed by provider name. */
  private readonly providers = new Map<string, ProviderAccumulator>()
  /** In-flight execution start timestamps (for auto-recording duration). */
  private readonly executionStart = new Map<string, number>()
  /** In-flight step start timestamps (for auto-recording duration). */
  private readonly stepStart = new Map<string, number>()
  /** Unsubscribe handles for the EventBus subscriptions. */
  private readonly unsubs: Array<() => void> = []

  constructor(eventBus?: IEventBus) {
    if (eventBus) {
      this.attachToBus(eventBus)
    }
  }

  // ----- Explicit recording API -------------------------------------------

  /**
   * Record metrics for a completed (or failed) workflow execution.
   * Overwrites any prior record for the same executionId.
   */
  recordExecution(
    executionId: string,
    metrics: ExecutionMetricsInput,
  ): void {
    const stepCount = this.countStepsForExecution(executionId)
    const record: ExecutionMetrics = {
      executionId,
      durationMs: metrics.durationMs,
      tokensUsed: metrics.tokensUsed,
      cost: metrics.cost,
      provider: metrics.provider,
      model: metrics.model,
      success: metrics.success,
      stepCount,
    }
    this.executions.set(executionId, record)
    // Also credit the provider with the call (idempotently: a provider
    // record may already exist from per-step recording).
    this.recordProvider(
      metrics.provider,
      metrics.durationMs,
      metrics.success,
      metrics.tokensUsed,
      metrics.cost,
    )
    logger.debug(
      { executionId, success: metrics.success, durationMs: metrics.durationMs },
      'MetricsCollector: execution recorded',
    )
  }

  /** Record metrics for a completed (or failed) step. */
  recordStep(
    executionId: string,
    stepId: string,
    metrics: StepMetricsInput,
  ): void {
    const key = `${executionId}::${stepId}`
    this.steps.set(key, { ...metrics, executionId, stepId })
    this.recordProvider(
      metrics.provider,
      metrics.durationMs,
      metrics.success,
      metrics.tokensUsed,
      metrics.cost,
    )
  }

  /**
   * Record a single provider call. Updates the per-provider accumulator
   * (call count, success/failure split, latency, tokens, cost).
   */
  recordProvider(
    provider: string,
    latencyMs: number,
    success: boolean,
    tokensUsed = 0,
    cost = 0,
  ): void {
    let acc = this.providers.get(provider)
    if (!acc) {
      acc = {
        provider,
        totalCalls: 0,
        successCount: 0,
        failureCount: 0,
        totalLatencyMs: 0,
        totalTokens: 0,
        totalCost: 0,
      }
      this.providers.set(provider, acc)
    }
    acc.totalCalls += 1
    if (success) acc.successCount += 1
    else acc.failureCount += 1
    acc.totalLatencyMs += latencyMs
    acc.totalTokens += tokensUsed
    acc.totalCost += cost
  }

  // ----- Read API ----------------------------------------------------------

  /** Get metrics for a single execution, or null if not recorded. */
  getExecutionMetrics(executionId: string): ExecutionMetrics | null {
    return this.executions.get(executionId) ?? null
  }

  /** Get aggregated metrics for a single provider, or null if not recorded. */
  getProviderMetrics(provider: string): ProviderMetrics | null {
    const acc = this.providers.get(provider)
    if (!acc) return null
    return {
      provider: acc.provider,
      totalCalls: acc.totalCalls,
      successCount: acc.successCount,
      failureCount: acc.failureCount,
      avgLatencyMs: acc.totalCalls > 0 ? acc.totalLatencyMs / acc.totalCalls : 0,
      totalTokens: acc.totalTokens,
      totalCost: acc.totalCost,
    }
  }

  /**
   * Compute aggregate metrics across all executions observed so far.
   * `successRate` is `successfulExecutions / totalExecutions` (0 when no
   * executions have been recorded). `avgExecutionMs` is the mean duration
   * across all executions.
   */
  getAggregateMetrics(): AggregateMetrics {
    let total = 0
    let success = 0
    let failed = 0
    let tokens = 0
    let cost = 0
    let duration = 0
    for (const m of this.executions.values()) {
      total += 1
      if (m.success) success += 1
      else failed += 1
      tokens += m.tokensUsed
      cost += m.cost
      duration += m.durationMs
    }
    const providerMetrics: Record<string, ProviderMetrics> = {}
    for (const [name, acc] of this.providers.entries()) {
      providerMetrics[name] = {
        provider: acc.provider,
        totalCalls: acc.totalCalls,
        successCount: acc.successCount,
        failureCount: acc.failureCount,
        avgLatencyMs:
          acc.totalCalls > 0 ? acc.totalLatencyMs / acc.totalCalls : 0,
        totalTokens: acc.totalTokens,
        totalCost: acc.totalCost,
      }
    }
    return {
      totalExecutions: total,
      successfulExecutions: success,
      failedExecutions: failed,
      successRate: total > 0 ? success / total : 0,
      totalTokens: tokens,
      totalCost: cost,
      avgExecutionMs: total > 0 ? duration / total : 0,
      providerMetrics,
    }
  }

  /**
   * Return a serializable snapshot of all metrics for the `/health`
   * endpoint. The snapshot is a plain object (no `Map`s).
   */
  getMetricsSnapshot(): Record<string, unknown> {
    const agg = this.getAggregateMetrics()
    return {
      timestamp: Date.now(),
      aggregate: agg,
      executions: Array.from(this.executions.values()),
      stepCount: this.steps.size,
      providerCount: this.providers.size,
    }
  }

  // ----- EventBus auto-recording ------------------------------------------

  /**
   * Subscribe to workflow lifecycle events on the given bus. Stored
   * unsubscribe handles are returned via `detach()` for clean teardown.
   */
  private attachToBus(bus: IEventBus): void {
    const sub = (type: string, handler: (e: WorkflowEvent) => void) => {
      this.unsubs.push(bus.subscribe(type, handler))
    }

    sub('workflow.started', (e) => {
      if (e.executionId) {
        this.executionStart.set(e.executionId, e.timestamp)
      }
    })
    sub('workflow.completed', (e) => {
      this.finalizeExecutionFromEvent(e, true)
    })
    sub('workflow.failed', (e) => {
      this.finalizeExecutionFromEvent(e, false)
    })
    sub('step.started', (e) => {
      if (e.executionId && e.stepId) {
        this.stepStart.set(`${e.executionId}::${e.stepId}`, e.timestamp)
      }
    })
    sub('step.completed', (e) => {
      this.finalizeStepFromEvent(e, true)
    })
    sub('step.failed', (e) => {
      this.finalizeStepFromEvent(e, false)
    })
    sub('generation.completed', (e) => {
      const provider = readString(e.data, 'provider')
      const latencyMs = readNumber(e.data, 'latencyMs')
      const tokens = readNumber(e.data, 'totalTokens')
      if (provider) {
        this.recordProvider(provider, latencyMs, true, tokens, 0)
      }
    })
    sub('provider.selected', (e) => {
      const provider = readString(e.data, 'provider')
      if (provider) {
        // No latency yet — just register the provider exists.
        this.recordProvider(provider, 0, true, 0, 0)
      }
    })
  }

  /**
   * Finalize an execution record from a `workflow.completed` /
   * `workflow.failed` event. Reads the start timestamp recorded on
   * `workflow.started`; if missing, duration is 0.
   */
  private finalizeExecutionFromEvent(
    e: WorkflowEvent,
    success: boolean,
  ): void {
    if (!e.executionId) return
    const start = this.executionStart.get(e.executionId)
    const durationMs = start !== undefined ? Math.max(0, e.timestamp - start) : 0
    this.recordExecution(e.executionId, {
      durationMs,
      tokensUsed: readNumber(e.data, 'totalTokens'),
      cost: readNumber(e.data, 'cost'),
      provider: readString(e.data, 'provider') ?? 'unknown',
      model: readString(e.data, 'model') ?? 'unknown',
      success,
    })
    this.executionStart.delete(e.executionId)
  }

  /** Finalize a step record from a `step.completed` / `step.failed` event. */
  private finalizeStepFromEvent(e: WorkflowEvent, success: boolean): void {
    if (!e.executionId || !e.stepId) return
    const key = `${e.executionId}::${e.stepId}`
    const start = this.stepStart.get(key)
    const durationMs = start !== undefined ? Math.max(0, e.timestamp - start) : 0
    this.recordStep(e.executionId, e.stepId, {
      durationMs,
      tokensUsed: readNumber(e.data, 'totalTokens'),
      cost: readNumber(e.data, 'cost'),
      provider: readString(e.data, 'provider') ?? 'unknown',
      success,
    })
    this.stepStart.delete(key)
  }

  /** Count step records currently held for a given execution. */
  private countStepsForExecution(executionId: string): number {
    let n = 0
    for (const k of this.steps.keys()) {
      if (k.startsWith(`${executionId}::`)) n += 1
    }
    return n
  }

  /** Detach from the EventBus (unsubscribe all handlers). */
  detach(): void {
    for (const unsub of this.unsubs) {
      try {
        unsub()
      } catch {
        // ignore — best-effort teardown
      }
    }
    this.unsubs.length = 0
  }
}

// ----- Helpers --------------------------------------------------------------

function readNumber(
  data: Record<string, unknown>,
  key: string,
): number {
  const v = data[key]
  return typeof v === 'number' && Number.isFinite(v) ? v : 0
}

function readString(
  data: Record<string, unknown>,
  key: string,
): string | undefined {
  const v = data[key]
  return typeof v === 'string' ? v : undefined
}
