// =============================================================================
// AICF V3 — Épica 6 — Knowledge Base
// =============================================================================
import type { ResearchSource } from './ResearchSource'

export interface KnowledgeEntry {
  id: string
  courseId: string
  key: string
  value: string
  type: 'fact' | 'definition' | 'reference' | 'example' | 'terminology'
  confidence: number
  source: ResearchSource
  createdAt: Date
  updatedAt: Date
}

export class KnowledgeBase {
  private readonly entries = new Map<string, KnowledgeEntry>()

  constructor(private readonly opts: { courseId: string }) {}

  async store(entry: Omit<KnowledgeEntry, 'id' | 'createdAt' | 'updatedAt'>): Promise<KnowledgeEntry> {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const now = new Date()
    const full: KnowledgeEntry = {
      ...entry,
      id: `kb-${ts}-${rand}`,
      createdAt: now,
      updatedAt: now,
    }
    this.entries.set(full.key, full)
    return full
  }

  async retrieve(key: string): Promise<KnowledgeEntry | null> {
    return this.entries.get(key) ?? null
  }

  async search(query: string): Promise<KnowledgeEntry[]> {
    const q = query.toLowerCase()
    return Array.from(this.entries.values()).filter(
      (e) => e.key.toLowerCase().includes(q) || e.value.toLowerCase().includes(q),
    )
  }

  async listByType(type: KnowledgeEntry['type']): Promise<KnowledgeEntry[]> {
    return Array.from(this.entries.values()).filter((e) => e.type === type)
  }

  async listAll(): Promise<KnowledgeEntry[]> {
    return Array.from(this.entries.values())
  }

  async export(): Promise<Record<string, unknown>> {
    const out: Record<string, unknown> = {}
    for (const [key, entry] of this.entries) {
      out[key] = { value: entry.value, type: entry.type, confidence: entry.confidence }
    }
    return out
  }
}
