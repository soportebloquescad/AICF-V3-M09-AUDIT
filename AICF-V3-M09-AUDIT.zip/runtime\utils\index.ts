// =============================================================================
// AICF V3 — Sprint 2 — Runtime Utils
// =============================================================================
// Utility functions used across the runtime.
// =============================================================================

export function generateId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `${prefix}-${ts}-${rand}`
}

export function generateRequestId(): string {
  return generateId('req')
}

export function generateCorrelationId(): string {
  return generateId('cor')
}

export function safeJsonParse(text: string): Record<string, unknown> | null {
  try {
    const result = JSON.parse(text)
    if (typeof result === 'object' && result !== null && !Array.isArray(result)) {
      return result as Record<string, unknown>
    }
    return null
  } catch {
    return null
  }
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength - 3) + '...'
}
