// =============================================================================
// AICF V3 — Course Agents: Shared Utilities
// =============================================================================
// Helpers shared by all course-generation agents:
//   - callAI(): invoke the AIAdapter with graceful failure
//   - extractJSON(): parse JSON from LLM responses (handles code fences)
//   - normalizeLevel(): map various level strings to canonical buckets
//   - BLOOM_VERBS / pickBloomVerbs(): Bloom's taxonomy verb banks
//   - readContext(): safely extract typed values from AgentInput.context
//   - elapsedMs() / errorToString(): small ergonomics helpers
//
// Agents NEVER call providers directly. They go through callAI(), which
// accepts a nullable AIAdapter and degrades gracefully to deterministic
// fallbacks when the adapter is absent or throws.
// =============================================================================

import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'

export interface CallAIOptions {
  systemPrompt?: string
  model?: string
  temperature?: number
  maxTokens?: number
}

export interface CallAIResult {
  content: string
  ok: boolean
  error?: string
}

/**
 * Invoke the AI adapter with a single prompt. Returns an empty content
 * string and ok=false when the adapter is absent or the call fails.
 * Never throws — agents rely on this to fall through to deterministic
 * fallbacks without try/catch noise.
 */
export async function callAI(
  aiAdapter: AIAdapter | null,
  prompt: string,
  opts: CallAIOptions = {},
): Promise<CallAIResult> {
  if (!aiAdapter) {
    return { content: '', ok: false }
  }
  const messages: ChatRequest['messages'] = []
  if (opts.systemPrompt) {
    messages.push({ role: 'system', content: opts.systemPrompt })
  }
  messages.push({ role: 'user', content: prompt })
  try {
    const response = await aiAdapter.chat({
      model: opts.model ?? 'default',
      messages,
      temperature: opts.temperature,
      maxTokens: opts.maxTokens,
    })
    return { content: response.content, ok: true }
  } catch (err) {
    return {
      content: '',
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    }
  }
}

/**
 * Parse JSON from an LLM response. Tries, in order:
 *   1. Direct JSON.parse on the trimmed string
 *   2. A fenced code block (```json ... ``` or ``` ... ```)
 *   3. The substring from the first '{' to the last '}'
 *   4. The substring from the first '[' to the last ']'
 * Returns null if no valid JSON can be extracted.
 */
export function extractJSON<T = unknown>(content: string): T | null {
  if (!content || typeof content !== 'string') return null
  const trimmed = content.trim()

  // 1. Direct parse
  try {
    return JSON.parse(trimmed) as T
  } catch {
    // fallthrough
  }

  // 2. Fenced code block
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fenced && fenced[1]) {
    try {
      return JSON.parse(fenced[1].trim()) as T
    } catch {
      // fallthrough
    }
  }

  // 3. First '{' to last '}'
  const objStart = trimmed.indexOf('{')
  const objEnd = trimmed.lastIndexOf('}')
  if (objStart !== -1 && objEnd > objStart) {
    try {
      return JSON.parse(trimmed.slice(objStart, objEnd + 1)) as T
    } catch {
      // fallthrough
    }
  }

  // 4. First '[' to last ']'
  const arrStart = trimmed.indexOf('[')
  const arrEnd = trimmed.lastIndexOf(']')
  if (arrStart !== -1 && arrEnd > arrStart) {
    try {
      return JSON.parse(trimmed.slice(arrStart, arrEnd + 1)) as T
    } catch {
      // fallthrough
    }
  }

  return null
}

/**
 * Normalize various level strings (English, Spanish, Portuguese) into one
 * of three canonical buckets used by the instructional designer.
 */
export function normalizeLevel(level: string): 'beginner' | 'intermediate' | 'advanced' {
  const l = (level ?? '').toLowerCase().trim()
  if (
    [
      'beginner',
      'introductory',
      'introduction',
      'basic',
      'basics',
      'foundation',
      'foundational',
      'fundamentals',
      'fundamental',
      'iniciante',
      'principiante',
      'basico',
      'inicial',
    ].includes(l)
  ) {
    return 'beginner'
  }
  if (
    ['advanced', 'advance', 'expert', 'mastery', 'master', 'avanzado', 'avancado', 'experto', 'superior'].includes(
      l,
    )
  ) {
    return 'advanced'
  }
  return 'intermediate'
}

/**
 * Bloom's taxonomy verb banks for each cognitive level. Used by the
 * InstructionalDesigner to seed learning objectives and by the
 * AssessmentWriter to phrase question stems.
 */
export const BLOOM_VERBS = {
  remember: [
    'define',
    'list',
    'name',
    'identify',
    'recall',
    'describe',
    'label',
    'state',
    'recognize',
    'retrieve',
  ],
  understand: [
    'explain',
    'summarize',
    'interpret',
    'classify',
    'compare',
    'discuss',
    'estimate',
    'illustrate',
    'infer',
  ],
  apply: [
    'apply',
    'demonstrate',
    'implement',
    'use',
    'solve',
    'compute',
    'execute',
    'practice',
    'employ',
    'carry out',
  ],
  analyze: [
    'analyze',
    'differentiate',
    'examine',
    'investigate',
    'deconstruct',
    'test',
    'categorize',
    'contrast',
    'break down',
  ],
  evaluate: [
    'evaluate',
    'justify',
    'critique',
    'assess',
    'recommend',
    'defend',
    'argue',
    'prioritize',
    'appraise',
    'judge',
  ],
  create: [
    'design',
    'build',
    'create',
    'develop',
    'formulate',
    'propose',
    'invent',
    'compose',
    'construct',
    'plan',
  ],
} as const

export type BloomLevel = keyof typeof BLOOM_VERBS

export const BLOOM_LEVELS_ORDER: readonly BloomLevel[] = [
  'remember',
  'understand',
  'apply',
  'analyze',
  'evaluate',
  'create',
] as const

/**
 * Select three Bloom levels appropriate for the given competency level.
 * Beginners focus on lower-order thinking; advanced learners on higher.
 */
export function pickBloomLevels(level: 'beginner' | 'intermediate' | 'advanced'): BloomLevel[] {
  if (level === 'beginner') return ['remember', 'understand', 'apply']
  if (level === 'advanced') return ['analyze', 'evaluate', 'create']
  return ['understand', 'apply', 'analyze']
}

/**
 * Safely read a typed value from a context record. Returns null when the
 * key is absent or the value is null/undefined.
 */
export function readContext<T = unknown>(context: Record<string, unknown>, key: string): T | null {
  const value = context[key]
  if (value === undefined || value === null) return null
  return value as T
}

/**
 * Clamp a number to the inclusive [min, max] range.
 */
export function clamp(value: number, min: number, max: number): number {
  if (Number.isNaN(value)) return min
  return Math.max(min, Math.min(max, value))
}

/**
 * Measure elapsed milliseconds since the given start timestamp.
 */
export function elapsedMs(start: number): number {
  return Date.now() - start
}

/**
 * Format an unknown error into a string suitable for AgentOutput.error.
 */
export function errorToString(err: unknown): string {
  if (err instanceof Error) return err.message
  if (typeof err === 'string') return err
  try {
    return JSON.stringify(err)
  } catch {
    return String(err)
  }
}
