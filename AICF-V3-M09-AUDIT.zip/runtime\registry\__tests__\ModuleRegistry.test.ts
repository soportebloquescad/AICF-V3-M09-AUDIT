// =============================================================================
// AICF V3 — ModuleRegistry Tests (Sprint 19: All 9 Modules Real)
// =============================================================================
// Tests for the ModuleRegistry with the new lifecycle-aware module shape.
//
// Sprint 19: the constructor no longer registers ANY stubs. The registry
// starts empty — modules are registered by bootstrap (via the manifest +
// ModuleFactory) or by tests via `register()`. Tests that need stubs
// register them explicitly using the exported `StubModule` class.
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { ModuleRegistry, StubModule } from '../ModuleRegistry'
import type { RuntimeModule, ModuleHealth } from '@/lib/runtime/contracts/RuntimeModule'

describe('ModuleRegistry (Sprint 15)', () => {
  it('should register ZERO modules by default (Sprint 19)', () => {
    const registry = new ModuleRegistry()
    const statuses = registry.getStatus()

    // Sprint 19: constructor no longer stubs anything. The registry
    // starts empty — modules are registered by bootstrap via the manifest.
    expect(statuses.length).toBe(0)
  })

  it('should register a real module and retrieve it', () => {
    const registry = new ModuleRegistry()
    const mock: RuntimeModule = {
      name: 'test',
      version: '1.0.0',
      isReady: () => true,
      getStatus: () => ({ name: 'test', ready: true, version: '1.0.0' }),
      async initialize() {},
      async health(): Promise<ModuleHealth> {
        return {
          ready: true,
          status: 'healthy',
          startupTime: new Date().toISOString(),
          dependencies: [],
          version: '1.0.0',
          lastInitialization: new Date().toISOString(),
        }
      },
    }

    registry.register('workflow', mock)
    const wf = registry.get('workflow')
    expect(wf).not.toBeNull()
    expect(wf?.name).toBe('test')
  })

  it('should return health for all registered modules', async () => {
    const registry = new ModuleRegistry()
    // Register stubs explicitly — Sprint 19: constructor no longer stubs.
    registry.register('localization', new StubModule('localization', '1.0.0', 'localization'))
    registry.register('assets', new StubModule('assets', '1.0.0', 'assets'))
    registry.register('reports', new StubModule('reports', '1.0.0', 'reports'))

    const healths = await registry.getHealth()

    expect(healths.length).toBe(3)
    // Stubs report unhealthy
    expect(healths.every((h) => h.health.status === 'unhealthy')).toBe(true)
  })

  it('should return health for real modules', async () => {
    const registry = new ModuleRegistry()
    const mock: RuntimeModule = {
      name: 'test',
      version: '1.0.0',
      isReady: () => true,
      getStatus: () => ({ name: 'test', ready: true, version: '1.0.0' }),
      async initialize() {},
      async health(): Promise<ModuleHealth> {
        return {
          ready: true,
          status: 'healthy',
          startupTime: '2026-01-01T00:00:00.000Z',
          dependencies: [],
          version: '1.0.0',
          lastInitialization: '2026-01-01T00:00:00.000Z',
        }
      },
    }
    registry.register('workflow', mock)

    const healths = await registry.getHealth()
    const wfHealth = healths.find((h) => h.category === 'workflow')
    expect(wfHealth).toBeDefined()
    expect(wfHealth?.health.status).toBe('healthy')
    expect(wfHealth?.health.ready).toBe(true)
  })

  it('should handle modules without getStatus() (defensive)', () => {
    const registry = new ModuleRegistry()
    // A minimal module without getStatus()
    const minimal = {
      name: 'minimal',
      version: '0.1.0',
      isReady: () => true,
    } as RuntimeModule

    registry.register('workflow', minimal)
    const statuses = registry.getStatus()
    const wf = statuses.find((s) => s.name === 'minimal')
    expect(wf).toBeDefined()
    expect(wf?.ready).toBe(true)
  })

  it('should initialize all registered modules', async () => {
    const registry = new ModuleRegistry()
    // Register stubs explicitly — Sprint 19: constructor no longer stubs.
    registry.register('localization', new StubModule('localization', '1.0.0', 'localization'))
    registry.register('assets', new StubModule('assets', '1.0.0', 'assets'))
    registry.register('reports', new StubModule('reports', '1.0.0', 'reports'))

    await registry.initializeAll()
    // Should not throw
    expect(registry.getStatus().length).toBe(3)
  })
})

// =============================================================================
// Sprint 2 Production Runtime — conflict detection tests
// =============================================================================

describe('ModuleRegistry — conflict detection (Sprint 2 Production Runtime)', () => {
  it('logs a warning when a DIFFERENT module instance is registered for an existing category', () => {
    const registry = new ModuleRegistry()
    const first = new StubModule('first', '1.0.0', 'workflow')
    const second = new StubModule('second', '2.0.0', 'workflow')

    // First registration — silent.
    registry.register('workflow', first)

    // Re-register with a DIFFERENT module instance — conflict detected.
    // The conflict is logged (best-effort); the new module replaces the old.
    registry.register('workflow', second)

    // The second module should now be the one returned by get().
    const retrieved = registry.get('workflow')
    expect(retrieved).toBe(second)
    expect(retrieved).not.toBe(first)
  })

  it('does NOT log a warning when the SAME module instance is re-registered (HMR safe)', () => {
    const registry = new ModuleRegistry()
    const mod = new StubModule('same', '1.0.0', 'workflow')

    registry.register('workflow', mod)
    // Re-register the SAME instance — should be silent + idempotent.
    registry.register('workflow', mod)

    const retrieved = registry.get('workflow')
    expect(retrieved).toBe(mod)
  })

  it('detects conflicts in registerWithMetadata (different module, same metadata.id)', () => {
    const registry = new ModuleRegistry()
    const first = new StubModule('first', '1.0.0', 'workflow')
    const second = new StubModule('second', '2.0.0', 'workflow')

    const metadata = {
      id: 'workflow-module',
      name: 'workflow',
      description: 'test workflow module',
      author: 'test',
      version: '1.0.0',
      category: 'workflow' as const,
      capabilities: ['workflow.execute'],
      contracts: { schemaVersion: '1.0.0', contractVersion: '1.0.0', runtimeVersion: '3.0.0', compatibility: 'compatible' as const },
      events: [],
      mission: 'test',
      priority: 1,
      dependencies: [],
    }

    registry.registerWithMetadata('workflow', first, metadata)
    // Re-register with a DIFFERENT module instance — conflict detected.
    registry.registerWithMetadata('workflow', second, metadata)

    // The second module should be the one in the registry.
    const entry = registry.getEntry('workflow-module')
    expect(entry?.module).toBe(second)
  })
})
