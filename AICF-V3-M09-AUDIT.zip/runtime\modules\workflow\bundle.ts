// =============================================================================
// AICF V3 — Workflow Module Bundle Singleton
// =============================================================================
// Process-level singleton that wires the Workflow Module, Generation Module,
// and Observability Module together. Created once on first access.
// =============================================================================

import { LiteLLMAdapter } from '@/lib/ai/LiteLLMAdapter'
import { RuntimeAdapter } from '@/lib/ai/RuntimeAdapter'
import { createWorkflowModule, type CreatedWorkflowModule } from './factory'
import { createGenerationModule } from '../generation'
import { createObservabilityModule } from '../observability'
import { logger } from '@/lib/ai/logger'

let bundle: CreatedWorkflowModule | null = null
let generationBundle: ReturnType<typeof createGenerationModule> | null = null
let observabilityBundle: ReturnType<typeof createObservabilityModule> | null = null

/**
 * Returns the singleton Workflow Module bundle.
 * Creates it on first call. Uses RuntimeAdapter as the AI adapter (which
 * itself uses M08/M18/M21 with LiteLLMAdapter fallback).
 */
export function getWorkflowModuleBundle(): CreatedWorkflowModule {
  if (!bundle) {
    logger.info('Initializing Workflow Module bundle (singleton)')

    // Use RuntimeAdapter (parallel to BFF's LiteLLMAdapter)
    const aiAdapter = new RuntimeAdapter()

    // Create generation module (needs aiAdapter)
    generationBundle = createGenerationModule({ aiAdapter })

    // Create observability module
    observabilityBundle = createObservabilityModule({})

    // Create workflow module (needs aiAdapter + optional generator)
    bundle = createWorkflowModule({
      aiAdapter,
      generator: generationBundle.generators.course,
      externalHealthChecks: {
        litellm: async () => {
          try {
            const litellm = new LiteLLMAdapter()
            return await litellm.health()
          } catch (err) {
            return { healthy: false, error: err instanceof Error ? err.message : String(err) }
          }
        },
      },
    })

    logger.info('Workflow Module bundle initialized')
  }
  return bundle
}

/**
 * Returns the singleton Generation Module bundle.
 */
export function getGenerationBundle(): ReturnType<typeof createGenerationModule> {
  if (!generationBundle) {
    getWorkflowModuleBundle() // triggers creation
  }
  return generationBundle!
}

/**
 * Returns the singleton Observability Module bundle.
 */
export function getObservabilityBundle(): ReturnType<typeof createObservabilityModule> {
  if (!observabilityBundle) {
    getWorkflowModuleBundle() // triggers creation
  }
  return observabilityBundle!
}

/**
 * Resets all bundles (for tests).
 * @internal
 */
export function _resetBundles(): void {
  bundle = null
  generationBundle = null
  observabilityBundle = null
}
