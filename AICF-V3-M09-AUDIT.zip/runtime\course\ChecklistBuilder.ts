// =============================================================================
// AICF V3 — Epica 8 — Checklist Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Lesson, Checklist, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class ChecklistBuilder implements EngineContract {
  readonly name = 'checklist-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('ChecklistBuilder: invalid input — expected Lesson[]')
    }
    const lessons = input as Lesson[]
    const checklists: Checklist[] = []
    for (const lesson of lessons) {
      if (this.opts.aiAdapter) {
        try {
          checklists.push(await this.buildWithAI(lesson))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'ChecklistBuilder: AI failed, using fallback')
        }
      }
      checklists.push(this.buildDeterministic(lesson))
    }
    return checklists
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(lesson: Lesson): Promise<Checklist> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a checklist designer. Create a practical checklist with items (each having id, label, completed=false, required). Respond as JSON.',
        },
        {
          role: 'user',
          content: `Lesson: ${lesson.title}\nObjectives: ${lesson.learningObjectives.join('; ')}\nTakeaways: ${lesson.keyTakeaways.join('; ')}\n\nCreate a preparation checklist. Return JSON: { "title": string, "category": "preparation"|"execution"|"review"|"delivery", "items": [{id, label, required}] }`,
        },
      ],
      temperature: 0.4,
      maxTokens: 2048,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; category?: Checklist['category']; items?: Array<{ id: string; label: string; required: boolean }> }
    return this.assembleChecklist(lesson, parsed.title ?? `Checklist: ${lesson.title}`, parsed.category ?? 'preparation', parsed.items ?? [], resp.provider as Provider, resp.model)
  }

  private buildDeterministic(lesson: Lesson): Checklist {
    const items = [
      { id: makeId('cli'), label: `Review the learning objectives for "${lesson.title}"`, completed: false, required: true },
      { id: makeId('cli'), label: 'Allocate sufficient uninterrupted study time (estimate: ' + lesson.durationMinutes + ' minutes)', completed: false, required: true },
      { id: makeId('cli'), label: 'Gather any prerequisite materials referenced in earlier lessons', completed: false, required: true },
      { id: makeId('cli'), label: 'Prepare a notebook or digital tool for capturing key insights', completed: false, required: false },
      { id: makeId('cli'), label: `Read the introduction section to orient yourself to ${lesson.title}`, completed: false, required: true },
      { id: makeId('cli'), label: 'Identify questions you hope the lesson will answer', completed: false, required: false },
      { id: makeId('cli'), label: 'Review the key concepts list and note any unfamiliar terms', completed: false, required: true },
      { id: makeId('cli'), label: `Ensure your environment supports focused learning for ${lesson.durationMinutes} minutes`, completed: false, required: false },
      { id: makeId('cli'), label: 'Commit to completing the practical application section actively', completed: false, required: true },
      { id: makeId('cli'), label: 'Plan to review the key takeaways after completing the lesson', completed: false, required: true },
    ]
    return this.assembleChecklist(lesson, `Preparation Checklist: ${lesson.title}`, 'preparation', items, 'runtime-adapter', 'deterministic-fallback')
  }

  private assembleChecklist(
    lesson: Lesson,
    title: string,
    category: Checklist['category'],
    items: Array<{ id: string; label: string; required: boolean }>,
    provider: Provider,
    model: string,
  ): Checklist {
    const now = new Date().toISOString()
    return {
      id: makeId('chk'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      title,
      items: items.map((i) => ({ id: i.id, label: i.label, completed: false, required: i.required })),
      category,
    }
  }
}
