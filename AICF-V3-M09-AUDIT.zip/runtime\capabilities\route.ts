// =============================================================================
// AICF V3 — GET /api/runtime/capabilities (Sprint 16)
// =============================================================================
// Returns all modules and their capabilities.
// Uses the same singleton RuntimeService as /api/runtime/status so the
// bootstrap-registered modules (with metadata) are visible.
// =============================================================================

import { NextResponse } from 'next/server'
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

async function getService() {
  return await getRuntimeService()
}

export async function GET() {
  const reqLogger = logger.child({ endpoint: '/runtime/capabilities', method: 'GET' })

  try {
    const service = await getService()

    if (!service) {
      return NextResponse.json({
        modules: [],
        capabilities: [],
        totalModules: 0,
        totalCapabilities: 0,
        error: 'Runtime not available',
        timestamp: new Date().toISOString(),
      }, { status: 503 })
    }

    const registry = service.getModuleRegistry()
    const entries = registry.getEntries()
    const capabilityRegistry = registry.getCapabilityRegistry()

    const result = {
      modules: entries.map((entry) => ({
        id: entry.metadata?.id || entry.module.name,
        name: entry.metadata?.name || entry.module.name,
        mission: entry.metadata?.mission || null,
        version: entry.module.version,
        ready: entry.module.isReady(),
        capabilities: entry.capabilities,
        dependencies: entry.metadata?.dependencies || [],
        contracts: entry.contracts,
        events: entry.events,
      })),
      capabilities: capabilityRegistry.snapshot(),
      totalModules: entries.length,
      totalCapabilities: capabilityRegistry.getAllCapabilities().length,
      timestamp: new Date().toISOString(),
    }

    reqLogger.info(
      { moduleCount: result.totalModules, capabilityCount: result.totalCapabilities },
      'Capabilities listed',
    )

    return NextResponse.json(result)
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to list capabilities',
    )
    return NextResponse.json(
      { error: 'Failed to list capabilities' },
      { status: 500 },
    )
  }
}
