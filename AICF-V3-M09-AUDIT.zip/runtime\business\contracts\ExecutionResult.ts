// =============================================================================
// AICF V3 — Business Execution Result Contract (Épica 2 — AI Factory Core)
// =============================================================================
// The return value of a business module's `executeJob()` method. Smaller
// than a JobResponse — it carries the operational outcome (ok/error/output)
// plus artifacts + metrics, but NOT the jobId or timestamps (those live on
// the JobResponse that the BusinessModuleRegistry builds around it).
//
// Design notes:
//   - `ok` is a boolean rather than a status enum because executeJob() only
//     has two terminal states from the module's perspective: succeeded or
//     failed. 'pending'/'running'/'cancelled' are orchestration-layer states
//     owned by the registry / RuntimeService.
//   - Use `createSuccessResult()` / `createFailedResult()` factories rather
//     than constructing the object literal — they fill in `durationMs: 0`
//     and keep the shape stable if new fields are added later.
//
// No `any`.
// =============================================================================

/**
 * An artifact produced by a single execution. Mirrors JobArtifact but is
 * part of the ExecutionResult shape (no separate import needed at the call
 * site).
 */
export interface ExecutionArtifact {
  /** Unique artifact ID. */
  id: string
  /** Artifact type (e.g. 'pdf', 'slides'). */
  type: string
  /** Human-readable name. */
  name: string
}

/**
 * Resource consumption metrics for a single execution.
 */
export interface ExecutionMetrics {
  /** Total tokens used. */
  tokensUsed?: number
  /** Estimated USD cost. */
  cost?: number
  /** Number of provider calls made. */
  providerCalls?: number
}

/**
 * The result of executing a single job in a business module.
 */
export interface ExecutionResult {
  /** True when the job succeeded. */
  ok: boolean

  /** Structured output (present when ok === true). */
  output?: Record<string, unknown>

  /** Error message (present when ok === false). */
  error?: string

  /** Wall-clock duration in milliseconds. */
  durationMs: number

  /** Artifacts produced by this execution. */
  artifacts?: ExecutionArtifact[]

  /** Resource consumption metrics. */
  metrics?: ExecutionMetrics
}

/**
 * Factory: creates a successful ExecutionResult.
 *
 * @example
 * const r = createSuccessResult({ title: 'Intro to Rust' }, { durationMs: 1200 })
 */
export function createSuccessResult(
  output: Record<string, unknown>,
  opts?: Partial<ExecutionResult>,
): ExecutionResult {
  return {
    ok: true,
    output,
    durationMs: opts?.durationMs ?? 0,
    artifacts: opts?.artifacts,
    metrics: opts?.metrics,
    error: opts?.error,
  }
}

/**
 * Factory: creates a failed ExecutionResult.
 *
 * @example
 * const r = createFailedResult('Not implemented', { durationMs: 0 })
 */
export function createFailedResult(
  error: string,
  opts?: Partial<ExecutionResult>,
): ExecutionResult {
  return {
    ok: false,
    error,
    durationMs: opts?.durationMs ?? 0,
    output: opts?.output,
    artifacts: opts?.artifacts,
    metrics: opts?.metrics,
  }
}
