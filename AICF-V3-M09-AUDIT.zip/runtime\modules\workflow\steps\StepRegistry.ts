// =============================================================================
// AICF V3 — Sprint 13+14 — Step Registry
// =============================================================================
// Registry of `IStepExecutor`s keyed by step type. The orchestrator looks
// up the executor for a given `WorkflowStepType` here; the
// `StepExecutorService` delegates per-step execution to whichever executor
// is registered for the step's `type`.
//
// Sprint 13+14 spec requirements covered:
//   - `register(stepType, executor)`  — register one executor per type
//   - `get(stepType)`                 — fetch executor, or null
//   - `list()`                        — enumerate registered types
//   - `clear()`                       — bulk unregister (used by tests)
//
// The registry is intentionally process-local and synchronous. Persistence
// of executor registrations across processes is out of scope for Sprint
// 13+14.
// =============================================================================

import type { IStepExecutor } from '@/lib/runtime/interfaces'

/**
 * Synchronous, in-memory registry of `IStepExecutor`s by step type.
 * Safe to call concurrently from multiple callers; the backing `Map` is
 * not protected against concurrent mutation because JS is single-threaded
 * for synchronous code.
 */
export class StepRegistry {
  private readonly executors = new Map<string, IStepExecutor>()

  /**
   * Register an executor for a step type. Overwrites any prior executor
   * registered for the same type.
   */
  register(stepType: string, executor: IStepExecutor): void {
    this.executors.set(stepType, executor)
  }

  /**
   * Fetch the executor registered for `stepType`, or `null` if none.
   */
  get(stepType: string): IStepExecutor | null {
    return this.executors.get(stepType) ?? null
  }

  /**
   * Return all currently-registered step types.
   */
  list(): string[] {
    return [...this.executors.keys()]
  }

  /**
   * Remove all registered executors. Used by tests to reset state between
   * cases.
   */
  clear(): void {
    this.executors.clear()
  }
}
