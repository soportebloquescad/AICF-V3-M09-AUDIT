// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Engine Interface
// =============================================================================
// The workflow engine is the top-level orchestrator for Sprint 13+14. It owns
// the execute / dry-run / cancel / pause / resume / status / trace surface
// consumed by the runtime API, the UI, and the CLI.
//
// Implementations compose a planner, an IStepExecutor, an IEventBus, an
// IArtifactStorage, and an IWorkflowStateStore — all wired through a shared
// WorkflowContext. This file declares only the contract; behavior lives in
// the concrete engine module.
//
// Sprint 13+14 spec requirements covered:
//   - Synchronous execute + async dry-run with no side-effects
//   - Pause / resume via persisted checkpoints (see `Checkpoint`)
//   - Cancel as a first-class lifecycle transition
//   - getStatus / getTrace for observability and audit
// =============================================================================

import type {
  WorkflowDefinition,
  WorkflowContext,
  WorkflowResult,
  DryRunResult,
  WorkflowExecution,
} from '@/lib/runtime/contracts/workflow'

/**
 * Minimal execution-trace shape. A full trace contract may live in a future
 * sprint; for now this captures the fields needed by the engine surface.
 *
 * Sprint 13+14 implementations may emit richer payloads — extend via
 * `data` rather than widening this interface.
 */
export interface ExecutionTrace {
  /** Execution id the trace entry belongs to. */
  executionId: string
  /** Step id the trace entry pertains to (absent for workflow-level traces). */
  stepId?: string
  /** Trace entry type (e.g. 'step.started', 'step.completed', 'workflow.resumed'). */
  type: string
  /** Epoch ms when the trace entry was recorded. */
  timestamp: number
  /** Type-specific payload. */
  data: Record<string, unknown>
}

/**
 * The workflow engine surface. Implementations MUST be safe to call from
 * concurrent callers — `executionId` is the unit of isolation.
 */
export interface IWorkflowEngine {
  /** Execute a workflow definition to completion (or terminal failure). */
  execute(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<WorkflowResult>

  /** Validate a definition and return a dry-run preview without side-effects. */
  dryRun(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<DryRunResult>

  /** Cancel a running or paused execution. No-op if already terminal. */
  cancel(executionId: string): Promise<void>

  /** Pause a running execution at the next checkpoint boundary. */
  pause(executionId: string): Promise<void>

  /** Resume a paused execution from its last checkpoint. */
  resume(executionId: string): Promise<WorkflowResult>

  /** Return the current execution envelope, or null if unknown. */
  getStatus(executionId: string): Promise<WorkflowExecution | null>

  /** Return the ordered trace entries for an execution. */
  getTrace(executionId: string): Promise<ExecutionTrace[]>
}
