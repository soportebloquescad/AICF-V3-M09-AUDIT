// =============================================================================
// AICF V3 — AI Adapter Interface
// =============================================================================
// The AIAdapter interface abstracts the AI backend from the AIService.
// Today: LiteLLMAdapter talks directly to LiteLLM.
// Tomorrow: RuntimeAdapter talks to Runtime M09 → Content Intelligence M08
//           → Infrastructure M18 → LiteLLM.
//
// The AIService never knows which adapter is in use. Swapping adapters
// requires changing exactly one line:
//   new LiteLLMAdapter()  →  new RuntimeAdapter()
// =============================================================================

/**
 * Represents a single message in a chat conversation.
 */
export interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

/**
 * Request payload for a chat completion.
 */
export interface ChatRequest {
  model: string
  messages: ChatMessage[]
  temperature?: number
  maxTokens?: number
  topP?: number
  stop?: string[]
  stream?: boolean
}

/**
 * Usage metadata returned by the AI provider.
 */
export interface ChatUsage {
  promptTokens: number
  completionTokens: number
  totalTokens: number
}

/**
 * Response from a chat completion.
 */
export interface ChatResponse {
  content: string
  model: string
  provider: string
  usage: ChatUsage | null
  durationMs: number
}

/**
 * Model descriptor returned by the models() method.
 */
export interface AIModel {
  id: string
  provider: string
  ownedBy?: string
}

/**
 * Health status of the AI backend.
 */
export interface AIHealth {
  healthy: boolean
  provider: string
  latencyMs?: number
  details?: Record<string, unknown>
}

/**
 * Error thrown when an AI adapter fails.
 */
export class AIAdapterError extends Error {
  constructor(
    message: string,
    public readonly code: 'TIMEOUT' | 'RATE_LIMIT' | 'AUTH' | 'MODEL_NOT_FOUND' | 'NETWORK' | 'UNKNOWN',
    public readonly statusCode: number = 500,
    public readonly cause?: unknown,
  ) {
    super(message)
    this.name = 'AIAdapterError'
  }
}

/**
 * The AIAdapter interface.
 *
 * Implementations:
 *   - LiteLLMAdapter: calls LiteLLM gateway directly.
 *   - RuntimeAdapter: (future) calls Runtime M09 → Content Intelligence.
 *
 * AIService only depends on this interface, never on a concrete adapter.
 */
export interface AIAdapter {
  /**
   * Perform a chat completion.
   * @throws {AIAdapterError} on any failure (timeout, auth, network, etc.)
   */
  chat(request: ChatRequest): Promise<ChatResponse>

  /**
   * List available models from the AI backend.
   * @throws {AIAdapterError} on failure.
   */
  models(): Promise<AIModel[]>

  /**
   * Check if the AI backend is healthy and reachable.
   */
  health(): Promise<AIHealth>
}
