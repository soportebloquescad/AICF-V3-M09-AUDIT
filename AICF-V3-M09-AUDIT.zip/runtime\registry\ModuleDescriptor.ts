// =============================================================================
// AICF V3 — Sprint 6 (RC33) — ModuleDescriptor
// =============================================================================
// A public type for describing modules before they are registered.
// Used by ModuleLoader to register modules with their metadata, dependencies,
// and factory function.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

/**
 * Describes a module to be registered in the RuntimeModuleRegistry.
 *
 * Contains everything needed to create, register, and resolve a module:
 *   - id, name, version, description
 *   - capabilities (what the module can do)
 *   - dependencies (which module IDs must be initialized first)
 *   - priority (lower = initialized first)
 *   - factory (creates the instance, receives the registry for DI)
 */
export interface ModuleDescriptor {
  /** Unique module identifier (e.g. 'm08-content-intelligence'). */
  readonly id: string
  /** Human-readable name. */
  readonly name: string
  /** Module version. */
  readonly version: string
  /** Human-readable description. */
  readonly description: string
  /** Capabilities this module provides (e.g. ['policy', 'routing', 'model-selection']). */
  readonly capabilities: readonly string[]
  /** Module IDs this module depends on (must be registered + initialized first). */
  readonly dependencies: readonly string[]
  /** Priority (lower = initialized first). Default 100. */
  readonly priority: number
  /**
   * Factory function that creates the module instance.
   * Receives the RuntimeModuleRegistry so it can resolve dependencies via DI.
   */
  readonly factory: (registry: unknown) => unknown
}
