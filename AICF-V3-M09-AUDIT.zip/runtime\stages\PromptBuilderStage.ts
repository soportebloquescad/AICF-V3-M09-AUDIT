// =============================================================================
// AICF V3 — Prompt Builder Stage
// =============================================================================
// Épica 1 — Stabilization: now uses the centralized PromptBuilder's
// DEFAULT_CHAT_SYSTEM constant (from @/lib/ai/PromptBuilder) instead of
// importing from the (now-deleted) ai/prompts/chat module. Eliminates the
// dead ai/prompts/ directory.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { ChatMessage } from '@/lib/ai/AIAdapter'
import { DEFAULT_CHAT_SYSTEM } from '@/lib/ai/PromptBuilder'
import { logger } from '@/lib/ai/logger'

/**
 * Creates the PromptBuilder stage.
 * Builds the messages array from:
 *   1. System prompt (from the centralized PromptBuilder)
 *   2. Request messages (user/assistant conversation)
 */
export function createPromptBuilderStage(): PipelineStage {
  return createPipelineStage('PromptBuilder', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    // Only build chat messages for the 'chat' operation. Other operations
    // (models, status, workflow, generate) must NOT have ctx.messages
    // populated, otherwise ExecutionStage treats them as chat requests.
    if (ctx.request.operation !== 'chat') {
      logger.debug(
        { requestId: ctx.request.requestId, operation: ctx.request.operation },
        'PromptBuilder: non-chat operation, skipping message construction',
      )
      return ctx
    }

    const requestMessages = ctx.request.messages || []
    const messages: ChatMessage[] = []

    // Check if a system prompt is already in the messages
    const hasSystem = requestMessages.some((m) => m.role === 'system')

    if (!hasSystem) {
      // Use the default system prompt from the centralized PromptBuilder
      messages.push({ role: 'system', content: DEFAULT_CHAT_SYSTEM })
    }

    // Append all request messages
    for (const msg of requestMessages) {
      messages.push(msg)
    }

    const next = cloneRuntimeContext(ctx)
    next.messages = messages

    logger.debug(
      { requestId: ctx.request.requestId, messageCount: messages.length },
      'PromptBuilder: messages prepared',
    )

    return next
  })
}
