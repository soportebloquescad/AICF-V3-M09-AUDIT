// =============================================================================
// AICF V3 — M08 ContentIntelligenceEngine Tests
// =============================================================================
// Verifies the 4 spec requirements:
//   1. decide() produces a DecisionPlan
//   2. decide() selects different policies for 'economy' vs 'premium' modes
//   3. decide() runs all 9 stages (audit.stages has 9 entries)
//   4. decide() honors custom policies registered via PolicyEngine.register()
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import {
  ContentIntelligenceEngine,
} from '../ContentIntelligenceEngine'
import { PolicyEngine } from '../PolicyEngine'
import { ProviderRouter } from '../ProviderRouter'
import { ModelSelector } from '../ModelSelector'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import type { DecisionPlan } from '../DecisionPlan'

describe('ContentIntelligenceEngine', () => {
  let engine: ContentIntelligenceEngine

  beforeEach(() => {
    engine = new ContentIntelligenceEngine(
      new PolicyEngine(),
      new ProviderRouter(true),
      new ModelSelector(true),
    )
  })

  it('decide() produces a DecisionPlan', async () => {
    const request = createRuntimeRequest({
      operation: 'chat',
      messages: [
        { role: 'user', content: 'Hello, how are you?' },
      ],
    })

    const plan: DecisionPlan = await engine.decide(request)

    expect(plan).toBeDefined()
    expect(plan.requestId).toBe(request.requestId)
    expect(plan.correlationId).toBe(request.correlationId)
    expect(typeof plan.provider).toBe('string')
    expect(plan.provider.length).toBeGreaterThan(0)
    expect(typeof plan.model).toBe('string')
    expect(plan.model.length).toBeGreaterThan(0)
    expect(typeof plan.temperature).toBe('number')
    expect(plan.temperature).toBeGreaterThanOrEqual(0)
    expect(typeof plan.maxTokens).toBe('number')
    expect(plan.maxTokens).toBeGreaterThan(0)
    expect(plan.cachePolicy).toBeDefined()
    expect(plan.retryPolicy).toBeDefined()
    expect(plan.fallbackStrategy).toBeDefined()
    expect(plan.audit).toBeDefined()
    expect(plan.audit.timestamp).toBeTruthy()
  })

  it('decide() selects different policies for economy vs premium modes', async () => {
    const economyRequest = createRuntimeRequest({
      operation: 'chat',
      metadata: { mode: 'economy' },
      messages: [{ role: 'user', content: 'Cheap please' }],
    })
    const premiumRequest = createRuntimeRequest({
      operation: 'chat',
      metadata: { mode: 'premium' },
      messages: [{ role: 'user', content: 'Best quality please' }],
    })

    const economyPlan = await engine.decide(economyRequest)
    const premiumPlan = await engine.decide(premiumRequest)

    expect(economyPlan.audit.policyMode).toBe('economy')
    expect(premiumPlan.audit.policyMode).toBe('premium')
    expect(economyPlan.audit.policyMode).not.toBe(premiumPlan.audit.policyMode)

    // Economy mode prefers economy providers (groq/litellm); premium prefers
    // premium providers (gemini/openrouter).
    const economyProviderIsEconomy =
      economyPlan.provider === 'groq' || economyPlan.provider === 'litellm'
    const premiumProviderIsPremium =
      premiumPlan.provider === 'gemini' || premiumPlan.provider === 'openrouter'
    expect(economyProviderIsEconomy).toBe(true)
    expect(premiumProviderIsPremium).toBe(true)

    // Premium mode should have a larger maxTokens than economy.
    expect(premiumPlan.maxTokens).toBeGreaterThanOrEqual(economyPlan.maxTokens)
  })

  it('decide() runs all 9 stages (audit.stages has 9 entries)', async () => {
    const request = createRuntimeRequest({
      operation: 'chat',
      metadata: { mode: 'balanced' },
      messages: [{ role: 'user', content: 'Hello' }],
    })

    const plan = await engine.decide(request)

    expect(plan.audit.stages).toHaveLength(9)
    const expectedStages = [
      'analyze-request',
      'load-policies',
      'detect-intent',
      'evaluate-context',
      'select-provider',
      'select-model',
      'apply-rules',
      'generate-plan',
      'audit-decision',
    ]
    for (let i = 0; i < expectedStages.length; i++) {
      expect(plan.audit.stages[i]!.stage).toBe(expectedStages[i])
      expect(typeof plan.audit.stages[i]!.durationMs).toBe('number')
    }
  })

  it('decide() honors custom policies registered via PolicyEngine.register()', async () => {
    const policyEngine = new PolicyEngine()
    const customMode = 'custom-experimental'
    policyEngine.register({
      mode: customMode,
      description: 'Custom experimental policy for testing.',
      temperatureRange: { min: 0.1, max: 0.3 },
      defaultTemperature: 0.2,
      defaultTopP: 0.8,
      maxTokensLimit: 512,
      defaultMaxTokens: 256,
      priority: 'critical',
      cachePolicy: {
        checkCache: false,
        setCache: false,
        ttlSeconds: 0,
        namespace: 'custom-experimental',
      },
      retryPolicy: {
        maxAttempts: 1,
        baseDelayMs: 0,
        backoffMultiplier: 1,
        retrySameProvider: false,
      },
      fallbackStrategy: {
        enabled: false,
        provider: 'litellm',
        model: 'litellm-auto',
        triggerOn: 'error',
      },
      costCeilingUsd: 0.001,
    })

    const localEngine = new ContentIntelligenceEngine(
      policyEngine,
      new ProviderRouter(true),
      new ModelSelector(true),
    )

    const request = createRuntimeRequest({
      operation: 'generate',
      metadata: { mode: customMode },
      messages: [{ role: 'user', content: 'Generate something' }],
    })

    const plan = await localEngine.decide(request)

    expect(plan.audit.policyMode).toBe(customMode)
    expect(plan.priority).toBe('critical')
    expect(plan.temperature).toBeGreaterThanOrEqual(0.1)
    expect(plan.temperature).toBeLessThanOrEqual(0.3)
    expect(plan.maxTokens).toBeLessThanOrEqual(512)
    expect(plan.cachePolicy.namespace).toBe('custom-experimental')
    expect(plan.cachePolicy.checkCache).toBe(false)
  })
})
