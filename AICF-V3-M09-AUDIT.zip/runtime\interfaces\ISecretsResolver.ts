// =============================================================================
// AICF V3 — Sprint 13+14 — Secrets Resolver Interface
// =============================================================================
// Resolves secret references (e.g. `${env:OPENAI_API_KEY}`) into concrete
// secret values at runtime. Used by providers, step executors, and the
// workflow engine to avoid hard-coding secrets into definitions.
//
// Sprint 13+14 spec requirements covered:
//   - Reference syntax: `${<source>:<key>}` (e.g. `${env:OPENAI_API_KEY}`,
//     `${vault:prod/openai/key}`, `${docker-secrets:openai_key}`)
//   - `resolve(reference)` returns the secret value (throws if not found)
//   - `has(reference)` for safe preflight checks
//   - `registerSource` for pluggable backends (env / vault / docker-secrets /
//     inline)
//   - `listSources` for diagnostics and UI
// =============================================================================

/** Backend a secret reference can resolve through. */
export type SecretSource = 'env' | 'vault' | 'docker-secrets' | 'inline'

/** Resolver function registered for a given source. */
export type SecretResolverFn = (key: string) => Promise<string | null>

/**
 * Secrets resolver contract. Implementations MUST NOT log resolved secret
 * values; only reference strings and resolution success / failure are
 * safe to log.
 */
export interface ISecretsResolver {
  /**
   * Resolve a secret reference into its value.
   * @param reference Reference string in the form `${<source>:<key>}`.
   * @throws If the source is unknown or the key is not found.
   */
  resolve(reference: string): Promise<string>
  /** Whether a reference is resolvable (source known + key present). */
  has(reference: string): Promise<boolean>
  /** List registered secret sources. */
  listSources(): SecretSource[]
  /** Register a resolver for a given source. */
  registerSource(source: SecretSource, resolver: SecretResolverFn): void
}
