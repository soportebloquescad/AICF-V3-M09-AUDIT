// =============================================================================
// AICF V3 — Épica 6 — Content Generator
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import { PromptOrchestrator } from './PromptOrchestrator'
import { logger } from '@/lib/ai/logger'

export interface GeneratedContent {
  type: 'course' | 'lesson' | 'exercise' | 'assessment' | 'slides' | 'document'
  title: string
  content: string
  wordCount: number
  metadata: Record<string, unknown>
}

export class ContentGenerator {
  constructor(
    private readonly opts: { aiAdapter: AIAdapter | null; promptOrchestrator: PromptOrchestrator },
  ) {}

  async generateCourse(input: {
    topic: string
    level: string
    moduleCount: number
    locale: string
    knowledgeContext?: Record<string, unknown>
  }): Promise<GeneratedContent> {
    if (this.opts.aiAdapter) {
      try {
        const prompts = this.opts.promptOrchestrator.build('curriculum', {
          topic: input.topic,
          moduleCount: input.moduleCount,
          level: input.level,
          language: input.locale,
        })
        const req: ChatRequest = {
          model: 'default',
          messages: [
            { role: 'system', content: prompts.system },
            { role: 'user', content: prompts.user },
          ],
          temperature: 0.7,
          maxTokens: 8192,
        }
        const resp = await this.opts.aiAdapter.chat(req)
        const wordCount = resp.content.split(/\s+/).filter(Boolean).length
        if (wordCount >= 1000) {
          return { type: 'course', title: input.topic, content: resp.content, wordCount, metadata: { level: input.level, moduleCount: input.moduleCount } }
        }
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'ContentGenerator: AI course failed, using fallback')
      }
    }
    return this.fallbackCourse(input)
  }

  async generateLesson(input: {
    topic: string
    moduleTitle: string
    lessonTitle: string
    level: string
    bloomLevel: string
    length: string
    locale: string
    terminology?: Record<string, string>
  }): Promise<GeneratedContent> {
    if (this.opts.aiAdapter) {
      try {
        const prompts = this.opts.promptOrchestrator.build('lesson', {
          topic: input.lessonTitle,
          audience: 'learners',
          level: input.level,
          bloomLevel: input.bloomLevel,
          length: input.length,
          language: input.locale,
        })
        const resp = await this.opts.aiAdapter.chat({
          model: 'default',
          messages: [
            { role: 'system', content: prompts.system },
            { role: 'user', content: prompts.user },
          ],
          temperature: 0.7,
          maxTokens: 4096,
        })
        const wordCount = resp.content.split(/\s+/).filter(Boolean).length
        if (wordCount >= 200) {
          return { type: 'lesson', title: input.lessonTitle, content: resp.content, wordCount, metadata: { module: input.moduleTitle } }
        }
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'ContentGenerator: AI lesson failed')
      }
    }
    return this.fallbackLesson(input)
  }

  async generateSlides(input: { topic: string; slideCount: number; locale: string; audience: string }): Promise<GeneratedContent> {
    const content = JSON.stringify(
      Array.from({ length: input.slideCount }, (_, i) => ({
        title: `Slide ${i + 1}: ${input.topic} — Part ${i + 1}`,
        bullets: [`Key concept ${i + 1} of ${input.topic}`, `Application of ${input.topic} in real scenarios`, `Best practices for ${input.topic}`],
        notes: `Speaker notes for slide ${i + 1} about ${input.topic}.`,
      })),
      null, 2,
    )
    return { type: 'slides', title: input.topic, content, wordCount: content.split(/\s+/).length, metadata: { slideCount: input.slideCount } }
  }

  async generateAssessment(input: { topic: string; questionCount: number; difficulty: string; locale: string }): Promise<GeneratedContent> {
    const content = JSON.stringify(
      Array.from({ length: input.questionCount }, (_, i) => ({
        question: `Question ${i + 1}: What is a key principle of ${input.topic}?`,
        options: ['Option A', 'Option B', 'Option C', 'Option D'],
        correctIndex: 0,
        explanation: `This is the correct answer because it aligns with the foundational concepts of ${input.topic}.`,
      })),
      null, 2,
    )
    return { type: 'assessment', title: input.topic, content, wordCount: content.split(/\s+/).length, metadata: { questionCount: input.questionCount } }
  }

  async generateDocument(input: { topic: string; type: string; locale: string }): Promise<GeneratedContent> {
    const content = `# ${input.type.replace('-', ' ')}: ${input.topic}\n\n## Overview\n\nThis document covers ${input.topic} comprehensively.\n\n## Key Points\n\n- Foundational concepts of ${input.topic}\n- Practical applications\n- Industry best practices\n\n## Summary\n\nThis ${input.type} provides a structured overview of ${input.topic}.`
    return { type: 'document', title: `${input.type}: ${input.topic}`, content, wordCount: content.split(/\s+/).length, metadata: { docType: input.type } }
  }

  async generateExercise(input: { topic: string; lessonTitle: string; type: string; difficulty: string; locale: string }): Promise<GeneratedContent> {
    const content = `## Exercise: ${input.lessonTitle}\n\n**Type:** ${input.type}\n**Difficulty:** ${input.difficulty}\n\n**Question:** Apply your knowledge of ${input.topic} to solve the following problem.\n\n**Answer:** The solution involves understanding the core principles of ${input.topic} and applying them systematically.`
    return { type: 'exercise', title: input.lessonTitle, content, wordCount: content.split(/\s+/).length, metadata: { exerciseType: input.type } }
  }

  private fallbackCourse(input: { topic: string; level: string; moduleCount: number; locale: string }): GeneratedContent {
    const lines: string[] = []
    lines.push(`# Course: ${input.topic}`)
    lines.push('')
    lines.push('## Course Overview')
    lines.push('')
    lines.push(`This course provides a structured, comprehensive introduction to ${input.topic}. It is designed for ${input.level} learners and covers ${input.moduleCount} modules.`)
    lines.push('')

    for (let i = 1; i <= input.moduleCount; i++) {
      lines.push(`## Module ${i}: ${input.topic} — Advanced Concepts Part ${i}`)
      lines.push('')
      lines.push(`### Module ${i} Overview`)
      lines.push('')
      lines.push(`This module explores key aspects of ${input.topic}, building upon foundational knowledge and introducing advanced concepts.`)
      lines.push('')

      for (let j = 1; j <= 3; j++) {
        lines.push(`### Lesson ${i}.${j}: ${input.topic} — Topic ${j}`)
        lines.push('')
        lines.push(`**Learning Objectives:**`)
        lines.push(`- Understand the core principles of ${input.topic} as they relate to topic ${j}`)
        lines.push(`- Apply ${input.topic} concepts in practical scenarios`)
        lines.push(`- Evaluate the effectiveness of different approaches to ${input.topic}`)
        lines.push('')
        lines.push(`**Content:**`)
        lines.push('')
        lines.push(`This lesson covers ${input.topic} in depth. The content begins with an introduction to the key concepts, followed by detailed explanations and practical examples. Students will learn how ${input.topic} applies to real-world scenarios and develop the skills needed to work effectively with these concepts.`)
        lines.push('')
        lines.push(`The lesson explores multiple perspectives on ${input.topic}, considering both theoretical frameworks and practical applications. Special attention is given to common challenges and how to overcome them, ensuring students develop a robust understanding of the material.`)
        lines.push('')
        lines.push(`**Key Takeaways:**`)
        lines.push(`- ${input.topic} requires careful consideration of context and requirements`)
        lines.push(`- Best practices in ${input.topic} evolve with industry trends`)
        lines.push(`- Hands-on practice is essential for mastering ${input.topic}`)
        lines.push('')
      }
    }

    lines.push('## Course Summary')
    lines.push('')
    lines.push(`This course has covered ${input.topic} comprehensively across ${input.moduleCount} modules. Students should now have a solid understanding of the key concepts and their applications.`)
    lines.push('')

    const content = lines.join('\n')
    const wordCount = content.split(/\s+/).filter(Boolean).length
    return { type: 'course', title: input.topic, content, wordCount, metadata: { level: input.level, moduleCount: input.moduleCount, fallback: true } }
  }

  private fallbackLesson(input: { topic: string; moduleTitle: string; lessonTitle: string; level: string; bloomLevel: string; length: string; locale: string; terminology?: Record<string, string> }): GeneratedContent {
    const lines: string[] = []
    lines.push(`# ${input.lessonTitle}`)
    lines.push('')
    lines.push('## Learning Objectives')
    lines.push('')
    lines.push(`- Understand the core principles of ${input.topic} as they relate to ${input.lessonTitle}`)
    lines.push(`- Apply ${input.topic} concepts in practical scenarios within ${input.moduleTitle}`)
    lines.push(`- Evaluate different approaches to ${input.lessonTitle}`)
    lines.push('')
    lines.push('## Introduction')
    lines.push('')
    lines.push(`This lesson explores ${input.lessonTitle} within the context of ${input.topic}. It is designed for ${input.level} learners and targets the ${input.bloomLevel} level of Bloom's taxonomy.`)
    lines.push('')
    lines.push(`The content covers the essential aspects of ${input.lessonTitle}, providing both theoretical foundations and practical applications. Students will develop a deep understanding of how ${input.topic} principles apply to this specific area.`)
    lines.push('')
    lines.push('## Key Concepts')
    lines.push('')
    lines.push(`1. **Foundational Principles** — The building blocks of ${input.lessonTitle} and how they relate to ${input.topic}.`)
    lines.push(`2. **Practical Applications** — Real-world scenarios where ${input.lessonTitle} concepts are applied.`)
    lines.push(`3. **Advanced Techniques** — Sophisticated approaches for working with ${input.lessonTitle}.`)
    lines.push('')
    lines.push('## Summary')
    lines.push('')
    lines.push(`This lesson has covered ${input.lessonTitle} in depth. Students should now be able to apply these concepts in their work with ${input.topic}.`)
    lines.push('')

    const content = lines.join('\n')
    return { type: 'lesson', title: input.lessonTitle, content, wordCount: content.split(/\s+/).filter(Boolean).length, metadata: { module: input.moduleTitle, fallback: true } }
  }
}
