// =============================================================================
// AICF V3 — Epica 8 — Assessment Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { ModulePlan, Assessment, QuizQuestion, AssessmentRubric, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class AssessmentBuilder implements EngineContract {
  readonly name = 'assessment-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('AssessmentBuilder: invalid input — expected ModulePlan[]')
    }
    const modules = input as ModulePlan[]
    const assessments: Assessment[] = []
    for (const mod of modules) {
      if (this.opts.aiAdapter) {
        try {
          assessments.push(await this.buildWithAI(mod))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'AssessmentBuilder: AI failed, using fallback')
        }
      }
      assessments.push(this.buildDeterministic(mod))
    }
    // Add a final assessment covering all modules
    if (modules.length > 0) {
      const finalAssessment = this.buildFinalAssessment(modules)
      assessments.push(finalAssessment)
    }
    return assessments
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(mod: ModulePlan): Promise<Assessment> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are an assessment designer. Create a formative assessment with rubric. Respond as JSON: { "title": string, "description": string, "type": "formative"|"summative"|"diagnostic", "questions": [{id, question, options[4], correctIndex, explanation, difficulty, bloomLevel}], "rubric": {criteria: [{name, weight, description}], totalPoints, passingThreshold} }',
        },
        {
          role: 'user',
          content: `Module: ${mod.title}\nOutcomes: ${mod.learningOutcomes.join('; ')}\nBloom levels: ${mod.bloomLevels.join(', ')}\n\nCreate a formative assessment with 5 questions and a rubric.`,
        },
      ],
      temperature: 0.4,
      maxTokens: 4096,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; description?: string; type?: Assessment['type']; questions?: QuizQuestion[]; rubric?: AssessmentRubric }
    return this.assembleAssessment(mod, parsed.title ?? `Assessment: ${mod.title}`, parsed.description ?? '', parsed.type ?? 'formative', parsed.questions ?? [], parsed.rubric ?? this.defaultRubric(), resp.provider as Provider, resp.model)
  }

  private buildDeterministic(mod: ModulePlan): Assessment {
    const questions: QuizQuestion[] = []
    const blooms = mod.bloomLevels.length > 0 ? mod.bloomLevels : ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate']
    for (let i = 0; i < 5; i++) {
      const outcome = mod.learningOutcomes[i % mod.learningOutcomes.length] ?? `concept ${i + 1} of ${mod.title}`
      questions.push({
        id: makeId('aq'),
        question: `In the context of ${mod.title}, demonstrate your understanding by answering: ${outcome}?`,
        options: [
          'A comprehensive and accurate response reflecting module outcomes',
          'A superficial response missing key elements',
          'An incorrect response based on misconceptions',
          'A response that confuses this concept with unrelated material',
        ],
        correctIndex: 0,
        explanation: `The correct response demonstrates mastery of ${outcome.toLowerCase()} as covered in ${mod.title}. It integrates theoretical understanding with practical application, reflecting the module's learning outcomes.`,
        difficulty: i < 2 ? 'easy' : i < 4 ? 'medium' : 'hard',
        bloomLevel: blooms[i % blooms.length],
      })
    }
    return this.assembleAssessment(mod, `Assessment: ${mod.title}`, `Formative assessment for ${mod.title} covering ${questions.length} questions across Bloom levels.`, 'formative', questions, this.defaultRubric(), 'runtime-adapter', 'deterministic-fallback')
  }

  private buildFinalAssessment(modules: ModulePlan[]): Assessment {
    const questions: QuizQuestion[] = []
    const blooms = ['Understand', 'Apply', 'Analyze', 'Evaluate', 'Create']
    for (let i = 0; i < 10; i++) {
      const mod = modules[i % modules.length] ?? modules[0]
      const outcome = mod?.learningOutcomes[i % (mod?.learningOutcomes.length ?? 1)] ?? 'course integration'
      questions.push({
        id: makeId('faq'),
        question: `Final Exam Question ${i + 1}: Integrating concepts from ${mod?.title ?? 'the course'}, ${outcome}?`,
        options: [
          'A response that synthesizes multiple module concepts accurately',
          'A response addressing only one module',
          'A response with significant conceptual errors',
          'A response that does not address the question',
        ],
        correctIndex: 0,
        explanation: `This final exam question tests integration across modules. The correct response synthesizes ${outcome.toLowerCase()} from ${mod?.title ?? 'the course'} with broader course themes, demonstrating comprehensive understanding.`,
        difficulty: i < 4 ? 'medium' : 'hard',
        bloomLevel: blooms[i % blooms.length],
      })
    }
    const now = new Date().toISOString()
    return {
      id: makeId('assess'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider: 'runtime-adapter',
      model: 'deterministic-fallback',
      runtimeVersion: RUNTIME_VERSION,
      moduleId: modules[0]?.id ?? 'all',
      moduleTitle: 'All Modules',
      title: 'Final Exam: Comprehensive Course Assessment',
      description: `A summative final exam covering all ${modules.length} modules. Contains ${questions.length} questions requiring integration of course concepts.`,
      type: 'final',
      questions,
      rubric: this.defaultRubric(),
      passingScore: 70,
      weight: 100,
      durationMinutes: questions.length * 3,
    }
  }

  private defaultRubric(): AssessmentRubric {
    return {
      criteria: [
        { name: 'Conceptual Accuracy', weight: 30, description: 'Correctness of factual and conceptual recall' },
        { name: 'Application', weight: 25, description: 'Ability to apply concepts to novel scenarios' },
        { name: 'Analysis', weight: 20, description: 'Depth of analytical thinking demonstrated' },
        { name: 'Synthesis', weight: 15, description: 'Integration of multiple concepts' },
        { name: 'Communication', weight: 10, description: 'Clarity and organization of responses' },
      ],
      totalPoints: 100,
      passingThreshold: 70,
    }
  }

  private assembleAssessment(
    mod: ModulePlan,
    title: string,
    description: string,
    type: Assessment['type'],
    questions: QuizQuestion[],
    rubric: AssessmentRubric,
    provider: Provider,
    model: string,
  ): Assessment {
    const now = new Date().toISOString()
    return {
      id: makeId('assess'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      moduleId: mod.id,
      moduleTitle: mod.title,
      title,
      description,
      type,
      questions,
      rubric,
      passingScore: 70,
      weight: type === 'final' ? 100 : 20,
      durationMinutes: questions.length * 3,
    }
  }
}
