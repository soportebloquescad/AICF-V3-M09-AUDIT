// =============================================================================
// AICF V3 — Sprint 4: RuntimeContext Immutability Tests
// =============================================================================
// Tests that:
//   - RuntimeContext properties are readonly (TypeScript enforces at compile)
//   - cloneRuntimeContext() returns a different reference
//   - cloneRuntimeContext() deep-clones nested mutable structures
//   - The original context is never mutated by cloning
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { createRuntimeContext, cloneRuntimeContext } from '../RuntimeContext'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'

describe('RuntimeContext Immutability (Sprint 4)', () => {
  it('createRuntimeContext returns a context with all expected fields', () => {
    const request = createRuntimeRequest({ operation: 'chat', model: 'test' })
    const ctx = createRuntimeContext(request)

    expect(ctx.request).toBe(request)
    expect(ctx.response).toBeDefined()
    expect(ctx.response.ok).toBe(true)
    expect(ctx.stageResults).toBeInstanceOf(Map)
    expect(ctx.provider).toBeNull()
    expect(ctx.model).toBeNull()
    expect(ctx.messages).toBeNull()
    expect(ctx.content).toBeNull()
    expect(ctx.usage).toBeNull()
    expect(ctx.models).toBeNull()
    expect(ctx.workflowResult).toBeNull()
    expect(ctx.cached).toBe(false)
    expect(ctx.metrics).toBeDefined()
    expect(ctx.metrics.latencyMs).toBe(0)
    expect(typeof ctx.startedAt).toBe('number')
    expect(Array.isArray(ctx.errors)).toBe(true)
    expect(ctx.errors.length).toBe(0)
    expect(typeof ctx.traceId).toBe('string')
  })

  it('cloneRuntimeContext returns a different reference', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const clone = cloneRuntimeContext(ctx)

    expect(clone).not.toBe(ctx)
  })

  it('cloneRuntimeContext preserves all property values', () => {
    const request = createRuntimeRequest({ operation: 'chat', model: 'test-model' })
    const ctx = createRuntimeContext(request)

    const clone = cloneRuntimeContext(ctx)

    expect(clone.request).toBe(ctx.request)
    expect(clone.response).toEqual(ctx.response)
    expect(clone.provider).toBe(ctx.provider)
    expect(clone.model).toBe(ctx.model)
    expect(clone.messages).toBe(ctx.messages)
    expect(clone.content).toBe(ctx.content)
    expect(clone.usage).toBe(ctx.usage)
    expect(clone.models).toBe(ctx.models)
    expect(clone.workflowResult).toBe(ctx.workflowResult)
    expect(clone.cached).toBe(ctx.cached)
    expect(clone.metrics).toEqual(ctx.metrics)
    expect(clone.startedAt).toBe(ctx.startedAt)
    expect(clone.traceId).toBe(ctx.traceId)
  })

  it('cloneRuntimeContext creates a new response object (not same reference)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const clone = cloneRuntimeContext(ctx)

    expect(clone.response).not.toBe(ctx.response)
    expect(clone.response).toEqual(ctx.response)
  })

  it('cloneRuntimeContext creates a new metrics object (not same reference)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const clone = cloneRuntimeContext(ctx)

    expect(clone.metrics).not.toBe(ctx.metrics)
    expect(clone.metrics).toEqual(ctx.metrics)
  })

  it('cloneRuntimeContext creates a new errors array (not same reference)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const clone = cloneRuntimeContext(ctx)

    expect(clone.errors).not.toBe(ctx.errors)
    expect(clone.errors).toEqual(ctx.errors)
  })

  it('cloneRuntimeContext creates a new stageResults Map (not same reference)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const clone = cloneRuntimeContext(ctx)

    expect(clone.stageResults).not.toBe(ctx.stageResults)
    expect(clone.stageResults.size).toBe(ctx.stageResults.size)
  })

  it('modifying the clone does not affect the original', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)
    const originalResponse = ctx.response
    const originalErrors = ctx.errors

    const clone = cloneRuntimeContext(ctx)
    clone.response = { ...clone.response, ok: false, error: 'test error' }
    clone.errors = [...clone.errors, { stage: 'test', message: 'err' }]

    expect(ctx.response.ok).toBe(true)
    expect(ctx.response).toBe(originalResponse)
    expect(ctx.errors).toBe(originalErrors)
    expect(ctx.errors.length).toBe(0)
  })

  it('modifying the clone stageResults does not affect the original', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const clone = cloneRuntimeContext(ctx)
    clone.stageResults.set('test', { ok: true })

    expect(ctx.stageResults.size).toBe(0)
    expect(clone.stageResults.size).toBe(1)
  })

  it('cloneRuntimeContext preserves messages array content but creates new reference', () => {
    const request = createRuntimeRequest({
      operation: 'chat',
      model: 'test',
      messages: [{ role: 'user', content: 'hello' }],
    })
    const ctx = createRuntimeContext(request)
    const clone1 = cloneRuntimeContext(ctx)
    clone1.messages = [{ role: 'system', content: 'sys' }, { role: 'user', content: 'hello' }]

    const clone2 = cloneRuntimeContext(clone1)
    expect(clone2.messages).not.toBe(clone1.messages)
    expect(clone2.messages).toEqual(clone1.messages)
  })

  it('cloneRuntimeContext handles null arrays correctly (messages, models, usage)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const clone = cloneRuntimeContext(ctx)
    expect(clone.messages).toBeNull()
    expect(clone.models).toBeNull()
    expect(clone.usage).toBeNull()
    expect(clone.workflowResult).toBeNull()
  })

  it('cloneRuntimeContext of a clone produces a different reference each time', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const clone1 = cloneRuntimeContext(ctx)
    const clone2 = cloneRuntimeContext(clone1)
    const clone3 = cloneRuntimeContext(clone2)

    expect(clone1).not.toBe(ctx)
    expect(clone2).not.toBe(clone1)
    expect(clone3).not.toBe(clone2)
  })

  it('traceId defaults to correlationId when no metadata.traceId is set', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    request.correlationId = 'corr-test-123'

    const ctx = createRuntimeContext(request)

    expect(ctx.traceId).toBe('corr-test-123')
  })

  it('traceId uses metadata.traceId when provided', () => {
    const request = createRuntimeRequest({
      operation: 'chat',
      metadata: { traceId: 'custom-trace-456' },
    })

    const ctx = createRuntimeContext(request)

    expect(ctx.traceId).toBe('custom-trace-456')
  })
})
