// =============================================================================
// AICF V3 — Business Context Contract (Épica 2 — AI Factory Core)
// =============================================================================
// The BusinessContext is the per-job shared state object — analogous to the
// RuntimeContext that flows through the Runtime pipeline. Every business
// module's `executeJob()` receives it.
//
// Differences vs RuntimeContext:
//   - The BusinessContext is NOT mutated by modules. Modules read from it;
//     they return their results as ExecutionResult.
//   - It carries trace metadata (correlationId, requestId, jobId) so the
//     AuditSubscriber can attribute events back to the originating request.
//   - `startedAt` is a numeric timestamp (ms since epoch) to make duration
//     math trivial; convert with `new Date(ctx.startedAt).toISOString()`
//     when serializing.
//
// No `any` — `unknown` is used for the open-ended `metadata` bag.
// =============================================================================

/**
 * The context that flows through the Business layer for a single job.
 * Immutable from the module's perspective.
 */
export interface BusinessContext {
  /** The job this context belongs to (matches JobRequest.jobId). */
  jobId: string

  /** Correlation ID for distributed tracing. */
  correlationId: string

  /** Request ID that originated this job (the RuntimeRequest.requestId). */
  requestId: string

  /** Acting user ID (optional — absent for system-triggered jobs). */
  userId?: string

  /** Workspace scope (optional). */
  workspaceId?: string

  /** Project scope (optional). */
  projectId?: string

  /** Locale tag (e.g. 'en', 'es', 'pt-BR'). Defaults to 'en'. */
  locale: string

  /** Epoch timestamp (ms) when the Business layer accepted this job. */
  startedAt: number

  /**
   * Open-ended metadata bag for module-specific propagation (e.g. feature
   * flags, A/B experiment IDs). Modules SHOULD NOT mutate this; they SHOULD
   * read known keys via their own DTOs.
   */
  metadata: Record<string, unknown>
}

/**
 * Factory: creates a BusinessContext from the minimum required fields.
 *
 * - `jobId` is required (callers usually pass the JobRequest.jobId).
 * - `correlationId` and `requestId` default to the jobId when omitted —
 *   this guarantees trace propagation even when the caller is a system
 *   job with no upstream request.
 * - `locale` defaults to 'en'.
 * - `startedAt` defaults to `Date.now()`.
 * - `metadata` defaults to an empty object.
 *
 * @example
 * const ctx = createBusinessContext({ jobId: req.jobId, userId: 'u-1' })
 */
export function createBusinessContext(opts: {
  jobId: string
  correlationId?: string
  requestId?: string
  userId?: string
  workspaceId?: string
  projectId?: string
  locale?: string
  metadata?: Record<string, unknown>
}): BusinessContext {
  return {
    jobId: opts.jobId,
    correlationId: opts.correlationId ?? opts.jobId,
    requestId: opts.requestId ?? opts.jobId,
    userId: opts.userId,
    workspaceId: opts.workspaceId,
    projectId: opts.projectId,
    locale: opts.locale ?? 'en',
    startedAt: Date.now(),
    metadata: opts.metadata ?? {},
  }
}
