// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — CheckpointEngine
// =============================================================================
// The CheckpointEngine persists intermediate pipeline state after each
// stage completes. On resume, the engine reads the latest checkpoint and
// returns the stage to resume from plus the accumulated context.
//
// Checkpoints are in-memory by default — they live for the duration of the
// process. A future sprint can swap in a persistent backing store without
// changing this interface.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * A single checkpoint. Captures the output of one stage plus the
 * accumulated context up to that point.
 */
export interface Checkpoint {
  /** Execution id this checkpoint belongs to. */
  executionId: string
  /** Course id this checkpoint belongs to. */
  courseId: string
  /** Stage name that produced this checkpoint. */
  stage: string
  /** Output of the stage. */
  output: unknown
  /** Accumulated context from all previous stages (including this one). */
  context: Record<string, unknown>
  /** ISO timestamp when the checkpoint was saved. */
  savedAt: string
  /** Monotonic index (0-based) of this checkpoint within the execution. */
  index: number
}

/**
 * The CheckpointEngine. Persists per-execution checkpoints in memory.
 */
export class CheckpointEngine {
  private readonly checkpoints = new Map<string, Checkpoint[]>()

  /**
   * Save a checkpoint for the given execution.
   */
  save(input: {
    executionId: string
    courseId: string
    stage: string
    output: unknown
    context: Record<string, unknown>
  }): Checkpoint {
    const list = this.checkpoints.get(input.executionId) ?? []
    const checkpoint: Checkpoint = {
      executionId: input.executionId,
      courseId: input.courseId,
      stage: input.stage,
      output: input.output,
      context: { ...input.context },
      savedAt: new Date().toISOString(),
      index: list.length,
    }
    list.push(checkpoint)
    this.checkpoints.set(input.executionId, list)
    logger.debug(
      { executionId: input.executionId, stage: input.stage, index: checkpoint.index },
      'CheckpointEngine: checkpoint saved',
    )
    return checkpoint
  }

  /**
   * List all checkpoints for an execution, in order. Returns [] if none.
   */
  list(executionId: string): Checkpoint[] {
    return this.checkpoints.get(executionId) ?? []
  }

  /**
   * Get the latest checkpoint for an execution. Returns null if none.
   */
  getLatest(executionId: string): Checkpoint | null {
    const list = this.checkpoints.get(executionId) ?? []
    if (list.length === 0) return null
    return list[list.length - 1]!
  }

  /**
   * Get a specific checkpoint by execution id and stage name.
   * Returns null if not found.
   */
  get(executionId: string, stage: string): Checkpoint | null {
    const list = this.checkpoints.get(executionId) ?? []
    return list.find((c) => c.stage === stage) ?? null
  }

  /**
   * Returns true if at least one checkpoint exists for the execution.
   */
  has(executionId: string): boolean {
    return (this.checkpoints.get(executionId)?.length ?? 0) > 0
  }

  /**
   * Return the stage name that should be resumed from. This is the stage
   * AFTER the latest checkpoint (i.e. the next stage to run). Returns null
   * if no checkpoints exist.
   *
   * @param stages The full ordered list of stage names in the pipeline.
   */
  getResumeStage(executionId: string, stages: string[]): string | null {
    const latest = this.getLatest(executionId)
    if (!latest) return null
    const idx = stages.indexOf(latest.stage)
    if (idx < 0 || idx + 1 >= stages.length) return null
    return stages[idx + 1]!
  }

  /**
   * Return the accumulated context from the latest checkpoint. Returns
   * an empty object if no checkpoints exist.
   */
  getResumedContext(executionId: string): Record<string, unknown> {
    const latest = this.getLatest(executionId)
    if (!latest) return {}
    return { ...latest.context }
  }

  /**
   * Clear all checkpoints for an execution.
   */
  clear(executionId: string): boolean {
    return this.checkpoints.delete(executionId)
  }

  /**
   * Return the number of checkpoints for an execution.
   */
  count(executionId: string): number {
    return this.checkpoints.get(executionId)?.length ?? 0
  }
}

/**
 * Singleton CheckpointEngine.
 */
let singleton: CheckpointEngine | null = null

export function getCheckpointEngine(): CheckpointEngine {
  if (!singleton) {
    singleton = new CheckpointEngine()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetCheckpointEngine(): void {
  singleton = null
}
