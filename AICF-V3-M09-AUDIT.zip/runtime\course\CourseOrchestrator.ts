// =============================================================================
// AICF V3 — Epica 8 — Course Orchestrator
// =============================================================================
// Runs 17 stages sequentially using the EngineRegistry. Each stage produces
// a typed artifact (cast from unknown at the boundary). Checkpoints are
// saved after each stage. The final stage assembles all artifacts into a
// CourseResult and produces a ZIP buffer.
// =============================================================================
import { ZipArchive } from 'archiver'
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { EngineRegistry } from './EngineRegistry'
import type {
  CourseRequest,
  CourseResult,
  KnowledgePack,
  Curriculum,
  ModulePlan,
  LessonPlan,
  Lesson,
  Exercise,
  Quiz,
  Assessment,
  CaseStudy,
  Checklist,
  Template,
  Presentation,
  Guide,
  QualityReport,
  StageResult,
  Provider,
} from './CourseContracts'
import { auditTrail } from './AuditTrail'
import { costEngine } from './CostEngine'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

function nowIso(): string {
  return new Date().toISOString()
}

export interface CourseOrchestratorOpts {
  aiAdapter: AIAdapter | null
  engineRegistry: EngineRegistry
}

export const ORCHESTRATOR_STAGES = [
  'research',
  'curriculum',
  'modules',
  'lesson-planning',
  'lesson-writing',
  'exercises',
  'quizzes',
  'assessments',
  'case-studies',
  'checklists',
  'templates',
  'slides',
  'guides',
  'quality',
  'validation',
  'publish',
  'zip',
] as const

export type OrchestratorStage = typeof ORCHESTRATOR_STAGES[number]

export class CourseOrchestrator implements EngineContract {
  readonly name = 'course-orchestrator'
  private healthy = false
  private readonly checkpoints = new Map<string, Record<string, unknown>>()

  constructor(private readonly opts: CourseOrchestratorOpts) {}

  async initialize(): Promise<void> {
    this.healthy = true
    logger.info({ engine: this.name }, 'CourseOrchestrator: initialized')
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('CourseOrchestrator: invalid input — expected CourseRequest')
    }
    return this.run(input as CourseRequest)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    return typeof obj.id === 'string' && typeof obj.topic === 'string' && typeof obj.moduleCount === 'number'
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider, latencyMs: h.latencyMs } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
    this.checkpoints.clear()
  }

  getCheckpoint(courseId: string, stage: string): Record<string, unknown> | null {
    return this.checkpoints.get(`${courseId}:${stage}`) ?? null
  }

  listCheckpoints(courseId: string): string[] {
    const prefix = `${courseId}:`
    return Array.from(this.checkpoints.keys()).filter((k) => k.startsWith(prefix)).map((k) => k.slice(prefix.length))
  }

  async run(request: CourseRequest): Promise<CourseResult> {
    const startMs = Date.now()
    const courseId = request.id
    const stages: StageResult[] = []
    auditTrail.record({
      correlationId: request.correlationId,
      courseId,
      action: 'course.start',
      actor: 'course-orchestrator',
      detail: `Starting course generation for "${request.topic}"`,
    })

    const result: CourseResult = this.emptyResult(request)

    try {
      // Stage 1: research
      const knowledgePack = await this.runStage<KnowledgePack>('research', request, async () => {
        const engine = this.opts.engineRegistry.get('research-engine')
        if (!engine) throw new Error('research-engine not registered')
        const out = await engine.execute({ courseRequest: request })
        return out as KnowledgePack
      }, stages, request.correlationId, courseId)
      this.checkpoints.set(`${courseId}:research`, { knowledgePackId: knowledgePack.id })

      // Stage 2: curriculum
      const curriculum = await this.runStage<Curriculum>('curriculum', request, async () => {
        const engine = this.opts.engineRegistry.get('curriculum-builder')
        if (!engine) throw new Error('curriculum-builder not registered')
        const out = await engine.execute({ knowledgePack, courseRequest: request })
        return out as Curriculum
      }, stages, request.correlationId, courseId)
      result.curriculum = curriculum
      result.title = curriculum.title
      result.description = curriculum.description

      // Stage 3: modules
      const modules = await this.runStage<ModulePlan[]>('modules', request, async () => {
        const engine = this.opts.engineRegistry.get('module-planner')
        if (!engine) throw new Error('module-planner not registered')
        const out = await engine.execute(curriculum)
        return out as ModulePlan[]
      }, stages, request.correlationId, courseId)
      result.modules = modules

      // Stage 4: lesson planning
      const lessonPlans = await this.runStage<LessonPlan[]>('lesson-planning', request, async () => {
        const engine = this.opts.engineRegistry.get('lesson-planner')
        if (!engine) throw new Error('lesson-planner not registered')
        const out = await engine.execute(modules)
        return out as LessonPlan[]
      }, stages, request.correlationId, courseId)

      // Stage 5: lesson writing
      const lessons = await this.runStage<Lesson[]>('lesson-writing', request, async () => {
        const engine = this.opts.engineRegistry.get('lesson-writer')
        if (!engine) throw new Error('lesson-writer not registered')
        const out = await engine.execute({ lessonPlans, knowledgePack })
        return out as Lesson[]
      }, stages, request.correlationId, courseId)
      result.lessons = lessons

      // Stage 6: exercises
      const exercises = await this.runStage<Exercise[]>('exercises', request, async () => {
        const engine = this.opts.engineRegistry.get('exercise-builder')
        if (!engine) throw new Error('exercise-builder not registered')
        const out = await engine.execute(lessons)
        return out as Exercise[]
      }, stages, request.correlationId, courseId)
      result.exercises = exercises

      // Stage 7: quizzes
      const quizzes = await this.runStage<Quiz[]>('quizzes', request, async () => {
        const engine = this.opts.engineRegistry.get('quiz-builder')
        if (!engine) throw new Error('quiz-builder not registered')
        const out = await engine.execute(modules)
        return out as Quiz[]
      }, stages, request.correlationId, courseId)
      result.quizzes = quizzes

      // Stage 8: assessments
      const assessments = await this.runStage<Assessment[]>('assessments', request, async () => {
        const engine = this.opts.engineRegistry.get('assessment-builder')
        if (!engine) throw new Error('assessment-builder not registered')
        const out = await engine.execute(modules)
        return out as Assessment[]
      }, stages, request.correlationId, courseId)
      result.assessments = assessments

      // Stage 9: case studies
      const caseStudies = await this.runStage<CaseStudy[]>('case-studies', request, async () => {
        const engine = this.opts.engineRegistry.get('case-study-builder')
        if (!engine) throw new Error('case-study-builder not registered')
        const out = await engine.execute(modules)
        return out as CaseStudy[]
      }, stages, request.correlationId, courseId)
      result.caseStudies = caseStudies

      // Stage 10: checklists
      const checklists = await this.runStage<Checklist[]>('checklists', request, async () => {
        const engine = this.opts.engineRegistry.get('checklist-builder')
        if (!engine) throw new Error('checklist-builder not registered')
        const out = await engine.execute(lessons)
        return out as Checklist[]
      }, stages, request.correlationId, courseId)
      result.checklists = checklists

      // Stage 11: templates
      const templates = await this.runStage<Template[]>('templates', request, async () => {
        const engine = this.opts.engineRegistry.get('template-builder')
        if (!engine) throw new Error('template-builder not registered')
        const out = await engine.execute(lessons)
        return out as Template[]
      }, stages, request.correlationId, courseId)
      result.templates = templates

      // Stage 12: slides — EPIC 10: assign courseId for traceability
      const presentation = await this.runStage<Presentation>('slides', request, async () => {
        const engine = this.opts.engineRegistry.get('slide-builder')
        if (!engine) throw new Error('slide-builder not registered')
        const out = await engine.execute({ title: curriculum.title, modules, lessons })
        const pres = out as Presentation
        // EPIC 10: propagate courseId for traceability
        return { ...pres, courseId }
      }, stages, request.correlationId, courseId)
      result.presentation = presentation

      // Stage 13: guides (teacher + student)
      const guides = await this.runStage<Guide[]>('guides', request, async () => {
        const engine = this.opts.engineRegistry.get('guide-builder')
        if (!engine) throw new Error('guide-builder not registered')
        const teacherGuide = await engine.execute({ type: 'teacher', title: curriculum.title, lessons, curriculum }) as Guide
        const studentGuide = await engine.execute({ type: 'student', title: curriculum.title, lessons, curriculum }) as Guide
        return [teacherGuide, studentGuide]
      }, stages, request.correlationId, courseId)
      result.guides = guides

      // Stage 14: quality
      const qualityReport = await this.runStage<QualityReport>('quality', request, async () => {
        const engine = this.opts.engineRegistry.get('quality-assurance')
        if (!engine) throw new Error('quality-assurance not registered')
        result.stages = stages
        const out = await engine.execute(result)
        return out as QualityReport
      }, stages, request.correlationId, courseId)
      result.qualityReport = qualityReport

      // Stage 15: validation
      await this.runStage<unknown>('validation', request, async () => {
        const engine = this.opts.engineRegistry.get('pre-publish-validators')
        if (!engine) throw new Error('pre-publish-validators not registered')
        result.stages = stages
        const out = await engine.execute(result)
        return out as unknown
      }, stages, request.correlationId, courseId)

      // Stage 16: publish (simulated)
      await this.runStage<unknown>('publish', request, async () => {
        const engine = this.opts.engineRegistry.get('publishing-engine')
        if (!engine) return null as unknown
        result.stages = stages
        const out = await engine.execute(result)
        return out as unknown
      }, stages, request.correlationId, courseId)

      // Stage 17: zip
      const zipResult = await this.runStage<{ zipBuffer: Buffer; sizeBytes: number }>('zip', request, async () => {
        result.stages = stages
        const zipBuffer = await this.buildZip(result)
        result.zipBuffer = zipBuffer
        result.zipUrl = `data:application/zip;base64,${zipBuffer.toString('base64').slice(0, 64)}...`
        return { zipBuffer, sizeBytes: zipBuffer.byteLength }
      }, stages, request.correlationId, courseId)

      result.status = 'completed'
      result.totalWordCount = result.lessons.reduce((sum, l) => sum + l.wordCount, 0)
      result.totalDurationMs = Date.now() - startMs
      const totalCost = costEngine.getTotal(request.correlationId)
      result.totalCost = totalCost.cost

      result.stages = stages

      auditTrail.record({
        correlationId: request.correlationId,
        courseId,
        action: 'course.complete',
        actor: 'course-orchestrator',
        detail: `Course completed in ${result.totalDurationMs}ms with ${result.totalWordCount} words, ${result.lessons.length} lessons, ZIP ${zipResult ? zipResult.sizeBytes : 0} bytes`,
        severity: 'info',
      })

      logger.info({ courseId, status: result.status, durationMs: result.totalDurationMs, wordCount: result.totalWordCount }, 'CourseOrchestrator: completed')
      return result
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      result.status = 'failed'
      result.error = message
      result.totalDurationMs = Date.now() - startMs
      result.stages = stages
      auditTrail.record({
        correlationId: request.correlationId,
        courseId,
        action: 'course.fail',
        actor: 'course-orchestrator',
        detail: message,
        severity: 'error',
      })
      logger.error({ courseId, error: message }, 'CourseOrchestrator: failed')
      return result
    }
  }

  private async runStage<T>(
    stage: string,
    request: CourseRequest,
    fn: () => Promise<T>,
    stages: StageResult[],
    correlationId: string,
    courseId: string,
  ): Promise<T> {
    const startedAt = nowIso()
    const startMs = Date.now()
    auditTrail.record({ correlationId, courseId, stage, action: 'stage.start', actor: 'course-orchestrator', detail: `Starting stage ${stage}` })
    try {
      const output = await fn()
      const completedAt = nowIso()
      const stageResult: StageResult = {
        stage,
        status: 'completed',
        startedAt,
        completedAt,
        durationMs: Date.now() - startMs,
        engineName: this.stageToEngine(stage),
        provider: 'runtime-adapter',
        model: 'orchestrator',
        output: output as unknown,
        checkpoint: { stage, courseId, correlationId },
      }
      stages.push(stageResult)
      this.checkpoints.set(`${courseId}:${stage}`, { output: 'completed', durationMs: stageResult.durationMs })
      auditTrail.record({ correlationId, courseId, stage, action: 'stage.complete', actor: 'course-orchestrator', detail: `Stage ${stage} completed in ${stageResult.durationMs}ms` })
      return output
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      const stageResult: StageResult = {
        stage,
        status: 'failed',
        startedAt,
        durationMs: Date.now() - startMs,
        engineName: this.stageToEngine(stage),
        provider: 'runtime-adapter',
        model: 'orchestrator',
        output: null,
        error: message,
        checkpoint: { stage, courseId, correlationId },
      }
      stages.push(stageResult)
      auditTrail.record({ correlationId, courseId, stage, action: 'stage.fail', actor: 'course-orchestrator', detail: message, severity: 'error' })
      throw err
    }
  }

  private stageToEngine(stage: string): string {
    const map: Record<string, string> = {
      research: 'research-engine',
      curriculum: 'curriculum-builder',
      modules: 'module-planner',
      'lesson-planning': 'lesson-planner',
      'lesson-writing': 'lesson-writer',
      exercises: 'exercise-builder',
      quizzes: 'quiz-builder',
      assessments: 'assessment-builder',
      'case-studies': 'case-study-builder',
      checklists: 'checklist-builder',
      templates: 'template-builder',
      slides: 'slide-builder',
      guides: 'guide-builder',
      quality: 'quality-assurance',
      validation: 'pre-publish-validators',
      publish: 'publishing-engine',
      zip: 'zip-exporter',
    }
    return map[stage] ?? stage
  }

  private emptyResult(request: CourseRequest): CourseResult {
    const now = nowIso()
    return {
      id: makeId('course'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider: request.provider,
      model: 'orchestrator',
      runtimeVersion: RUNTIME_VERSION,
      courseRequestId: request.id,
      topic: request.topic,
      title: request.title,
      description: request.description,
      status: 'generating',
      curriculum: null,
      modules: [],
      lessons: [],
      exercises: [],
      quizzes: [],
      assessments: [],
      caseStudies: [],
      checklists: [],
      templates: [],
      presentation: null,
      guides: [],
      qualityReport: null,
      stages: [],
      zipBuffer: null,
      zipUrl: '',
      totalWordCount: 0,
      totalDurationMs: 0,
      totalCost: 0,
    }
  }

  private async buildZip(result: CourseResult): Promise<Buffer> {
    return new Promise<Buffer>((resolve, reject) => {
      const archive = new ZipArchive({ zlib: { level: 6 } })
      const chunks: Buffer[] = []
      archive.on('data', (chunk: Buffer) => chunks.push(chunk))
      archive.on('end', () => resolve(Buffer.concat(chunks)))
      archive.on('error', (err: Error) => reject(err))

      archive.append(JSON.stringify(result, this.zipReplacer, 2), { name: 'course.json' })
      if (result.curriculum) {
        archive.append(JSON.stringify(result.curriculum, null, 2), { name: 'curriculum.json' })
      }
      for (const mod of result.modules) {
        archive.append(JSON.stringify(mod, null, 2), { name: `modules/${mod.id}.json` })
      }
      for (const lesson of result.lessons) {
        archive.append(lesson.content, { name: `lessons/${lesson.id}.md` })
        archive.append(JSON.stringify(lesson, null, 2), { name: `lessons/${lesson.id}.json` })
      }
      for (const ex of result.exercises) {
        archive.append(JSON.stringify(ex, null, 2), { name: `exercises/${ex.id}.json` })
      }
      for (const quiz of result.quizzes) {
        archive.append(JSON.stringify(quiz, null, 2), { name: `quizzes/${quiz.id}.json` })
      }
      for (const a of result.assessments) {
        archive.append(JSON.stringify(a, null, 2), { name: `assessments/${a.id}.json` })
      }
      for (const cs of result.caseStudies) {
        archive.append(JSON.stringify(cs, null, 2), { name: `case-studies/${cs.id}.json` })
      }
      for (const cl of result.checklists) {
        archive.append(JSON.stringify(cl, null, 2), { name: `checklists/${cl.id}.json` })
      }
      for (const t of result.templates) {
        archive.append(t.body, { name: `templates/${t.id}.${t.format === 'markdown' ? 'md' : t.format === 'html' ? 'html' : 'txt'}` })
      }
      if (result.presentation) {
        archive.append(JSON.stringify(result.presentation, null, 2), { name: `presentation/${result.presentation.id}.json` })
      }
      for (const g of result.guides) {
        const body = g.sections.map((s) => `# ${s.title}\n\n${s.content}`).join('\n\n')
        archive.append(body, { name: `guides/${g.id}-${g.type}.md` })
      }
      if (result.qualityReport) {
        archive.append(JSON.stringify(result.qualityReport, null, 2), { name: 'quality-report.json' })
      }

      archive.finalize()
    })
  }

  private zipReplacer(_key: string, value: unknown): unknown {
    if (value instanceof Buffer) {
      return { __buffer: true, length: value.byteLength }
    }
    return value
  }
}

// Helper to extend CourseResult with a checkpoint method (internal use only)
// NOTE: CourseResult is an interface; the orchestrator tracks checkpoints
// internally via this.checkpoints. No prototype augmentation is performed.
