// =============================================================================
// AICF V3 — Épica 9 — StoryboardGenerator
// =============================================================================
// Generates a structured storyboard for a course presentation. The storyboard
// is the planning layer that drives both the ImageGenerator and the
// InteractivePresentationEngine.
//
// REUSES: SlideGenerator (existing) for slide structure, MediaGenerator
// (existing) for visual descriptions, logger.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

export interface StoryboardSlide {
  index: number
  type: 'cover' | 'agenda' | 'content' | 'diagram' | 'quiz' | 'exercise' | 'case-study' | 'summary'
  title: string
  subtitle: string
  bullets: string[]
  speakerNotes: string
  visual: {
    imagePrompt: string
    diagramPrompt: string | null
    iconHint: string
    animationHint: string
  }
  timing: {
    estimatedSeconds: number
    transition: 'fade' | 'slide' | 'zoom' | 'convex' | 'none'
  }
  countryName?: string
}

export interface Storyboard {
  courseId: string
  title: string
  narrative: string
  slides: StoryboardSlide[]
  visual: {
    images: string[]
    diagrams: string[]
    icons: string[]
    animations: string[]
  }
  speakerNotes: string[]
  timing: {
    total: number
    perSlide: number[]
  }
}

export class StoryboardGenerator {
  private readonly log = logger.child({ component: 'StoryboardGenerator' })

  generate(opts: {
    courseId: string
    title: string
    description: string
    moduleCount: number
    theme: ThemePreset
    locale: LocaleContext
  }): Storyboard {
    const { courseId, title, description, moduleCount, locale } = opts
    this.log.info({ courseId, title, moduleCount }, 'StoryboardGenerator: generating storyboard')

    const slides: StoryboardSlide[] = []
    let idx = 0

    // Cover slide
    slides.push({
      index: idx++,
      type: 'cover',
      title,
      subtitle: description || `A comprehensive course on ${title}`,
      bullets: [],
      speakerNotes: `Welcome to ${title}. This course is adapted for ${locale.country.name}.`,
      visual: {
        imagePrompt: `Professional cover illustration for a course about ${title}. Theme: ${opts.theme.label}. Style: modern, clean, with ${locale.country.name} cultural elements.`,
        diagramPrompt: null,
        iconHint: 'play-circle',
        animationHint: 'fade-in',
      },
      timing: { estimatedSeconds: 30, transition: 'fade' },
      countryName: locale.country.name,
    })

    // Agenda slide
    slides.push({
      index: idx++,
      type: 'agenda',
      title: 'Course Agenda',
      subtitle: `What you will learn in this ${moduleCount}-module course`,
      bullets: Array.from({ length: moduleCount }, (_, i) => `Module ${i + 1}: Key concepts and hands-on practice`),
      speakerNotes: 'Walk through the agenda. Emphasize the hands-on approach.',
      visual: {
        imagePrompt: `Agenda overview diagram for ${title} course with ${moduleCount} modules.`,
        diagramPrompt: `graph LR\n  A[Start] --> B[Module 1]\n  B --> C[Module ${moduleCount}]\n  C --> D[Finish]`,
        iconHint: 'list',
        animationHint: 'slide-left',
      },
      timing: { estimatedSeconds: 45, transition: 'slide' },
    })

    // Content slides per module
    for (let m = 0; m < moduleCount; m++) {
      const example = locale.examples[m % locale.examples.length] ?? `Apply ${title} concepts in module ${m + 1}.`
      slides.push({
        index: idx++,
        type: 'content',
        title: `Module ${m + 1}: ${title}`,
        subtitle: 'Core concepts and practical application',
        bullets: locale.examples.slice(0, 3),
        speakerNotes: `Module ${m + 1} covers key concepts with examples from ${locale.country.name}.`,
        visual: {
          imagePrompt: `Concept illustration for module ${m + 1} of ${title}. Show ${example}. Style: infographic, clean.`,
          diagramPrompt: `graph TB\n  A[Input] --> B[Process ${m + 1}]\n  B --> C[Output]\n  C --> D[Feedback]`,
          iconHint: 'book-open',
          animationHint: 'zoom',
        },
        timing: { estimatedSeconds: 120, transition: 'convex' },
      })
    }

    // Case study slide
    slides.push({
      index: idx++,
      type: 'case-study',
      title: `Case Study: ${title} in ${locale.country.name}`,
      subtitle: locale.realCases[0] ?? `Real-world application of ${title}`,
      bullets: locale.realCases.slice(0, 3),
      speakerNotes: `Discuss the case study. Key takeaway from ${locale.country.name}.`,
      visual: {
        imagePrompt: `Case study illustration for ${title} applied in ${locale.country.name}. Show real companies and context.`,
        diagramPrompt: null,
        iconHint: 'briefcase',
        animationHint: 'fade',
      },
      timing: { estimatedSeconds: 90, transition: 'slide' },
      countryName: locale.country.name,
    })

    // Quiz slide
    slides.push({
      index: idx++,
      type: 'quiz',
      title: `Knowledge Check: ${title}`,
      subtitle: 'Test your understanding (interactive)',
      bullets: locale.exercises.slice(0, 3),
      speakerNotes: 'Pause and let participants answer the quiz questions.',
      visual: {
        imagePrompt: `Quiz illustration for ${title}. Show question marks and interactive elements.`,
        diagramPrompt: null,
        iconHint: 'help-circle',
        animationHint: 'zoom',
      },
      timing: { estimatedSeconds: 60, transition: 'convex' },
    })

    // Summary slide
    slides.push({
      index: idx++,
      type: 'summary',
      title: 'Summary & Next Steps',
      subtitle: 'Key takeaways and how to apply them',
      bullets: [
        'Review the key concepts covered',
        'Apply the exercises to your own context',
        'Explore the additional resources',
      ],
      speakerNotes: 'Recap the main points and encourage participants to apply what they learned.',
      visual: {
        imagePrompt: `Summary illustration for ${title}. Show checkmarks and next steps.`,
        diagramPrompt: null,
        iconHint: 'check-circle',
        animationHint: 'fade',
      },
      timing: { estimatedSeconds: 30, transition: 'fade' },
    })

    const totalSeconds = slides.reduce((sum, s) => sum + s.timing.estimatedSeconds, 0)
    const perSlide = slides.map((s) => s.timing.estimatedSeconds)

    const storyboard: Storyboard = {
      courseId,
      title,
      narrative: `This storyboard covers ${title} across ${moduleCount} modules, adapted for ${locale.country.name}. It includes ${slides.length} slides with a total estimated duration of ${totalSeconds} seconds.`,
      slides,
      visual: {
        images: slides.map((s) => s.visual.imagePrompt),
        diagrams: slides.filter((s) => s.visual.diagramPrompt).map((s) => s.visual.diagramPrompt!),
        icons: slides.map((s) => s.visual.iconHint),
        animations: slides.map((s) => s.visual.animationHint),
      },
      speakerNotes: slides.map((s) => s.speakerNotes),
      timing: { total: totalSeconds, perSlide },
    }

    this.log.info({ courseId, slideCount: slides.length, totalSeconds }, 'StoryboardGenerator: storyboard complete')
    return storyboard
  }
}
