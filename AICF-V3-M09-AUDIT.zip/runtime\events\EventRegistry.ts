// =============================================================================
// AICF V3 — Runtime Event Registry (Sprint 21: EDA Runtime Observability)
// =============================================================================
// A registry of all EDA events emitted by the runtime pipeline. Each event
// carries:
//   - name: matches a RuntimeEventType literal (typed as string to allow
//     tests + extensions to register ad-hoc events without a TS error)
//   - version: schema version of the payload (currently '1.0')
//   - stage: the pipeline stage that emits the event
//   - description: human-readable summary
//   - producer: the module/component that produces the event
//   - expectedConsumers: list of subscribers expected to handle the event
//   - payloadSchema: a JSON-Schema-ish description of the payload fields
//
// The registry is pre-populated with all 12 EDA lifecycle events added in
// Sprint Foundation-Core. Sprint 21 only adds metadata around those events —
// no new event types are introduced.
// =============================================================================

/**
 * Registration record describing one EDA event in the runtime.
 */
export interface EventRegistration {
  /** Event name — typically matches a RuntimeEventType literal. */
  name: string

  /** Schema version of the event payload. */
  version: string

  /** Pipeline stage that emits this event. */
  stage: string

  /** Human-readable description. */
  description: string

  /** Module/component that produces this event. */
  producer: string

  /** Subscribers expected to consume this event. */
  expectedConsumers: string[]

  /** Loose payload schema — describes the fields in the payload object. */
  payloadSchema: Record<string, unknown>
}

/**
 * In-memory registry of EDA events. Pre-populated with all 12 lifecycle
 * events emitted by the runtime pipeline.
 */
export class RuntimeEventRegistry {
  private readonly registrations = new Map<string, EventRegistration>()

  /**
   * Registers (or replaces) an event registration by name.
   */
  register(reg: EventRegistration): void {
    this.registrations.set(reg.name, reg)
  }

  /**
   * Returns the registration for `name`, or null if not registered.
   */
  get(name: string): EventRegistration | null {
    return this.registrations.get(name) || null
  }

  /**
   * Returns all registered events (in insertion order).
   */
  list(): EventRegistration[] {
    return Array.from(this.registrations.values())
  }

  /**
   * Returns all events emitted by the given pipeline stage.
   */
  listByStage(stage: string): EventRegistration[] {
    return this.list().filter((reg) => reg.stage === stage)
  }

  /**
   * Returns a JSON-serializable array of all registrations.
   */
  toJSON(): EventRegistration[] {
    return this.list()
  }
}

/**
 * The pre-populated registry of all 12 EDA lifecycle events emitted by the
 * runtime pipeline. Order matches the canonical pipeline execution order:
 *
 *   RequestReceived          (RuntimeService — order 1)
 *   ValidationStarted        (Validate      — order 2)
 *   ValidationCompleted      (Validate      — order 3)
 *   PolicyStarted            (Policy        — order 4)
 *   PolicyCompleted          (Policy        — order 5)
 *   RoutingStarted           (Routing       — order 6)
 *   RoutingCompleted         (Routing       — order 7)
 *   ExecutionStarted         (Execution     — order 8)
 *   ExecutionFinished        (Execution     — order 9)
 *   AuditStarted             (PostProcessing— order 10)
 *   AuditCompleted           (PostProcessing— order 11)
 *   ResponseReturned         (RuntimeService— order 12)
 */
export const runtimeEventRegistry = new RuntimeEventRegistry()

runtimeEventRegistry.register({
  name: 'RequestReceived',
  version: '1.0',
  stage: 'RuntimeService',
  description: 'Emitted when the RuntimeService receives a new request, before the pipeline runs.',
  producer: 'RuntimeService',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      correlationId: { type: 'string' },
      operation: { type: 'string' },
      model: { type: 'string' },
      messageCount: { type: 'number' },
    },
    required: ['requestId', 'correlationId', 'operation'],
  },
})

runtimeEventRegistry.register({
  name: 'ValidationStarted',
  version: '1.0',
  stage: 'Validate',
  description: 'Emitted before the Validate stage validates the incoming request schema.',
  producer: 'ValidateStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      operation: { type: 'string' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'ValidationCompleted',
  version: '1.0',
  stage: 'Validate',
  description: 'Emitted after the Validate stage finishes, with the validation result.',
  producer: 'ValidateStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      valid: { type: 'boolean' },
      errors: { type: 'array', items: { type: 'string' } },
    },
    required: ['requestId', 'valid'],
  },
})

runtimeEventRegistry.register({
  name: 'PolicyStarted',
  version: '1.0',
  stage: 'Policy',
  description: 'Emitted before the Policy stage evaluates the request against CI policy rules.',
  producer: 'PolicyStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      operation: { type: 'string' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'PolicyCompleted',
  version: '1.0',
  stage: 'Policy',
  description: 'Emitted after the Policy stage finishes, with the policy decision.',
  producer: 'PolicyStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      allowed: { type: 'boolean' },
      reason: { type: 'string' },
    },
    required: ['requestId', 'allowed'],
  },
})

runtimeEventRegistry.register({
  name: 'RoutingStarted',
  version: '1.0',
  stage: 'Routing',
  description: 'Emitted before the Routing stage selects a provider+model.',
  producer: 'RoutingStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      operation: { type: 'string' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'RoutingCompleted',
  version: '1.0',
  stage: 'Routing',
  description: 'Emitted after the Routing stage selects a provider+model.',
  producer: 'RoutingStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      provider: { type: 'string' },
      model: { type: 'string' },
    },
    required: ['requestId', 'provider', 'model'],
  },
})

runtimeEventRegistry.register({
  name: 'ExecutionStarted',
  version: '1.0',
  stage: 'Execution',
  description: 'Emitted before the Execution stage tries M21/M18/fallback generation.',
  producer: 'ExecutionStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      provider: { type: 'string' },
      model: { type: 'string' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'ExecutionFinished',
  version: '1.0',
  stage: 'Execution',
  description: 'Emitted after the Execution stage finishes, with success/duration/module.',
  producer: 'ExecutionStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      success: { type: 'boolean' },
      module: { type: 'string' },
      durationMs: { type: 'number' },
    },
    required: ['requestId', 'success'],
  },
})

runtimeEventRegistry.register({
  name: 'AuditStarted',
  version: '1.0',
  stage: 'PostProcessing',
  description: 'Emitted before the PostProcessing stage normalizes the response.',
  producer: 'PostProcessingStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      operation: { type: 'string' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'AuditCompleted',
  version: '1.0',
  stage: 'PostProcessing',
  description: 'Emitted after the PostProcessing stage normalizes the response.',
  producer: 'PostProcessingStage',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      module: { type: 'string' },
      tokensTotal: { type: 'number' },
    },
    required: ['requestId'],
  },
})

runtimeEventRegistry.register({
  name: 'ResponseReturned',
  version: '1.0',
  stage: 'RuntimeService',
  description: 'Emitted after the pipeline runs, with the final response summary.',
  producer: 'RuntimeService',
  expectedConsumers: ['AuditSubscriber', 'MetricsSubscriber', 'DashboardSubscriber'],
  payloadSchema: {
    type: 'object',
    properties: {
      requestId: { type: 'string' },
      ok: { type: 'boolean' },
      status: { type: 'number' },
      durationMs: { type: 'number' },
    },
    required: ['requestId', 'ok'],
  },
})
