// =============================================================================
// AICF V3 — Epica 7 — Rubric System
// =============================================================================
// Eight real heuristic-based evaluation criteria (0-10 scale each).
// =============================================================================

export interface RubricCriteria {
  accuracy: number
  completeness: number
  clarity: number
  depth: number
  pedagogy: number
  engagement: number
  consistency: number
  accessibility: number
}

export interface Rubric {
  total: number
  average: number
  grade: 'A' | 'B' | 'C' | 'D' | 'F'
  criteria: RubricCriteria
  notes: string[]
}

export interface RubricMetadata {
  topic: string
  level: string
  locale: string
  audience: string
  expectedWordCount?: number
  moduleCount?: number
  lessonCount?: number
}

const BLOOM_VERBS = ['define', 'describe', 'explain', 'apply', 'analyze', 'evaluate', 'create', 'identify', 'compare', 'design', 'summarize', 'synthesize']
const FILLER_WORDS = ['very', 'really', 'just', 'actually', 'basically', 'literally', 'simply', 'thing', 'stuff', 'kind of', 'sort of']
const ACCESSIBILITY_MARKERS = ['alt', 'image', 'caption', 'transcript', 'subtitle', 'aria', 'heading', 'semantic']

function clamp(n: number, min = 0, max = 10): number {
  return Math.max(min, Math.min(max, n))
}

class RubricSystemImpl {
  evaluate(content: string, metadata: RubricMetadata): Rubric {
    const notes: string[] = []
    const lowerContent = content.toLowerCase()
    const words = content.split(/\s+/).filter(Boolean)
    const sentences = content.split(/[.!?]+/).filter((s) => s.trim().length > 0)
    const paragraphs = content.split(/\n\n+/).filter((p) => p.trim().length > 0)

    // 1. Accuracy — heuristic: presence of factual markers, references, citations
    const hasReferences = /references?|bibliography|\[\d+\]|\(author,?\s*\d{4}\)|https?:\/\//i.test(content)
    const hasDefinitions = /(?:is defined as|refers to|means|is a|is an|are)\s/gi.test(content)
    const hasExamples = /for example|for instance|such as|e\.g\.|like\s+/gi.test(content)
    let accuracy = 4
    if (hasReferences) accuracy += 3
    if (hasDefinitions) accuracy += 2
    if (hasExamples) accuracy += 2
    if (!hasReferences) notes.push('No references or citations detected — accuracy may be unverifiable')
    accuracy = clamp(accuracy)

    // 2. Completeness — heuristic: section coverage, word count vs expected
    const expectedWords = metadata.expectedWordCount ?? Math.max(1000, (metadata.moduleCount ?? 1) * 800)
    const wordRatio = words.length / expectedWords
    const hasObjectives = /objectives?|learning outcomes?|goals?/i.test(content)
    const hasSummary = /summary|conclusion|recap|wrap-up/i.test(content)
    const hasAssessment = /exercise|quiz|assessment|practice|activity/i.test(content)
    let completeness = 3
    completeness += clamp(wordRatio * 4, 0, 3)
    if (hasObjectives) completeness += 1
    if (hasSummary) completeness += 1
    if (hasAssessment) completeness += 1
    if (words.length < 500) notes.push(`Word count (${words.length}) is too low for a complete lesson`)
    completeness = clamp(completeness)

    // 3. Clarity — heuristic: sentence length, filler words, readability
    const avgSentenceLen = sentences.length > 0 ? words.length / sentences.length : 0
    const fillerCount = FILLER_WORDS.reduce((c, w) => c + (lowerContent.match(new RegExp(`\\b${w}\\b`, 'g')) ?? []).length, 0)
    let clarity = 8
    if (avgSentenceLen > 30) clarity -= 2
    if (avgSentenceLen > 40) clarity -= 1
    if (avgSentenceLen < 10) clarity -= 1
    clarity -= clamp(fillerCount * 0.3, 0, 3)
    if (fillerCount > 5) notes.push(`High filler-word count (${fillerCount}) reduces clarity`)
    clarity = clamp(clarity)

    // 4. Depth — heuristic: technical vocabulary, code blocks, multi-level headings
    const codeBlocks = (content.match(/```/g) ?? []).length / 2
    const headingLevels = (content.match(/^#{2,4}\s/gm) ?? []).length
    const technicalTerms = (lowerContent.match(/\b(?:algorithm|architecture|framework|protocol|paradigm|methodology|infrastructure|optimization|semantic|syntactic)\b/g) ?? []).length
    let depth = 3
    depth += clamp(codeBlocks, 0, 2)
    depth += clamp(headingLevels * 0.2, 0, 2)
    depth += clamp(technicalTerms * 0.15, 0, 3)
    if (technicalTerms < 3) notes.push('Limited technical depth — few domain-specific terms detected')
    depth = clamp(depth)

    // 5. Pedagogy — heuristic: Bloom verbs, scaffolding, learning objectives
    const bloomCount = BLOOM_VERBS.reduce((c, v) => c + (lowerContent.match(new RegExp(`\\b${v}`, 'g')) ?? []).length, 0)
    const hasScaffolding = /first|then|next|finally|step \d|step-by-step|prerequisite/i.test(content)
    let pedagogy = 3
    pedagogy += clamp(bloomCount * 0.3, 0, 5)
    if (hasScaffolding) pedagogy += 2
    if (bloomCount < 3) notes.push('Few Bloom-taxonomy action verbs — pedagogical intent unclear')
    pedagogy = clamp(pedagogy)

    // 6. Engagement — heuristic: questions, scenarios, interactive elements
    const questionCount = (content.match(/\?/g) ?? []).length
    const hasScenarios = /scenario|case study|imagine|consider|suppose|situation/i.test(content)
    const hasInteractive = /try this|practice|exercise|activity|hands-on|workshop/i.test(content)
    let engagement = 4
    engagement += clamp(questionCount * 0.3, 0, 3)
    if (hasScenarios) engagement += 2
    if (hasInteractive) engagement += 1
    if (questionCount === 0) notes.push('No questions detected — engagement may be low')
    engagement = clamp(engagement)

    // 7. Consistency — heuristic: heading patterns, terminology repetition
    const h2Count = (content.match(/^##\s/gm) ?? []).length
    const h3Count = (content.match(/^###\s/gm) ?? []).length
    const headingVariance = h2Count > 0 && h3Count > 0 ? Math.abs(h2Count - h3Count) : 0
    let consistency = 8
    if (headingVariance > 5) consistency -= 2
    if (paragraphs.length < 3) consistency -= 2
    const repeatedPhrases = this.countRepeatedPhrases(content)
    consistency -= clamp(repeatedPhrases * 0.5, 0, 3)
    if (repeatedPhrases > 2) notes.push(`${repeatedPhrases} repeated phrases detected — check for redundancy`)
    consistency = clamp(consistency)

    // 8. Accessibility — heuristic: alt text, captions, semantic markup
    const images = (content.match(/!\[[^\]]*\]\([^)]+\)/g) ?? []).length
    const imagesWithAlt = (content.match(/!\[[^\]]+\]\([^)]+\)/g) ?? []).length
    const accessibilityMarkers = ACCESSIBILITY_MARKERS.reduce((c, m) => c + (lowerContent.includes(m) ? 1 : 0), 0)
    let accessibility = 5
    if (images > 0) {
      accessibility += clamp((imagesWithAlt / images) * 3, 0, 3)
    } else {
      accessibility += 2 // no images = no alt-text debt
    }
    accessibility += clamp(accessibilityMarkers * 0.3, 0, 2)
    if (images > 0 && imagesWithAlt === 0) notes.push('Images without alt text — accessibility issue')
    accessibility = clamp(accessibility)

    const criteria: RubricCriteria = {
      accuracy,
      completeness,
      clarity,
      depth,
      pedagogy,
      engagement,
      consistency,
      accessibility,
    }
    const total = Object.values(criteria).reduce((s, v) => s + v, 0)
    const average = total / 8
    const grade: Rubric['grade'] = average >= 9 ? 'A' : average >= 8 ? 'B' : average >= 7 ? 'C' : average >= 5 ? 'D' : 'F'

    return { total, average, grade, criteria, notes }
  }

  private countRepeatedPhrases(content: string): number {
    const phrases = content.toLowerCase().match(/\b(\w+\s+){3,}\w+\b/g) ?? []
    const seen = new Map<string, number>()
    for (const p of phrases) {
      seen.set(p, (seen.get(p) ?? 0) + 1)
    }
    let repeats = 0
    for (const count of seen.values()) {
      if (count > 1) repeats++
    }
    return repeats
  }
}

export const rubricSystem = new RubricSystemImpl()
