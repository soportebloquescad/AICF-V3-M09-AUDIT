// =============================================================================
// AICF V3 — Hot Reloadable Contract (Sprint 16: Runtime Plugin Integration)
// =============================================================================
// Interface for modules that support hot reload.
// All Sprint 16 modules implement this so the Runtime can call reload()
// in the future without restarting the process.
// =============================================================================

/**
 * Interface for modules that support hot reload.
 *
 * Sprint 16: all modules implement this, but reload() is not called yet.
 * The Runtime will use it in a future sprint to swap modules without restart.
 */
export interface HotReloadable {
  /** Load the module (alias for initialize). */
  load(): Promise<void>

  /** Unload the module (alias for dispose). */
  unload(): Promise<void>

  /** Reload the module (unload + load). */
  reload(): Promise<void>

  /** Dispose all resources (final cleanup). */
  dispose(): Promise<void>
}
