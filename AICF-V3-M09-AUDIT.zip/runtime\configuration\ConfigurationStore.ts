// =============================================================================
// AICF V3 — Sprint 10 — ConfigurationStore (in-memory, process-level)
// =============================================================================
import type { CourseConfiguration } from './CourseConfiguration'
import { createDefaultConfiguration } from './CourseConfiguration'
import { logger } from '@/lib/ai/logger'

export class ConfigurationStore {
  private readonly log = logger.child({ component: 'ConfigurationStore' })
  private readonly memory = new Map<string, CourseConfiguration>()

  async create(config: CourseConfiguration): Promise<CourseConfiguration> {
    const id = config.id || this.makeId()
    const toSave: CourseConfiguration = { ...config, id, version: 1 }
    this.memory.set(id, toSave)
    this.log.info({ id }, 'ConfigurationStore: created')
    return toSave
  }

  async update(id: string, patch: Partial<CourseConfiguration>): Promise<CourseConfiguration | null> {
    const existing = this.memory.get(id)
    if (!existing) return null
    const updated: CourseConfiguration = {
      ...existing, ...patch, id,
      version: existing.version + 1,
      updatedAt: new Date().toISOString(),
    }
    this.memory.set(id, updated)
    this.log.info({ id, version: updated.version }, 'ConfigurationStore: updated')
    return updated
  }

  async get(id: string): Promise<CourseConfiguration | null> {
    return this.memory.get(id) ?? null
  }

  async list(): Promise<CourseConfiguration[]> {
    return Array.from(this.memory.values()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  }

  async delete(id: string): Promise<boolean> {
    return this.memory.delete(id)
  }

  private makeId(): string {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 8)
    return `cfg-${ts}-${rand}`
  }
}

let singleton: ConfigurationStore | null = null
export function getConfigurationStore(): ConfigurationStore {
  if (!singleton) singleton = new ConfigurationStore()
  return singleton
}
export function resetConfigurationStore(): void { singleton = null }
