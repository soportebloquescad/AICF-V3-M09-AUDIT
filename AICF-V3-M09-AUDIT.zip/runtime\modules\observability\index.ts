// =============================================================================
// AICF V3 — Sprint 13+14 — Observability Module — Barrel + Factory
// =============================================================================
// Public surface for the observability runtime module. Re-exports the
// metrics collector, trace collector, logger provider, and the module
// class, plus a `createObservabilityModule(deps?)` factory that wires them
// together with sensible defaults.
//
// Sprint 13+14 spec requirements covered:
//   - Single import surface for external consumers:
//       import {
//         ObservabilityModule,
//         createObservabilityModule,
//       } from '@/lib/runtime/modules/observability'
//   - `createObservabilityModule(deps?)` accepts an optional `baseLogger`
//     (defaults to the pino logger from `@/lib/ai/logger`) and an optional
//     `eventBus` (for auto-creation of trace spans from workflow events).
//   - Returns `{ module, metrics, trace, loggerProvider }` so callers can
//     reach into the individual collectors if needed.
// =============================================================================

// --- Metrics -----------------------------------------------------------------
export { ObservabilityMetricsCollector } from './metrics/MetricsCollector'
export type {
  HistogramStats,
  StandardMetricName,
} from './metrics/MetricsCollector'
export { STANDARD_METRICS } from './metrics/MetricsCollector'

// --- Trace -------------------------------------------------------------------
export { TraceCollector } from './trace/TraceCollector'
export type { TraceSpan, TraceEvent } from './trace/TraceCollector'

// --- Logger ------------------------------------------------------------------
export { LoggerProvider } from './logger/LoggerProvider'
export type { Logger, LogEntry, LogLevel } from './logger/LoggerProvider'

// --- Module ------------------------------------------------------------------
export { ObservabilityModule } from './ObservabilityModule'

// =============================================================================
// Factory
// =============================================================================

import type { Logger as PinoLogger } from 'pino'
import type { IEventBus } from '@/lib/runtime/interfaces'
import { logger as defaultBaseLogger } from '@/lib/ai/logger'

import { ObservabilityMetricsCollector } from './metrics/MetricsCollector'
import { TraceCollector } from './trace/TraceCollector'
import { LoggerProvider } from './logger/LoggerProvider'
import { ObservabilityModule } from './ObservabilityModule'

/** Optional dependencies accepted by `createObservabilityModule`. */
export interface CreateObservabilityModuleDeps {
  /**
   * Base pino logger. Defaults to the singleton `logger` from
   * `@/lib/ai/logger`. Pass a custom instance for tests or for routing
   * observability logs to a separate transport.
   */
  baseLogger?: PinoLogger
  /**
   * Optional event bus. When provided, the trace collector subscribes to
   * workflow lifecycle events and auto-creates spans from them.
   */
  eventBus?: IEventBus
}

/** Wired bundle returned by `createObservabilityModule`. */
export interface ObservabilityModuleBundle {
  /** The `RuntimeModule`-implementing entry point. */
  module: ObservabilityModule
  /** The metrics collector (counters / histograms / gauges). */
  metrics: ObservabilityMetricsCollector
  /** The trace collector (distributed spans by correlationId). */
  trace: TraceCollector
  /** The logger provider (named child loggers + in-memory ring buffer). */
  loggerProvider: LoggerProvider
}

/**
 * Build a fully-wired observability module bundle.
 *
 * @example
 *   const { module, loggerProvider } = createObservabilityModule({ eventBus })
 *   await module.initialize()
 *   const log = loggerProvider.getLogger('my-module')
 *   log.info('hello', { foo: 'bar' })
 *
 * The factory is idempotent in the sense that each call constructs a fresh
 * bundle; bundles do not share state.
 */
export function createObservabilityModule(
  deps: CreateObservabilityModuleDeps = {},
): ObservabilityModuleBundle {
  const baseLogger = deps.baseLogger ?? defaultBaseLogger
  const metrics = new ObservabilityMetricsCollector()
  const trace = new TraceCollector(deps.eventBus)
  const loggerProvider = new LoggerProvider(baseLogger)
  const observabilityModule = new ObservabilityModule(
    metrics,
    trace,
    loggerProvider,
  )

  baseLogger.debug(
    {
      hasEventBus: deps.eventBus !== undefined,
      hasCustomLogger: deps.baseLogger !== undefined,
    },
    'observability module created',
  )

  return {
    module: observabilityModule,
    metrics,
    trace,
    loggerProvider,
  }
}
