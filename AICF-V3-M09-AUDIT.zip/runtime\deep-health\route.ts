// =============================================================================
// AICF V3 — Sprint 2.2 — GET /api/runtime/deep-health (READINESS + DEPENDENCIES)
// =============================================================================
// Deep health: verifies Runtime, LiteLLM, PostgreSQL, n8n, Open WebUI.
// Returns 200 if ALL healthy, 503 if ANY fail.
// Returns x-correlation-id header.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { peekRuntimeService } from '@/lib/runtime/runtime-singleton'
import { createCorrelationId, extractCorrelationIdFromHeaders, CORRELATION_ID_HEADER } from '@/lib/runtime/middleware/CorrelationId'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  const correlationId = extractCorrelationIdFromHeaders(request.headers) ?? createCorrelationId()
  const reqLogger = logger.child({ endpoint: '/runtime/deep-health', correlationId })
  const timestamp = new Date().toISOString()
  const checks: Record<string, { healthy: boolean; latencyMs: number; error?: string }> = {}

  // 1. Runtime
  const rtStart = Date.now()
  const service = peekRuntimeService()
  checks.runtime = {
    healthy: service !== null,
    latencyMs: Date.now() - rtStart,
    error: service ? undefined : 'RuntimeService not initialized',
  }

  // 2. LiteLLM
  const llmStart = Date.now()
  const litellmUrl = process.env.LITELLM_BASE_URL || 'http://localhost:4000'
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${litellmUrl}/health`, { signal: controller.signal })
    clearTimeout(timer)
    checks.litellm = { healthy: res.ok, latencyMs: Date.now() - llmStart }
  } catch (err) {
    checks.litellm = { healthy: false, latencyMs: Date.now() - llmStart, error: err instanceof Error ? err.message : 'LiteLLM not reachable' }
  }

  // 3. PostgreSQL
  const pgStart = Date.now()
  try {
    const { db } = await import('@/lib/db')
    await db.$queryRaw`SELECT 1`
    checks.postgresql = { healthy: true, latencyMs: Date.now() - pgStart }
  } catch (err) {
    checks.postgresql = { healthy: false, latencyMs: Date.now() - pgStart, error: err instanceof Error ? err.message : 'DB not configured' }
  }

  // 4. n8n
  const n8nStart = Date.now()
  const n8nUrl = process.env.N8N_BASE_URL || 'http://localhost:5678'
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${n8nUrl}/healthz`, { signal: controller.signal })
    clearTimeout(timer)
    checks.n8n = { healthy: res.ok, latencyMs: Date.now() - n8nStart }
  } catch {
    checks.n8n = { healthy: false, latencyMs: Date.now() - n8nStart, error: 'n8n not reachable' }
  }

  // 5. Open WebUI
  const owuiStart = Date.now()
  const owuiUrl = process.env.OPENWEBUI_BASE_URL || 'http://localhost:8080'
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${owuiUrl}/health`, { signal: controller.signal })
    clearTimeout(timer)
    checks.openwebui = { healthy: res.ok, latencyMs: Date.now() - owuiStart }
  } catch {
    checks.openwebui = { healthy: false, latencyMs: Date.now() - owuiStart, error: 'Open WebUI not reachable' }
  }

  const allHealthy = Object.values(checks).every((c) => c.healthy)
  reqLogger.info({ allHealthy, checks }, 'Deep health check complete')

  return NextResponse.json(
    { status: allHealthy ? 'healthy' : 'unhealthy', checks, timestamp, correlationId },
    { status: 200, headers: { [CORRELATION_ID_HEADER]: correlationId } },
  )
}
