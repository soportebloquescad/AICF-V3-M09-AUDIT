// =============================================================================
// AICF V3 — Sprint 13+14 — Variable Resolver
// =============================================================================
// Resolves `{{variable}}` placeholders inside strings, arrays, and plain
// objects. Used by the step executor to materialize step inputs / configs
// against the per-execution variable bindings carried in `WorkflowContext`.
//
// Supported syntax:
//   - `{{var}}`               — direct lookup
//   - `{{user.name}}`         — dot-notation nested lookup
//   - `{{var|default value}}` — default when `var` is missing / undefined
//   - `{{var|}}`              — empty-string default
//
// Sprint 13+14 spec requirements covered:
//   - Recursive resolution of strings, arrays, and objects
//   - Dot-notation for nested variable bindings
//   - Default-value fallback for graceful degradation
//   - No `any` — open values typed as `unknown` with explicit guards
//
// The resolver is pure: it does not mutate inputs and does not perform I/O.
// =============================================================================

/** Match `{{path|default}}` style placeholders. */
const PLACEHOLDER_RE = /\{\{\s*([^}]+?)\s*\}\}/g

/**
 * Resolves `{{variable}}` placeholders in workflow configs / inputs against
 * a variables map. Pure and stateless — safe to call concurrently.
 */
export class VariableResolver {
  /**
   * Recursively resolve placeholders in a value of arbitrary shape.
   * - Strings are template-resolved via `resolveString`.
   * - Arrays are mapped recursively.
   * - Plain objects are mapped recursively (preserving key order).
   * - All other values (numbers, booleans, null, undefined, class instances)
   *   are returned as-is.
   *
   * @param value     The value to resolve.
   * @param variables Variable bindings visible to the resolver.
   */
  resolve(value: unknown, variables: Record<string, unknown>): unknown {
    if (typeof value === 'string') {
      return this.resolveString(value, variables)
    }
    if (Array.isArray(value)) {
      return value.map((item) => this.resolve(item, variables))
    }
    if (this.isPlainObject(value)) {
      const out: Record<string, unknown> = {}
      for (const [k, v] of Object.entries(value)) {
        out[k] = this.resolve(v, variables)
      }
      return out
    }
    return value
  }

  /**
   * Replace every `{{path|default}}` placeholder in `str` with the resolved
   * value. When a placeholder resolves to a non-string value, the resolved
   * value is JSON-serialized (objects / arrays) or stringified (numbers /
   * booleans). Missing variables fall back to the supplied default, or to
   * the literal placeholder text if no default was supplied.
   *
   * Special case: if the entire string is a single placeholder, the raw
   * resolved value (object / array / number) is returned — not stringified —
   * so step configs like `{ "topic": "{{inputs.topic}}" }` can pass through
   * structured values cleanly.
   */
  resolveString(str: string, variables: Record<string, unknown>): string {
    // Whole-string single-placeholder fast path: return the raw value.
    const wholeMatch = /^\{\{\s*([^}]+?)\s*\}\}$/.exec(str.trim())
    if (wholeMatch && str.trim() === str.trim()) {
      // Confirm there is exactly one placeholder and nothing else.
      const matches = [...str.matchAll(PLACEHOLDER_RE)]
      if (matches.length === 1) {
        const raw = this.lookup(matches[0][1], variables)
        if (raw === undefined) {
          return str
        }
        if (typeof raw === 'string') return raw
        return this.stringify(raw)
      }
    }

    return str.replace(PLACEHOLDER_RE, (full, expr: string) => {
      const value = this.lookup(expr, variables)
      if (value === undefined) {
        // Preserve the original placeholder when unresolved.
        return full
      }
      if (typeof value === 'string') return value
      return this.stringify(value)
    })
  }

  /**
   * Resolve a whole-string placeholder and return the *raw* value (not
   * stringified). Useful when a step input binding expects a structured
   * value (array / object) sourced from a single `{{var}}` reference.
   *
   * If the string contains any literal text outside the single placeholder,
   * the string-resolved result is returned instead.
   */
  resolveValue(str: string, variables: Record<string, unknown>): unknown {
    if (typeof str !== 'string') return str
    const matches = [...str.matchAll(PLACEHOLDER_RE)]
    if (matches.length === 1 && str.trim() === str.trim()) {
      const wholeMatch = /^\{\{\s*([^}]+?)\s*\}\}$/.exec(str.trim())
      if (wholeMatch) {
        return this.lookup(wholeMatch[1], variables)
      }
    }
    return this.resolveString(str, variables)
  }

  /**
   * Look up a single placeholder expression (`path|default`) against the
   * variables map. Supports dot-notation traversal and a `|`-delimited
   * default value (empty string allowed).
   */
  private lookup(expr: string, variables: Record<string, unknown>): unknown {
    const pipeIdx = expr.indexOf('|')
    let path: string
    let hasDefault = false
    let defaultValue = ''
    if (pipeIdx >= 0) {
      path = expr.slice(0, pipeIdx).trim()
      hasDefault = true
      defaultValue = expr.slice(pipeIdx + 1)
    } else {
      path = expr.trim()
    }

    const value = this.traverse(path, variables)
    if (value === undefined || value === null) {
      return hasDefault ? defaultValue : value
    }
    return value
  }

  /**
   * Traverse a dot-notation path (`user.profile.name`) against `variables`.
   * Returns `undefined` if any segment is missing or non-traversable.
   */
  private traverse(path: string, variables: Record<string, unknown>): unknown {
    if (path === '') return undefined
    const parts = path.split('.').filter((p) => p.length > 0)
    let current: unknown = variables
    for (const part of parts) {
      if (this.isPlainObject(current)) {
        current = (current as Record<string, unknown>)[part]
      } else if (Array.isArray(current)) {
        const idx = Number.parseInt(part, 10)
        if (!Number.isFinite(idx)) return undefined
        current = current[idx]
      } else {
        return undefined
      }
      if (current === undefined) return undefined
    }
    return current
  }

  /**
   * Stringify a non-string resolved value. Objects / arrays are JSON-encoded;
   * primitives use `String(...)`.
   */
  private stringify(value: unknown): string {
    if (value === null) return 'null'
    if (typeof value === 'object') return JSON.stringify(value)
    return String(value)
  }

  /**
   * Plain-object guard: returns true for `{}`-style objects, false for
   * arrays, null, class instances, etc.
   */
  private isPlainObject(value: unknown): value is Record<string, unknown> {
    if (typeof value !== 'object' || value === null) return false
    if (Array.isArray(value)) return false
    const proto = Object.getPrototypeOf(value)
    return proto === Object.prototype || proto === null
  }
}
