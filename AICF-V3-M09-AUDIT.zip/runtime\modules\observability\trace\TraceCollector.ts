// =============================================================================
// AICF V3 — Sprint 13+14 — Observability Module — Trace Collector
// =============================================================================
// Collects distributed trace spans across all runtime modules. A "trace" is
// the ordered set of spans sharing a single `correlationId`; spans form a
// tree via optional `parentId` references. The collector is the in-process
// equivalent of an OpenTelemetry span exporter — it stores spans in memory
// by correlationId and exposes them for inspection by the /health endpoint,
// the audit log, and the dev dashboard.
//
// Sprint 13+14 spec requirements covered:
//   - `TraceSpan` interface: id / correlationId / name / parentId / startTime
//     / endTime / durationMs / attributes / events
//   - `startSpan` / `endSpan` lifecycle (end computes durationMs)
//   - `addAttribute` / `addEvent` for span enrichment
//   - `getTraces(correlationId)` / `getAllTraces()` for inspection
//   - `clear(correlationId?)` for teardown / privacy hygiene
//   - Optional EventBus subscription that auto-creates spans from workflow
//     lifecycle events (workflow.started → start span; workflow.completed /
//     workflow.failed → end span; same for step.* events)
//
// Design notes:
//   - Span objects are mutable: `endSpan`, `addAttribute`, and `addEvent`
//     mutate the span in place. This matches OpenTelemetry's ergonomics and
//     avoids the overhead of immutability on the hot path.
//   - Open spans are tracked in a side map keyed by span id so `endSpan`
//     is O(1) and we can detect double-end safely.
//   - Auto-subscribe uses `workflow.started` / `step.started` to open spans
//     and `workflow.completed` / `workflow.failed` / `workflow.cancelled` /
//     `step.completed` / `step.failed` to close them. The span name mirrors
//     the event type so the resulting trace is human-readable.
//   - No `any` is used; event `data` payloads are read via `unknown` +
//     `typeof` guards.
// =============================================================================

import type { IEventBus } from '@/lib/runtime/interfaces'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'

/** A single timestamped event attached to a span (e.g. "cache hit", "retry"). */
export interface TraceEvent {
  /** Event name (e.g. `'retry'`, `'cache.hit'`). */
  name: string
  /** Epoch ms when the event was recorded. */
  timestamp: number
  /** Type-specific event payload. */
  data: Record<string, unknown>
}

/**
 * A single span within a distributed trace. Spans are mutable: `endSpan`,
 * `addAttribute`, and `addEvent` mutate the instance in place.
 */
export interface TraceSpan {
  /** Unique span id (sortable, collision-resistant). */
  id: string
  /** Correlation id this span belongs to (groups spans into a trace). */
  correlationId: string
  /** Human-readable span name (e.g. `'workflow.started'`, `'llm.chat'`). */
  name: string
  /** Parent span id (omit for root spans). */
  parentId?: string
  /** Epoch ms when the span was opened. */
  startTime: number
  /** Epoch ms when the span was closed (set by `endSpan`). */
  endTime?: number
  /** Wall-clock duration in ms (set by `endSpan`). */
  durationMs?: number
  /** Free-form span attributes (key → value). */
  attributes: Record<string, unknown>
  /** Ordered list of timestamped events attached to the span. */
  events: TraceEvent[]
}

/**
 * Generate a unique, sortable span id. Format: `span-<ts>-<rand>`.
 * The timestamp prefix makes ids roughly sortable by creation time
 * without a global counter; the random suffix prevents collisions
 * between spans emitted in the same millisecond.
 */
function generateSpanId(now: number): string {
  const rand = Math.random().toString(36).slice(2, 10)
  return `span-${now}-${rand}`
}

/**
 * Collects distributed trace spans. Construct with an `IEventBus` to enable
 * auto-creation of spans from workflow lifecycle events; callers can also
 * invoke `startSpan` / `endSpan` directly for non-workflow spans (e.g. LLM
 * provider calls, IO operations, custom module flows).
 */
export class TraceCollector {
  /** Spans grouped by correlationId (a trace = the array of its spans). */
  private readonly traces = new Map<string, TraceSpan[]>()
  /** Open spans keyed by span id (for O(1) endSpan lookup + double-end guard). */
  private readonly openSpans = new Map<string, TraceSpan>()
  /**
   * Open auto-created spans keyed by `${correlationId}::workflow` or
   * `${correlationId}::step::${stepId}`. Used to match start/end events.
   */
  private readonly autoSpanIndex = new Map<string, TraceSpan>()
  /** Unsubscribe handles for the EventBus subscriptions (empty if no bus). */
  private readonly unsubs: Array<() => void> = []

  constructor(eventBus?: IEventBus) {
    if (eventBus) {
      this.attachToBus(eventBus)
    }
  }

  // ----- Explicit span API --------------------------------------------------

  /**
   * Open a new span under the given correlationId. Returns the span so the
   * caller can attach attributes / events and later pass it to `endSpan`.
   *
   * @param correlationId  Trace id (groups spans into a trace).
   * @param name           Human-readable span name.
   * @param parentId       Optional parent span id (omit for root spans).
   */
  startSpan(
    correlationId: string,
    name: string,
    parentId?: string,
  ): TraceSpan {
    const startTime = Date.now()
    const span: TraceSpan = {
      id: generateSpanId(startTime),
      correlationId,
      name,
      startTime,
      attributes: {},
      events: [],
    }
    if (parentId !== undefined) span.parentId = parentId
    let arr = this.traces.get(correlationId)
    if (arr === undefined) {
      arr = []
      this.traces.set(correlationId, arr)
    }
    arr.push(span)
    this.openSpans.set(span.id, span)
    return span
  }

  /**
   * Close a span. Sets `endTime` and `durationMs` on the span (mutating it
   * in place) and returns the same span for chaining. Double-ending a span
   * is a no-op (the original endTime is preserved).
   */
  endSpan(span: TraceSpan): TraceSpan {
    // Idempotent: if already closed, return as-is.
    if (span.endTime !== undefined) return span
    const endTime = Date.now()
    span.endTime = endTime
    span.durationMs = Math.max(0, endTime - span.startTime)
    this.openSpans.delete(span.id)
    return span
  }

  /**
   * Attach a typed attribute to a span. Overwrites any prior value for the
   * same key.
   */
  addAttribute(span: TraceSpan, key: string, value: unknown): void {
    span.attributes[key] = value
  }

  /**
   * Attach a timestamped event to a span. The timestamp defaults to now.
   */
  addEvent(
    span: TraceSpan,
    name: string,
    data: Record<string, unknown> = {},
  ): void {
    span.events.push({
      name,
      timestamp: Date.now(),
      data,
    })
  }

  // ----- Read API -----------------------------------------------------------

  /** Return the ordered list of spans for a correlationId (empty if none). */
  getTraces(correlationId: string): TraceSpan[] {
    const arr = this.traces.get(correlationId)
    return arr !== undefined ? [...arr] : []
  }

  /**
   * Return every trace keyed by correlationId. The returned object is a
   * shallow copy; mutating it does not affect the collector. Span objects
   * themselves are NOT cloned (they remain shared references).
   */
  getAllTraces(): Record<string, TraceSpan[]> {
    const out: Record<string, TraceSpan[]> = {}
    for (const [k, v] of this.traces.entries()) {
      out[k] = [...v]
    }
    return out
  }

  /** Number of distinct correlationIds (traces) currently held. */
  getTraceCount(): number {
    return this.traces.size
  }

  /** Total number of spans across all traces. */
  getSpanCount(): number {
    let n = 0
    for (const arr of this.traces.values()) n += arr.length
    return n
  }

  // ----- Teardown -----------------------------------------------------------

  /**
   * Clear traces. With no argument, clears everything (and detaches auto
   * span index entries). With a correlationId, clears only that trace.
   */
  clear(correlationId?: string): void {
    if (correlationId !== undefined) {
      const arr = this.traces.get(correlationId)
      if (arr !== undefined) {
        for (const s of arr) {
          this.openSpans.delete(s.id)
        }
      }
      this.traces.delete(correlationId)
      // Remove any auto-span index entries for this correlationId.
      const prefix = `${correlationId}::`
      for (const key of this.autoSpanIndex.keys()) {
        if (key.startsWith(prefix)) {
          this.autoSpanIndex.delete(key)
        }
      }
    } else {
      this.traces.clear()
      this.openSpans.clear()
      this.autoSpanIndex.clear()
    }
  }

  /** Detach from the EventBus (unsubscribe all handlers). */
  detach(): void {
    for (const unsub of this.unsubs) {
      try {
        unsub()
      } catch {
        // ignore — best-effort teardown
      }
    }
    this.unsubs.length = 0
  }

  // ----- EventBus auto-recording -------------------------------------------

  /**
   * Subscribe to workflow lifecycle events on the given bus. For each event
   * with a correlationId, open or close a span mirroring the event type.
   */
  private attachToBus(bus: IEventBus): void {
    const sub = (type: string, handler: (e: WorkflowEvent) => void) => {
      this.unsubs.push(bus.subscribe(type, handler))
    }

    sub('workflow.started', (e) => {
      const cid = e.correlationId
      if (!cid) return
      const span = this.startSpan(cid, 'workflow')
      this.autoSpanIndex.set(`${cid}::workflow`, span)
      this.addAttribute(span, 'executionId', e.executionId ?? '')
      this.addAttribute(span, 'startedAt', e.timestamp)
    })

    const endWorkflow = (e: WorkflowEvent, outcome: string): void => {
      const cid = e.correlationId
      if (!cid) return
      const span = this.autoSpanIndex.get(`${cid}::workflow`)
      if (!span) return
      this.addAttribute(span, 'outcome', outcome)
      this.addAttribute(span, 'endedAt', e.timestamp)
      this.endSpan(span)
      this.autoSpanIndex.delete(`${cid}::workflow`)
    }
    sub('workflow.completed', (e) => endWorkflow(e, 'completed'))
    sub('workflow.failed', (e) => endWorkflow(e, 'failed'))
    sub('workflow.cancelled', (e) => endWorkflow(e, 'cancelled'))

    sub('step.started', (e) => {
      const cid = e.correlationId
      const stepId = e.stepId
      if (!cid || !stepId) return
      // Parent is the workflow span (if it exists).
      const parent = this.autoSpanIndex.get(`${cid}::workflow`)
      const span = this.startSpan(
        cid,
        `step:${stepId}`,
        parent?.id,
      )
      this.autoSpanIndex.set(`${cid}::step::${stepId}`, span)
      this.addAttribute(span, 'stepId', stepId)
      this.addAttribute(span, 'startedAt', e.timestamp)
    })

    const endStep = (e: WorkflowEvent, outcome: string): void => {
      const cid = e.correlationId
      const stepId = e.stepId
      if (!cid || !stepId) return
      const span = this.autoSpanIndex.get(`${cid}::step::${stepId}`)
      if (!span) return
      this.addAttribute(span, 'outcome', outcome)
      this.addAttribute(span, 'endedAt', e.timestamp)
      this.endSpan(span)
      this.autoSpanIndex.delete(`${cid}::step::${stepId}`)
    }
    sub('step.completed', (e) => endStep(e, 'completed'))
    sub('step.failed', (e) => endStep(e, 'failed'))
  }
}
