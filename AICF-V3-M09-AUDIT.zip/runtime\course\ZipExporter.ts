// =============================================================================
// AICF V3 — Épica 6 — ZIP Exporter
// =============================================================================
import { ZipArchive } from 'archiver'
import { logger } from '@/lib/ai/logger'
import type { CourseArtifact } from './CourseArtifactRegistry'

export class ZipExporter {
  async export(projectId: string, artifacts: CourseArtifact[]): Promise<Buffer> {
    logger.info({ projectId, artifactCount: artifacts.length }, 'ZipExporter: starting')
    return new Promise<Buffer>((resolve, reject) => {
      const archive = new ZipArchive({ zlib: { level: 6 } })
      const chunks: Buffer[] = []
      archive.on('data', (chunk: Buffer) => chunks.push(chunk))
      archive.on('end', () => { const buffer = Buffer.concat(chunks); logger.info({ projectId, zipSize: buffer.byteLength }, 'ZipExporter: completed'); resolve(buffer) })
      archive.on('error', (err: Error) => { logger.error({ projectId, error: err.message }, 'ZipExporter: failed'); reject(err) })
      for (const art of artifacts) {
        archive.append(art.content, { name: `${projectId}/${art.name}` })
      }
      archive.finalize()
    })
  }
}
