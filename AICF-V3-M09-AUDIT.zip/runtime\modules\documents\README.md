# Documents Module — Business-layer document generation

Real Business-layer module (Épica 3 — Educational Factory). Extends
`BusinessModuleBase` and exposes two capabilities:

- `generateDocument` — Generate a structured document from a topic + type.
- `exportDocument` — Export a document (alias of `generateDocument`).

## Document types

| Type | Sections |
| --- | --- |
| `workbook` | Overview, Exercises, Practice Problems, Answer Key, Self-Assessment |
| `teacher-guide` | Learning Objectives, Teaching Tips, Lesson Plan, Assessment Rubric, Differentiation |
| `student-guide` | Course Overview, Key Concepts, How to Study, Resources, FAQ |
| `implementation-guide` | Project Context, Phase 1 — Discovery, Phase 2 — Design, Phase 3 — Implementation, Phase 4 — Rollout |
| `glossary` | A, B, C, D, E–Z |
| `checklist` | Pre-Launch Checklist, Operational Readiness, Rollout Day, Post-Launch Review |
| `resources` | Getting Started, Going Deeper, Community, Tools |

## Status

IMPLEMENTED. `executeJob()` produces real markdown documents via two paths:

1. **AI mode** (when an `AIAdapter` is injected via the constructor): prompts
   the LLM for structured JSON sections, parses them into typed content.
2. **Fallback mode** (no adapter, or AI call fails): a deterministic generator
   produces real, structured content from the requested topic.

Output includes a standalone HTML5 document with embedded CSS, a minimal
markdown-to-HTML renderer (headings, lists, tables, blockquotes, bold,
italics, inline code), and print styles.

## Metadata

| Field | Value |
| --- | --- |
| id | `document` |
| version | `1.0.0` |
| mission | `document` |
| priority | 35 |
| dependencies | (none) |
| capabilities | `generateDocument`, `exportDocument` |

## Lifecycle

Inherited from `BusinessModuleBase`.

## Constructor

```typescript
new DocumentModule(aiAdapter?, model?)
```

- `aiAdapter` — optional `AIAdapter` from `@/lib/ai/AIAdapter`. When omitted,
  the module always uses the deterministic fallback.
- `model` — model id passed to the adapter (default `groq-llama-3.3-70b`).
