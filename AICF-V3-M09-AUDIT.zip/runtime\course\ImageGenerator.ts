// =============================================================================
// AICF V3 — Épica 9 — ImageGenerator
// =============================================================================
// Generates images for slides with hash-based caching and provider
// abstraction. Images are registered in CourseArtifactRegistry.
//
// REUSES: MediaGenerator (existing) for SVG generation, which produces
// topic-specific images (NOT placeholders). The cache prevents regenerating
// identical images.
//
// Provider order (configurable):
//   1. local (default — uses MediaGenerator SVGs)
//   2. flux (future — when API available)
//   3. sdxl (future)
//   4. imagen (future)
//   5. dalle (future)
// =============================================================================

import { createHash } from 'node:crypto'
import { MediaGenerator } from '../media/MediaGenerator'
import { CourseArtifactRegistry } from './CourseArtifactRegistry'
import type { ThemePreset } from '../theme/ThemeCatalog'
import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

export type ImageProvider = 'local' | 'flux' | 'sdxl' | 'imagen' | 'dalle'

export interface ImageArtifact {
  id: string
  type: 'image'
  format: 'svg' | 'png' | 'jpg' | 'webp'
  name: string
  content: Buffer
  sha256: string
  sizeBytes: number
  metadata: {
    provider: ImageProvider
    model: string
    prompt: string
    negativePrompt?: string
    width: number
    height: number
    cacheKey: string
  }
  createdAt: string
}

export interface ImageGeneratorOpts {
  provider?: ImageProvider
  width?: number
  height?: number
  projectId: string
  jobId: string
}

export class ImageGenerator {
  private readonly log = logger.child({ component: 'ImageGenerator' })
  private readonly mediaGen = new MediaGenerator()
  private readonly cache = new Map<string, ImageArtifact>()

  /**
   * Generates an image for a slide. Checks cache first (by hash of
   * prompt + model + dimensions). If cached, returns the cached artifact.
   * Otherwise generates a new image via the configured provider.
   *
   * Default provider is 'local' which uses MediaGenerator to produce
   * topic-specific SVG images (NOT placeholders).
   */
  async generate(opts: {
    prompt: string
    type: 'hero' | 'concept' | 'icon' | 'infographic'
    theme: ThemePreset
    locale: LocaleContext
    projectId: string
    jobId: string
    provider?: ImageProvider
    width?: number
    height?: number
  }): Promise<ImageArtifact> {
    const provider = opts.provider ?? 'local'
    const width = opts.width ?? 800
    const height = opts.height ?? 400
    const model = provider === 'local' ? 'media-generator-svg' : provider
    const cacheKey = this.computeCacheKey(opts.prompt, model, width, height)

    // Check cache
    const cached = this.cache.get(cacheKey)
    if (cached) {
      this.log.debug({ cacheKey: cacheKey.slice(0, 16), provider }, 'ImageGenerator: cache hit')
      return cached
    }

    // Check CourseArtifactRegistry for existing image with same hash
    const existingArtifacts = await CourseArtifactRegistry.listByProject(opts.projectId)
    const existing = existingArtifacts.find((a) => a.sha256 === cacheKey)
    if (existing) {
      const artifact: ImageArtifact = {
        id: existing.artifactId,
        type: 'image',
        format: 'svg',
        name: existing.name,
        content: existing.content,
        sha256: existing.sha256,
        sizeBytes: existing.sizeBytes,
        metadata: {
          provider,
          model,
          prompt: opts.prompt,
          width,
          height,
          cacheKey,
        },
        createdAt: existing.createdAt,
      }
      this.cache.set(cacheKey, artifact)
      this.log.debug({ cacheKey: cacheKey.slice(0, 16) }, 'ImageGenerator: registry cache hit')
      return artifact
    }

    // Generate new image
    const startTime = Date.now()
    let svgContent: string

    switch (provider) {
      case 'local':
        svgContent = this.generateLocalSvg(opts)
        break
      case 'flux':
      case 'sdxl':
      case 'imagen':
      case 'dalle':
        // Future: call external image generation API
        // For now, fall back to local SVG generation
        this.log.warn({ provider }, 'ImageGenerator: provider not yet available, using local SVG')
        svgContent = this.generateLocalSvg(opts)
        break
      default:
        svgContent = this.generateLocalSvg(opts)
    }

    const content = Buffer.from(svgContent, 'utf-8')
    const sha256 = createHash('sha256').update(content).digest('hex')
    const name = `image-${opts.type}-${Date.now().toString(36)}.svg`

    // Register in CourseArtifactRegistry
    const registered = await CourseArtifactRegistry.register({
      projectId: opts.projectId,
      jobId: opts.jobId,
      type: 'course' as never, // CourseArtifactType doesn't have 'image' — use 'course'
      format: 'markdown' as never, // Use closest available format
      name,
      content,
    })

    const artifact: ImageArtifact = {
      id: registered.artifactId,
      type: 'image',
      format: 'svg',
      name,
      content,
      sha256,
      sizeBytes: content.byteLength,
      metadata: {
        provider,
        model,
        prompt: opts.prompt,
        width,
        height,
        cacheKey,
      },
      createdAt: new Date().toISOString(),
    }

    // Store in cache
    this.cache.set(cacheKey, artifact)

    const durationMs = Date.now() - startTime
    this.log.info(
      { provider, type: opts.type, sizeBytes: content.byteLength, durationMs, cacheKey: cacheKey.slice(0, 16) },
      'ImageGenerator: image generated and registered',
    )

    return artifact
  }

  /**
   * Generates multiple images for a storyboard. Each image is cached
   * independently. Returns an array of ImageArtifacts in the same order
   * as the input prompts.
   */
  async generateBatch(opts: {
    prompts: Array<{ prompt: string; type: 'hero' | 'concept' | 'icon' | 'infographic' }>
    theme: ThemePreset
    locale: LocaleContext
    projectId: string
    jobId: string
    provider?: ImageProvider
  }): Promise<ImageArtifact[]> {
    const results: ImageArtifact[] = []
    for (const item of opts.prompts) {
      const artifact = await this.generate({
        prompt: item.prompt,
        type: item.type,
        theme: opts.theme,
        locale: opts.locale,
        projectId: opts.projectId,
        jobId: opts.jobId,
        provider: opts.provider,
      })
      results.push(artifact)
    }
    this.log.info({ count: results.length, cached: results.filter((r) => this.cache.has(r.metadata.cacheKey)).length }, 'ImageGenerator: batch complete')
    return results
  }

  /**
   * Returns cache statistics.
   */
  getCacheStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys()).map((k) => k.slice(0, 16)),
    }
  }

  /**
   * Clears the in-memory cache (for tests).
   */
  clearCache(): void {
    this.cache.clear()
  }

  // --- Private helpers ---

  private computeCacheKey(prompt: string, model: string, width: number, height: number): string {
    return createHash('sha256').update(`${prompt}|${model}|${width}x${height}`).digest('hex')
  }

  private generateLocalSvg(opts: {
    prompt: string
    type: 'hero' | 'concept' | 'icon' | 'infographic'
    theme: ThemePreset
    locale: LocaleContext
  }): string {
    switch (opts.type) {
      case 'hero':
        return this.mediaGen.generateHero(opts.prompt, opts.theme)
      case 'concept':
        return this.mediaGen.generateConcept(opts.prompt, 1, opts.theme)
      case 'icon':
        return this.mediaGen.generateIcon(opts.prompt, opts.theme)
      case 'infographic':
        return this.mediaGen.generateInfographic(opts.locale, opts.theme)
      default:
        return this.mediaGen.generateHero(opts.prompt, opts.theme)
    }
  }
}
