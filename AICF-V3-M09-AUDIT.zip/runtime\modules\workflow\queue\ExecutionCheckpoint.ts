// =============================================================================
// AICF V3 — Sprint 13+14 — Queue-facing Checkpoint Re-export (Batch C2)
// =============================================================================
// The execution checkpoint manager is the persistence seam used by both
// the workflow `state` subsystem and the workflow `queue` subsystem
// (the durable scheduler that drives deferred / retried executions).
//
// To avoid a hard cross-subsystem dependency (queue → state), this file
// re-exports the canonical implementation from `state/ExecutionCheckpoint`
// so the queue subsystem can import it from its own namespace:
//
//   import { ExecutionCheckpointManager } from '@/lib/runtime/modules/workflow/queue/ExecutionCheckpoint'
//
// The implementation lives in exactly one place (`state/`); this file is
// a thin alias. If the queue subsystem ever needs a specialized
// checkpoint manager, it can shadow this re-export with its own
// implementation without touching the `state` subsystem.
// =============================================================================

export {
  ExecutionCheckpointManager,
} from '../state/ExecutionCheckpoint'
