// =============================================================================
// AICF V3 — Épica 6 — Production Result Store
// =============================================================================
import type { ProductionResult } from './ProductionEngine'

class ProductionResultStoreImpl {
  private readonly results = new Map<string, ProductionResult>()

  store(courseId: string, result: ProductionResult): void {
    this.results.set(courseId, result)
  }

  get(courseId: string): ProductionResult | null {
    return this.results.get(courseId) ?? null
  }

  has(courseId: string): boolean {
    return this.results.has(courseId)
  }

  clear(): void {
    this.results.clear()
  }
}

export const ProductionResultStore = new ProductionResultStoreImpl()
