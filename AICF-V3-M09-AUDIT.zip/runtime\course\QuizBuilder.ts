// =============================================================================
// AICF V3 — Epica 8 — Quiz Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { ModulePlan, Quiz, QuizQuestion, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class QuizBuilder implements EngineContract {
  readonly name = 'quiz-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('QuizBuilder: invalid input — expected ModulePlan[]')
    }
    const modules = input as ModulePlan[]
    const quizzes: Quiz[] = []
    for (const mod of modules) {
      if (this.opts.aiAdapter) {
        try {
          quizzes.push(await this.buildWithAI(mod))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'QuizBuilder: AI failed, using fallback')
        }
      }
      quizzes.push(this.buildDeterministic(mod))
    }
    return quizzes
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(mod: ModulePlan): Promise<Quiz> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are an assessment designer. Create quiz questions with id, question, options (4 strings), correctIndex (0-3), explanation, difficulty, bloomLevel. Respond as JSON: { "title": string, "description": string, "questions": [...] }',
        },
        {
          role: 'user',
          content: `Module: ${mod.title}\nSummary: ${mod.summary}\nLearning outcomes: ${mod.learningOutcomes.join('; ')}\n\nCreate a 5-question quiz. Return JSON.`,
        },
      ],
      temperature: 0.4,
      maxTokens: 4096,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; description?: string; questions?: QuizQuestion[] }
    return this.assembleQuiz(mod, parsed.title ?? `Quiz: ${mod.title}`, parsed.description ?? '', parsed.questions ?? [], resp.provider as Provider, resp.model)
  }

  private buildDeterministic(mod: ModulePlan): Quiz {
    const questions: QuizQuestion[] = []
    const blooms = ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate']
    const difficulties: QuizQuestion['difficulty'][] = ['easy', 'easy', 'medium', 'medium', 'hard']
    const outcomes = mod.learningOutcomes.length > 0 ? mod.learningOutcomes : ['key concept', 'practical application', 'critical evaluation']
    for (let i = 0; i < 5; i++) {
      const outcome = outcomes[i % outcomes.length] ?? `module concept ${i + 1}`
      questions.push({
        id: makeId('q'),
        question: `Which of the following best describes ${outcome.toLowerCase()} as covered in ${mod.title}?`,
        options: [
          `A correct understanding of ${outcome.toLowerCase()} that aligns with the module's learning outcomes`,
          `A common misconception that oversimplifies the concept`,
          `An unrelated concept from a different module`,
          `A partially correct but incomplete description`,
        ],
        correctIndex: 0,
        explanation: `The first option is correct because it accurately reflects the definition and application of ${outcome.toLowerCase()} as presented in ${mod.title}. The other options represent common misconceptions, unrelated material, or incomplete descriptions that fail to capture the full scope of the concept.`,
        difficulty: difficulties[i] ?? 'medium',
        bloomLevel: blooms[i % blooms.length],
      })
    }
    return this.assembleQuiz(mod, `Quiz: ${mod.title}`, `This quiz assesses your understanding of ${mod.title}. It contains ${questions.length} questions covering key concepts, applications, and analysis from the module.`, questions, 'runtime-adapter', 'deterministic-fallback')
  }

  private assembleQuiz(
    mod: ModulePlan,
    title: string,
    description: string,
    questions: QuizQuestion[],
    provider: Provider,
    model: string,
  ): Quiz {
    const now = new Date().toISOString()
    return {
      id: makeId('quiz'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      moduleId: mod.id,
      moduleTitle: mod.title,
      title,
      description,
      questions,
      passingScore: 70,
      maxAttempts: 3,
      durationMinutes: questions.length * 2,
    }
  }
}
