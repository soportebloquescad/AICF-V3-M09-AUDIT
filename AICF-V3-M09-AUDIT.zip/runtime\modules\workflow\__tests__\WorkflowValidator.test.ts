// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — WorkflowValidator Tests
// =============================================================================
// Tests for the WorkflowValidator. Verifies that valid definitions pass,
// that structural errors (missing metadata, empty steps, duplicate ids,
// unknown dependsOn, cycles, unregistered providers) are flagged, and
// that `validateInputs` enforces required inputs.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { WorkflowValidator } from '../engine/WorkflowValidator'
import type {
  WorkflowDefinition,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'

/** Build a minimal valid workflow definition for tests. */
function makeDefinition(
  overrides: Partial<WorkflowDefinition> = {},
): WorkflowDefinition {
  const step1: WorkflowStepDefinition = {
    id: 'step-1',
    name: 'Step 1',
    type: 'chat',
    provider: 'chat',
    config: {},
    inputs: {},
    outputs: { result: 'step1Result' },
    dependsOn: [],
    retries: 0,
  }
  const step2: WorkflowStepDefinition = {
    id: 'step-2',
    name: 'Step 2',
    type: 'generate',
    provider: 'generate',
    config: {},
    inputs: { topic: '{{inputs.topic}}' },
    outputs: { content: 'step2Content' },
    dependsOn: ['step-1'],
    retries: 0,
  }
  return {
    metadata: {
      id: 'wf-test',
      name: 'Test Workflow',
      version: '1.0.0',
      description: 'Test',
      author: 'tester',
      createdAt: 0,
      updatedAt: 0,
      tags: [],
      category: 'test',
    },
    version: '1.0.0',
    inputs: {
      topic: { name: 'topic', type: 'string', required: true },
    },
    outputs: {
      content: {
        name: 'content',
        type: 'string',
        description: 'final',
        fromStep: 'step-2',
      },
    },
    steps: [step1, step2],
    checkpoints: [],
    ...overrides,
  }
}

describe('WorkflowValidator', () => {
  let validator: WorkflowValidator

  beforeEach(() => {
    validator = new WorkflowValidator(
      new Set(['chat', 'generate', 'validate', 'transform', 'conditional']),
    )
  })

  it('valid definition passes', () => {
    const result = validator.validate(makeDefinition())
    expect(result.valid).toBe(true)
    expect(result.errors).toEqual([])
  })

  it('missing metadata fails', () => {
    const def = makeDefinition()
    def.metadata = undefined as unknown as WorkflowDefinition['metadata']
    const result = validator.validate(def)
    expect(result.valid).toBe(false)
    expect(result.errors.some((e) => e.includes('metadata'))).toBe(true)
  })

  it('empty steps array fails', () => {
    const result = validator.validate(makeDefinition({ steps: [] }))
    expect(result.valid).toBe(false)
    expect(result.errors.some((e) => e.includes('non-empty'))).toBe(true)
  })

  it('duplicate step ids fail', () => {
    const def = makeDefinition()
    def.steps = [
      { ...def.steps[0], id: 'dup' },
      { ...def.steps[1], id: 'dup', dependsOn: [] },
    ]
    const result = validator.validate(def)
    expect(result.valid).toBe(false)
    expect(result.errors.some((e) => e.includes('"dup" is not unique'))).toBe(true)
  })

  it('invalid dependsOn reference fails', () => {
    const def = makeDefinition()
    def.steps = [
      { ...def.steps[0] },
      { ...def.steps[1], dependsOn: ['does-not-exist'] },
    ]
    const result = validator.validate(def)
    expect(result.valid).toBe(false)
    expect(
      result.errors.some((e) => e.includes('depends on unknown step')),
    ).toBe(true)
  })

  it('circular dependency fails', () => {
    const def = makeDefinition()
    def.steps = [
      { ...def.steps[0], id: 'a', dependsOn: ['b'] },
      { ...def.steps[1], id: 'b', dependsOn: ['a'] },
    ]
    const result = validator.validate(def)
    expect(result.valid).toBe(false)
    expect(
      result.errors.some((e) => e.includes('circular dependency')),
    ).toBe(true)
  })

  it('unregistered provider fails', () => {
    const def = makeDefinition()
    def.steps = [
      { ...def.steps[0], provider: 'unknown-provider' },
      { ...def.steps[1], dependsOn: [] },
    ]
    const result = validator.validate(def)
    expect(result.valid).toBe(false)
    expect(
      result.errors.some((e) => e.includes('unknown provider')),
    ).toBe(true)
  })

  it('validateInputs: missing required input fails', () => {
    const def = makeDefinition()
    const result = validator.validateInputs(def, {})
    expect(result.valid).toBe(false)
    expect(
      result.errors.some((e) => e.includes('required input "topic"')),
    ).toBe(true)
  })

  it('validateInputs: valid inputs pass', () => {
    const def = makeDefinition()
    const result = validator.validateInputs(def, { topic: 'Rust ownership' })
    expect(result.valid).toBe(true)
    expect(result.errors).toEqual([])
  })

  it('validateInputs: type mismatch fails', () => {
    const def = makeDefinition()
    const result = validator.validateInputs(def, { topic: 42 })
    expect(result.valid).toBe(false)
    expect(
      result.errors.some((e) => e.includes('does not match declared type')),
    ).toBe(true)
  })
})
