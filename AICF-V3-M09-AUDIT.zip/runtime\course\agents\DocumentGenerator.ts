// =============================================================================
// AICF V3 — Document Generator Agent
// =============================================================================
// Generates supporting documents for the course: a syllabus, a study
// guide, an assessment rubric, and a glossary. Reads `context.curriculum`
// and `context.lessons` to scope the documents. Each document carries a
// type, title, and substantive content.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, normalizeLevel, readContext } from './agentUtils'

export interface DocumentGeneratorDeps {
  aiAdapter: AIAdapter | null
}

type DocumentType = 'syllabus' | 'study-guide' | 'rubric' | 'glossary'

interface CourseDocument {
  type: DocumentType
  title: string
  content: string
}

interface DocumentsPayload {
  documents: CourseDocument[]
}

interface CurriculumShape {
  modules?: Array<{ title: string; summary?: string; lessons?: Array<{ title: string }> }>
}

interface LessonShape {
  title: string
  content?: string
}

const DOCUMENT_TYPES: DocumentType[] = ['syllabus', 'study-guide', 'rubric', 'glossary']

export class DocumentGenerator implements Agent {
  public readonly name = 'document-generator'

  constructor(private readonly deps: DocumentGeneratorDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const curriculum = readContext<CurriculumShape>(input.context, 'curriculum')
      const lessons = readContext<LessonShape[]>(input.context, 'lessons')
      const ai = this.deps.aiAdapter
      const documents: CourseDocument[] = []

      for (const docType of DOCUMENT_TYPES) {
        const aiResult = await callAI(ai, buildPrompt(input, docType, curriculum, lessons), {
          systemPrompt:
            'You are a course documentation specialist. Respond with valid JSON only.',
          temperature: 0.4,
          maxTokens: 1800,
        })
        if (aiResult.ok && aiResult.content) {
          const parsed = extractJSON<{ content?: string }>(aiResult.content)
          if (parsed && typeof parsed.content === 'string' && parsed.content.length > 100) {
            documents.push({
              type: docType,
              title: titleFor(docType, input.topic),
              content: parsed.content,
            })
            continue
          }
        }
        documents.push(fallbackDocument(input, docType, curriculum, lessons))
      }

      return {
        agentName: this.name,
        result: { documents },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function titleFor(docType: DocumentType, topic: string): string {
  switch (docType) {
    case 'syllabus':
      return `Syllabus: ${topic}`
    case 'study-guide':
      return `Study Guide: ${topic}`
    case 'rubric':
      return `Assessment Rubric: ${topic}`
    case 'glossary':
      return `Glossary: ${topic}`
  }
}

function buildPrompt(
  input: AgentInput,
  docType: DocumentType,
  curriculum: CurriculumShape | null,
  lessons: LessonShape[] | null,
): string {
  const moduleTitles =
    curriculum?.modules?.map((m) => `- ${m.title}`).join('\n') ?? '(no curriculum available)'
  const lessonTitles =
    Array.isArray(lessons) && lessons.length > 0
      ? lessons.map((l) => `- ${l.title}`).join('\n')
      : '(no lessons available)'
  return [
    `Generate a ${docType} document for a course on "${input.topic}".`,
    `Audience: ${input.audience}. Level: ${input.level}. Locale: ${input.locale}.`,
    `Modules:`,
    moduleTitles,
    `Lessons:`,
    lessonTitles,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "content": string   // Markdown, 300-700 words, well-structured`,
    `}`,
  ].join('\n')
}

function fallbackDocument(
  input: AgentInput,
  docType: DocumentType,
  curriculum: CurriculumShape | null,
  lessons: LessonShape[] | null,
): CourseDocument {
  const topic = input.topic
  const level = normalizeLevel(input.level)
  const audience = input.audience
  const moduleList =
    curriculum?.modules?.map((m) => `1. ${m.title} - ${m.summary ?? ''}`).join('\n') ??
    `1. Foundations of ${topic}\n2. Core Principles\n3. Applied Techniques`
  const lessonList =
    Array.isArray(lessons) && lessons.length > 0
      ? lessons.map((l) => `- ${l.title}`).join('\n')
      : `- Introduction to ${topic}\n- Core Concepts\n- Applied Practice`

  switch (docType) {
    case 'syllabus':
      return {
        type: 'syllabus',
        title: titleFor('syllabus', topic),
        content: [
          `# Syllabus: ${topic}`,
          ``,
          `## Course Information`,
          `- **Topic:** ${topic}`,
          `- **Audience:** ${audience}`,
          `- **Level:** ${level}`,
          `- **Locale:** ${input.locale}`,
          ``,
          `## Course Description`,
          `This course provides a structured path through ${topic}, designed for ${audience} at the ${level} level. It combines conceptual foundations with applied practice and culminates in a capstone synthesis.`,
          ``,
          `## Learning Outcomes`,
          `By the end of the course, learners will be able to:`,
          `- Explain the core concepts of ${topic}.`,
          `- Apply standard techniques in realistic scenarios.`,
          `- Evaluate approaches and select appropriate methods.`,
          `- Synthesize prior learning into end-to-end solutions.`,
          ``,
          `## Module Outline`,
          moduleList,
          ``,
          `## Assessment`,
          `- Formative: lesson quizzes, in-lesson exercises, reflection prompts.`,
          `- Summative: final assessment, capstone project.`,
          `- Mastery threshold: 75%.`,
          ``,
          `## Policies`,
          `- Learners are expected to complete lessons in order.`,
          `- Practice exercises are strongly recommended before assessments.`,
          `- Feedback is welcomed at the end of each module.`,
        ].join('\n'),
      }
    case 'study-guide':
      return {
        type: 'study-guide',
        title: titleFor('study-guide', topic),
        content: [
          `# Study Guide: ${topic}`,
          ``,
          `## How to Use This Guide`,
          `This study guide accompanies the ${topic} course. Work through each section in order, complete the practice prompts, and revisit any section that feels unclear.`,
          ``,
          `## Lessons Covered`,
          lessonList,
          ``,
          `## Key Terms to Master`,
          `- The central concept of each lesson.`,
          `- The relationships between adjacent topics.`,
          `- The standard terminology used in the field.`,
          ``,
          `## Study Strategies`,
          `1. **Active recall.** After reading each lesson, close the material and write down what you remember.`,
          `2. **Spaced repetition.** Revisit earlier lessons at increasing intervals.`,
          `3. **Applied practice.** Complete every exercise, not just the required ones.`,
          `4. **Reflection.** After each module, note what surprised you and what remains unclear.`,
          ``,
          `## Self-Check Questions`,
          `- Can you define each key term in your own words?`,
          `- Can you identify when to apply each technique?`,
          `- Can you spot common pitfalls and explain why they occur?`,
          ``,
          `## Where to Get Help`,
          `If a concept remains unclear after review, revisit the worked examples in the lesson, then attempt the associated exercise. Persistent confusion is a signal to slow down rather than push forward.`,
        ].join('\n'),
      }
    case 'rubric':
      return {
        type: 'rubric',
        title: titleFor('rubric', topic),
        content: [
          `# Assessment Rubric: ${topic}`,
          ``,
          `This rubric applies to the formative and summative assessments in the ${topic} course. Each criterion is scored on a 0-4 scale.`,
          ``,
          `## Scoring Scale`,
          `- **4 - Exemplary.** The response demonstrates fluent, accurate, and complete mastery.`,
          `- **3 - Proficient.** The response is correct and complete with minor gaps.`,
          `- **2 - Developing.** The response shows partial understanding with notable gaps.`,
          `- **1 - Beginning.** The response shows minimal understanding.`,
          `- **0 - No evidence.** The response is absent or off-topic.`,
          ``,
          `## Criteria`,
          ``,
          `### 1. Conceptual Accuracy`,
          `- 4: All key concepts are defined and applied correctly.`,
          `- 3: Concepts are correct with minor imprecision.`,
          `- 2: Some concepts are correct; others are confused.`,
          `- 1: Few concepts are correct.`,
          `- 0: No correct concepts.`,
          ``,
          `### 2. Application`,
          `- 4: Techniques are selected and applied flawlessly in context.`,
          `- 3: Techniques are applied correctly with minor slips.`,
          `- 2: Techniques are attempted but applied inconsistently.`,
          `- 1: Techniques are misapplied.`,
          `- 0: No application attempted.`,
          ``,
          `### 3. Analysis and Justification`,
          `- 4: Reasoning is clear, well-structured, and fully justified.`,
          `- 3: Reasoning is clear with minor gaps in justification.`,
          `- 2: Reasoning is present but incomplete.`,
          `- 1: Reasoning is minimal or unclear.`,
          `- 0: No reasoning provided.`,
          ``,
          `### 4. Communication`,
          `- 4: Response is clear, organized, and uses precise terminology.`,
          `- 3: Response is clear with minor organizational issues.`,
          `- 2: Response is understandable but disorganized.`,
          `- 1: Response is difficult to follow.`,
          `- 0: No communicable response.`,
          ``,
          `## Mastery Threshold`,
          `Learners achieve mastery with an average score of 3.0 or higher across all criteria.`,
        ].join('\n'),
      }
    case 'glossary':
      return {
        type: 'glossary',
        title: titleFor('glossary', topic),
        content: [
          `# Glossary: ${topic}`,
          ``,
          `This glossary defines the key terms used throughout the ${topic} course. Terms are listed in the order they typically appear.`,
          ``,
          `- **${topic}.** The overarching subject of this course, combining conceptual foundations with applied practice.`,
          `- **Foundations.** The core vocabulary, history, and motivating problems that frame the field.`,
          `- **Core Principles.** The fundamental concepts and mental models that practitioners rely on.`,
          `- **Practical Methods.** The standard workflows and techniques used in day-to-day practice.`,
          `- **Applied Techniques.** Methods adapted to real-world scenarios and constraints.`,
          `- **Advanced Concepts.** Topics that build on the foundations and require prior mastery.`,
          `- **Integration.** The process of combining individual techniques into end-to-end solutions.`,
          `- **Capstone.** A culminating exercise that synthesizes the entire course.`,
          `- **Formative Assessment.** Low-stakes checks (quizzes, exercises) that guide learning.`,
          `- **Summative Assessment.** High-stakes evaluations (final exam, capstone) that measure mastery.`,
          `- **Mastery Threshold.** The minimum score (75% in this course) required to demonstrate competence.`,
          `- **Differentiation.** The adaptation of content, process, or product to suit the learner's level.`,
          ``,
          `Learners are encouraged to add their own entries as they encounter new terms in the lessons.`,
        ].join('\n'),
      }
  }
}
