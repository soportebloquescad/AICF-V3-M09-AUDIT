// =============================================================================
// AICF V3 — Sprint 13+14 — Transformation Provider
// =============================================================================
// Provider that fulfills the `'transform'` capability. Performs pure
// data transformations on input data: JSON-to-Markdown rendering, template
// substitution, shape projection, etc. No AI calls — all transformations
// are local and deterministic.
//
// Sprint 13+14 spec requirements covered:
//   - `IProvider` interface compliance
//   - Reads `transform` type from `input.transform` (e.g.
//     `'json-to-markdown'`, `'template'`)
//   - Returns `output: { content, format }`
//   - Pluggable transform registry — new transform kinds can be added
//     without touching the provider
// =============================================================================

import type {
  IProvider,
  ProviderCapability,
  ProviderManifest,
  StepExecutionResult,
} from '@/lib/runtime/interfaces'
import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Transform function signature. */
export type TransformFn = (
  input: Record<string, unknown>,
) => { content: string; format: string } | { error: string }

/**
 * Provider that performs pure data transformations. Thread-safe across
 * executions; all transforms are synchronous and side-effect-free.
 */
export class TransformationProvider implements IProvider {
  readonly name = 'transform'
  readonly capabilities: ProviderCapability[] = ['transform']
  private ready = false
  private readonly transforms = new Map<string, TransformFn>()

  constructor() {
    // Register the built-in transforms.
    this.registerTransform('json-to-markdown', this.jsonToMarkdown)
    this.registerTransform('template', this.templateTransform)
    this.registerTransform('json-pretty', this.jsonPretty)
  }

  /** Initialize the provider. Marks itself ready. */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug(
      { provider: this.name, transforms: this.listTransforms() },
      'transformation provider initialized',
    )
  }

  /** Whether `initialize` has been called. */
  isReady(): boolean {
    return this.ready
  }

  /** Self-describing manifest for the registry / UI. */
  getManifest(): ProviderManifest {
    return {
      name: this.name,
      version: '1.0.0',
      capabilities: [...this.capabilities],
      config: { transforms: this.listTransforms() },
      description: 'Performs pure data transformations (JSON→Markdown, template, ...)',
    }
  }

  /**
   * Execute the `'transform'` capability.
   *
   * Input shape (read from `input`):
   *   - `transform`: `string` (e.g. `'json-to-markdown'`, `'template'`)
   *     (required)
   *   - `data`: `unknown` (the data to transform)
   *   - `template`: `string` (for `'template'` transform — supports
   *     `{{key}}` placeholders resolved against `data`)
   *
   * Output shape:
   *   - `content`: transformed string
   *   - `format`: output format (e.g. `'markdown'`, `'text'`, `'json'`)
   */
  async execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    _ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    if (capability !== 'transform') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `transformation provider cannot handle capability "${capability}"`,
      }
    }

    const start = Date.now()
    const transformName =
      typeof input.transform === 'string' ? input.transform : ''
    if (!transformName) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: 'input.transform is missing or not a string',
      }
    }

    const fn = this.transforms.get(transformName)
    if (!fn) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: `unknown transform "${transformName}" (available: ${this.listTransforms().join(', ')})`,
      }
    }

    try {
      const result = fn(input)
      if ('error' in result) {
        return {
          ok: false,
          output: {},
          artifacts: [],
          durationMs: Date.now() - start,
          error: result.error,
        }
      }
      return {
        ok: true,
        output: { content: result.content, format: result.format },
        artifacts: [],
        durationMs: Date.now() - start,
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'unknown transform error'
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: message,
      }
    }
  }

  /** Register a new transform by name. Overwrites any prior transform. */
  registerTransform(name: string, fn: TransformFn): void {
    this.transforms.set(name, fn)
  }

  /** List the names of all registered transforms. */
  listTransforms(): string[] {
    return [...this.transforms.keys()]
  }

  // ----- Built-in transforms ---------------------------------------------

  /** Convert a JSON object into a Markdown document. */
  private jsonToMarkdown = (
    input: Record<string, unknown>,
  ): { content: string; format: string } | { error: string } => {
    const data = input.data
    if (data === undefined) {
      return { error: 'input.data is required for json-to-markdown' }
    }
    const title =
      typeof input.title === 'string' && input.title.length > 0
        ? input.title
        : 'Document'
    const lines: string[] = [`# ${title}`, '']
    this.appendMarkdownValue(lines, data, 0)
    return { content: lines.join('\n'), format: 'markdown' }
  }

  /** Render a `{{var}}` template against `input.data`. */
  private templateTransform = (
    input: Record<string, unknown>,
  ): { content: string; format: string } | { error: string } => {
    const template =
      typeof input.template === 'string' ? input.template : ''
    if (!template) {
      return { error: 'input.template is required for template transform' }
    }
    const data =
      input.data && typeof input.data === 'object' && !Array.isArray(input.data)
        ? (input.data as Record<string, unknown>)
        : {}
    const content = template.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (full, expr: string) => {
      const path = expr.trim()
      const value = this.lookup(path, data)
      if (value === undefined) return full
      if (typeof value === 'string') return value
      return JSON.stringify(value)
    })
    return { content, format: 'text' }
  }

  /** Pretty-print a JSON value as indented JSON text. */
  private jsonPretty = (
    input: Record<string, unknown>,
  ): { content: string; format: string } | { error: string } => {
    const data = input.data
    if (data === undefined) {
      return { error: 'input.data is required for json-pretty' }
    }
    return { content: JSON.stringify(data, null, 2), format: 'json' }
  }

  // ----- Helpers ---------------------------------------------------------

  /** Append a Markdown rendering of `value` to `lines` at depth `indent`. */
  private appendMarkdownValue(
    lines: string[],
    value: unknown,
    indent: number,
  ): void {
    const pad = '  '.repeat(indent)
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === 'object') {
          lines.push(`${pad}- `)
          this.appendMarkdownValue(lines, item, indent + 1)
        } else {
          lines.push(`${pad}- ${this.stringify(item)}`)
        }
      }
    } else if (value && typeof value === 'object') {
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        if (v && typeof v === 'object') {
          lines.push(`${pad}**${k}**:`)
          this.appendMarkdownValue(lines, v, indent + 1)
        } else {
          lines.push(`${pad}- **${k}**: ${this.stringify(v)}`)
        }
      }
    } else {
      lines.push(`${pad}${this.stringify(value)}`)
    }
  }

  /** Dot-notation lookup against `data`. */
  private lookup(path: string, data: Record<string, unknown>): unknown {
    const parts = path.split('.').filter((p) => p.length > 0)
    let cur: unknown = data
    for (const p of parts) {
      if (cur && typeof cur === 'object' && !Array.isArray(cur)) {
        cur = (cur as Record<string, unknown>)[p]
      } else {
        return undefined
      }
    }
    return cur
  }

  /** Stringify a primitive value for Markdown rendering. */
  private stringify(value: unknown): string {
    if (value === null) return 'null'
    if (value === undefined) return ''
    if (typeof value === 'object') return JSON.stringify(value)
    return String(value)
  }
}
