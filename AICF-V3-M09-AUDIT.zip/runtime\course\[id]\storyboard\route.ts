// =============================================================================
// AICF V3 — Épica 9 — GET /api/runtime/course/[id]/storyboard
// =============================================================================
// Returns the storyboard (presentation slides) for a course generation job.
//
// Identifier resolution chain:
//   [id] (URL segment) → jobId
//     → CourseJobStore.get(jobId) → CourseJob (404 if not found)
//     → CourseArtifactRegistry.listByJob(jobId) → presentation artifacts
//
// The [id] segment is treated as a jobId — same convention as /progress,
// /quality, /exports. The CourseArtifactRegistry indexes artifacts by BOTH
// projectId AND jobId; we use listByJob(jobId) so the lookup is consistent
// with the URL identifier (no projectId mismatch).
//
// Responses:
//   200 — job found; returns storyboard (slides) or empty array if no
//         presentation artifact has been produced yet
//   404 — jobId not found in CourseJobStore
// =============================================================================
import { NextRequest, NextResponse } from 'next/server'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id: jobId } = await params
  const reqLogger = logger.child({
    endpoint: '/api/runtime/course/[id]/storyboard',
    method: 'GET',
    jobId,
  })

  try {
    const job = await CourseJobStore.get(jobId)

    if (!job) {
      reqLogger.info({ jobId }, 'Storyboard: job not found')
      return NextResponse.json(
        { error: 'Job not found', jobId },
        { status: 404 },
      )
    }

    // Look up presentation artifacts by jobId (NOT projectId) so the
    // identifier chain stays consistent: URL → jobId → artifacts.
    const artifacts = await CourseArtifactRegistry.listByJob(jobId)
    const presentation = artifacts.find((a) => a.type === 'presentation')

    reqLogger.info(
      { jobId, artifactCount: artifacts.length, hasPresentation: Boolean(presentation) },
      'Storyboard retrieved',
    )

    return NextResponse.json({
      jobId: job.id,
      courseId: job.courseId,
      status: job.status,
      stage: job.stage,
      hasStoryboard: Boolean(presentation),
      storyboard: presentation
        ? {
            artifactId: presentation.artifactId,
            name: presentation.name,
            format: presentation.format,
            sizeBytes: presentation.sizeBytes,
            sha256: presentation.sha256,
            createdAt: presentation.createdAt,
            content: presentation.content.toString('utf-8'),
          }
        : null,
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Storyboard: failed',
    )
    return NextResponse.json(
      { error: 'Failed to get storyboard' },
      { status: 500 },
    )
  }
}
