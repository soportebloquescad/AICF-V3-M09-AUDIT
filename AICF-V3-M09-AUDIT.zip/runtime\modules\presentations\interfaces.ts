// =============================================================================
// AICF V3 — Presentations Module Contract (Sprint: Foundation Modules)
// =============================================================================
// Typed contract for the Presentation Generation module.
//
// Responsibilities:
//   - Generate full presentations from a topic string
//   - Each slide carries a title, free-form content, and optional notes
//   - Configurable slide count, theme, and notes inclusion via
//     `PresentationOptions`
//
// Distinct from the Slides module: Slides returns bullet-driven decks while
// Presentations returns richer per-slide content blocks suitable for full
// narrative decks.
//
// This file contains INTERFACES ONLY — no implementation classes.
// Strict TypeScript: no `any`.
// =============================================================================

import type { RuntimeModule } from '@/lib/runtime/contracts/RuntimeModule'

/**
 * Options accepted by `PresentationsModule.generatePresentation`.
 */
export interface PresentationOptions {
  /** Number of slides to generate. */
  slideCount?: number

  /** Visual theme identifier (provider-specific). */
  theme?: string

  /** Whether to include speaker notes on each slide. */
  includeNotes?: boolean
}

/**
 * A single presentation slide with richer content than the Slides module.
 */
export interface PresentationSlide {
  /** Slide title. */
  title: string

  /** Free-form slide content (markdown / HTML / plain text — provider-defined). */
  content: string

  /** Optional speaker notes. */
  notes?: string
}

/**
 * Structured result returned by `PresentationsModule.generatePresentation`.
 */
export interface PresentationResult {
  /** Whether generation completed without errors. */
  ok: boolean

  /** Generated slides in order. */
  slides: PresentationSlide[]

  /** Theme that was actually applied (echoes `PresentationOptions.theme`). */
  theme: string
}

/**
 * Public surface of the Presentations module.
 */
export interface PresentationsModule extends RuntimeModule {
  /**
   * Generate a full presentation for the given topic.
   *
   * @param topic  Topic / prompt describing the presentation.
   * @param opts   Optional generation knobs (slideCount, theme, includeNotes).
   */
  generatePresentation(
    topic: string,
    opts?: PresentationOptions,
  ): Promise<PresentationResult>
}
