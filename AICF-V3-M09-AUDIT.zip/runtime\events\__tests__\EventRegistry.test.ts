// =============================================================================
// AICF V3 — EventRegistry Tests (Sprint 21)
// =============================================================================
// Verifies:
//   - register + get round-trips a registration
//   - list returns all registrations in insertion order
//   - listByStage filters by the producing stage
//   - get returns null for unknown names
//   - the pre-populated runtimeEventRegistry has all 12 EDA events
//   - the 12 events cover stages: RuntimeService, Validate, Policy,
//     Routing, Execution, PostProcessing
//   - toJSON returns a JSON-serializable array
//   - re-registering a name replaces the previous registration
// =============================================================================

import { describe, it, expect } from 'bun:test'
import { RuntimeEventRegistry, runtimeEventRegistry, type EventRegistration } from '../EventRegistry'

describe('RuntimeEventRegistry (empty instance)', () => {
  it('register + get round-trips a registration', () => {
    const reg = new RuntimeEventRegistry()
    const entry: EventRegistration = {
      name: 'TestEvent',
      version: '1.0',
      stage: 'Test',
      description: 'Test event',
      producer: 'TestStage',
      expectedConsumers: ['audit'],
      payloadSchema: { type: 'object' },
    }
    reg.register(entry)
    expect(reg.get('TestEvent')).toBe(entry)
  })

  it('get returns null for an unknown name', () => {
    const reg = new RuntimeEventRegistry()
    expect(reg.get('Nope')).toBeNull()
  })

  it('list returns an empty array when nothing is registered', () => {
    const reg = new RuntimeEventRegistry()
    expect(reg.list()).toEqual([])
  })

  it('list returns all registrations in insertion order', () => {
    const reg = new RuntimeEventRegistry()
    const a: EventRegistration = {
      name: 'A',
      version: '1.0',
      stage: 'S1',
      description: 'a',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    const b: EventRegistration = {
      name: 'B',
      version: '1.0',
      stage: 'S2',
      description: 'b',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    const c: EventRegistration = {
      name: 'C',
      version: '1.0',
      stage: 'S1',
      description: 'c',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    reg.register(a)
    reg.register(b)
    reg.register(c)
    expect(reg.list()).toEqual([a, b, c])
  })

  it('listByStage returns only events from the requested stage', () => {
    const reg = new RuntimeEventRegistry()
    const a: EventRegistration = {
      name: 'A',
      version: '1.0',
      stage: 'S1',
      description: 'a',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    const b: EventRegistration = {
      name: 'B',
      version: '1.0',
      stage: 'S2',
      description: 'b',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    const c: EventRegistration = {
      name: 'C',
      version: '1.0',
      stage: 'S1',
      description: 'c',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    reg.register(a)
    reg.register(b)
    reg.register(c)
    expect(reg.listByStage('S1')).toEqual([a, c])
    expect(reg.listByStage('S2')).toEqual([b])
    expect(reg.listByStage('S3')).toEqual([])
  })

  it('re-registering the same name replaces the previous registration', () => {
    const reg = new RuntimeEventRegistry()
    const v1: EventRegistration = {
      name: 'X',
      version: '1.0',
      stage: 'S',
      description: 'v1',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    const v2: EventRegistration = {
      name: 'X',
      version: '1.1',
      stage: 'S',
      description: 'v2',
      producer: 'p',
      expectedConsumers: [],
      payloadSchema: {},
    }
    reg.register(v1)
    expect(reg.get('X')).toBe(v1)
    reg.register(v2)
    expect(reg.get('X')).toBe(v2)
    expect(reg.list().length).toBe(1)
  })
})

describe('runtimeEventRegistry (pre-populated)', () => {
  const EXPECTED_12 = [
    'RequestReceived',
    'ValidationStarted',
    'ValidationCompleted',
    'PolicyStarted',
    'PolicyCompleted',
    'RoutingStarted',
    'RoutingCompleted',
    'ExecutionStarted',
    'ExecutionFinished',
    'AuditStarted',
    'AuditCompleted',
    'ResponseReturned',
  ] as const

  it('has exactly 12 events registered', () => {
    expect(runtimeEventRegistry.list().length).toBe(12)
  })

  it('contains every expected event by name', () => {
    for (const name of EXPECTED_12) {
      const reg = runtimeEventRegistry.get(name)
      expect(reg).not.toBeNull()
      expect(reg?.name).toBe(name)
    }
  })

  it('every registration has version "1.0"', () => {
    for (const reg of runtimeEventRegistry.list()) {
      expect(reg.version).toBe('1.0')
    }
  })

  it('every registration has a non-empty description + producer', () => {
    for (const reg of runtimeEventRegistry.list()) {
      expect(reg.description.length).toBeGreaterThan(0)
      expect(reg.producer.length).toBeGreaterThan(0)
    }
  })

  it('every registration lists at least the AuditSubscriber as expected consumer', () => {
    for (const reg of runtimeEventRegistry.list()) {
      expect(reg.expectedConsumers).toContain('AuditSubscriber')
      expect(reg.expectedConsumers).toContain('MetricsSubscriber')
      expect(reg.expectedConsumers).toContain('DashboardSubscriber')
    }
  })

  it('every registration has a payloadSchema object', () => {
    for (const reg of runtimeEventRegistry.list()) {
      expect(typeof reg.payloadSchema).toBe('object')
      expect(reg.payloadSchema).not.toBeNull()
    }
  })

  it('covers stages: RuntimeService, Validate, Policy, Routing, Execution, PostProcessing', () => {
    const stages = new Set(runtimeEventRegistry.list().map((reg) => reg.stage))
    expect(stages.has('RuntimeService')).toBe(true)
    expect(stages.has('Validate')).toBe(true)
    expect(stages.has('Policy')).toBe(true)
    expect(stages.has('Routing')).toBe(true)
    expect(stages.has('Execution')).toBe(true)
    expect(stages.has('PostProcessing')).toBe(true)
  })

  it('listByStage("RuntimeService") returns RequestReceived + ResponseReturned', () => {
    const regs = runtimeEventRegistry.listByStage('RuntimeService')
    const names = regs.map((r) => r.name).sort()
    expect(names).toEqual(['RequestReceived', 'ResponseReturned'])
  })

  it('listByStage("Policy") returns PolicyStarted + PolicyCompleted', () => {
    const regs = runtimeEventRegistry.listByStage('Policy')
    const names = regs.map((r) => r.name).sort()
    expect(names).toEqual(['PolicyCompleted', 'PolicyStarted'])
  })

  it('listByStage("PostProcessing") returns AuditStarted + AuditCompleted', () => {
    const regs = runtimeEventRegistry.listByStage('PostProcessing')
    const names = regs.map((r) => r.name).sort()
    expect(names).toEqual(['AuditCompleted', 'AuditStarted'])
  })

  it('toJSON returns a JSON-serializable array with 12 entries', () => {
    const json = runtimeEventRegistry.toJSON()
    expect(Array.isArray(json)).toBe(true)
    expect(json.length).toBe(12)
    // JSON round-trip must succeed (no functions, no cycles)
    const serialized = JSON.stringify(json)
    expect(serialized.length).toBeGreaterThan(0)
    const parsed = JSON.parse(serialized) as EventRegistration[]
    expect(parsed.length).toBe(12)
  })
})
