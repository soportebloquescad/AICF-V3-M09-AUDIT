// =============================================================================
// AICF V3 — Documents Module Contract (Sprint: Foundation Modules)
// =============================================================================
// Typed contract for the Document Generation module.
//
// Responsibilities:
//   - Generate structured documents from a topic string
//   - Support multiple output formats: markdown, html, pdf
//   - Configurable section count via `DocumentOptions`
//
// This file contains INTERFACES ONLY — no implementation classes.
// Strict TypeScript: no `any`.
// =============================================================================

import type { RuntimeModule } from '@/lib/runtime/contracts/RuntimeModule'

/**
 * Supported output formats for the Documents module.
 */
export type DocumentFormat = 'markdown' | 'html' | 'pdf'

/**
 * Options accepted by `DocumentsModule.generateDocument`.
 */
export interface DocumentOptions {
  /** Output format. Defaults to 'markdown' when omitted. */
  format?: DocumentFormat

  /** Number of sections to generate. */
  sections?: number
}

/**
 * Structured result returned by `DocumentsModule.generateDocument`.
 */
export interface DocumentResult {
  /** Whether generation completed without errors. */
  ok: boolean

  /** Serialized document content (format-dependent payload). */
  content: string

  /** Format that was actually produced (echoes `DocumentOptions.format`). */
  format: string

  /** Number of sections that were generated. */
  sections: number
}

/**
 * Public surface of the Documents module.
 */
export interface DocumentsModule extends RuntimeModule {
  /**
   * Generate a structured document for the given topic.
   *
   * @param topic  Topic / prompt describing the document.
   * @param opts   Optional generation knobs (format, sections).
   */
  generateDocument(topic: string, opts?: DocumentOptions): Promise<DocumentResult>
}
