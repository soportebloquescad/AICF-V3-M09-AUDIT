// =============================================================================
// AICF V3 — MetricsSubscriber Tests (Sprint 22: PR 2 — Observability subscribers)
// =============================================================================
// Verifies:
//   - onEvent() calls metricsRegistry.recordCall(pipelineStage, durationMs)
//   - When metadata.durationMs is undefined, recordCall receives 0
//   - getEventCounts() returns per-stage (pipelineStage) counters
//   - getTotalEvents() returns the grand total events received
//   - onEvent() never throws — registry errors are caught + swallowed
//   - isReady() returns false before initialize(), true after
//   - createMetricsSubscriber() factory returns a MetricsSubscriber
//
// No `any`. Uses the real MetricsRegistry + a throwing fake to validate the
// best-effort contract. Uses `testModule` not `module` per project
// conventions.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { MetricsSubscriber, createMetricsSubscriber } from '../MetricsSubscriber'
import { MetricsRegistry, type ModuleMetrics } from '../../metrics/MetricsRegistry'
import {
  createEventMetadata,
  createEnvelope,
  type RuntimeEventEnvelope,
} from '../../events/EventMetadata'

/**
 * Helper: builds an envelope with sensible defaults for tests.
 * `testModule` is the pipeline stage that emitted the event.
 */
function makeEnvelope(
  overrides: Partial<{
    requestId: string
    correlationId: string
    operation: string
    pipelineStage: string
    stageOrder: number
    durationMs: number
    payload: Record<string, unknown>
  }> = {},
): RuntimeEventEnvelope<Record<string, unknown>> {
  const meta = createEventMetadata({
    correlationId: overrides.correlationId ?? 'cor-1',
    requestId: overrides.requestId ?? 'req-1',
    operation: overrides.operation ?? 'chat',
    pipelineStage: overrides.pipelineStage ?? 'Policy',
    stageOrder: overrides.stageOrder ?? 4,
    durationMs: overrides.durationMs,
  })
  return createEnvelope(meta, overrides.payload ?? { allowed: true })
}

describe('MetricsSubscriber (Sprint 22: PR 2)', () => {
  let metricsRegistry: MetricsRegistry

  beforeEach(() => {
    metricsRegistry = new MetricsRegistry()
  })

  // -------------------------------------------------------------------------
  // isReady()
  // -------------------------------------------------------------------------
  describe('isReady()', () => {
    it('returns false before initialize()', () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      expect(sub.isReady()).toBe(false)
    })

    it('returns true after initialize()', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })
  })

  // -------------------------------------------------------------------------
  // onEvent() — registry recording
  // -------------------------------------------------------------------------
  describe('onEvent() records to MetricsRegistry', () => {
    it('records a call against the pipelineStage module', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      const testModule = 'Routing'
      await sub.onEvent(makeEnvelope({ pipelineStage: testModule, durationMs: 12 }))

      const m: ModuleMetrics = metricsRegistry.getMetrics(testModule)
      expect(m.callCount).toBe(1)
      expect(m.totalDurationMs).toBe(12)
      expect(m.avgLatencyMs).toBe(12)
    })

    it('passes durationMs from metadata when present', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      await sub.onEvent(makeEnvelope({ pipelineStage: 'Execution', durationMs: 100 }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Execution', durationMs: 200 }))

      const m = metricsRegistry.getMetrics('Execution')
      expect(m.callCount).toBe(2)
      expect(m.totalDurationMs).toBe(300)
      expect(m.avgLatencyMs).toBe(150)
    })

    it('passes 0 when metadata.durationMs is undefined', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      // makeEnvelope omits durationMs unless explicitly set.
      await sub.onEvent(makeEnvelope({ pipelineStage: 'PostProcessing' }))

      const m = metricsRegistry.getMetrics('PostProcessing')
      expect(m.callCount).toBe(1)
      expect(m.totalDurationMs).toBe(0)
      expect(m.avgLatencyMs).toBe(0)
    })

    it('accumulates calls across multiple events for the same stage', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      const testModule = 'Policy'
      for (let i = 1; i <= 5; i++) {
        await sub.onEvent(makeEnvelope({ pipelineStage: testModule, durationMs: i * 10 }))
      }

      const m = metricsRegistry.getMetrics(testModule)
      expect(m.callCount).toBe(5)
      expect(m.totalDurationMs).toBe(150) // 10+20+30+40+50
      expect(m.avgLatencyMs).toBe(30)
    })

    it('records separate stages into separate module records', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy', durationMs: 5 }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Routing', durationMs: 15 }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy', durationMs: 25 }))

      expect(metricsRegistry.getMetrics('Policy').callCount).toBe(2)
      expect(metricsRegistry.getMetrics('Routing').callCount).toBe(1)
      expect(metricsRegistry.getMetrics('Policy').totalDurationMs).toBe(30)
      expect(metricsRegistry.getMetrics('Routing').totalDurationMs).toBe(15)
    })
  })

  // -------------------------------------------------------------------------
  // getEventCounts() — per-stage counter map
  // -------------------------------------------------------------------------
  describe('getEventCounts()', () => {
    it('returns an empty record when no events have been received', () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      expect(sub.getEventCounts()).toEqual({})
    })

    it('counts events per pipelineStage', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Routing' }))

      const counts = sub.getEventCounts()
      expect(counts.Policy).toBe(2)
      expect(counts.Routing).toBe(1)
    })

    it('returns a snapshot — mutating the result does not affect internal state', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' }))
      const counts = sub.getEventCounts()
      counts.Policy = 999
      counts['FAKE'] = 0

      // Internal state unchanged.
      expect(sub.getEventCounts().Policy).toBe(1)
      expect(sub.getEventCounts().FAKE).toBeUndefined()
    })
  })

  // -------------------------------------------------------------------------
  // getTotalEvents() — grand total counter
  // -------------------------------------------------------------------------
  describe('getTotalEvents()', () => {
    it('returns 0 when no events have been received', () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      expect(sub.getTotalEvents()).toBe(0)
    })

    it('returns the grand total across all stages', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Routing' }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Execution' }))
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' }))

      expect(sub.getTotalEvents()).toBe(4)
    })

    it('sums correctly across multiple stages', async () => {
      const sub = new MetricsSubscriber(metricsRegistry)
      await sub.initialize()

      const stages = ['Policy', 'Routing', 'Execution', 'PostProcessing']
      for (const testModule of stages) {
        for (let i = 0; i < 3; i++) {
          await sub.onEvent(makeEnvelope({ pipelineStage: testModule }))
        }
      }

      // 4 stages × 3 events each = 12 total.
      expect(sub.getTotalEvents()).toBe(12)
      const counts = sub.getEventCounts()
      const sum = Object.values(counts).reduce((acc, n) => acc + n, 0)
      expect(sum).toBe(12)
    })
  })

  // -------------------------------------------------------------------------
  // onEvent() — error handling (best-effort, never throws)
  // -------------------------------------------------------------------------
  describe('onEvent() error handling', () => {
    it('swallows errors from metricsRegistry.recordCall() — does NOT throw', async () => {
      // Build a fake registry whose recordCall throws.
      const throwingRegistry = {
        recordCall(): void {
          throw new Error('synthetic recordCall() failure')
        },
        getMetrics(): ModuleMetrics {
          return metricsRegistry.getMetrics('x')
        },
        getAllMetrics(): Record<string, ModuleMetrics> {
          return {}
        },
        reset(): void {},
        resetAll(): void {},
        getModuleIds(): string[] {
          return []
        },
      } as unknown as MetricsRegistry

      const sub = new MetricsSubscriber(throwingRegistry)
      await sub.initialize()

      // The promise should resolve, not reject — best-effort contract.
      await expect(sub.onEvent(makeEnvelope())).resolves.toBeUndefined()
    })

    it('does not increment counters when recordCall throws', async () => {
      let throwOnce = true
      const flakyRegistry = {
        recordCall(moduleId: string): void {
          if (throwOnce) {
            throwOnce = false
            throw new Error('first call fails')
          }
          // Subsequent calls delegate to the real registry.
          metricsRegistry.recordCall(moduleId, 0)
        },
        getMetrics(moduleId: string): ModuleMetrics {
          return metricsRegistry.getMetrics(moduleId)
        },
        getAllMetrics(): Record<string, ModuleMetrics> {
          return metricsRegistry.getAllMetrics()
        },
        reset(): void {},
        resetAll(): void {},
        getModuleIds(): string[] {
          return metricsRegistry.getModuleIds()
        },
      } as unknown as MetricsRegistry

      const sub = new MetricsSubscriber(flakyRegistry)
      await sub.initialize()

      // The implementation puts recordCall() before the internal counter
      // increments inside the same try/catch. When recordCall() throws on
      // the first call, the counters for THAT event are NOT incremented
      // (the catch block runs). The subscriber keeps accepting subsequent
      // events without re-throwing — that is the "best-effort" contract.
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' })) // swallowed
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy' })) // ok
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Routing' })) // ok

      // 1 swallowed + 2 successful → total = 2.
      expect(sub.getTotalEvents()).toBe(2)
      const counts = sub.getEventCounts()
      expect(counts.Policy).toBe(1)
      expect(counts.Routing).toBe(1)
    })
  })

  // -------------------------------------------------------------------------
  // createMetricsSubscriber() factory
  // -------------------------------------------------------------------------
  describe('createMetricsSubscriber() factory', () => {
    it('returns a MetricsSubscriber instance', () => {
      const sub = createMetricsSubscriber(metricsRegistry)
      expect(sub).toBeInstanceOf(MetricsSubscriber)
    })

    it('binds to the provided metricsRegistry', async () => {
      const sub = createMetricsSubscriber(metricsRegistry)
      await sub.initialize()
      await sub.onEvent(makeEnvelope({ pipelineStage: 'Policy', durationMs: 7 }))
      expect(metricsRegistry.getMetrics('Policy').callCount).toBe(1)
    })

    it('factory result name is "metrics-subscriber"', () => {
      const sub = createMetricsSubscriber(metricsRegistry)
      expect(sub.name).toBe('metrics-subscriber')
    })
  })
})
