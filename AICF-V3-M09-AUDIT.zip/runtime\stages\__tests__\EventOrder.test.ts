// =============================================================================
// AICF V3 — EDA Event Order Tests (Sprint 21)
// =============================================================================
// Validates that the 12 EDA events fire in the correct order through the
// full request lifecycle:
//
//   RequestReceived          (RuntimeService — order 1)
//   ValidationStarted        (Validate       — order 2)
//   ValidationCompleted      (Validate       — order 3)
//   PolicyStarted            (Policy         — order 4)
//   PolicyCompleted          (Policy         — order 5)
//   RoutingStarted           (Routing        — order 6)
//   RoutingCompleted         (Routing        — order 7)
//   ExecutionStarted         (Execution      — order 8)
//   ExecutionFinished        (Execution      — order 9)
//   AuditStarted             (PostProcessing — order 10)
//   AuditCompleted           (PostProcessing — order 11)
//   ResponseReturned         (RuntimeService — order 12)
//
// Test approach:
//   1. Build a real pipeline with the Sprint 21 stages (eventBus-wired)
//      using a stub fallback that returns empty content.
//   2. Subscribe to onAll() on the bus and record each event type.
//   3. Run service.execute(chatRequest).
//   4. Assert the recorded event types match the canonical 12-event order.
//
// No `any`. Variable named `testModule` not `module` (ESLint rule).
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeService, _resetGlobalBootstrap } from '../../services/RuntimeService'
import { RuntimeEventBus } from '../../events/RuntimeEventBus'
import { Pipeline } from '../../pipeline/Pipeline'
import { buildDefaultPipeline } from '../../pipeline/PipelineRegistry'
import { createRuntimeRequest } from '../../contracts/RuntimeRequest'
import type { RuntimeEventType } from '../../events/RuntimeEvents'

const EXPECTED_ORDER: RuntimeEventType[] = [
  'RequestReceived',
  'ValidationStarted',
  'ValidationCompleted',
  'PolicyStarted',
  'PolicyCompleted',
  'RoutingStarted',
  'RoutingCompleted',
  'ExecutionStarted',
  'ExecutionFinished',
  'AuditStarted',
  'AuditCompleted',
  'ResponseReturned',
]

describe('EDA event order (Sprint 21)', () => {
  beforeEach(() => {
    _resetGlobalBootstrap()
  })

  it('fires all 12 EDA events in the canonical pipeline order', async () => {
    // 1. Fresh EventBus for this test.
    const bus = new RuntimeEventBus()

    // 2. Record every event type that flows through the bus. onAll() gets
    //    called for every emit() (including those triggered by
    //    publishEnvelope which delegates to emit()).
    const observed: RuntimeEventType[] = []
    bus.onAll((event) => {
      observed.push(event.type)
    })

    // 3. Build a real pipeline with the Sprint 21 stages wired to the bus.
    //    The stub fallback returns empty content so Execution falls through
    //    to the fallback (success path), which still emits
    //    ExecutionStarted/ExecutionFinished.
    const testModule = buildDefaultPipeline({
      fallback: async () => ({
        content: 'test-fallback-response',
        model: 'groq-llama-3.3-70b',
        provider: 'litellm',
        usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 },
        durationMs: 0,
      }),
      eventBus: bus,
    })
    const pipeline = new Pipeline(testModule)

    // 4. RuntimeService uses the eventBus + the wired pipeline.
    const service = new RuntimeService({ pipeline, eventBus: bus })
    await service.initialize()

    // 5. Execute a chat request through the pipeline.
    const request = createRuntimeRequest({
      operation: 'chat',
      messages: [{ role: 'user', content: 'Hello, runtime!' }],
    })

    await service.execute(request)

    // 6. Assert the canonical 12-event order.
    expect(observed).toEqual(EXPECTED_ORDER)
    expect(observed.length).toBe(12)
  })

  it('every event carries the expected stageOrder (1-12)', async () => {
    const bus = new RuntimeEventBus()

    // Record metadata for each event (via the envelope attached to data).
    const observedStageOrders: number[] = []
    const observedTypes: RuntimeEventType[] = []
    bus.onAll((event) => {
      observedTypes.push(event.type)
      // The envelope is attached as `data.envelope` by publishEnvelope().
      const envelope = (event.data as { envelope?: { metadata?: { stageOrder?: number } } } | undefined)?.envelope
      if (envelope?.metadata?.stageOrder !== undefined) {
        observedStageOrders.push(envelope.metadata.stageOrder)
      }
    })

    const testModule = buildDefaultPipeline({
      fallback: async () => ({
        content: 'test',
        model: 'groq-llama-3.3-70b',
        provider: 'litellm',
        usage: null,
        durationMs: 0,
      }),
      eventBus: bus,
    })
    const pipeline = new Pipeline(testModule)

    const service = new RuntimeService({ pipeline, eventBus: bus })
    await service.initialize()

    const request = createRuntimeRequest({
      operation: 'chat',
      messages: [{ role: 'user', content: 'Hello' }],
    })

    await service.execute(request)

    // Every event should have a stageOrder matching its position in the
    // canonical sequence (1-indexed).
    expect(observedTypes).toEqual(EXPECTED_ORDER)
    expect(observedStageOrders).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
  })

  it('preserves the same order across multiple sequential requests', async () => {
    const bus = new RuntimeEventBus()

    const testModule = buildDefaultPipeline({
      fallback: async () => ({
        content: 'r',
        model: 'm',
        provider: 'p',
        usage: null,
        durationMs: 0,
      }),
      eventBus: bus,
    })
    const pipeline = new Pipeline(testModule)
    const service = new RuntimeService({ pipeline, eventBus: bus })
    await service.initialize()

    for (let i = 0; i < 3; i++) {
      const observed: RuntimeEventType[] = []
      const off = bus.onAll((event) => {
        observed.push(event.type)
      })

      const request = createRuntimeRequest({
        operation: 'chat',
        messages: [{ role: 'user', content: `Run ${i}` }],
      })

      await service.execute(request)
      off()

      expect(observed).toEqual(EXPECTED_ORDER)
    }
  })

  it('events fire in order even when no eventBus is provided (graceful)', async () => {
    // When no eventBus is wired, the pipeline still runs — no events are
    // emitted. The request should succeed normally.
    const service = new RuntimeService()
    await service.initialize()

    const request = createRuntimeRequest({
      operation: 'chat',
      messages: [{ role: 'user', content: 'Hello' }],
    })

    const response = await service.execute(request)
    // The default pipeline's no-op fallback returns empty content — the
    // response shape itself is valid (ok:true, requestId set, etc.).
    expect(response.requestId).toBe(request.requestId)
  })
})
