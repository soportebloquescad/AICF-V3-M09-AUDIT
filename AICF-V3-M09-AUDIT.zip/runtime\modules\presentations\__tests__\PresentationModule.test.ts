// =============================================================================
// AICF V3 — PresentationModule Tests (Épica 3 — Educational Factory)
// =============================================================================
// Verifies the PresentationModule:
//   - generatePresentation fallback (no AI) — produces a real slide deck.
//   - HTML output is valid HTML5 with embedded CSS.
//   - createSlides, generateSlides, exportSlides, generatePresentation are
//     all accepted job types.
//   - Unknown job types produce a failed ExecutionResult.
//
// No `any`. The variable holding the module under test is named `testModule`.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { PresentationModule, PRESENTATION_MODULE_METADATA } from '../PresentationModule'
import { createBusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

class MockAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> {
    return {
      content: JSON.stringify({
        title: 'Mock Deck',
        slides: [
          { title: 'Slide 1', bullets: ['A', 'B', 'C'], notes: 'Notes 1' },
          { title: 'Slide 2', bullets: ['D', 'E', 'F'], notes: 'Notes 2' },
        ],
      }),
      model: 'mock',
      provider: 'mock',
      usage: null,
      durationMs: 1,
    }
  }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: true, provider: 'mock' } }
}

class FailingAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> { throw new Error('AI unavailable') }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: false, provider: 'failing' } }
}

const ctx = createBusinessContext({ jobId: 'job-test-pres-1' })

describe('PresentationModule (Épica 3)', () => {
  describe('metadata + lifecycle', () => {
    const testModule = new PresentationModule()

    it('exposes the correct metadata', () => {
      expect(testModule.getMetadata()).toEqual(PRESENTATION_MODULE_METADATA)
      expect(testModule.name).toBe('presentation')
    })

    it('declares the expected capabilities', () => {
      const caps = testModule.getCapabilities().map((c) => c.name)
      expect(caps).toContain('createSlides')
      expect(caps).toContain('generateSlides')
      expect(caps).toContain('exportSlides')
      expect(caps).toContain('generatePresentation')
    })

    it('becomes ready after initialize()', async () => {
      expect(testModule.isReady()).toBe(false)
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
    })
  })

  describe('executeJob — fallback (no AI)', () => {
    const testModule = new PresentationModule()

    it('produces a structured slide deck', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 5 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const deck = result.output!.deck as Record<string, unknown>
      expect(typeof deck.title).toBe('string')
      expect(deck.topic).toBe('Serverless')
      expect(deck.theme).toBe('default')
      const slides = deck.slides as Array<Record<string, unknown>>
      expect(slides).toHaveLength(5)
      expect(slides[0].bullets).toBeDefined()
      expect((slides[0].bullets as unknown[]).length).toBeGreaterThanOrEqual(3)
    })

    it('respects the slideCount knob', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as unknown[]
      expect(slides).toHaveLength(3)
    })

    it('accepts the legacy "count" field as well', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', count: 4 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as unknown[]
      expect(slides).toHaveLength(4)
    })

    it('includes markdown source', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      expect(typeof deck.markdown).toBe('string')
      expect((deck.markdown as string)).toContain('## ')
    })

    it('includes speaker notes when includeNotes is true (default)', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as Array<Record<string, unknown>>
      expect(slides[0].notes).toBeDefined()
    })

    it('omits speaker notes when includeNotes is false', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3, includeNotes: false },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as Array<Record<string, unknown>>
      expect(slides[0].notes).toBeUndefined()
    })
  })

  describe('executeJob — HTML output', () => {
    const testModule = new PresentationModule()

    it('produces valid HTML5', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const html = deck.html as string
      expect(html.startsWith('<!DOCTYPE html>')).toBe(true)
      expect(html).toContain('<html')
      expect(html).toContain('</html>')
      expect(html).toContain('<head>')
      expect(html).toContain('<body>')
    })

    it('embeds CSS in a <style> tag', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 2 },
        ctx,
      )
      const html = (result.output!.deck as Record<string, unknown>).html as string
      expect(html).toContain('<style>')
      expect(html).toContain('--accent')
    })

    it('includes keyboard navigation script', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 2 },
        ctx,
      )
      const html = (result.output!.deck as Record<string, unknown>).html as string
      expect(html).toContain('ArrowRight')
      expect(html).toContain('ArrowLeft')
    })

    it('includes print styles', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 2 },
        ctx,
      )
      const html = (result.output!.deck as Record<string, unknown>).html as string
      expect(html).toContain('@media print')
    })

    it('includes a slide counter', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 4 },
        ctx,
      )
      const html = (result.output!.deck as Record<string, unknown>).html as string
      expect(html).toContain('deck-counter')
    })

    it('renders every slide title inside the HTML', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      const deck = result.output!.deck as Record<string, unknown>
      const html = deck.html as string
      const slides = deck.slides as Array<Record<string, unknown>>
      for (const s of slides) {
        expect(html).toContain(s.title as string)
      }
    })
  })

  describe('executeJob — AI mode (mock)', () => {
    let testModule: PresentationModule

    beforeEach(() => {
      testModule = new PresentationModule(new MockAIAdapter())
    })

    it('parses the AI JSON into typed slides', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 2 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as Array<Record<string, unknown>>
      expect(slides).toHaveLength(2)
      expect(slides[0].title).toBe('Slide 1')
      expect(slides[0].bullets).toEqual(['A', 'B', 'C'])
    })

    it('reports providerCalls=1 in metrics', async () => {
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 2 },
        ctx,
      )
      expect(result.metrics?.providerCalls).toBe(1)
    })
  })

  describe('executeJob — AI failure degrades to fallback', () => {
    it('still produces a deck when the AI adapter throws', async () => {
      const testModule = new PresentationModule(new FailingAIAdapter())
      const result = await testModule.executeJob(
        'createSlides',
        { topic: 'Serverless', slideCount: 3 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const deck = result.output!.deck as Record<string, unknown>
      const slides = deck.slides as unknown[]
      expect(slides.length).toBeGreaterThan(0)
      expect(testModule.getMetrics().errorCount).toBeGreaterThan(0)
    })
  })

  describe('executeJob — accepts all slide job types', () => {
    const testModule = new PresentationModule()
    const jobTypes = ['createSlides', 'generateSlides', 'exportSlides', 'generatePresentation']

    for (const jobType of jobTypes) {
      it(`accepts jobType=${jobType}`, async () => {
        const result = await testModule.executeJob(jobType, { topic: 'Rust', slideCount: 2 }, ctx)
        expect(result.ok).toBe(true)
      })
    }
  })

  describe('executeJob — unknown job type', () => {
    const testModule = new PresentationModule()

    it('returns a failed ExecutionResult', async () => {
      const result = await testModule.executeJob('bogusJob', { topic: 'Rust' }, ctx)
      expect(result.ok).toBe(false)
      expect(result.error).toContain('Unknown job type')
      expect(result.error).toContain('bogusJob')
    })
  })
})
