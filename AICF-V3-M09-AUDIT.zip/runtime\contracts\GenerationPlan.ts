// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — GenerationPlan
// =============================================================================
// The generation plan produced before the actual AI generation.
//
// Before generating an artifact, the Runtime builds a GenerationPlan that
// describes:
//   - The artifact type
//   - The structure (sections / modules / slides to generate)
//   - Estimated token usage and cost
//   - The provider and model to use
//
// This allows budget enforcement and structure validation before spending
// tokens.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

/**
 * A single structural element in a generation plan.
 */
export interface GenerationPlanItem {
  /** Unique item ID (e.g. 'module-1', 'slide-3'). */
  id: string

  /** Item type (e.g. 'module', 'lesson', 'slide', 'section', 'exercise'). */
  type: string

  /** Human-readable title for the item. */
  title: string
}

/**
 * A generation plan produced before the actual AI generation.
 *
 * Captures the intended structure, estimated cost, and provider/model
 * selection for an artifact generation.
 */
export interface GenerationPlan {
  /** The artifact type to generate (matches ArtifactRequest.type). */
  type: string

  /** The structural items to generate (modules, slides, sections, etc.). */
  structure: GenerationPlanItem[]

  /** Estimated total tokens to be consumed. */
  estimatedTokens: number

  /** Estimated USD cost. */
  estimatedCost: number

  /** The AI provider to use (e.g. 'groq', 'gemini', 'openrouter'). */
  provider: string

  /** The AI model to use (e.g. 'groq-llama-3.3-70b'). */
  model: string
}

/**
 * Factory: creates a GenerationPlan with sensible defaults.
 *
 * @example
 * const plan = createGenerationPlan({ type: 'course', structure: items, provider: 'groq', model: 'groq-llama-3.3-70b' })
 */
export function createGenerationPlan(
  partial: Partial<GenerationPlan> & Pick<GenerationPlan, 'type' | 'structure' | 'provider' | 'model'>,
): GenerationPlan {
  return {
    estimatedTokens: 0,
    estimatedCost: 0,
    ...partial,
  }
}
