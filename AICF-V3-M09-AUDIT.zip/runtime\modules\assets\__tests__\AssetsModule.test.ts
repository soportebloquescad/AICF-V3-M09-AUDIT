// =============================================================================
// AICF V3 — Sprint 19 — Assets Module Reference Tests
// =============================================================================
// Verifies that the AssetsModule follows the reference pattern:
//   - Full lifecycle (initialize / isReady / dispose)
//   - Health and metadata accessors
//   - Capabilities (storeAsset, getAsset, deleteAsset, listAssets,
//     getAssetUrl) return the expected shapes and honor filters
//
// Tests are self-contained — no external services or fixtures required.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import {
  AssetsModule,
  ASSETS_METADATA,
  createAssetsModule,
  type AssetRecord,
} from '../AssetsModule'

describe('AssetsModule', () => {
  let testModule: AssetsModule

  beforeEach(() => {
    testModule = createAssetsModule()
  })

  describe('lifecycle', () => {
    it('initialize() → isReady() === true', async () => {
      expect(testModule.isReady()).toBe(false)
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      await testModule.initialize()
      const firstStartup = (await testModule.health()).startupTime
      await testModule.initialize()
      const secondStartup = (await testModule.health()).startupTime
      expect(secondStartup).toBe(firstStartup)
    })

    it('dispose() → isReady() === false', async () => {
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
      await testModule.dispose()
      expect(testModule.isReady()).toBe(false)
    })

    it('reload() works', async () => {
      await testModule.initialize()
      await testModule.reload()
      expect(testModule.isReady()).toBe(true)
    })
  })

  describe('health and metadata', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('health() returns healthy when initialized', async () => {
      const h = await testModule.health()
      expect(h.ready).toBe(true)
      expect(h.status).toBe('healthy')
      expect(h.version).toBe(ASSETS_METADATA.version)
      expect(h.dependencies).toEqual([])
    })

    it('getMetadata() returns the declared plugin metadata', () => {
      const meta = testModule.getMetadata()
      expect(meta).toEqual(ASSETS_METADATA)
      expect(meta.id).toBe('assets')
      expect(meta.priority).toBe(15)
      expect(meta.dependencies).toEqual([])
      expect(meta.capabilities).toContain('storeAsset')
      expect(meta.capabilities).toContain('getAsset')
      expect(meta.capabilities).toContain('deleteAsset')
      expect(meta.capabilities).toContain('listAssets')
      expect(meta.capabilities).toContain('getAssetUrl')
      expect(meta.events).toEqual(['asset.stored', 'asset.deleted', 'asset.accessed'])
    })

    it('getStatus() returns the expected status shape', () => {
      const s = testModule.getStatus()
      expect(s.name).toBe(ASSETS_METADATA.name)
      expect(s.ready).toBe(true)
      expect(s.version).toBe(ASSETS_METADATA.version)
      expect(s.details?.implemented).toBe(true)
    })
  })

  describe('storeAsset and getAsset', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('storeAsset returns a generated ID', async () => {
      const { id } = await testModule.storeAsset({
        content: 'aGVsbG8=',
        mimeType: 'text/plain',
        name: 'hello.txt',
      })
      expect(typeof id).toBe('string')
      expect(id.length).toBeGreaterThan(0)
    })

    it('getAsset returns the stored asset', async () => {
      const { id } = await testModule.storeAsset({
        content: 'aGVsbG8=',
        mimeType: 'text/plain',
        name: 'hello.txt',
        metadata: { origin: 'test' },
      })
      const asset = await testModule.getAsset(id)
      expect(asset).not.toBeNull()
      expect(asset?.id).toBe(id)
      expect(asset?.name).toBe('hello.txt')
      expect(asset?.mimeType).toBe('text/plain')
      expect(asset?.content).toBe('aGVsbG8=')
      expect(asset?.size).toBeGreaterThan(0)
      expect(asset?.metadata).toEqual({ origin: 'test' })
      expect(asset?.createdAt).toBeTruthy()
    })

    it('getAsset returns null for an unknown ID', async () => {
      const asset = await testModule.getAsset('does-not-exist')
      expect(asset).toBeNull()
    })

    it('getAsset returns a defensive copy (mutating it does not affect storage)', async () => {
      const { id } = await testModule.storeAsset({
        content: 'aGVsbG8=',
        mimeType: 'text/plain',
        name: 'hello.txt',
        metadata: { foo: 'bar' },
      })
      const first = await testModule.getAsset(id)
      if (first) {
        first.name = 'mutated'
        first.metadata.foo = 'mutated'
      }
      const second = await testModule.getAsset(id)
      expect(second?.name).toBe('hello.txt')
      expect(second?.metadata.foo).toBe('bar')
    })
  })

  describe('deleteAsset', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns true when deleting an existing asset', async () => {
      const { id } = await testModule.storeAsset({
        content: 'aGVsbG8=',
        mimeType: 'text/plain',
        name: 'hello.txt',
      })
      const deleted = await testModule.deleteAsset(id)
      expect(deleted).toBe(true)
      const after = await testModule.getAsset(id)
      expect(after).toBeNull()
    })

    it('returns false when deleting an unknown asset', async () => {
      const deleted = await testModule.deleteAsset('does-not-exist')
      expect(deleted).toBe(false)
    })
  })

  describe('listAssets', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns all stored assets when no filter is given', async () => {
      await testModule.storeAsset({ content: 'YQ==', mimeType: 'text/plain', name: 'a.txt' })
      await testModule.storeAsset({ content: 'Yg==', mimeType: 'image/png', name: 'b.png' })
      const list = await testModule.listAssets()
      expect(list).toHaveLength(2)
    })

    it('filters by mimeType', async () => {
      await testModule.storeAsset({ content: 'YQ==', mimeType: 'text/plain', name: 'a.txt' })
      await testModule.storeAsset({ content: 'Yg==', mimeType: 'image/png', name: 'b.png' })
      await testModule.storeAsset({ content: 'Yw==', mimeType: 'text/plain', name: 'c.txt' })
      const list = await testModule.listAssets({ mimeType: 'text/plain' })
      expect(list).toHaveLength(2)
      expect(list.every((a: AssetRecord) => a.mimeType === 'text/plain')).toBe(true)
    })

    it('filters by name', async () => {
      await testModule.storeAsset({ content: 'YQ==', mimeType: 'text/plain', name: 'a.txt' })
      await testModule.storeAsset({ content: 'Yg==', mimeType: 'image/png', name: 'b.png' })
      const list = await testModule.listAssets({ name: 'a.txt' })
      expect(list).toHaveLength(1)
      expect(list[0]?.name).toBe('a.txt')
    })

    it('returns an empty array when nothing matches the filter', async () => {
      await testModule.storeAsset({ content: 'YQ==', mimeType: 'text/plain', name: 'a.txt' })
      const list = await testModule.listAssets({ mimeType: 'image/jpeg' })
      expect(list).toEqual([])
    })

    it('returns defensive copies', async () => {
      const { id } = await testModule.storeAsset({ content: 'YQ==', mimeType: 'text/plain', name: 'a.txt' })
      const list = await testModule.listAssets()
      list[0]!.name = 'mutated'
      const after = await testModule.getAsset(id)
      expect(after?.name).toBe('a.txt')
    })
  })

  describe('getAssetUrl', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns a data URL for a stored asset', async () => {
      const { id } = await testModule.storeAsset({
        content: 'aGVsbG8=',
        mimeType: 'text/plain',
        name: 'hello.txt',
      })
      const url = await testModule.getAssetUrl(id)
      expect(url).toBe('data:text/plain;base64,aGVsbG8=')
    })

    it('returns null for an unknown ID', async () => {
      const url = await testModule.getAssetUrl('does-not-exist')
      expect(url).toBeNull()
    })
  })
})
