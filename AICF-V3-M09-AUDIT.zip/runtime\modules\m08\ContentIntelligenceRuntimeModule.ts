// =============================================================================
// AICF V3 — Content Intelligence Module (M08) — Sprint 16 Plugin
// =============================================================================
// Wraps the M08 facade (download/content-intelligence/) as a first-class
// Runtime plugin with full lifecycle, metadata, capabilities, and versioned
// contracts.
//
// Capabilities: routeModel, buildPrompt, applyPolicy, selectProvider, checkBudget
// Mission: M08
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { CONTENT_INTELLIGENCE_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * The shape of the M08 facade (from download/content-intelligence/).
 */
export interface M08Facade {
  getPolicyEngine(): {
    evaluate: (request: unknown) =>
      | { allowed: boolean; decisions?: unknown[]; violations?: Array<{ ruleId: string; reason?: string }> | string[] }
      | Promise<{ allowed: boolean; decisions?: unknown[]; violations?: Array<{ ruleId: string; reason?: string }> | string[] }>
  }
  getBudgetManager(): {
    reserve: (request: unknown) =>
      | { ok: boolean; reservationId?: string; tokens?: number; cost?: number; reason?: string }
      | Promise<{ ok: boolean; reservationId?: string; tokens?: number; cost?: number; reason?: string }>
  }
  getProvider(): {
    select: (request: unknown) =>
      | { name: string; available: boolean; egress?: string; via?: string }
      | Promise<{ name: string; available: boolean; egress?: string; via?: string }>
  }
}

/**
 * Plugin metadata for the Content Intelligence module.
 */
export const CONTENT_INTELLIGENCE_METADATA: PluginMetadata = {
  id: 'content-intelligence',
  name: 'Content Intelligence',
  description: 'Policy evaluation, budget management, provider routing, prompt building',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M08',
  priority: 15,
  dependencies: [],
  capabilities: [...CONTENT_INTELLIGENCE_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['policy.evaluated', 'budget.reserved', 'provider.selected'],
}

/**
 * Content Intelligence Runtime Module (M08).
 * Wraps the M08 facade and exposes it as a first-class plugin.
 */
export class ContentIntelligenceRuntimeModule implements RuntimeModule, HotReloadable {
  readonly name = CONTENT_INTELLIGENCE_METADATA.name
  readonly version = CONTENT_INTELLIGENCE_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(private readonly ci: M08Facade) {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
    logger.info({ initLatencyMs: this.initLatencyMs }, 'ContentIntelligenceModule: initialized')
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'download/content-intelligence',
        capabilities: CONTENT_INTELLIGENCE_CAPABILITIES,
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    logger.info('ContentIntelligenceModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('ContentIntelligenceModule: shut down')
  }

  // --- HotReloadable ---
  async load(): Promise<void> { await this.initialize() }
  async unload(): Promise<void> { await this.dispose() }
  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    await this.initialize()
  }

  // --- M08 capabilities (thin wrappers) ---
  getPolicyEngine() { return this.ci.getPolicyEngine() }
  getBudgetManager() { return this.ci.getBudgetManager() }
  getProvider() { return this.ci.getProvider() }

  /**
   * Gets the plugin metadata.
   */
  getMetadata(): PluginMetadata {
    return CONTENT_INTELLIGENCE_METADATA
  }
}

/**
 * Factory: creates a ContentIntelligenceRuntimeModule from the M08 facade.
 */
export function createContentIntelligenceModule(ci: M08Facade): ContentIntelligenceRuntimeModule {
  return new ContentIntelligenceRuntimeModule(ci)
}
