// =============================================================================
// AICF V3 — Reports Module (Sprint 19: Reference Plugin Implementation)
// =============================================================================
// Reference implementation of a Runtime plugin module. Follows the EXACT
// pattern established by ContentIntelligenceRuntimeModule (M08):
//   - Full lifecycle: initialize, isReady, getStatus, health, getMetrics,
//     dispose, shutdown
//   - HotReloadable: load, unload, reload
//   - Plugin metadata via REPORTS_METADATA + getMetadata()
//   - Internal telemetry: initialized, disposed, startupTime,
//     lastInitialization, lastError, initLatencyMs, operationCount,
//     errorCount, lastUsed
//   - markUsed() / recordError() helpers
//
// Capabilities: generateReport, getReportStatus, listReports, exportReport
// Mission: reports
//
// Dependencies: localization, assets (declared in metadata; not enforced
// at runtime — this module is self-contained for the reference impl, but
// in a real deployment it could use the localization module to localize
// report titles and the assets module to persist exported artifacts).
//
// Storage: an in-memory Map<string, ReportRecord>. All generation happens
// synchronously in-process and completes immediately (status: 'completed').
//
// Runtime Agnostic: only imports from @/lib/ai/logger.
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { REPORTS_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * The lifecycle status of a report.
 */
export type ReportStatus = 'pending' | 'running' | 'completed' | 'failed'

/**
 * A stored report record.
 */
export interface ReportRecord {
  /** Unique report ID. */
  id: string
  /** Report type (e.g., 'summary', 'audit', 'statistics'). */
  type: string
  /** Lifecycle status. */
  status: ReportStatus
  /** Caller-supplied parameters used to generate the report. */
  params: Record<string, unknown>
  /** Generated report payload. */
  data: Record<string, unknown>
  /** ISO timestamp when the report was created. */
  createdAt: string
  /** ISO timestamp when the report reached a terminal state, or null. */
  completedAt: string | null
}

/**
 * Optional filter passed to `listReports()`.
 */
export interface ReportFilter {
  /** Filter by report type. */
  type?: string
  /** Filter by lifecycle status. */
  status?: ReportStatus
}

/**
 * Supported export formats.
 */
export type ExportFormat = 'json' | 'markdown' | 'csv'

/**
 * Result of an export operation.
 */
export interface ExportResult {
  /** Serialized report content. */
  content: string
  /** MIME type of the serialized content. */
  mimeType: string
}

/**
 * Generates a reasonably-unique report ID without external dependencies.
 */
function generateReportId(): string {
  const ts = Date.now().toString(36)
  const rnd = Math.random().toString(36).slice(2, 10)
  return `report_${ts}_${rnd}`
}

/**
 * Returns true if a value is a plain object (not an array, not null, not a
 * primitive). Used to flatten nested data into CSV rows.
 */
function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * Flattens a nested object into single-level key/value pairs using dot
 * notation. Arrays are joined with '; '. Primitive values are stringified.
 */
function flattenForCsv(data: Record<string, unknown>): Record<string, string> {
  const out: Record<string, string> = {}
  const walk = (prefix: string, value: unknown): void => {
    if (isPlainObject(value)) {
      for (const [k, v] of Object.entries(value)) {
        walk(prefix ? `${prefix}.${k}` : k, v)
      }
      return
    }
    if (Array.isArray(value)) {
      out[prefix] = value
        .map((v) => (isPlainObject(v) ? JSON.stringify(v) : String(v)))
        .join('; ')
      return
    }
    if (value === null || value === undefined) {
      out[prefix] = ''
      return
    }
    out[prefix] = String(value)
  }
  walk('', data)
  return out
}

/**
 * Escapes a single CSV cell. Quotes the cell when it contains a comma,
 * quote, newline, or leading/trailing whitespace.
 */
function escapeCsvCell(value: string): string {
  if (/[",\n\r]/.test(value) || /^\s|\s$/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`
  }
  return value
}

/**
 * Builds a minimal CSV string from a flat key/value record. Always emits
 * a header row followed by one data row.
 */
function toCsv(flat: Record<string, string>): string {
  const keys = Object.keys(flat)
  if (keys.length === 0) return ''
  const header = keys.map(escapeCsvCell).join(',')
  const row = keys.map((k) => escapeCsvCell(flat[k])).join(',')
  return `${header}\n${row}`
}

/**
 * Generates the report payload for the given type. Unknown types echo
 * back the params so the caller still gets a useful, inspectable result.
 */
function generateReportData(
  type: string,
  params: Record<string, unknown>,
): Record<string, unknown> {
  switch (type) {
    case 'summary':
      return {
        type: 'summary',
        generatedAt: new Date().toISOString(),
        counts: {
          modules: 0,
          workflows: 0,
          generations: 0,
          assets: 0,
        },
        params,
      }
    case 'audit':
      return {
        type: 'audit',
        generatedAt: new Date().toISOString(),
        trail: [] as Array<Record<string, unknown>>,
        params,
      }
    case 'statistics':
      return {
        type: 'statistics',
        generatedAt: new Date().toISOString(),
        statistics: {
          totalRequests: 0,
          successRate: 1,
          avgLatencyMs: 0,
          errorCount: 0,
        },
        params,
      }
    default:
      return {
        type,
        generatedAt: new Date().toISOString(),
        params,
      }
  }
}

/**
 * Plugin metadata for the Reports module.
 */
export const REPORTS_METADATA: PluginMetadata = {
  id: 'reports',
  name: 'Reports',
  description: 'Generación de informes, estadísticas y auditoría',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'reports',
  priority: 25,
  dependencies: ['localization', 'assets'],
  capabilities: [...REPORTS_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['report.generated', 'report.exported'],
}

/**
 * Reports Runtime Module.
 *
 * Self-contained: takes no constructor arguments. All state lives in an
 * internal Map<string, ReportRecord>.
 */
export class ReportsModule implements RuntimeModule, HotReloadable {
  readonly name = REPORTS_METADATA.name
  readonly version = REPORTS_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  private readonly reports = new Map<string, ReportRecord>()

  /**
   * No-argument constructor — the module is fully self-contained.
   */
  constructor() {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.disposed = false
    this.initLatencyMs = Date.now() - start
    logger.info(
      { initLatencyMs: this.initLatencyMs },
      'ReportsModule: initialized',
    )
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'runtime/modules/reports',
        capabilities: REPORTS_CAPABILITIES,
        reportCount: this.reports.size,
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: REPORTS_METADATA.dependencies,
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    this.reports.clear()
    logger.info('ReportsModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    this.reports.clear()
    logger.info('ReportsModule: shut down')
  }

  // --- HotReloadable ---

  async load(): Promise<void> {
    await this.initialize()
  }

  async unload(): Promise<void> {
    await this.dispose()
  }

  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    this.lastError = null
    await this.initialize()
  }

  /**
   * Returns the plugin metadata.
   */
  getMetadata(): PluginMetadata {
    return REPORTS_METADATA
  }

  // --- Internal helpers ---

  private markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  private recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }

  // --- Reports capabilities ---

  /**
   * Generates a report of the given type and stores it. Returns the new
   * report's ID and final status (always 'completed' — generation is
   * synchronous and cannot fail in-process).
   */
  async generateReport(
    type: string,
    params: Record<string, unknown>,
  ): Promise<{ id: string; status: string }> {
    this.markUsed()
    try {
      const id = generateReportId()
      const createdAt = new Date().toISOString()
      const data = generateReportData(type, params)
      const record: ReportRecord = {
        id,
        type,
        status: 'completed',
        params: { ...params },
        data,
        createdAt,
        completedAt: createdAt,
      }
      this.reports.set(id, record)
      logger.debug({ id, type }, 'ReportsModule: report.generated')
      return { id, status: record.status }
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Returns the status of a report by ID, or null when not found.
   */
  async getReportStatus(
    id: string,
  ): Promise<{ id: string; status: string; type: string; createdAt: string } | null> {
    this.markUsed()
    try {
      const record = this.reports.get(id)
      if (!record) return null
      return {
        id: record.id,
        status: record.status,
        type: record.type,
        createdAt: record.createdAt,
      }
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Lists all reports, optionally filtered by type or status.
   */
  async listReports(filter?: ReportFilter): Promise<ReportRecord[]> {
    this.markUsed()
    try {
      const all = Array.from(this.reports.values())
      const filtered = all.filter((record) => {
        if (filter?.type && record.type !== filter.type) return false
        if (filter?.status && record.status !== filter.status) return false
        return true
      })
      // Defensive copies.
      return filtered.map((r) => ({
        ...r,
        params: { ...r.params },
        data: { ...r.data },
      }))
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Exports a report to the requested format. Returns null when the report
   * ID is unknown.
   *
   * - `json`:     JSON.stringify(record.data)
   * - `markdown`: A fenced code block containing pretty-printed JSON.
   * - `csv`:      A two-row CSV (header + values) from the flat key/value
   *               pairs in record.data.
   */
  async exportReport(id: string, format: ExportFormat): Promise<ExportResult | null> {
    this.markUsed()
    try {
      const record = this.reports.get(id)
      if (!record) return null
      let content: string
      let mimeType: string
      switch (format) {
        case 'json':
          content = JSON.stringify(record.data)
          mimeType = 'application/json'
          break
        case 'markdown':
          content = `# ${record.type} Report\n\n\`\`\`json\n${JSON.stringify(record.data, null, 2)}\n\`\`\``
          mimeType = 'text/markdown'
          break
        case 'csv': {
          const flat = flattenForCsv(record.data)
          content = toCsv(flat)
          mimeType = 'text/csv'
          break
        }
        default: {
          // Exhaustiveness guard — if a new format is added without a
          // handler, we throw here rather than silently returning empty.
          const exhaustive: never = format
          throw new Error(`ReportsModule: unsupported export format '${String(exhaustive)}'`)
        }
      }
      logger.debug({ id, format }, 'ReportsModule: report.exported')
      return { content, mimeType }
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }
}

/**
 * Factory: creates a ReportsModule with no external dependencies.
 */
export function createReportsModule(): ReportsModule {
  return new ReportsModule()
}
