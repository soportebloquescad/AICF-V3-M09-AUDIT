// =============================================================================
// AICF V3 — Epica 8 — Module Planner Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Curriculum, ModulePlan, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class ModulePlanner implements EngineContract {
  readonly name = 'module-planner'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('ModulePlanner: invalid input — expected Curriculum')
    }
    const curriculum = input as Curriculum
    if (this.opts.aiAdapter) {
      try {
        return await this.planWithAI(curriculum)
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'ModulePlanner: AI failed, using fallback')
      }
    }
    return this.planDeterministic(curriculum)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    return typeof obj.id === 'string' && typeof obj.topic === 'string' && typeof obj.moduleCount === 'number'
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async planWithAI(curriculum: Curriculum): Promise<ModulePlan[]> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a curriculum architect. Break the curriculum into N modules. Respond as JSON array where each module has: title, summary, learningOutcomes (string[]), durationHours (number).',
        },
        {
          role: 'user',
          content: `Curriculum: ${curriculum.title}\nDescription: ${curriculum.description}\nModule count: ${curriculum.moduleCount}\nLearning outcomes: ${curriculum.learningOutcomes.join('; ')}\n\nReturn JSON array of ${curriculum.moduleCount} modules.`,
        },
      ],
      temperature: 0.4,
      maxTokens: 4096,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as Array<{ title?: string; summary?: string; learningOutcomes?: string[]; durationHours?: number }>
    return parsed.slice(0, curriculum.moduleCount).map((m, i) => this.assembleModule(
      curriculum,
      {
        title: m.title ?? `Module ${i + 1}: ${curriculum.topic}`,
        summary: m.summary ?? `Module ${i + 1} of the ${curriculum.topic} curriculum.`,
        learningOutcomes: m.learningOutcomes ?? [],
        durationHours: typeof m.durationHours === 'number' ? m.durationHours : 2,
      },
      i,
      resp.provider as Provider,
      resp.model,
    ))
  }

  private planDeterministic(curriculum: Curriculum): ModulePlan[] {
    const modules: ModulePlan[] = []
    const arcs = ['Foundations', 'Core Concepts', 'Practical Applications', 'Advanced Techniques', 'Integration & Mastery', 'Specialized Topics', 'Industry Context', 'Critical Evaluation', 'Project Application', 'Capstone Synthesis']
    const blooms = ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create']
    for (let i = 0; i < curriculum.moduleCount; i++) {
      const arc = arcs[i % arcs.length]
      const parsed = {
        title: `Module ${i + 1}: ${curriculum.topic} — ${arc}`,
        summary: `Module ${i + 1} explores ${arc.toLowerCase()} of ${curriculum.topic}. Students will engage with key concepts through structured lessons, practical exercises, and reflective activities. This module builds on prior material and prepares learners for subsequent advanced topics.`,
        learningOutcomes: [
          `Identify key ${arc.toLowerCase()} of ${curriculum.topic}`,
          `Apply ${arc.toLowerCase()} principles in practical scenarios`,
          `Evaluate the role of ${arc.toLowerCase()} within the broader field of ${curriculum.topic}`,
        ],
        durationHours: 2,
      }
      modules.push(this.assembleModule(curriculum, parsed, i, 'runtime-adapter', 'deterministic-fallback'))
    }
    return modules
  }

  private assembleModule(
    curriculum: Curriculum,
    parsed: { title: string; summary: string; learningOutcomes: string[]; durationHours: number },
    index: number,
    provider: Provider,
    model: string,
  ): ModulePlan {
    const now = new Date().toISOString()
    return {
      id: makeId('mod'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      curriculumId: curriculum.id,
      moduleIndex: index,
      title: parsed.title,
      summary: parsed.summary,
      learningOutcomes: parsed.learningOutcomes,
      lessonCount: 3,
      durationHours: parsed.durationHours,
      bloomLevels: ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create'].slice(0, 4),
    }
  }
}
