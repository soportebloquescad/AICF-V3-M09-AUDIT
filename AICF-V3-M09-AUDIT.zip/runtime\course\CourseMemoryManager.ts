// =============================================================================
// AICF V3 — Épica 6 — Course Memory Manager
// =============================================================================
import { CourseMemory, type MemoryDiff } from './CourseMemory'

export class CourseMemoryManager {
  private readonly memory: CourseMemory

  constructor(private readonly opts: { courseId: string }) {
    this.memory = new CourseMemory(opts)
  }

  getMemory(): CourseMemory {
    return this.memory
  }

  async saveState(stage: string, state: Record<string, unknown>): Promise<void> {
    await this.memory.checkpoint(stage, state)
  }

  async loadState(): Promise<Record<string, unknown> | null> {
    const cp = await this.memory.resume()
    return cp?.data ?? null
  }

  async canResume(): Promise<boolean> {
    const cp = await this.memory.resume()
    return cp !== null
  }

  async getRemainingStages(allStages: string[]): Promise<string[]> {
    const cp = await this.memory.resume()
    if (!cp) return allStages
    const { remaining } = await this.memory.incremental(cp.id)
    return remaining.length > 0 ? remaining : allStages.filter((s) => !allStages.includes(cp.stage))
  }

  async diffVersions(v1: string, v2: string): Promise<MemoryDiff> {
    return this.memory.diff(v1, v2)
  }
}
