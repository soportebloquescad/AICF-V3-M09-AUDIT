// =============================================================================
// AICF V3 — Documents Module (barrel)
// =============================================================================
// Re-exports the public typed contracts of the Documents module plus the
// concrete DocumentModule (Épica 3 — Educational Factory).
// =============================================================================

export type {
  DocumentsModule,
  DocumentOptions,
  DocumentFormat,
  DocumentResult,
} from './interfaces'

export {
  DocumentModule,
  DOCUMENT_MODULE_METADATA,
  DOCUMENT_CAPABILITIES,
} from './DocumentModule'

export type {
  DocumentType,
  DocumentSection,
  GeneratedDocument,
} from './DocumentModule'
