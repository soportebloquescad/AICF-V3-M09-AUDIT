// =============================================================================
// AICF V3 — Épica 9 — GET /api/runtime/course/[id]/progress
// =============================================================================
// Returns the progress of a course generation job.
//
// Identifier resolution chain:
//   [id] (URL segment) → jobId → CourseJobStore.get(jobId) → CourseJob
//
// The [id] segment is treated as a jobId (same convention as /storyboard,
// /quality, /exports). This is consistent with how CourseWorker creates
// jobs (CourseJobStore.create() returns a job whose .id is the jobId).
//
// Responses:
//   200 — job found, returns progress + stage + status
//   404 — jobId not found in CourseJobStore
// =============================================================================
import { NextRequest, NextResponse } from 'next/server'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id: jobId } = await params
  const reqLogger = logger.child({
    endpoint: '/api/runtime/course/[id]/progress',
    method: 'GET',
    jobId,
  })

  try {
    const job = await CourseJobStore.get(jobId)

    if (!job) {
      reqLogger.info({ jobId }, 'Progress: job not found')
      return NextResponse.json(
        { error: 'Job not found', jobId },
        { status: 404 },
      )
    }

    reqLogger.info(
      { jobId, status: job.status, stage: job.stage, progress: job.progress },
      'Progress retrieved',
    )

    return NextResponse.json({
      jobId: job.id,
      courseId: job.courseId,
      status: job.status,
      stage: job.stage,
      progress: job.progress,
      startedAt: job.startedAt,
      updatedAt: job.updatedAt,
      completedAt: job.completedAt ?? null,
      error: job.error ?? null,
      artifactCount: job.artifacts.length,
      logs: job.logs,
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Progress: failed',
    )
    return NextResponse.json(
      { error: 'Failed to get job progress' },
      { status: 500 },
    )
  }
}
