// =============================================================================
// AICF V3 — Sprint 13+14 — Trace Storage (Batch C2)
// =============================================================================
// In-memory store for `ExecutionTrace` entries, keyed by execution id.
// The store is the trace subsystem's retention layer: the event bus
// delivers workflow events, the store converts each event into a trace
// entry and retains them (capped) for audit / replay / UI queries.
//
// Sprint 13+14 spec requirements covered:
//   - `record(trace)` — append a trace entry
//   - `getTraces(executionId)` — ordered traces for one execution
//   - `getAllTraces()` — every retained trace, in record order
//   - `clear(executionId?)` — clear one execution's traces, or all
//   - `getTraceCount(executionId?)` — count for one execution, or total
//   - Optional `IEventBus` subscription on construction: every
//     published `WorkflowEvent` is auto-converted to a trace entry
//
// Design notes:
//   - The trace cap (`maxTraces`, default 10000) is a GLOBAL cap on
//     total retained traces across all executions. When the cap is
//     exceeded, the oldest trace (by insertion order, across all
//     executions) is evicted. This bounds memory regardless of how
//     many executions are in flight. A per-execution cap could be
//     layered on top in a future enhancement.
//   - Events without an `executionId` (pre-execution events) are
//     recorded under the sentinel key `'__no_execution__'` so they are
//     not lost. `getTraces('__no_execution__')` returns them.
//   - The store deep-clones on `record` so the caller's reference
//     cannot mutate retained state, and returns shallow copies on read
//     so callers cannot mutate the store's internal arrays. (Trace
//     entries themselves are treated as immutable after recording.)
//   - `detach()` unsubscribes from the event bus (if one was attached)
//     so the store can be cleanly disposed.
// =============================================================================

import type { IEventBus } from '@/lib/runtime/interfaces'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'
import type { ExecutionTrace, TraceLevel } from './ExecutionTrace'
import { createTrace } from './ExecutionTrace'
import { logger } from '@/lib/ai/logger'

/** Default cap on total retained traces across all executions. */
const DEFAULT_MAX_TRACES = 10000

/** Sentinel execution id for events that carry no executionId. */
const NO_EXECUTION_KEY = '__no_execution__'

/**
 * In-memory trace store. Construct with an optional `IEventBus` to
 * auto-record every published event as a trace entry; otherwise call
 * `record()` manually.
 *
 *   const storage = new TraceStorage(5000, eventBus)
 *   // ... events flow in and are auto-recorded ...
 *   const traces = storage.getTraces('exec-1')
 */
export class TraceStorage {
  /** Traces keyed by execution id, in record order. */
  private readonly traces = new Map<string, ExecutionTrace[]>()
  /** Global insertion-ordered list of `[executionId, trace]` for FIFO eviction. */
  private readonly insertionOrder: Array<{ executionId: string; trace: ExecutionTrace }> = []
  /** Unsubscribe function for the event-bus subscription, if any. */
  private unsubscribe?: () => void

  /**
   * @param maxTraces  Global cap on total retained traces. Default 10000.
   * @param eventBus   Optional event bus to auto-subscribe to.
   */
  constructor(
    private readonly maxTraces: number = DEFAULT_MAX_TRACES,
    eventBus?: IEventBus,
  ) {
    if (eventBus) {
      // Subscribe to every event and convert it to a trace entry.
      // `subscribeAll` returns an unsubscribe function we retain for
      // `detach()`.
      this.unsubscribe = eventBus.subscribeAll((event) => {
        this.recordWorkflowEvent(event)
      })
      logger.debug(
        { maxTraces: this.maxTraces },
        'TraceStorage: subscribed to event bus',
      )
    }
  }

  /**
   * Append a trace entry. Deep-clones the trace so the caller's
   * reference cannot mutate retained state. Enforces the global cap by
   * evicting the oldest trace (across all executions) when exceeded.
   */
  record(trace: ExecutionTrace): void {
    const clone: ExecutionTrace = JSON.parse(JSON.stringify(trace)) as ExecutionTrace
    const key = clone.executionId || NO_EXECUTION_KEY
    if (!clone.executionId) {
      // Preserve the original (possibly empty) executionId on the
      // clone but bucket under the sentinel key so the entry is
      // retrievable.
      clone.executionId = key
    }

    let list = this.traces.get(key)
    if (!list) {
      list = []
      this.traces.set(key, list)
    }
    list.push(clone)
    this.insertionOrder.push({ executionId: key, trace: clone })

    this.enforceCap()
  }

  /**
   * Return the ordered traces for one execution. Returns a shallow
   * copy so callers can iterate / mutate without affecting the store.
   * Returns an empty array if the execution has no traces.
   */
  getTraces(executionId: string): ExecutionTrace[] {
    const list = this.traces.get(executionId)
    if (!list) return []
    return list.slice()
  }

  /**
   * Return every retained trace, in global record order (oldest first).
   * Returns a flat array; callers that need per-execution grouping
   * should use `getTraces(executionId)`.
   */
  getAllTraces(): ExecutionTrace[] {
    return this.insertionOrder.map((entry) => entry.trace)
  }

  /**
   * Clear traces for one execution, or (when `executionId` is omitted)
   * clear ALL traces. Also compacts the insertion-order index.
   */
  clear(executionId?: string): void {
    if (executionId === undefined) {
      this.traces.clear()
      this.insertionOrder.length = 0
      logger.debug('TraceStorage: cleared all traces')
      return
    }
    const removed = this.traces.delete(executionId)
    if (removed) {
      // Compact the insertion-order index by filtering out entries
      // belonging to the cleared execution.
      for (let i = this.insertionOrder.length - 1; i >= 0; i--) {
        if (this.insertionOrder[i].executionId === executionId) {
          this.insertionOrder.splice(i, 1)
        }
      }
    }
    logger.debug(
      { executionId, removed },
      'TraceStorage: cleared traces for execution',
    )
  }

  /**
   * Return the trace count for one execution, or (when `executionId`
   * is omitted) the total trace count across all executions.
   */
  getTraceCount(executionId?: string): number {
    if (executionId !== undefined) {
      return this.traces.get(executionId)?.length ?? 0
    }
    return this.insertionOrder.length
  }

  /**
   * Unsubscribe from the event bus (if one was attached on
   * construction). Safe to call multiple times; subsequent calls are
   * no-ops. Does NOT clear retained traces — call `clear()` for that.
   */
  detach(): void {
    if (this.unsubscribe) {
      this.unsubscribe()
      this.unsubscribe = undefined
      logger.debug('TraceStorage: detached from event bus')
    }
  }

  // ----- Internal helpers ---------------------------------------------------

  /**
   * Convert a `WorkflowEvent` into an `ExecutionTrace` and record it.
   * Events without an `executionId` are bucketed under the sentinel
   * key so they are not lost.
   */
  private recordWorkflowEvent(event: WorkflowEvent): void {
    const executionId = event.executionId ?? NO_EXECUTION_KEY
    const trace = createTrace(
      executionId,
      event.type,
      event.data,
      {
        ...(event.stepId !== undefined ? { stepId: event.stepId } : {}),
        level: event.level as TraceLevel,
        timestamp: event.timestamp,
      },
    )
    this.record(trace)
  }

  /**
   * Enforce the global trace cap by evicting the oldest trace(s)
   * (across all executions) until the count is within the cap. Eviction
   * is FIFO by insertion order.
   */
  private enforceCap(): void {
    while (this.insertionOrder.length > this.maxTraces) {
      const oldest = this.insertionOrder.shift()
      if (!oldest) break
      const list = this.traces.get(oldest.executionId)
      if (list) {
        list.shift()
        if (list.length === 0) {
          this.traces.delete(oldest.executionId)
        }
      }
    }
  }
}
