// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — MetricsCollector Tests
// =============================================================================
// Tests for MetricsCollector. Verifies per-execution, per-provider, and
// aggregate metrics, snapshot serialization, and auto-recording from
// EventBus lifecycle events on construction.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { MetricsCollector } from '../metrics/MetricsCollector'
import { InMemoryEventBus } from '../events/EventBus'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'

describe('MetricsCollector', () => {
  let collector: MetricsCollector

  beforeEach(() => {
    collector = new MetricsCollector()
  })

  it('recordExecution + getExecutionMetrics', () => {
    collector.recordExecution('exec-1', {
      durationMs: 1000,
      tokensUsed: 500,
      cost: 0.01,
      provider: 'mock',
      model: 'mock-model',
      success: true,
    })
    const m = collector.getExecutionMetrics('exec-1')
    expect(m).not.toBeNull()
    expect(m?.durationMs).toBe(1000)
    expect(m?.tokensUsed).toBe(500)
    expect(m?.cost).toBe(0.01)
    expect(m?.success).toBe(true)
    expect(m?.provider).toBe('mock')
    expect(m?.model).toBe('mock-model')
  })

  it('recordProvider + getProviderMetrics', () => {
    collector.recordProvider('mock', 100, true, 200, 0.005)
    collector.recordProvider('mock', 200, false, 0, 0)
    const m = collector.getProviderMetrics('mock')
    expect(m).not.toBeNull()
    expect(m?.totalCalls).toBe(2)
    expect(m?.successCount).toBe(1)
    expect(m?.failureCount).toBe(1)
    expect(m?.avgLatencyMs).toBe(150)
    expect(m?.totalTokens).toBe(200)
    expect(m?.totalCost).toBe(0.005)
  })

  it('getAggregateMetrics returns totals across all executions', () => {
    collector.recordExecution('exec-1', {
      durationMs: 1000,
      tokensUsed: 500,
      cost: 0.01,
      provider: 'mock',
      model: 'mock-model',
      success: true,
    })
    collector.recordExecution('exec-2', {
      durationMs: 2000,
      tokensUsed: 800,
      cost: 0.02,
      provider: 'mock',
      model: 'mock-model',
      success: false,
    })
    const agg = collector.getAggregateMetrics()
    expect(agg.totalExecutions).toBe(2)
    expect(agg.successfulExecutions).toBe(1)
    expect(agg.failedExecutions).toBe(1)
    expect(agg.successRate).toBe(0.5)
    expect(agg.totalTokens).toBe(1300)
    expect(agg.totalCost).toBeCloseTo(0.03, 6)
    expect(agg.avgExecutionMs).toBe(1500)
    // Provider 'mock' was credited through recordExecution.
    expect(agg.providerMetrics['mock']).toBeDefined()
    expect(agg.providerMetrics['mock'].totalCalls).toBeGreaterThanOrEqual(2)
  })

  it('getMetricsSnapshot returns serializable object (no Maps)', () => {
    collector.recordExecution('exec-1', {
      durationMs: 100,
      tokensUsed: 50,
      cost: 0,
      provider: 'mock',
      model: 'mock-model',
      success: true,
    })
    const snap = collector.getMetricsSnapshot()
    // Must be JSON-serializable (no Maps, no functions).
    expect(() => JSON.stringify(snap)).not.toThrow()
    const parsed = JSON.parse(JSON.stringify(snap)) as Record<string, unknown>
    expect(parsed.timestamp).toBeDefined()
    expect(parsed.aggregate).toBeDefined()
    expect(parsed.executions).toBeDefined()
    expect(Array.isArray(parsed.executions)).toBe(true)
    expect(parsed.stepCount).toBe(0)
    expect(parsed.providerCount).toBe(1)
  })

  it('auto-records from EventBus events when constructed with a bus', async () => {
    const bus = new InMemoryEventBus()
    const auto = new MetricsCollector(bus)

    const startEvent: WorkflowEvent = {
      type: 'workflow.started',
      timestamp: 1000,
      level: 'info',
      executionId: 'exec-auto',
      data: { workflowId: 'wf-1' },
    }
    const completeEvent: WorkflowEvent = {
      type: 'workflow.completed',
      timestamp: 2500,
      level: 'info',
      executionId: 'exec-auto',
      data: {
        totalTokens: 600,
        cost: 0.012,
        provider: 'auto-prov',
        model: 'auto-model',
      },
    }
    await bus.publish(startEvent)
    await bus.publish(completeEvent)

    const m = auto.getExecutionMetrics('exec-auto')
    expect(m).not.toBeNull()
    // durationMs = completeEvent.timestamp - startEvent.timestamp = 1500.
    expect(m?.durationMs).toBe(1500)
    expect(m?.tokensUsed).toBe(600)
    expect(m?.cost).toBe(0.012)
    expect(m?.success).toBe(true)
    expect(m?.provider).toBe('auto-prov')
    expect(m?.model).toBe('auto-model')
  })
})
