// =============================================================================
// AICF V3 — RuntimeEventBus EDA Tests (Sprint Foundation-Core)
// =============================================================================
// Focused tests for the 12 new EDA request-lifecycle event types added in
// Sprint Foundation-Core:
//   RequestReceived, ValidationStarted, ValidationCompleted,
//   PolicyStarted, PolicyCompleted, RoutingStarted, RoutingCompleted,
//   ExecutionStarted, ExecutionFinished, AuditStarted, AuditCompleted,
//   ResponseReturned.
//
// Verifies:
//   - emit + on(type) round-trips each EDA event type
//   - emitEvent() forwards the EDA-specific fields (valid, errors, allowed,
//     provider, model, module, success, numeric status)
//   - onAll() receives every EDA event
//   - type-specific handlers are NOT invoked for other EDA event types
//   - unsubscribe stops further delivery
//   - handler errors are swallowed (don't break delivery to other handlers)
//
// No `any`. Self-contained mocks.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeEventBus } from '../RuntimeEventBus'
import { createRuntimeEvent } from '../RuntimeEvents'
import type { RuntimeEvent, RuntimeEventType } from '../RuntimeEvents'

/** The 12 EDA event types added in Sprint Foundation-Core. */
const EDA_EVENT_TYPES: RuntimeEventType[] = [
  'RequestReceived',
  'ValidationStarted',
  'ValidationCompleted',
  'PolicyStarted',
  'PolicyCompleted',
  'RoutingStarted',
  'RoutingCompleted',
  'ExecutionStarted',
  'ExecutionFinished',
  'AuditStarted',
  'AuditCompleted',
  'ResponseReturned',
]

describe('RuntimeEventBus — EDA events (Sprint Foundation-Core)', () => {
  let bus: RuntimeEventBus

  beforeEach(() => {
    bus = new RuntimeEventBus()
  })

  // -------------------------------------------------------------------------
  // emit + on(type) round-trip for each EDA event
  // -------------------------------------------------------------------------
  describe('emit + on(type) round-trip', () => {
    it.each(EDA_EVENT_TYPES)('delivers a %s event to its type-specific handler', async (type) => {
      const received: RuntimeEvent[] = []
      bus.on(type, (e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent(type, { requestId: 'req-1' }))
      expect(received.length).toBe(1)
      expect(received[0].type).toBe(type)
      expect(received[0].requestId).toBe('req-1')
    })

    it('delivers the same event instance to the handler', async () => {
      const event = createRuntimeEvent('RequestReceived', { requestId: 'r1' })
      const received: RuntimeEvent[] = []
      bus.on('RequestReceived', (e) => {
        received.push(e)
      })
      await bus.emit(event)
      expect(received[0]).toBe(event)
    })
  })

  // -------------------------------------------------------------------------
  // emitEvent convenience method — EDA-specific fields
  // -------------------------------------------------------------------------
  describe('emitEvent forwards EDA-specific fields', () => {
    it('forwards valid + errors on ValidationCompleted', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ValidationCompleted', (e) => {
        received.push(e)
      })
      await bus.emitEvent('ValidationCompleted', {
        requestId: 'r1',
        valid: false,
        errors: ['field.required', 'field.tooShort'],
      })
      expect(received[0].valid).toBe(false)
      expect(received[0].errors).toEqual(['field.required', 'field.tooShort'])
    })

    it('forwards allowed on PolicyCompleted', async () => {
      const received: RuntimeEvent[] = []
      bus.on('PolicyCompleted', (e) => {
        received.push(e)
      })
      await bus.emitEvent('PolicyCompleted', { requestId: 'r1', allowed: true })
      expect(received[0].allowed).toBe(true)
    })

    it('forwards provider + model on RoutingCompleted', async () => {
      const received: RuntimeEvent[] = []
      bus.on('RoutingCompleted', (e) => {
        received.push(e)
      })
      await bus.emitEvent('RoutingCompleted', {
        requestId: 'r1',
        provider: 'litellm',
        model: 'gpt-4o',
      })
      expect(received[0].provider).toBe('litellm')
      expect(received[0].model).toBe('gpt-4o')
    })

    it('forwards module + success on ExecutionFinished', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ExecutionFinished', (e) => {
        received.push(e)
      })
      await bus.emitEvent('ExecutionFinished', {
        requestId: 'r1',
        module: 'generation',
        success: true,
      })
      expect(received[0].module).toBe('generation')
      expect(received[0].success).toBe(true)
    })

    it('forwards numeric HTTP status on ResponseReturned', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ResponseReturned', (e) => {
        received.push(e)
      })
      await bus.emitEvent('ResponseReturned', { requestId: 'r1', status: 200 })
      expect(received[0].status).toBe(200)
    })

    it('forwards numeric status on ExecutionFinished', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ExecutionFinished', (e) => {
        received.push(e)
      })
      await bus.emitEvent('ExecutionFinished', {
        requestId: 'r1',
        status: 500,
        success: false,
      })
      expect(received[0].status).toBe(500)
      expect(received[0].success).toBe(false)
    })

    it('forwards module on AuditCompleted', async () => {
      const received: RuntimeEvent[] = []
      bus.on('AuditCompleted', (e) => {
        received.push(e)
      })
      await bus.emitEvent('AuditCompleted', { requestId: 'r1', module: 'observability' })
      expect(received[0].module).toBe('observability')
    })
  })

  // -------------------------------------------------------------------------
  // onAll
  // -------------------------------------------------------------------------
  describe('onAll', () => {
    it('receives every EDA event type', async () => {
      const received: RuntimeEvent[] = []
      bus.onAll((e) => {
        received.push(e)
      })
      for (const type of EDA_EVENT_TYPES) {
        await bus.emit(createRuntimeEvent(type, { requestId: 'r1' }))
      }
      expect(received.length).toBe(EDA_EVENT_TYPES.length)
      const types = received.map((e) => e.type)
      expect(types).toEqual(EDA_EVENT_TYPES)
    })

    it('receives the event alongside type-specific handlers', async () => {
      const allReceived: RuntimeEvent[] = []
      const typedReceived: RuntimeEvent[] = []
      bus.onAll((e) => {
        allReceived.push(e)
      })
      bus.on('RequestReceived', (e) => {
        typedReceived.push(e)
      })
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' }))
      expect(allReceived.length).toBe(1)
      expect(typedReceived.length).toBe(1)
    })
  })

  // -------------------------------------------------------------------------
  // handler isolation — type-specific handlers ignore other EDA types
  // -------------------------------------------------------------------------
  describe('handler isolation', () => {
    it('a RequestReceived handler is NOT invoked for ResponseReturned', async () => {
      const received: RuntimeEvent[] = []
      bus.on('RequestReceived', (e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent('ResponseReturned', { requestId: 'r1' }))
      expect(received).toEqual([])
    })

    it('a ValidationCompleted handler ignores ValidationStarted', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ValidationCompleted', (e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent('ValidationStarted', { requestId: 'r1' }))
      expect(received).toEqual([])
    })

    it('an ExecutionStarted handler ignores ExecutionFinished', async () => {
      const received: RuntimeEvent[] = []
      bus.on('ExecutionStarted', (e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent('ExecutionFinished', { requestId: 'r1' }))
      expect(received).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // unsubscribe
  // -------------------------------------------------------------------------
  describe('unsubscribe', () => {
    it('stops further delivery to a type-specific EDA handler', async () => {
      const received: RuntimeEvent[] = []
      const off = bus.on('RequestReceived', (e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' }))
      off()
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r2' }))
      expect(received.length).toBe(1)
      expect(received[0].requestId).toBe('r1')
    })

    it('stops further delivery to an onAll handler', async () => {
      const received: RuntimeEvent[] = []
      const off = bus.onAll((e) => {
        received.push(e)
      })
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' }))
      off()
      await bus.emit(createRuntimeEvent('ResponseReturned', { requestId: 'r2' }))
      expect(received.length).toBe(1)
    })
  })

  // -------------------------------------------------------------------------
  // error swallowing
  // -------------------------------------------------------------------------
  describe('error handling', () => {
    it('a throwing type-specific handler does not stop delivery to onAll', async () => {
      const allReceived: RuntimeEvent[] = []
      bus.on('RequestReceived', () => {
        throw new Error('boom')
      })
      bus.onAll((e) => {
        allReceived.push(e)
      })
      // Should not reject — the handler error is swallowed by the bus.
      await expect(
        bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' })),
      ).resolves.toBeUndefined()
      expect(allReceived.length).toBe(1)
    })

    it('a throwing onAll handler does not stop delivery to type-specific handlers', async () => {
      const typedReceived: RuntimeEvent[] = []
      bus.on('RequestReceived', (e) => {
        typedReceived.push(e)
      })
      bus.onAll(() => {
        throw new Error('boom')
      })
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' }))
      expect(typedReceived.length).toBe(1)
    })

    it('a throwing type-specific handler does not stop delivery to another type-specific handler', async () => {
      const secondReceived: RuntimeEvent[] = []
      bus.on('RequestReceived', () => {
        throw new Error('first handler boom')
      })
      bus.on('RequestReceived', (e) => {
        secondReceived.push(e)
      })
      await bus.emit(createRuntimeEvent('RequestReceived', { requestId: 'r1' }))
      expect(secondReceived.length).toBe(1)
    })
  })
})
