// =============================================================================
// AICF V3 — Business Module Registry Tests (Épica 2 — AI Factory Core, B11)
// =============================================================================
// Verifies `BusinessModuleRegistry`:
//   - register(): adds a module, retrievable by id.
//   - register(): overwriting a previous registration is allowed (logged).
//   - unregister(): drops the module.
//   - get(): returns the module or null.
//   - list(): returns every module in insertion order.
//   - findByCapability(): returns every module exposing a capability name.
//   - listCapabilities(): returns de-duplicated capability names across modules.
//   - listIds() + clear(): diagnostic helpers.
//
// No `any`. Modules under test are named `testModule` / `testModuleA` /
// `testModuleB` (not `module`) per project conventions.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { BusinessModuleRegistry } from '../BusinessModuleRegistry'
import { defineModule } from '../../plugin/PluginSDK'
import { createCapability } from '../../contracts/Capability'
import { createFailedResult } from '../../contracts/ExecutionResult'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'

/**
 * Builds a tiny BusinessModuleBase instance with the given name + capability
 * names. Used as test data — its executeJob is a stub.
 */
function makeModule(id: string, capabilityNames: string[]): ReturnType<typeof defineModule> {
  const meta: PluginMetadata = {
    id,
    name: id,
    description: `Test module ${id}`,
    author: 'test',
    version: '1.0.0',
    mission: id,
    priority: 50,
    dependencies: [],
    capabilities: capabilityNames,
    contracts: createVersionedContract('1.0.0', 'compatible'),
  }
  return defineModule({
    name: id,
    version: '1.0.0',
    metadata: meta,
    capabilities: capabilityNames.map((n) => createCapability(n, `${n} capability`)),
    executeJob: async () => createFailedResult('Not implemented'),
  })
}

describe('BusinessModuleRegistry (Épica 2 — B11)', () => {
  let registry: BusinessModuleRegistry

  beforeEach(() => {
    registry = new BusinessModuleRegistry()
  })

  // -------------------------------------------------------------------------
  // register() + get()
  // -------------------------------------------------------------------------
  describe('register() + get()', () => {
    it('register() makes the module retrievable via get()', () => {
      const testModule = makeModule('course', ['createCourse'])
      registry.register(testModule)
      expect(registry.get('course')).toBe(testModule)
    })

    it('get() returns null for an unknown id', () => {
      expect(registry.get('does-not-exist')).toBeNull()
    })

    it('register() overwrites a previous registration for the same id', () => {
      const a = makeModule('course', ['createCourse'])
      const b = makeModule('course', ['createCourse', 'generateCourse'])
      registry.register(a)
      registry.register(b)
      expect(registry.get('course')).toBe(b)
      // The overwritten module's capabilities should NOT appear in the
      // registry's view of 'course'.
      expect(registry.findByCapability('generateCourse')).toContain(b)
    })
  })

  // -------------------------------------------------------------------------
  // unregister()
  // -------------------------------------------------------------------------
  describe('unregister()', () => {
    it('drops the module from the registry', () => {
      const testModule = makeModule('course', ['createCourse'])
      registry.register(testModule)
      registry.unregister('course')
      expect(registry.get('course')).toBeNull()
      expect(registry.list().length).toBe(0)
    })

    it('is a no-op for an unknown id (does not throw)', () => {
      expect(() => registry.unregister('nope')).not.toThrow()
    })
  })

  // -------------------------------------------------------------------------
  // list()
  // -------------------------------------------------------------------------
  describe('list()', () => {
    it('returns an empty array when the registry is empty', () => {
      expect(registry.list()).toEqual([])
    })

    it('returns every registered module in insertion order', () => {
      const testModuleA = makeModule('course', ['createCourse'])
      const testModuleB = makeModule('quiz', ['createQuiz'])
      const testModuleC = makeModule('presentation', ['createSlides'])
      registry.register(testModuleA)
      registry.register(testModuleB)
      registry.register(testModuleC)
      const list = registry.list()
      expect(list.length).toBe(3)
      expect(list[0]).toBe(testModuleA)
      expect(list[1]).toBe(testModuleB)
      expect(list[2]).toBe(testModuleC)
    })
  })

  // -------------------------------------------------------------------------
  // findByCapability()
  // -------------------------------------------------------------------------
  describe('findByCapability()', () => {
    it('returns every module that exposes the capability', () => {
      const testModuleA = makeModule('course', ['createCourse', 'exportCourse'])
      const testModuleB = makeModule('presentation', ['createSlides'])
      // A second module that also exposes 'createCourse' (overlap).
      const testModuleC = makeModule('course-v2', ['createCourse'])
      registry.register(testModuleA)
      registry.register(testModuleB)
      registry.register(testModuleC)

      const matches = registry.findByCapability('createCourse')
      expect(matches.length).toBe(2)
      expect(matches).toContain(testModuleA)
      expect(matches).toContain(testModuleC)
    })

    it('returns an empty array when no module exposes the capability', () => {
      const testModule = makeModule('course', ['createCourse'])
      registry.register(testModule)
      expect(registry.findByCapability('createQuiz')).toEqual([])
    })

    it('returns an empty array when the registry is empty', () => {
      expect(registry.findByCapability('createCourse')).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // listCapabilities()
  // -------------------------------------------------------------------------
  describe('listCapabilities()', () => {
    it('returns de-duplicated capability names across modules', () => {
      const testModuleA = makeModule('course', ['createCourse', 'exportCourse'])
      const testModuleB = makeModule('course-v2', ['createCourse', 'generateCourse'])
      registry.register(testModuleA)
      registry.register(testModuleB)
      const caps = registry.listCapabilities()
      // 'createCourse' appears in both but should appear once in the output.
      expect(caps).toContain('createCourse')
      expect(caps).toContain('exportCourse')
      expect(caps).toContain('generateCourse')
      const deDuped = new Set(caps)
      expect(deDuped.size).toBe(caps.length)
    })

    it('returns an empty array when the registry is empty', () => {
      expect(registry.listCapabilities()).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // listIds() + clear()
  // -------------------------------------------------------------------------
  describe('listIds() + clear()', () => {
    it('listIds() returns every registered id in insertion order', () => {
      registry.register(makeModule('course', ['createCourse']))
      registry.register(makeModule('quiz', ['createQuiz']))
      expect(registry.listIds()).toEqual(['course', 'quiz'])
    })

    it('clear() empties the registry', () => {
      registry.register(makeModule('course', ['createCourse']))
      registry.register(makeModule('quiz', ['createQuiz']))
      registry.clear()
      expect(registry.list().length).toBe(0)
      expect(registry.listCapabilities().length).toBe(0)
      expect(registry.listIds().length).toBe(0)
    })
  })
})
