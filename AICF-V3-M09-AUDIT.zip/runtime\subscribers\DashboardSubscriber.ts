// =============================================================================
// AICF V3 — DashboardSubscriber (Sprint 22)
// =============================================================================
// Forwards EDA events to a live dashboard cache backed by a fixed-size ring
// buffer. The buffer overwrites the oldest entry when full — it never grows
// unbounded, so memory usage is constant regardless of how many events the
// runtime emits over its lifetime.
//
// Sprint 22 (this file) replaces the Sprint 21 stub with a real
// ring-buffer-backed implementation:
//   - onEvent(event) — O(1) push, no allocations beyond the single slot write.
//   - getRecentEvents(limit?) — returns the most recent N events in
//     chronological order (oldest first). O(limit).
//   - getEventCount() — total events received since the subscriber was
//     created (monotonically increasing; NOT the buffer size).
//
// All side-effects are best-effort: onEvent() never throws.
// =============================================================================

import type { RuntimeEventEnvelope } from '../events/EventMetadata'
import { logger } from '@/lib/ai/logger'
import type { EventSubscriber } from './AuditSubscriber'

/** Default ring-buffer capacity (entries). */
const DEFAULT_MAX_EVENTS = 1000

/**
 * Dashboard subscriber — keeps the most recent N EDA events in a fixed-size
 * ring buffer for live dashboards / polling consumers.
 *
 * The buffer is allocated once at construction time. `onEvent()` is O(1):
 * it writes the event into the slot at the current write cursor, advances
 * the cursor (wrapping at capacity), and increments the total-events
 * counter. No allocations happen on the hot path.
 *
 * When the buffer is full, the oldest entry is overwritten — total memory
 * is bounded by `capacity * sizeof(envelope)` for the lifetime of the
 * subscriber.
 */
export class DashboardSubscriber implements EventSubscriber {
  readonly name = 'dashboard-subscriber'
  private ready = false

  /** Fixed-size ring buffer. Entries are `undefined` until first written. */
  private readonly buffer: Array<RuntimeEventEnvelope<unknown> | undefined>

  /** Maximum number of entries the buffer can hold. */
  private readonly capacity: number

  /** Next write position (always in [0, capacity)). */
  private writeCursor = 0

  /** Number of slots currently filled (capped at capacity). */
  private filled = 0

  /** Total events received since construction (monotonically increasing). */
  private totalEvents = 0

  constructor(maxEvents: number = DEFAULT_MAX_EVENTS) {
    // Defensive: enforce a positive integer capacity. A non-positive value
    // would break the modulo arithmetic; clamp to 1.
    const safeCap = Number.isInteger(maxEvents) && maxEvents > 0 ? maxEvents : DEFAULT_MAX_EVENTS
    this.capacity = safeCap
    this.buffer = new Array<RuntimeEventEnvelope<unknown> | undefined>(safeCap)
  }

  /**
   * Initializes the subscriber. Flips the ready flag.
   */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug(
      { subscriber: this.name, capacity: this.capacity },
      'DashboardSubscriber: initialized',
    )
  }

  isReady(): boolean {
    return this.ready
  }

  async onEvent(event: RuntimeEventEnvelope<unknown>): Promise<void> {
    try {
      // O(1) write — no allocation on the hot path.
      this.buffer[this.writeCursor] = event
      this.writeCursor = (this.writeCursor + 1) % this.capacity
      if (this.filled < this.capacity) {
        this.filled += 1
      }
      this.totalEvents += 1
    } catch (err) {
      logger.error(
        {
          subscriber: this.name,
          eventId: event.metadata.eventId,
          error: err instanceof Error ? err.message : String(err),
        },
        'DashboardSubscriber: onEvent failed (swallowed)',
      )
    }
  }

  /**
   * Returns the most recent N events in chronological order (oldest first).
   *
   * When `limit` is omitted, returns every event currently in the buffer.
   * When `limit` exceeds the number of stored events, returns all stored
   * events. When `limit <= 0`, returns an empty array.
   *
   * The returned array is a fresh allocation — mutating it does not affect
   * the subscriber's internal state.
   *
   * Implementation note: the slice is the `max` events ENDING at the most
   * recent write. The most recent event lives at slot
   * `(writeCursor - 1 + capacity) % capacity`, so the oldest event in the
   * returned slice lives `max` slots before that — i.e., at
   * `(writeCursor - max + capacity) % capacity`. This single formula works
   * for both the wrapped (filled === capacity) and non-wrapped
   * (filled < capacity) cases, so there is no branch on the hot path.
   */
  getRecentEvents(limit?: number): RuntimeEventEnvelope<unknown>[] {
    const max = Math.max(0, Math.min(limit ?? this.filled, this.filled))
    if (max === 0) return []

    const result: RuntimeEventEnvelope<unknown>[] = new Array(max)
    // The oldest entry in the returned slice — see implementation note above.
    const startIdx = (this.writeCursor - max + this.capacity) % this.capacity

    for (let i = 0; i < max; i++) {
      const bufferIdx = (startIdx + i) % this.capacity
      const entry = this.buffer[bufferIdx]
      if (entry !== undefined) {
        result[i] = entry
      }
    }
    return result
  }

  /**
   * Returns the total number of events received since the subscriber was
   * created. This is monotonically increasing and may exceed the buffer
   * capacity — overwritten events are still counted.
   */
  getEventCount(): number {
    return this.totalEvents
  }
}

/**
 * Factory: creates a DashboardSubscriber with the given capacity (default
 * 1000 entries).
 *
 * @example
 * const sub = createDashboardSubscriber(500)
 * await sub.initialize()
 */
export function createDashboardSubscriber(maxEvents?: number): DashboardSubscriber {
  return new DashboardSubscriber(maxEvents)
}
