// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — RuntimeRecovery Tests
// =============================================================================
// Tests for RuntimeRecovery. Verifies that recover() lists pending
// executions and resumes them, that recoverExecution(id) recovers a single
// execution, that getRecoveryReport() returns the last report, that
// terminal executions are skipped, and that one failure does not abort
// recovery of other executions.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeRecovery } from '../recovery/RuntimeRecovery'
import { InMemoryEventBus } from '../events/EventBus'
import { InMemoryWorkflowStateStore } from '../state/WorkflowStateStore'
import type { RecoveryEngine } from '../recovery/RuntimeRecovery'
import type { IEventBus } from '@/lib/runtime/interfaces'
import type { WorkflowExecution } from '@/lib/runtime/contracts/workflow'
import { createPendingExecution } from '@/lib/runtime/contracts/workflow'

/** Mock engine that records resume() calls and can be configured to fail. */
class MockRecoveryEngine implements RecoveryEngine {
  resumeCalls: string[] = []
  // Set of execution ids that should throw on resume.
  failFor: Set<string> = new Set()

  async resume(executionId: string): Promise<unknown> {
    this.resumeCalls.push(executionId)
    if (this.failFor.has(executionId)) {
      throw new Error(`resume failed for ${executionId}`)
    }
    return { executionId }
  }
}

/** Build an execution envelope with a specific status. */
function makeExecution(
  id: string,
  status: WorkflowExecution['status'],
): WorkflowExecution {
  const exec = createPendingExecution(
    'wf-test',
    '1.0.0',
    {},
    `corr-${id}`,
    false,
    [],
  )
  exec.executionId = id
  exec.status = status
  return exec
}

describe('RuntimeRecovery', () => {
  let stateStore: InMemoryWorkflowStateStore
  let eventBus: IEventBus
  let engine: MockRecoveryEngine
  let recovery: RuntimeRecovery

  beforeEach(() => {
    stateStore = new InMemoryWorkflowStateStore()
    eventBus = new InMemoryEventBus()
    engine = new MockRecoveryEngine()
    recovery = new RuntimeRecovery(stateStore, engine, eventBus)
  })

  it('recover() lists pending executions and attempts to resume them', async () => {
    await stateStore.saveExecution(makeExecution('e-1', 'pending'))
    await stateStore.saveExecution(makeExecution('e-2', 'running'))
    await stateStore.saveExecution(makeExecution('e-3', 'paused'))
    await stateStore.saveExecution(makeExecution('e-done', 'completed'))

    const result = await recovery.recover()
    expect(result.recovered.sort()).toEqual(['e-1', 'e-2', 'e-3'])
    expect(result.failed).toEqual([])
    // All three pending executions should have had resume() called.
    expect(engine.resumeCalls.length).toBe(3)
    expect(engine.resumeCalls.sort()).toEqual(['e-1', 'e-2', 'e-3'])
  })

  it('recoverExecution(id) recovers a single execution and emits workflow.resumed', async () => {
    await stateStore.saveExecution(makeExecution('e-1', 'paused'))
    const resumedEvents: string[] = []
    eventBus.subscribe('workflow.resumed', (e) => { resumedEvents.push(e.executionId ?? '') })

    const ok = await recovery.recoverExecution('e-1')
    expect(ok).toBe(true)
    expect(engine.resumeCalls).toEqual(['e-1'])
    expect(resumedEvents).toEqual(['e-1'])
  })

  it('getRecoveryReport() returns the last report (empty before first run)', async () => {
    // Before any recover() call, the report is empty.
    const before = recovery.getRecoveryReport()
    expect(before.timestamp).toBe(0)
    expect(before.recovered).toEqual([])
    expect(before.failed).toEqual([])

    await stateStore.saveExecution(makeExecution('e-1', 'pending'))
    await recovery.recover()
    const after = recovery.getRecoveryReport()
    expect(after.timestamp).toBeGreaterThan(0)
    expect(after.recovered).toEqual(['e-1'])
    expect(after.failed).toEqual([])
  })

  it('already-terminal executions are skipped', async () => {
    await stateStore.saveExecution(makeExecution('e-done', 'completed'))
    await stateStore.saveExecution(makeExecution('e-failed', 'failed'))
    await stateStore.saveExecution(makeExecution('e-cancel', 'cancelled'))
    const ok = await recovery.recoverExecution('e-done')
    expect(ok).toBe(false)
    expect(engine.resumeCalls.length).toBe(0)
  })

  it('recovery failure in one execution does NOT stop others', async () => {
    await stateStore.saveExecution(makeExecution('e-good-1', 'pending'))
    await stateStore.saveExecution(makeExecution('e-bad', 'running'))
    await stateStore.saveExecution(makeExecution('e-good-2', 'paused'))
    engine.failFor.add('e-bad')

    const result = await recovery.recover()
    expect(result.recovered.length).toBe(2)
    expect(result.recovered).toContain('e-good-1')
    expect(result.recovered).toContain('e-good-2')
    expect(result.failed).toEqual(['e-bad'])
    expect(engine.resumeCalls.length).toBe(3)

    // The report should contain the failure detail.
    const report = recovery.getRecoveryReport()
    expect(report.failed.length).toBe(1)
    expect(report.failed[0].executionId).toBe('e-bad')
    expect(report.failed[0].error).toContain('resume failed')
  })

  it('recoverExecution returns false for unknown id', async () => {
    const ok = await recovery.recoverExecution('does-not-exist')
    expect(ok).toBe(false)
  })
})
