// =============================================================================
// AICF V3 — Shared Builders (Épica 2 — AI Factory Core, B9)
// =============================================================================
// Convenience builders that construct a JobRequest + BusinessContext from
// the common "topic + options" shape used by every content-generation job.
//
// These exist so API handlers don't repeat the same shape-assembly boilerplate.
// They DO NOT validate input — callers should run the matching validator
// from `shared/validators.ts` first.
//
// No `any`.
// =============================================================================

import type { JobRequest, JobType } from '../contracts/JobRequest'
import { createJobRequest } from '../contracts/JobRequest'
import type { BusinessContext } from '../contracts/BusinessContext'
import { createBusinessContext } from '../contracts/BusinessContext'

/**
 * Options accepted by `buildJobRequest()`. All optional — every field is
 * placed into the JobRequest.input or JobRequest.metadata bag as
 * appropriate.
 */
export interface BuildJobRequestOptions {
  level?: string
  modules?: number
  format?: string
  language?: string
  audience?: string
  /** Optional override for the job's metadata bag. */
  metadata?: JobRequest['metadata']
}

/**
 * Builds a JobRequest from a jobType + topic + optional shape knobs.
 *
 * The `topic` is always placed into `input.topic`. The other optional
 * fields are placed into `input` only when provided, so callers can
 * distinguish "absent" from "explicitly set to undefined".
 *
 * @example
 * const req = buildJobRequest('createCourse', 'Intro to Rust', {
 *   level: 'beginner',
 *   modules: 5,
 *   language: 'en',
 * })
 */
export function buildJobRequest(
  jobType: JobType,
  topic: string,
  opts?: BuildJobRequestOptions,
): JobRequest {
  const input: Record<string, unknown> = { topic }
  if (opts?.level !== undefined) input.level = opts.level
  if (opts?.modules !== undefined) input.modules = opts.modules
  if (opts?.format !== undefined) input.format = opts.format
  if (opts?.language !== undefined) input.language = opts.language
  if (opts?.audience !== undefined) input.audience = opts.audience

  return createJobRequest(jobType, input, opts?.metadata)
}

/**
 * Builds a BusinessContext from a jobId + optional user/locale. Mirrors
 * `createBusinessContext()` but is exported here so callers can build both
 * the request + the context from the same `business/shared` barrel.
 *
 * @example
 * const ctx = buildBusinessContext(req.jobId, { userId: 'u-1', locale: 'en' })
 */
export function buildBusinessContext(
  jobId: string,
  opts?: { userId?: string; locale?: string },
): BusinessContext {
  return createBusinessContext({
    jobId,
    userId: opts?.userId,
    locale: opts?.locale,
  })
}
