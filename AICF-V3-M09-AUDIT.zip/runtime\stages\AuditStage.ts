// =============================================================================
// AICF V3 — Sprint 2 — Audit Stage
// =============================================================================
// Records the request/response in the audit trail (best-effort).
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'

export function createAuditStage(): PipelineStage {
  return createPipelineStage('Audit', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    ctx.response.stages = [...(ctx.response.stages ?? []), 'Audit']
    return ctx
  })
}
