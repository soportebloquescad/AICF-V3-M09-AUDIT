// =============================================================================
// AICF V3 — Épica 6 — Course Artifact Registry
// =============================================================================
import { createHash } from 'node:crypto'
import { logger } from '@/lib/ai/logger'

export type CourseArtifactType = 'course' | 'presentation' | 'quiz' | 'workbook' | 'teacher-guide' | 'student-guide' | 'manifest' | 'quality-score' | 'knowledge-sources' | 'zip'
export type CourseArtifactFormat = 'markdown' | 'html' | 'json' | 'zip' | 'pdf' | 'pptx'

export interface CourseArtifact {
  artifactId: string
  projectId: string
  jobId: string
  type: CourseArtifactType
  format: CourseArtifactFormat
  name: string
  content: Buffer
  sha256: string
  sizeBytes: number
  createdAt: string
}

class CourseArtifactRegistryImpl {
  private readonly artifacts = new Map<string, CourseArtifact>()

  async register(input: { projectId: string; jobId: string; type: CourseArtifactType; format: CourseArtifactFormat; name: string; content: Buffer | string }): Promise<CourseArtifact> {
    const content = typeof input.content === 'string' ? Buffer.from(input.content, 'utf-8') : input.content
    const sha256 = createHash('sha256').update(content).digest('hex')
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const artifactId = `art-${ts}-${rand}`
    const artifact: CourseArtifact = { artifactId, projectId: input.projectId, jobId: input.jobId, type: input.type, format: input.format, name: input.name, content, sha256, sizeBytes: content.byteLength, createdAt: new Date().toISOString() }
    this.artifacts.set(`${input.projectId}:${artifactId}`, artifact)
    logger.info({ artifactId, projectId: input.projectId, type: input.type, sizeBytes: content.byteLength }, 'CourseArtifactRegistry: registered')
    return artifact
  }

  async get(projectId: string, artifactId: string): Promise<CourseArtifact | null> { return this.artifacts.get(`${projectId}:${artifactId}`) ?? null }
  async listByProject(projectId: string): Promise<CourseArtifact[]> { return Array.from(this.artifacts.values()).filter((a) => a.projectId === projectId) }
  async listByJob(jobId: string): Promise<CourseArtifact[]> { return Array.from(this.artifacts.values()).filter((a) => a.jobId === jobId) }
  async delete(projectId: string, artifactId: string): Promise<boolean> { return this.artifacts.delete(`${projectId}:${artifactId}`) }
  async clear(): Promise<void> { this.artifacts.clear() }
  async size(): Promise<number> { return this.artifacts.size }
}

export const CourseArtifactRegistry = new CourseArtifactRegistryImpl()
