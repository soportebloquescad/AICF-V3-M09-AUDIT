// =============================================================================
// AICF V3 — GET /runtime/models
// =============================================================================
// Épica 1 — Stabilization (H2): uses getRuntimeService() singleton instead of
// `new RuntimeService()` so the Infrastructure module (M18) is available to
// serve the models list. Previously this route created a fresh RuntimeService
// per request with no modules registered, returning an empty stages list
// instead of actual models.
// =============================================================================

import { NextResponse } from 'next/server'
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  const reqLogger = logger.child({ endpoint: '/runtime/models', method: 'GET' })

  const runtimeRequest = createRuntimeRequest({ operation: 'models' })
  const service = await getRuntimeService()
  if (!service) {
    return NextResponse.json({ error: 'Runtime not initialized' }, { status: 503 })
  }
  const response = await service.execute(runtimeRequest)

  reqLogger.info({ requestId: response.requestId, ok: response.ok, modelCount: response.models?.length || 0 }, 'Runtime models retrieved')

  return NextResponse.json(response, { status: response.ok ? 200 : 500 })
}
