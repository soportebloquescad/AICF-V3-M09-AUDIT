import { PrismaClient } from '@prisma/client'

// =============================================================================
// AICF V3 — Prisma Client (PostgreSQL)
// Mission 23: Platform Environment Integration & Production Readiness
// =============================================================================
// Singleton PrismaClient for the AICF platform.
// Uses PostgreSQL exclusively — no SQLite references.
// =============================================================================

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
