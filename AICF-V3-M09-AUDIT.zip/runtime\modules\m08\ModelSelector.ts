// =============================================================================
// AICF V3 — M08 Content Intelligence — ModelSelector
// =============================================================================
// The ModelSelector holds metadata about every registered model and selects
// the most appropriate model for a given (provider, policy, task) tuple.
//
// Selection rules:
//   - Filter to models belonging to the requested provider.
//   - For 'fast' tasks: prefer models flagged `fast === true`.
//   - Clamp the policy temperature to the model's allowed range.
//   - Clamp the policy maxTokens to the model's `maxOutputTokens` limit.
// =============================================================================

import type { PolicyDefinition } from './PolicyEngine'
import { logger } from '@/lib/ai/logger'

/**
 * Task hint used by the model selector to pick a model variant.
 */
export type ModelTask = 'chat' | 'generation' | 'research' | 'long-form' | 'code' | 'vision'

/**
 * Static metadata about a single model. Does not include secrets — the
 * actual API key is loaded by the AIAdapter at execution time.
 */
export interface ModelMetadata {
  /** Model id (unique within the selector). */
  id: string
  /** Provider name this model belongs to. */
  provider: string
  /** Human-readable label. */
  label: string
  /** Maximum context window in tokens (input + output). */
  contextWindow: number
  /** Maximum output tokens the model can generate in a single call. */
  maxOutputTokens: number
  /** Whether this is a premium / frontier model. */
  premium: boolean
  /** Whether this model is optimized for low-cost economy workloads. */
  economy: boolean
  /** Whether this model is optimized for fast inference (low latency). */
  fast: boolean
  /** Tasks this model is well-suited for. */
  tasks: ModelTask[]
}

/**
 * Result returned by `ModelSelector.select()`.
 */
export interface ModelSelectionResult {
  /** The selected model. */
  model: ModelMetadata
  /** Human-readable reason for the selection. */
  reason: string
  /** Temperature to use (clamped to the policy range). */
  temperature: number
  /** Top-p value to use (from the policy). */
  topP: number
  /** Max tokens to use (clamped to the model's limit). */
  maxTokens: number
  /** Stop sequences (passed through from the request, if any). */
  stop: string[]
  /** Estimated total token consumption for a typical request. */
  estimatedTokens: number
}

/**
 * The 4 default models. Registered in `registerDefaults()`.
 */
const DEFAULT_MODELS: ModelMetadata[] = [
  {
    id: 'groq-llama-3.3-70b',
    provider: 'groq',
    label: 'Llama 3.3 70B (Groq LPU)',
    contextWindow: 32768,
    maxOutputTokens: 8192,
    premium: false,
    economy: true,
    fast: true,
    tasks: ['chat', 'generation'],
  },
  {
    id: 'gemini-2.0-flash',
    provider: 'gemini',
    label: 'Gemini 2.0 Flash',
    contextWindow: 1048576,
    maxOutputTokens: 8192,
    premium: true,
    economy: false,
    fast: true,
    tasks: ['chat', 'generation', 'vision', 'long-form'],
  },
  {
    id: 'gemini-2.5-pro',
    provider: 'gemini',
    label: 'Gemini 2.5 Pro',
    contextWindow: 2097152,
    maxOutputTokens: 8192,
    premium: true,
    economy: false,
    fast: false,
    tasks: ['chat', 'generation', 'research', 'long-form', 'vision'],
  },
  {
    id: 'openrouter-auto',
    provider: 'openrouter',
    label: 'OpenRouter Auto',
    contextWindow: 131072,
    maxOutputTokens: 16384,
    premium: true,
    economy: false,
    fast: true,
    tasks: ['chat', 'generation', 'code'],
  },
]

/**
 * The ModelSelector. Holds a registry of model metadata and selects the
 * most appropriate model for a given (provider, policy, task) tuple.
 */
export class ModelSelector {
  private readonly models = new Map<string, ModelMetadata>()

  constructor(registerDefaults = true) {
    if (registerDefaults) {
      this.registerDefaults()
    }
  }

  /**
   * Register the 4 default models.
   */
  registerDefaults(): void {
    for (const m of DEFAULT_MODELS) {
      this.models.set(m.id, m)
    }
    logger.debug(
      { count: this.models.size, ids: this.list().map((m) => m.id) },
      'ModelSelector: default models registered',
    )
  }

  /**
   * Register a custom model. Overwrites any existing model with the same id.
   */
  register(model: ModelMetadata): void {
    this.models.set(model.id, model)
    logger.info({ model: model.id, provider: model.provider }, 'ModelSelector: model registered')
  }

  /**
   * Get a model by id. Returns null if not registered.
   */
  get(id: string): ModelMetadata | null {
    return this.models.get(id) ?? null
  }

  /**
   * List all registered models.
   */
  list(): ModelMetadata[] {
    return Array.from(this.models.values())
  }

  /**
   * List models belonging to a specific provider.
   */
  listByProvider(provider: string): ModelMetadata[] {
    return this.list().filter((m) => m.provider === provider)
  }

  /**
   * Select the best model for the given (provider, policy, task) tuple.
   *
   * Algorithm:
   *   1. Filter to models belonging to the requested provider.
   *   2. If no models for that provider, fall back to all models.
   *   3. Prefer models matching the requested task.
   *   4. For 'fast' policy mode: prefer fast models.
   *   5. Sort by preference: matching task > premium > fast > economy.
   *   6. Pick the first one.
   *   7. Clamp temperature to the policy range and maxTokens to the model limit.
   */
  select(provider: string, policy: PolicyDefinition, task?: ModelTask): ModelSelectionResult | null {
    let candidates = this.listByProvider(provider)
    if (candidates.length === 0) {
      logger.warn(
        { provider, fallback: 'all-providers' },
        'ModelSelector: no models for provider, falling back to all providers',
      )
      candidates = this.list()
    }
    if (candidates.length === 0) {
      logger.warn({ provider }, 'ModelSelector: no models registered')
      return null
    }

    // Prefer models matching the task.
    let preferred = task ? candidates.filter((m) => m.tasks.includes(task)) : []
    let reason: string
    if (preferred.length === 0) {
      preferred = candidates
      reason = `no model matches task "${task ?? 'none'}", using first model for provider "${provider}"`
    } else {
      reason = `model matches task "${task}"`
    }

    // For 'fast' policy mode, prefer fast models.
    if (policy.mode === 'fast') {
      const fast = preferred.filter((m) => m.fast)
      if (fast.length > 0) {
        preferred = fast
        reason += ' (fast preferred)'
      }
    }

    // Sort: premium models first for premium/deep-research, economy first for economy mode.
    const mode = policy.mode
    preferred.sort((a, b) => {
      if (mode === 'economy') {
        if (a.economy !== b.economy) return a.economy ? -1 : 1
      } else if (mode === 'premium' || mode === 'deep-research') {
        if (a.premium !== b.premium) return a.premium ? -1 : 1
      }
      if (a.fast !== b.fast) return a.fast ? -1 : 1
      return 0
    })

    const model = preferred[0]!

    // Clamp temperature and maxTokens.
    const temperature = clamp(
      policy.defaultTemperature,
      policy.temperatureRange.min,
      policy.temperatureRange.max,
    )
    const maxTokens = Math.min(policy.defaultMaxTokens, model.maxOutputTokens, policy.maxTokensLimit)
    const estimatedTokens = Math.min(
      model.contextWindow,
      maxTokens + Math.floor(maxTokens * 0.5),
    )

    logger.debug(
      {
        provider,
        model: model.id,
        task: task ?? null,
        temperature,
        maxTokens,
        reason,
      },
      'ModelSelector: model selected',
    )

    return {
      model,
      reason,
      temperature,
      topP: policy.defaultTopP,
      maxTokens,
      stop: [],
      estimatedTokens,
    }
  }
}

function clamp(value: number, min: number, max: number): number {
  if (value < min) return min
  if (value > max) return max
  return value
}

/**
 * Singleton ModelSelector with default models pre-registered.
 */
let singleton: ModelSelector | null = null

export function getModelSelector(): ModelSelector {
  if (!singleton) {
    singleton = new ModelSelector(true)
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetModelSelector(): void {
  singleton = null
}
