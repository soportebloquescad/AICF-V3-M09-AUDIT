// =============================================================================
// AICF V3 — Sprint 8 RC54 — StoryboardEngine
// =============================================================================
// Converts CourseResult content into a structured storyboard of slides.
// REUSES: CourseResult, Lesson, Module from CourseContracts.
// =============================================================================

import type { CourseResult } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

export type SlideType = 'cover' | 'toc' | 'module-intro' | 'lesson' | 'exercise' | 'quiz' | 'diagram' | 'summary' | 'resources'

export interface StoryboardSlide {
  index: number
  type: SlideType
  title: string
  subtitle: string
  content: string
  layout: 'full' | 'split-left' | 'split-right' | 'centered' | 'image-focus'
  imagePrompt: string | null
  mermaidDiagram: string | null
  speakerNotes: string
  interactiveElements: string[]
}

export interface Storyboard {
  courseId: string
  title: string
  totalSlides: number
  slides: StoryboardSlide[]
}

export class StoryboardEngine {
  private readonly log = logger.child({ component: 'StoryboardEngine' })

  build(course: CourseResult): Storyboard {
    this.log.info({ courseId: course.id }, 'StoryboardEngine: building storyboard')
    const slides: StoryboardSlide[] = []
    let idx = 0

    // Cover slide
    slides.push({
      index: idx++, type: 'cover', title: course.title, subtitle: course.description,
      content: `Modules: ${course.modules.length} | Lessons: ${course.lessons.length} | Words: ${course.totalWordCount}`,
      layout: 'centered', imagePrompt: `Professional hero image for "${course.title}"`, mermaidDiagram: null,
      speakerNotes: `Welcome to ${course.title}. This course covers ${course.description.slice(0, 100)}.`,
      interactiveElements: [],
    })

    // TOC slide
    slides.push({
      index: idx++, type: 'toc', title: 'Course Overview', subtitle: 'What you will learn',
      content: course.modules.map((m, i) => `${i + 1}. ${m.title}`).join('\n'),
      layout: 'full', imagePrompt: null, mermaidDiagram: this.courseStructureMermaid(course),
      speakerNotes: 'Let\'s walk through what we\'ll cover in this course.',
      interactiveElements: ['navigation-links'],
    })

    // Per-module slides
    for (const mod of course.modules) {
      // Module intro
      slides.push({
        index: idx++, type: 'module-intro', title: mod.title, subtitle: mod.summary,
        content: mod.learningOutcomes.map(o => `• ${o}`).join('\n'),
        layout: 'split-left', imagePrompt: `Concept image for module: ${mod.title}`,
        mermaidDiagram: null,
        speakerNotes: `In this module, we explore ${mod.title}. ${mod.summary}`,
        interactiveElements: ['progress-indicator'],
      })

      const modLessons = course.lessons.filter(l => l.moduleId === mod.id)
      for (const lesson of modLessons) {
        // Lesson slide
        slides.push({
          index: idx++, type: 'lesson', title: lesson.title, subtitle: `${lesson.durationMinutes} min | Bloom: ${lesson.bloomLevel}`,
          content: this.extractKeyContent(lesson.content),
          layout: 'split-right', imagePrompt: `Illustration for: ${lesson.title}`,
          mermaidDiagram: this.lessonMermaid(lesson.title, lesson.keyTakeaways),
          speakerNotes: `Key points: ${lesson.learningObjectives.slice(0, 3).join('; ')}`,
          interactiveElements: ['accordion-objectives', 'tabs-content'],
        })
      }

      // Exercises for this module
      const modExercises = course.exercises.filter(e => modLessons.some(l => l.id === e.lessonId))
      if (modExercises.length > 0) {
        slides.push({
          index: idx++, type: 'exercise', title: `Practice: ${mod.title}`, subtitle: `${modExercises.length} exercises`,
          content: modExercises.map(e => `📝 ${e.question}`).join('\n\n'),
          layout: 'full', imagePrompt: null, mermaidDiagram: null,
          speakerNotes: 'Guide students through these exercises. Encourage peer discussion.',
          interactiveElements: ['accordion-hints', 'reveal-answer'],
        })
      }

      // Quiz for this module
      const quiz = course.quizzes.find(q => q.moduleId === mod.id)
      if (quiz) {
        slides.push({
          index: idx++, type: 'quiz', title: quiz.title, subtitle: quiz.description,
          content: quiz.questions.map((q, i) => `Q${i + 1}: ${q.question}`).join('\n\n'),
          layout: 'centered', imagePrompt: null, mermaidDiagram: null,
          speakerNotes: `Passing score: ${quiz.passingScore}%. Allow ${quiz.durationMinutes} minutes.`,
          interactiveElements: ['quiz-interactive', 'feedback-reveal'],
        })
      }
    }

    // Summary slide
    slides.push({
      index: idx++, type: 'summary', title: 'Course Summary', subtitle: 'What you\'ve learned',
      content: `You completed ${course.modules.length} modules with ${course.lessons.length} lessons totaling ${course.totalWordCount} words.`,
      layout: 'centered', imagePrompt: 'Celebration / achievement image', mermaidDiagram: null,
      speakerNotes: 'Congratulations on completing the course. Review key takeaways and apply them.',
      interactiveElements: ['achievement-display'],
    })

    // Resources slide
    slides.push({
      index: idx++, type: 'resources', title: 'Additional Resources', subtitle: 'Keep learning',
      content: '• Course ZIP download\n• Interactive HTML version\n• Teacher Pack\n• Student Guide',
      layout: 'full', imagePrompt: null, mermaidDiagram: null,
      speakerNotes: 'All resources are available for download. The HTML version works offline.',
      interactiveElements: ['download-buttons'],
    })

    return { courseId: course.id, title: course.title, totalSlides: slides.length, slides }
  }

  private extractKeyContent(content: string): string {
    const lines = content.split('\n').filter(l => l.trim())
    const keyLines = lines.filter(l => /^#+\s|^>\s|^\d+\./.test(l)).slice(0, 8)
    return keyLines.join('\n') || content.slice(0, 500)
  }

  private courseStructureMermaid(course: CourseResult): string {
    return `graph TD\n  Root[${course.title}]\n${course.modules.map((m, i) => `  Root --> M${i}[${m.title}]`).join('\n')}`
  }

  private lessonMermaid(title: string, takeaways: string[]): string {
    if (takeaways.length === 0) return ''
    return `graph LR\n  L[${title}]\n${takeaways.slice(0, 3).map((t, i) => `  L --> T${i}[${t.slice(0, 30)}]`).join('\n')}`
  }
}
