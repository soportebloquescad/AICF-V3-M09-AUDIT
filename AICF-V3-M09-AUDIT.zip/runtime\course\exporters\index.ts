// =============================================================================
// AICF V3 — Exporters barrel (Epic 6 — Exporters)
// =============================================================================
// Re-exports every public exporter so callers can import them from a single
// entry point:
//
//   import { HTMLExporter, PDFExporter } from '@/lib/runtime/course/exporters'
//
// The shared Markdown-to-HTML transformer is also re-exported because the
// HTML/DOCX/PDF exporters share the same Markdown vocabulary and downstream
// callers (e.g. test fixtures) may want to verify a fragment directly.
// =============================================================================

export { HTMLExporter } from './HTMLExporter'
export type { HtmlExportMetadata } from './HTMLExporter'

export { DOCXExporter } from './DOCXExporter'
export type { DocxExportMetadata, DocxPageSetup } from './DOCXExporter'

export { PDFExporter } from './PDFExporter'
export type { PdfExportMetadata, PdfPageSetup } from './PDFExporter'

export { PPTXExporter } from './PPTXExporter'
export type { PptxExportMetadata, PptxSlide } from './PPTXExporter'

export { SCORMExporter } from './SCORMExporter'
export type { ScormExportMetadata, ScormVersion, ScormItem } from './SCORMExporter'

export { MoodleExporter } from './MoodleExporter'
export type { MoodleExportMetadata, MoodleActivity } from './MoodleExporter'

export { markdownToHtml, markdownToSlides, escapeHtml } from './markdownToHtml'
export type { MarkdownSlide } from './markdownToHtml'
