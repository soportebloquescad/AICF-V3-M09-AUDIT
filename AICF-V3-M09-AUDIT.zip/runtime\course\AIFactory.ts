// =============================================================================
// AICF V3 — Epica 8 — AI Factory
// =============================================================================
// Top-level facade for course generation. Wires the EngineRegistry, registers
// all 19 Epica 7+8 engines, and exposes generateCourse / resumeCourse /
// regenerateStage / health.
// =============================================================================
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import { engineRegistry, type EngineRegistry, type RegistryHealth } from './EngineRegistry'
import type { HealthStatus } from './EngineContract'
import { CourseOrchestrator, type OrchestratorStage } from './CourseOrchestrator'
import { registerCourseEngines } from './RuntimeEngineRegistration'
import type { CourseRequest, CourseResult, StageResult } from './CourseContracts'
import { auditTrail } from './AuditTrail'
import { costEngine } from './CostEngine'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

function nowIso(): string {
  return new Date().toISOString()
}

export interface AIFactoryOpts {
  aiAdapter: AIAdapter | null
  registry?: EngineRegistry
}

export interface GenerateCourseInput {
  topic: string
  title?: string
  description?: string
  audience?: string
  level?: CourseRequest['level']
  locale?: string
  country?: string
  moduleCount?: number
  researchDepth?: CourseRequest['researchDepth']
  contentTypes?: CourseRequest['contentTypes']
  certification?: CourseRequest['certification']
  budget?: number
  mode?: CourseRequest['mode']
}

export class AIFactory {
  readonly name = 'ai-factory'
  private readonly registry: EngineRegistry
  private readonly orchestrator: CourseOrchestrator
  private readonly courses = new Map<string, CourseResult>()

  constructor(private readonly opts: AIFactoryOpts) {
    this.registry = opts.registry ?? engineRegistry
    registerCourseEngines(this.registry, opts.aiAdapter)
    this.orchestrator = new CourseOrchestrator({ aiAdapter: opts.aiAdapter, engineRegistry: this.registry })
    logger.info({ engineCount: this.registry.size() }, 'AIFactory: initialized')
  }

  async generateCourse(input: GenerateCourseInput): Promise<CourseResult> {
    const request = this.buildRequest(input)
    logger.info({ courseId: request.id, topic: request.topic }, 'AIFactory: generateCourse starting')

    auditTrail.record({
      correlationId: request.correlationId,
      courseId: request.id,
      action: 'course.create',
      actor: 'ai-factory',
      detail: `Creating course "${request.topic}" with ${request.moduleCount} modules`,
    })

    const result = await this.orchestrator.execute(request) as CourseResult
    this.courses.set(request.id, result)
    this.courses.set(result.id, result)

    const cost = costEngine.getTotal(request.correlationId)
    logger.info({ courseId: result.id, status: result.status, cost: cost.cost, tokens: cost.tokens }, 'AIFactory: generateCourse complete')
    return result
  }

  async resumeCourse(courseId: string): Promise<CourseResult | null> {
    const existing = this.courses.get(courseId)
    if (!existing) {
      logger.warn({ courseId }, 'AIFactory: resumeCourse — course not found')
      return null
    }
    if (existing.status === 'completed') {
      logger.info({ courseId }, 'AIFactory: resumeCourse — already complete')
      return existing
    }
    // Re-run from the last completed checkpoint
    const completedStages = existing.stages.filter((s) => s.status === 'completed').map((s) => s.stage)
    const lastStage = completedStages[completedStages.length - 1]
    logger.info({ courseId, lastStage, completedCount: completedStages.length }, 'AIFactory: resumeCourse — resuming')

    auditTrail.record({
      correlationId: existing.courseRequestId,
      courseId,
      action: 'recovery.resume',
      actor: 'ai-factory',
      detail: `Resuming from stage ${lastStage ?? 'start'}`,
    })

    // For simplicity, re-run the full course (true incremental resume would
    // require checkpoint deserialization which is handled by RecoveryManager)
    const request = this.reconstructRequest(existing)
    if (!request) return null
    const result = await this.orchestrator.execute(request) as CourseResult
    this.courses.set(courseId, result)
    return result
  }

  async regenerateStage(courseId: string, stage: string): Promise<CourseResult | null> {
    const existing = this.courses.get(courseId)
    if (!existing) {
      logger.warn({ courseId }, 'AIFactory: regenerateStage — course not found')
      return null
    }
    const stageIndex = existing.stages.findIndex((s) => s.stage === stage)
    if (stageIndex < 0) {
      logger.warn({ courseId, stage }, 'AIFactory: regenerateStage — stage not found')
      return null
    }

    auditTrail.record({
      correlationId: existing.courseRequestId,
      courseId,
      stage,
      action: 'stage.retry',
      actor: 'ai-factory',
      detail: `Regenerating stage ${stage}`,
    })

    // Re-run the full course (true single-stage regeneration would require
    // re-entering the pipeline at the specified stage with prior checkpoints)
    const request = this.reconstructRequest(existing)
    if (!request) return null
    const result = await this.orchestrator.execute(request) as CourseResult
    this.courses.set(courseId, result)
    return result
  }

  async health(): Promise<{ factory: HealthStatus; registry: RegistryHealth }> {
    const registryHealth = await this.registry.health()
    const orchestratorHealth = await this.orchestrator.health()
    return { factory: orchestratorHealth, registry: registryHealth }
  }

  getRegistry(): EngineRegistry {
    return this.registry
  }

  getOrchestrator(): CourseOrchestrator {
    return this.orchestrator
  }

  getCourse(courseId: string): CourseResult | null {
    return this.courses.get(courseId) ?? null
  }

  listCourses(): CourseResult[] {
    return Array.from(this.courses.values())
  }

  getStageResults(courseId: string): StageResult[] {
    return this.courses.get(courseId)?.stages ?? []
  }

  listStages(): readonly OrchestratorStage[] {
    return [
      'research', 'curriculum', 'modules', 'lesson-planning', 'lesson-writing',
      'exercises', 'quizzes', 'assessments', 'case-studies', 'checklists',
      'templates', 'slides', 'guides', 'quality', 'validation', 'publish', 'zip',
    ]
  }

  private buildRequest(input: GenerateCourseInput): CourseRequest {
    const now = nowIso()
    const id = makeId('req')
    const correlationId = makeId('corr')
    return {
      id,
      version: '3.0.0',
      createdAt: now,
      updatedAt: now,
      generatorVersion: '3.0.0',
      provider: 'runtime-adapter',
      model: 'deterministic-fallback',
      runtimeVersion: 'AICF-V3-RC1',
      topic: input.topic,
      title: input.title ?? input.topic,
      description: input.description ?? `A comprehensive course on ${input.topic}.`,
      audience: input.audience ?? 'general learners',
      level: input.level ?? 'intermediate',
      locale: input.locale ?? 'en-US',
      country: input.country ?? 'Global',
      moduleCount: input.moduleCount ?? 5,
      researchDepth: input.researchDepth ?? 'standard',
      contentTypes: input.contentTypes ?? ['course', 'exercises', 'quiz', 'assessment', 'presentation', 'guide'],
      certification: input.certification ?? { finalExam: true, rubrics: true, certificate: false, badges: false, finalProject: false },
      budget: input.budget ?? 1.0,
      mode: input.mode ?? 'balanced',
      correlationId,
    }
  }

  private reconstructRequest(result: CourseResult): CourseRequest | null {
    const now = nowIso()
    return {
      id: result.courseRequestId || makeId('req'),
      version: result.version,
      createdAt: result.createdAt,
      updatedAt: now,
      generatorVersion: result.generatorVersion,
      provider: result.provider,
      model: result.model,
      runtimeVersion: result.runtimeVersion,
      topic: result.topic,
      title: result.title,
      description: result.description,
      audience: result.curriculum?.audience ?? 'general learners',
      level: result.curriculum?.level ?? 'intermediate',
      locale: result.curriculum?.locale ?? 'en-US',
      country: 'Global',
      moduleCount: result.modules.length,
      researchDepth: 'standard',
      contentTypes: ['course'],
      certification: { finalExam: true, rubrics: true, certificate: false, badges: false, finalProject: false },
      budget: 1.0,
      mode: 'balanced',
      correlationId: makeId('corr'),
    }
  }
}

// Module-level singleton accessor.
// Uses globalThis to survive Turbopack dev-server module re-evaluation.
const GLOBAL_AIFACTORY_KEY = '__AICF_AIFACTORY_INSTANCE__'

export function getAIFactory(aiAdapter?: AIAdapter | null): AIFactory {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_AIFACTORY_KEY]) {
    g[GLOBAL_AIFACTORY_KEY] = new AIFactory({ aiAdapter: aiAdapter ?? null })
  }
  return g[GLOBAL_AIFACTORY_KEY] as AIFactory
}

export function resetAIFactory(): void {
  const g = globalThis as unknown as Record<string, unknown>
  g[GLOBAL_AIFACTORY_KEY] = null
}
