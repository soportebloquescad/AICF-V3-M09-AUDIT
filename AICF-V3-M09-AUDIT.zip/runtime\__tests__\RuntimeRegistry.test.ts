// =============================================================================
// AICF V3 — Runtime Registry Tests (Sprint 19: All 9 Modules Real)
// =============================================================================
// Tests for the ModuleRegistry.
//
// Sprint 19 changes:
//   - The registry constructor no longer registers ANY stubs. All 9 modules
//     (observability, localization, infrastructure, workflow,
//     content-intelligence, assets, generation, real-generation, reports)
//     are real implementations registered by RuntimeBootstrap via the
//     manifest + ModuleFactory.
//   - Registry starts empty; tests register modules explicitly via
//     `register()` or `registerWithMetadata()`.
//   - Registry supports health() aggregation + capabilities + metadata.
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { ModuleRegistry, StubModule } from '../registry/ModuleRegistry'

describe('ModuleRegistry', () => {
  it('should register ZERO modules by default (Sprint 19)', () => {
    const registry = new ModuleRegistry()
    const statuses = registry.getStatus()

    // Sprint 19: constructor no longer stubs anything. The registry starts
    // empty — modules are registered by bootstrap via the manifest.
    expect(statuses.length).toBe(0)
  })

  it('should return null for unready modules', () => {
    const registry = new ModuleRegistry()

    expect(registry.getContentIntelligence()).toBeNull()
    expect(registry.getRealGeneration()).toBeNull()
    expect(registry.getInfrastructure()).toBeNull()
    expect(registry.getWorkflow()).toBeNull()
  })

  it('should register and retrieve a real module', () => {
    const registry = new ModuleRegistry()

    const mockModule = {
      name: 'test-ci',
      version: '1.0.0',
      isReady: () => true,
      getStatus: () => ({ name: 'test-ci', ready: true, version: '1.0.0' }),
      initialize: async () => {},
      evaluatePolicy: async () => ({ allowed: true }),
      checkBudget: async () => true,
      selectProvider: async () => ({ provider: 'groq', model: 'llama-3.3' }),
    }

    registry.register('content-intelligence', mockModule as never)

    const ci = registry.getContentIntelligence()
    expect(ci).not.toBeNull()
    expect(ci?.name).toBe('test-ci')
  })

  it('should initialize all registered modules without throwing', async () => {
    const registry = new ModuleRegistry()
    // Register a couple of stubs explicitly so initializeAll has work to do.
    registry.register('localization', new StubModule('localization', '1.0.0', 'localization'))
    registry.register('assets', new StubModule('assets', '1.0.0', 'assets'))

    // Stubs don't set ready=true, but initializeAll should not throw.
    await registry.initializeAll()

    const statuses = registry.getStatus()
    expect(statuses.length).toBe(2)
    expect(statuses.every((s) => s.ready === false)).toBe(true)
  })

  it('should return health for all registered modules', async () => {
    const registry = new ModuleRegistry()
    registry.register('localization', new StubModule('localization', '1.0.0', 'localization'))
    registry.register('assets', new StubModule('assets', '1.0.0', 'assets'))
    registry.register('reports', new StubModule('reports', '1.0.0', 'reports'))

    const healths = await registry.getHealth()

    expect(healths.length).toBe(3)
    // Stubs report unhealthy (ready=false)
    expect(healths.every((h) => h.health.status === 'unhealthy')).toBe(true)
  })

  it('should allow registering workflow module (Sprint 15)', () => {
    const registry = new ModuleRegistry()

    const mockWorkflow = {
      name: 'workflow-runtime',
      version: '1.0.0',
      isReady: () => true,
      getStatus: () => ({ name: 'workflow-runtime', ready: true, version: '1.0.0' }),
      initialize: async () => {},
      health: async () => ({
        ready: true,
        status: 'healthy' as const,
        startupTime: new Date().toISOString(),
        dependencies: [],
        version: '1.0.0',
        lastInitialization: new Date().toISOString(),
      }),
    }

    registry.register('workflow', mockWorkflow as never)

    const wf = registry.getWorkflow()
    expect(wf).not.toBeNull()
  })
})
