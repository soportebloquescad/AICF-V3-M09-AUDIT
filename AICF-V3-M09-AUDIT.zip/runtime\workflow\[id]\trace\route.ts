// =============================================================================
// AICF V3 — GET /api/runtime/workflow/[id]/trace (Sprint 13+14)
// =============================================================================
// Returns the execution trace (event history) for an execution.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getWorkflowModuleBundle } from '@/lib/runtime/modules/workflow/bundle'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow/[id]/trace', method: 'GET', executionId: id })

  try {
    const bundle = getWorkflowModuleBundle()

    // Get traces from trace storage
    const traces = bundle.traceStorage.getTraces(id)

    // Also get event history from the event bus
    const events = await bundle.eventBus.getHistory(id)

    reqLogger.info({ traceCount: traces.length, eventCount: events.length }, 'Trace retrieved')
    return NextResponse.json({ executionId: id, traces, events })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to get trace',
    )
    return NextResponse.json({ error: 'Failed to get trace' }, { status: 500 })
  }
}
