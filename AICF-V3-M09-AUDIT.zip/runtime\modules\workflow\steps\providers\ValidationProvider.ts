// =============================================================================
// AICF V3 — Sprint 13+14 — Validation Provider
// =============================================================================
// Provider that fulfills the `'validate'` capability. Validates a data
// payload against a JSON-Schema-like spec (or a simple predicate). Used
// by workflow steps that gate downstream execution on data quality (e.g.
// "validate generated quiz structure before publishing").
//
// Sprint 13+14 spec requirements covered:
//   - `IProvider` interface compliance
//   - Reads `schema` / `data` from the step input
//   - Returns `output: { valid: boolean, errors: string[] }`
//   - Lightweight JSON-Schema-style field validation (required + type);
//     full JSON-Schema is out of scope
// =============================================================================

import type {
  IProvider,
  ProviderCapability,
  ProviderManifest,
  StepExecutionResult,
} from '@/lib/runtime/interfaces'
import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Minimal JSON-Schema-like shape we can validate against. */
export interface ValidationSchema {
  /** Required top-level property names. */
  required?: string[]
  /** Per-property type expectations. */
  properties?: Record<
    string,
    { type: 'string' | 'number' | 'boolean' | 'object' | 'array' }
  >
}

/**
 * Provider that validates input data against a schema. Thread-safe across
 * executions.
 */
export class ValidationProvider implements IProvider {
  readonly name = 'validate'
  readonly capabilities: ProviderCapability[] = ['validate']
  private ready = false

  /** Initialize the provider. Marks itself ready. */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug({ provider: this.name }, 'validation provider initialized')
  }

  /** Whether `initialize` has been called. */
  isReady(): boolean {
    return this.ready
  }

  /** Self-describing manifest for the registry / UI. */
  getManifest(): ProviderManifest {
    return {
      name: this.name,
      version: '1.0.0',
      capabilities: [...this.capabilities],
      config: {},
      description: 'Validates input data against a JSON-Schema-like spec',
    }
  }

  /**
   * Execute the `'validate'` capability.
   *
   * Input shape (read from `input`):
   *   - `schema`: `ValidationSchema` (required)
   *   - `data`: `Record<string, unknown>` (required)
   *
   * Output shape:
   *   - `valid`: boolean
   *   - `errors`: string[]
   */
  async execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    _ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    if (capability !== 'validate') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `validation provider cannot handle capability "${capability}"`,
      }
    }

    const start = Date.now()
    const schema = this.extractSchema(input.schema)
    const data = this.extractData(input.data)
    const errors: string[] = []

    if (!schema) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: 'input.schema is missing or malformed',
      }
    }

    if (!data) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: 'input.data is missing or not an object',
      }
    }

    // Check required fields.
    if (schema.required) {
      for (const field of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(data, field)) {
          errors.push(`missing required field: "${field}"`)
        }
      }
    }

    // Check per-property types (only for present fields).
    if (schema.properties) {
      for (const [field, spec] of Object.entries(schema.properties)) {
        if (!Object.prototype.hasOwnProperty.call(data, field)) continue
        if (!this.matchesType(data[field], spec.type)) {
          errors.push(
            `field "${field}" does not match declared type "${spec.type}"`,
          )
        }
      }
    }

    return {
      ok: true,
      output: { valid: errors.length === 0, errors },
      artifacts: [],
      durationMs: Date.now() - start,
    }
  }

  /** Coerce `raw` into a `ValidationSchema`, or `null` if malformed. */
  private extractSchema(raw: unknown): ValidationSchema | null {
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
      return null
    }
    const r = raw as Record<string, unknown>
    const out: ValidationSchema = {}
    if (Array.isArray(r.required)) {
      out.required = r.required.filter(
        (s): s is string => typeof s === 'string',
      )
    }
    if (r.properties && typeof r.properties === 'object' && !Array.isArray(r.properties)) {
      const props: ValidationSchema['properties'] = {}
      const src = r.properties as Record<string, unknown>
      for (const [k, v] of Object.entries(src)) {
        if (
          v &&
          typeof v === 'object' &&
          typeof (v as { type?: unknown }).type === 'string'
        ) {
          const t = (v as { type: string }).type
          if (
            t === 'string' ||
            t === 'number' ||
            t === 'boolean' ||
            t === 'object' ||
            t === 'array'
          ) {
            props[k] = { type: t }
          }
        }
      }
      out.properties = props
    }
    return out
  }

  /** Coerce `raw` into a `Record<string, unknown>`, or `null`. */
  private extractData(raw: unknown): Record<string, unknown> | null {
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
      return null
    }
    return raw as Record<string, unknown>
  }

  /** Runtime type matcher. */
  private matchesType(
    value: unknown,
    type: 'string' | 'number' | 'boolean' | 'object' | 'array',
  ): boolean {
    switch (type) {
      case 'string':
        return typeof value === 'string'
      case 'number':
        return typeof value === 'number'
      case 'boolean':
        return typeof value === 'boolean'
      case 'array':
        return Array.isArray(value)
      case 'object':
        return typeof value === 'object' && value !== null && !Array.isArray(value)
      default:
        return true
    }
  }
}
