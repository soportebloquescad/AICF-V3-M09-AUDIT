// =============================================================================
// AICF V3 — Epica 8 — Observability Manager
// =============================================================================
// Aggregates stage-level and course-level metrics for monitoring and
// cost analysis. Complements the CostEngine and AuditTrail by providing
// roll-up views across courses and stages.
// =============================================================================
import type { CourseResult, StageResult, Provider } from './CourseContracts'
import { costEngine, type CostRecord } from './CostEngine'
import { logger } from '@/lib/ai/logger'

export interface StageMetrics {
  stage: string
  executionCount: number
  successCount: number
  failureCount: number
  averageDurationMs: number
  totalDurationMs: number
  minDurationMs: number
  maxDurationMs: number
  averageCost: number
  totalCost: number
  averageTokens: number
  totalTokens: number
  providers: Record<Provider, number>
}

export interface CourseMetrics {
  courseId: string
  courseRequestId: string
  topic: string
  status: CourseResult['status']
  totalStages: number
  completedStages: number
  failedStages: number
  totalDurationMs: number
  totalCost: number
  totalTokens: number
  totalWordCount: number
  lessonCount: number
  moduleCount: number
  exerciseCount: number
  quizCount: number
  assessmentCount: number
  zipSizeBytes: number
  qualityScore: number | null
  qualityPassed: boolean | null
  startedAt: string
  completedAt: string | null
}

export interface CostBreakdown {
  totalCost: number
  totalTokens: number
  byProvider: Record<Provider, { cost: number; tokens: number; records: number }>
  byStage: Record<string, { cost: number; tokens: number; records: number }>
  byCourse: Record<string, { cost: number; tokens: number; records: number }>
  recordCount: number
  averageCostPerRecord: number
}

class ObservabilityManagerImpl {
  private readonly stageRuns = new Map<string, Array<{ durationMs: number; cost: number; tokens: number; provider: Provider; success: boolean }>>()
  private readonly courseResults = new Map<string, CourseResult>()

  recordStage(input: {
    courseId: string
    stage: string
    durationMs: number
    success: boolean
    provider: Provider
    cost?: number
    tokens?: number
  }): void {
    const runs = this.stageRuns.get(input.stage) ?? []
    runs.push({
      durationMs: input.durationMs,
      cost: input.cost ?? 0,
      tokens: input.tokens ?? 0,
      provider: input.provider,
      success: input.success,
    })
    this.stageRuns.set(input.stage, runs)
    logger.debug({ courseId: input.courseId, stage: input.stage, durationMs: input.durationMs }, 'ObservabilityManager: stage recorded')
  }

  recordCourse(course: CourseResult): void {
    this.courseResults.set(course.id, course)
    for (const stage of course.stages) {
      this.recordStage({
        courseId: course.id,
        stage: stage.stage,
        durationMs: stage.durationMs,
        success: stage.status === 'completed',
        provider: stage.provider,
        cost: stage.cost ?? 0,
        tokens: stage.tokenUsage?.totalTokens ?? 0,
      })
    }
  }

  getStageMetrics(stage: string): StageMetrics | null {
    const runs = this.stageRuns.get(stage)
    if (!runs || runs.length === 0) return null
    const executionCount = runs.length
    const successCount = runs.filter((r) => r.success).length
    const failureCount = executionCount - successCount
    const durations = runs.map((r) => r.durationMs)
    const costs = runs.map((r) => r.cost)
    const tokens = runs.map((r) => r.tokens)
    const providers: Record<Provider, number> = {
      groq: 0, gemini: 0, claude: 0, openai: 0, openrouter: 0, litellm: 0, 'runtime-adapter': 0,
    }
    for (const r of runs) {
      providers[r.provider] = (providers[r.provider] ?? 0) + 1
    }
    return {
      stage,
      executionCount,
      successCount,
      failureCount,
      averageDurationMs: Math.round(durations.reduce((a, b) => a + b, 0) / executionCount),
      totalDurationMs: durations.reduce((a, b) => a + b, 0),
      minDurationMs: Math.min(...durations),
      maxDurationMs: Math.max(...durations),
      averageCost: Math.round((costs.reduce((a, b) => a + b, 0) / executionCount) * 1_000_000) / 1_000_000,
      totalCost: Math.round(costs.reduce((a, b) => a + b, 0) * 1_000_000) / 1_000_000,
      averageTokens: Math.round(tokens.reduce((a, b) => a + b, 0) / executionCount),
      totalTokens: tokens.reduce((a, b) => a + b, 0),
      providers,
    }
  }

  getAllStageMetrics(): StageMetrics[] {
    return Array.from(this.stageRuns.keys()).map((s) => this.getStageMetrics(s)!).filter(Boolean)
  }

  getCourseMetrics(courseId: string): CourseMetrics | null {
    const course = this.courseResults.get(courseId)
    if (!course) return null
    const completedStages = course.stages.filter((s) => s.status === 'completed').length
    const failedStages = course.stages.filter((s) => s.status === 'failed').length
    const startedAt = course.stages[0]?.startedAt ?? course.createdAt
    const completedAt = course.stages[course.stages.length - 1]?.completedAt ?? null
    const costTotal = costEngine.getTotal(courseId)
    return {
      courseId: course.id,
      courseRequestId: course.courseRequestId,
      topic: course.topic,
      status: course.status,
      totalStages: course.stages.length,
      completedStages,
      failedStages,
      totalDurationMs: course.totalDurationMs,
      totalCost: costTotal.cost,
      totalTokens: costTotal.tokens,
      totalWordCount: course.totalWordCount,
      lessonCount: course.lessons.length,
      moduleCount: course.modules.length,
      exerciseCount: course.exercises.length,
      quizCount: course.quizzes.length,
      assessmentCount: course.assessments.length,
      zipSizeBytes: course.zipBuffer?.byteLength ?? 0,
      qualityScore: course.qualityReport?.overallScore ?? null,
      qualityPassed: course.qualityReport?.passed ?? null,
      startedAt,
      completedAt,
    }
  }

  getAllCourseMetrics(): CourseMetrics[] {
    return Array.from(this.courseResults.keys()).map((id) => this.getCourseMetrics(id)!).filter(Boolean)
  }

  getCostBreakdown(courseId?: string): CostBreakdown {
    const records: CostRecord[] = courseId ? costEngine.getByCourseId(courseId) : costEngine.list()
    const byProvider = {} as CostBreakdown['byProvider']
    const byStage: Record<string, { cost: number; tokens: number; records: number }> = {}
    const byCourse: Record<string, { cost: number; tokens: number; records: number }> = {}
    let totalCost = 0
    let totalTokens = 0

    const providerInit: Record<Provider, { cost: number; tokens: number; records: number }> = {
      groq: { cost: 0, tokens: 0, records: 0 },
      gemini: { cost: 0, tokens: 0, records: 0 },
      claude: { cost: 0, tokens: 0, records: 0 },
      openai: { cost: 0, tokens: 0, records: 0 },
      openrouter: { cost: 0, tokens: 0, records: 0 },
      litellm: { cost: 0, tokens: 0, records: 0 },
      'runtime-adapter': { cost: 0, tokens: 0, records: 0 },
    }
    Object.assign(byProvider, providerInit)

    for (const r of records) {
      totalCost += r.cost
      totalTokens += r.totalTokens
      if (!byProvider[r.provider]) {
        byProvider[r.provider] = { cost: 0, tokens: 0, records: 0 }
      }
      byProvider[r.provider]!.cost += r.cost
      byProvider[r.provider]!.tokens += r.totalTokens
      byProvider[r.provider]!.records += 1
      if (!byStage[r.stage]) byStage[r.stage] = { cost: 0, tokens: 0, records: 0 }
      byStage[r.stage]!.cost += r.cost
      byStage[r.stage]!.tokens += r.totalTokens
      byStage[r.stage]!.records += 1
      if (!byCourse[r.courseId]) byCourse[r.courseId] = { cost: 0, tokens: 0, records: 0 }
      byCourse[r.courseId]!.cost += r.cost
      byCourse[r.courseId]!.tokens += r.totalTokens
      byCourse[r.courseId]!.records += 1
    }

    return {
      totalCost: Math.round(totalCost * 1_000_000) / 1_000_000,
      totalTokens,
      byProvider,
      byStage,
      byCourse,
      recordCount: records.length,
      averageCostPerRecord: records.length > 0 ? Math.round((totalCost / records.length) * 1_000_000) / 1_000_000 : 0,
    }
  }

  getSummary(): {
    totalCourses: number
    totalStages: number
    totalCost: number
    totalTokens: number
    totalWords: number
    averageCourseDurationMs: number
    averageQualityScore: number | null
  } {
    const courses = Array.from(this.courseResults.values())
    const costTotal = costEngine.getTotal()
    const totalWords = courses.reduce((s, c) => s + c.totalWordCount, 0)
    const totalDuration = courses.reduce((s, c) => s + c.totalDurationMs, 0)
    const qualityScores = courses.map((c) => c.qualityReport?.overallScore).filter((s): s is number => typeof s === 'number')
    return {
      totalCourses: courses.length,
      totalStages: Array.from(this.stageRuns.values()).reduce((s, r) => s + r.length, 0),
      totalCost: costTotal.cost,
      totalTokens: costTotal.tokens,
      totalWords,
      averageCourseDurationMs: courses.length > 0 ? Math.round(totalDuration / courses.length) : 0,
      averageQualityScore: qualityScores.length > 0 ? Math.round(qualityScores.reduce((a, b) => a + b, 0) / qualityScores.length) : null,
    }
  }

  clear(): void {
    this.stageRuns.clear()
    this.courseResults.clear()
  }

  size(): { stages: number; courses: number } {
    return { stages: this.stageRuns.size, courses: this.courseResults.size }
  }
}

export const observabilityManager = new ObservabilityManagerImpl()
