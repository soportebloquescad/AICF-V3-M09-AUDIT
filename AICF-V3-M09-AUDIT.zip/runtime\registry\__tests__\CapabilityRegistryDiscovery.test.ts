// =============================================================================
// AICF V3 — CapabilityRegistry Discovery Engine Tests (Sprint 17)
// =============================================================================
// Tests for the Sprint 17 discovery methods on CapabilityRegistry:
//   - registerModuleInfo()    → stores per-module info (version, priority, tags, health)
//   - lookupFirst()           → first module with capability (or null)
//   - lookupAll(query)        → all matches filtered by version/priority/tags/minPriority/maxPriority
//   - lookupByCapability()    → all modules providing a capability
//   - lookupByTag()           → modules with a tag (across all capabilities)
//   - lookupByVersion()       → modules with a version (across all capabilities)
//   - getBestMatch()          → lowest-priority healthy/degraded module
//   - getByPriority()         → modules with priority >= minPriority, sorted ascending
//
// Note: registerModuleInfo() does NOT register capability mappings. Tests
// must call BOTH register(moduleId, capabilities) and registerModuleInfo(...)
// so the lookup methods can find the module and enrich the result with info.
// No `any`.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { CapabilityRegistry } from '../CapabilityRegistry'
import type {
  CapabilityQuery,
  CapabilityResult,
  ModuleHealthLevel,
} from '../CapabilityRegistry'

/**
 * Convenience: registers a module's capabilities AND its discovery info in
 * one call so tests don't have to repeat the two-step dance.
 */
function registerModule(
  registry: CapabilityRegistry,
  moduleId: string,
  capabilities: string[],
  info: {
    version?: string
    priority?: number
    tags?: string[]
    health?: ModuleHealthLevel
  } = {},
): void {
  registry.register(moduleId, capabilities)
  registry.registerModuleInfo(moduleId, {
    version: info.version ?? '1.0.0',
    priority: info.priority ?? 10,
    tags: info.tags ?? [],
    health: info.health ?? 'healthy',
  })
}

describe('CapabilityRegistry Discovery Engine (Sprint 17)', () => {
  let registry: CapabilityRegistry

  beforeEach(() => {
    registry = new CapabilityRegistry()
  })

  // -------------------------------------------------------------------------
  // registerModuleInfo()
  // -------------------------------------------------------------------------
  describe('registerModuleInfo()', () => {
    it('stores module info that enriches lookup results', () => {
      registerModule(registry, 'm1', ['capA'], {
        version: '2.1.0',
        priority: 5,
        tags: ['stable', 'fast'],
        health: 'healthy',
      })
      const result = registry.lookupFirst('capA')
      expect(result).not.toBeNull()
      expect(result?.moduleId).toBe('m1')
      expect(result?.version).toBe('2.1.0')
      expect(result?.priority).toBe(5)
      expect(result?.tags).toEqual(['stable', 'fast'])
      expect(result?.health).toBe('healthy')
    })

    it('overwrites previous info for the same module', () => {
      registerModule(registry, 'm1', ['capA'], { version: '1.0.0', priority: 5 })
      registerModule(registry, 'm1', ['capA'], { version: '2.0.0', priority: 3 })
      const result = registry.lookupFirst('capA')
      expect(result?.version).toBe('2.0.0')
      expect(result?.priority).toBe(3)
    })
  })

  // -------------------------------------------------------------------------
  // lookupFirst()
  // -------------------------------------------------------------------------
  describe('lookupFirst()', () => {
    it('returns the first module that provides a capability', () => {
      registerModule(registry, 'm1', ['capA'])
      registerModule(registry, 'm2', ['capA'])
      const result = registry.lookupFirst('capA')
      expect(result).not.toBeNull()
      expect(result?.capability).toBe('capA')
      // The first match should be one of the two registered modules.
      expect(['m1', 'm2']).toContain(result?.moduleId as string)
    })

    it('returns null for an unknown capability', () => {
      expect(registry.lookupFirst('nope')).toBeNull()
    })

    it('returns a result with default info when only register() was called', () => {
      // register() without registerModuleInfo() — buildResult falls back to
      // version='0.0.0', priority=MAX_SAFE_INTEGER, health='unhealthy'.
      registry.register('m1', ['capA'])
      const result = registry.lookupFirst('capA')
      expect(result?.version).toBe('0.0.0')
      expect(result?.priority).toBe(Number.MAX_SAFE_INTEGER)
      expect(result?.health).toBe('unhealthy')
      expect(result?.tags).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // lookupAll()
  // -------------------------------------------------------------------------
  describe('lookupAll()', () => {
    beforeEach(() => {
      registerModule(registry, 'm1', ['capA'], {
        version: '1.0.0',
        priority: 10,
        tags: ['stable'],
      })
      registerModule(registry, 'm2', ['capA'], {
        version: '2.0.0',
        priority: 20,
        tags: ['beta', 'fast'],
      })
      registerModule(registry, 'm3', ['capA'], {
        version: '1.0.0',
        priority: 30,
        tags: ['fast'],
      })
    })

    it('returns all matching modules when no filters are applied', () => {
      const query: CapabilityQuery = { capability: 'capA' }
      const results = registry.lookupAll(query)
      expect(results.length).toBe(3)
      const ids = results.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['m1', 'm2', 'm3'])
    })

    it('filters by version', () => {
      const results = registry.lookupAll({ capability: 'capA', version: '1.0.0' })
      expect(results.length).toBe(2)
      const ids = results.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['m1', 'm3'])
    })

    it('filters by minPriority', () => {
      const results = registry.lookupAll({ capability: 'capA', minPriority: 20 })
      expect(results.length).toBe(2)
      const ids = results.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['m2', 'm3'])
    })

    it('filters by maxPriority', () => {
      const results = registry.lookupAll({ capability: 'capA', maxPriority: 20 })
      expect(results.length).toBe(2)
      const ids = results.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['m1', 'm2'])
    })

    it('filters by tags (module must have ALL listed tags)', () => {
      const results = registry.lookupAll({ capability: 'capA', tags: ['fast'] })
      const ids = results.map((r) => r.moduleId).sort()
      expect(ids).toEqual(['m2', 'm3'])
    })

    it('returns empty array for an unknown capability', () => {
      expect(registry.lookupAll({ capability: 'nope' })).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // lookupByCapability()
  // -------------------------------------------------------------------------
  describe('lookupByCapability()', () => {
    it('returns all modules that provide the given capability', () => {
      registerModule(registry, 'm1', ['capA', 'capB'])
      registerModule(registry, 'm2', ['capA'])
      registerModule(registry, 'm3', ['capB'])

      const capAResults = registry.lookupByCapability('capA')
      expect(capAResults.length).toBe(2)
      const capAIds = capAResults.map((r) => r.moduleId).sort()
      expect(capAIds).toEqual(['m1', 'm2'])

      const capBResults = registry.lookupByCapability('capB')
      expect(capBResults.length).toBe(2)
      const capBIds = capBResults.map((r) => r.moduleId).sort()
      expect(capBIds).toEqual(['m1', 'm3'])
    })

    it('returns empty array for an unknown capability', () => {
      expect(registry.lookupByCapability('nope')).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // lookupByTag()
  // -------------------------------------------------------------------------
  describe('lookupByTag()', () => {
    it('returns all modules with the given tag (one result per capability)', () => {
      registerModule(registry, 'm1', ['capA', 'capB'], { tags: ['stable'] })
      registerModule(registry, 'm2', ['capA'], { tags: ['beta'] })
      registerModule(registry, 'm3', ['capC'], { tags: ['stable'] })

      const stable = registry.lookupByTag('stable')
      // m1 has 2 capabilities (capA, capB) + m3 has 1 (capC) = 3 results.
      expect(stable.length).toBe(3)
      const m1Results = stable.filter((r) => r.moduleId === 'm1')
      expect(m1Results.map((r) => r.capability).sort()).toEqual(['capA', 'capB'])
      expect(stable.some((r) => r.moduleId === 'm3' && r.capability === 'capC')).toBe(true)
    })

    it('returns empty array for an unknown tag', () => {
      registerModule(registry, 'm1', ['capA'], { tags: ['stable'] })
      expect(registry.lookupByTag('nope')).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // lookupByVersion()
  // -------------------------------------------------------------------------
  describe('lookupByVersion()', () => {
    it('returns all modules whose version matches (exact match)', () => {
      registerModule(registry, 'm1', ['capA'], { version: '1.0.0' })
      registerModule(registry, 'm2', ['capB'], { version: '2.0.0' })
      registerModule(registry, 'm3', ['capC'], { version: '1.0.0' })

      const v1 = registry.lookupByVersion('1.0.0')
      expect(v1.length).toBe(2)
      const v1Ids = v1.map((r) => r.moduleId).sort()
      expect(v1Ids).toEqual(['m1', 'm3'])

      const v2 = registry.lookupByVersion('2.0.0')
      expect(v2.length).toBe(1)
      expect(v2[0].moduleId).toBe('m2')
    })

    it('returns empty array for an unknown version', () => {
      registerModule(registry, 'm1', ['capA'], { version: '1.0.0' })
      expect(registry.lookupByVersion('9.9.9')).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // getBestMatch()
  // -------------------------------------------------------------------------
  describe('getBestMatch()', () => {
    it('returns the lowest-priority (best) healthy match', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 50, health: 'healthy' })
      registerModule(registry, 'm2', ['capA'], { priority: 10, health: 'healthy' })
      registerModule(registry, 'm3', ['capA'], { priority: 5, health: 'healthy' })

      const best = registry.getBestMatch('capA')
      expect(best?.moduleId).toBe('m3')
      expect(best?.priority).toBe(5)
    })

    it('skips unhealthy modules', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 1, health: 'unhealthy' })
      registerModule(registry, 'm2', ['capA'], { priority: 50, health: 'healthy' })

      const best = registry.getBestMatch('capA')
      // m1 has lower priority but is unhealthy → skipped. m2 wins.
      expect(best?.moduleId).toBe('m2')
    })

    it('returns null when all candidates are unhealthy', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 1, health: 'unhealthy' })
      registerModule(registry, 'm2', ['capA'], { priority: 2, health: 'unhealthy' })
      expect(registry.getBestMatch('capA')).toBeNull()
    })

    it('returns null when no module provides the capability', () => {
      expect(registry.getBestMatch('nope')).toBeNull()
    })

    it('breaks ties by preferring healthy over degraded', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 10, health: 'degraded' })
      registerModule(registry, 'm2', ['capA'], { priority: 10, health: 'healthy' })
      const best = registry.getBestMatch('capA')
      expect(best?.moduleId).toBe('m2')
    })
  })

  // -------------------------------------------------------------------------
  // getByPriority()
  // -------------------------------------------------------------------------
  describe('getByPriority()', () => {
    it('returns modules with priority >= minPriority, sorted ascending', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 5 })
      registerModule(registry, 'm2', ['capA'], { priority: 15 })
      registerModule(registry, 'm3', ['capA'], { priority: 10 })
      registerModule(registry, 'm4', ['capA'], { priority: 20 })

      const results: CapabilityResult[] = registry.getByPriority('capA', 10)
      const priorities = results.map((r) => r.priority)
      // minPriority=10 is inclusive: m2 (15), m3 (10), m4 (20) qualify.
      expect(priorities).toEqual([10, 15, 20])
    })

    it('returns empty array when no module meets the threshold', () => {
      registerModule(registry, 'm1', ['capA'], { priority: 5 })
      expect(registry.getByPriority('capA', 100)).toEqual([])
    })

    it('returns empty array for an unknown capability', () => {
      expect(registry.getByPriority('nope', 0)).toEqual([])
    })
  })
})
