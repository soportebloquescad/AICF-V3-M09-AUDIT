// =============================================================================
// AICF V3 — Module Registry (Sprint 19: All 9 Modules Real)
// =============================================================================
// Registers Runtime modules with full metadata, capabilities, contracts,
// events, health, and statistics.
//
// Sprint 19: the constructor no longer registers any stub modules. All 9
// modules (observability, localization, infrastructure, workflow,
// content-intelligence, assets, generation, real-generation, reports)
// have real implementations that are registered by RuntimeBootstrap via
// the manifest + ModuleFactory.
//
// Sprint 16 additions (backward compatible):
//   - RegistryEntry: { module, metadata, capabilities, factory, contracts, events, health, statistics }
//   - getCapabilities(moduleId) → string[]
//   - getModulesByCapability(capability) → string[]
//   - getMetadata(moduleId) → PluginMetadata
//   - CapabilityRegistry integration
//
// Sprint 15 behavior preserved:
//   - register(category, module) still works (metadata is optional)
//   - getStatus(), getHealth(), initializeAll() unchanged
// =============================================================================

import type { RuntimeModule, RuntimeModuleCategory, RuntimeStatus, ModuleHealth } from '../contracts/RuntimeModule'
import type { PluginMetadata } from '../contracts/PluginMetadata'
import type { VersionedContract } from '../contracts/VersionedContract'
import { CapabilityRegistry } from './CapabilityRegistry'
import type {
  ContentIntelligenceModule,
  RealGenerationModule,
  WorkflowModule as WorkflowModuleInterface,
  LocalizationModule,
  AssetsModule,
  ReportsModule,
  InfrastructureModule,
} from '../contracts/ModuleInterfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Module statistics tracked by the registry.
 */
export interface ModuleStatistics {
  /** Number of times the module has been called. */
  callCount: number
  /** Number of errors. */
  errorCount: number
  /** Last time the module was used (ISO string). */
  lastUsed: string | null
  /** Average latency in ms. */
  avgLatencyMs: number
  /** Total latency in ms. */
  totalLatencyMs: number
}

/**
 * A full registry entry: the module instance + all its metadata.
 */
export interface RegistryEntry {
  module: RuntimeModule
  metadata: PluginMetadata | null
  capabilities: string[]
  factory: (() => RuntimeModule) | null
  contracts: VersionedContract | null
  events: string[]
  health: ModuleHealth | null
  statistics: ModuleStatistics
}

/**
 * A stub module that can be used for tests or temporary placeholder
 * registrations. Sprint 19: no longer used by the constructor (all 9
 * modules are real), but kept as a utility for tests that need a
 * minimal module implementation.
 */
export class StubModule implements RuntimeModule {
  constructor(
    public readonly name: string,
    public readonly version: string,
    private readonly category: RuntimeModuleCategory,
  ) {}

  async initialize(): Promise<void> {
    logger.debug({ module: this.name, category: this.category }, 'Stub module initialized (no-op)')
  }

  isReady(): boolean {
    return false
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: false,
      version: this.version,
      details: { category: this.category, implemented: false },
    }
  }
}

/**
 * Creates a fresh statistics object.
 */
function createEmptyStatistics(): ModuleStatistics {
  return {
    callCount: 0,
    errorCount: 0,
    lastUsed: null,
    avgLatencyMs: 0,
    totalLatencyMs: 0,
  }
}

/**
 * Registry of Runtime modules.
 *
 * Sprint 19: the constructor registers ZERO stubs. All 9 modules are real
 * implementations registered by RuntimeBootstrap (via the manifest +
 * ModuleFactory). The `StubModule` class is exported above for tests that
 * need a minimal module implementation.
 */
export class ModuleRegistry {
  private readonly modules = new Map<RuntimeModuleCategory, RuntimeModule>()
  private readonly entries = new Map<string, RegistryEntry>()
  private readonly capabilityRegistry = new CapabilityRegistry()

  constructor() {
    // Sprint 19: no stubs — all 9 modules are registered by bootstrap
    // via the manifest + ModuleFactory. The registry starts empty.
  }

  /**
   * Registers a module (replaces stub with real implementation).
   *
   * Conflict detection (Sprint 2 Production Runtime): when a module is
   * already registered for the same category AND the new module is a
   * DIFFERENT instance, a warning is logged. The new module replaces the
   * old one (idempotent semantics preserved for legitimate re-registration
   * during HMR / bootstrap retries). Re-registering the SAME instance is
   * silent (no-op).
   *
   * This satisfies the "registro único de módulos" requirement: duplicate
   * registrations are DETECTED + LOGGED, never silently swallowed.
   */
  register(category: RuntimeModuleCategory, module: RuntimeModule): void {
    const existing = this.modules.get(category)
    if (existing && existing !== module) {
      logger.warn(
        {
          category,
          existingModule: existing.name,
          existingVersion: existing.version,
          newModule: module.name,
          newVersion: module.version,
        },
        'ModuleRegistry: CONFLICT — overwriting existing module for category',
      )
    }
    this.modules.set(category, module)
    logger.info(
      { category, module: module.name, version: module.version, ready: module.isReady() },
      'Module registered',
    )
  }

  /**
   * Registers a module with full metadata (Sprint 16).
   * This is the preferred registration method for real modules.
   *
   * Conflict detection (Sprint 2 Production Runtime): when metadata.id is
   * already registered AND the new module is a DIFFERENT instance, a
   * warning is logged. Same instance re-registration is silent.
   */
  registerWithMetadata(
    category: RuntimeModuleCategory,
    module: RuntimeModule,
    metadata: PluginMetadata,
  ): void {
    const existingEntry = this.entries.get(metadata.id)
    if (existingEntry && existingEntry.module !== module) {
      logger.warn(
        {
          category,
          moduleId: metadata.id,
          existingModule: existingEntry.module.name,
          newModule: module.name,
        },
        'ModuleRegistry: CONFLICT — overwriting existing metadata-registered module',
      )
    }
    this.modules.set(category, module)
    this.entries.set(metadata.id, {
      module,
      metadata,
      capabilities: metadata.capabilities,
      factory: null,
      contracts: metadata.contracts,
      events: metadata.events || [],
      health: null,
      statistics: createEmptyStatistics(),
    })
    this.capabilityRegistry.register(metadata.id, metadata.capabilities)
    logger.info(
      { category, moduleId: metadata.id, module: module.name, capabilities: metadata.capabilities },
      'Module registered with metadata',
    )
  }

  /**
   * Gets a module by category.
   */
  get(category: RuntimeModuleCategory): RuntimeModule | null {
    return this.modules.get(category) || null
  }

  /**
   * Gets the Content Intelligence module (typed).
   */
  getContentIntelligence(): ContentIntelligenceModule | null {
    const m = this.modules.get('content-intelligence')
    if (m && m.isReady()) return m as unknown as ContentIntelligenceModule
    return null
  }

  /**
   * Gets the Real Generation module (typed).
   */
  getRealGeneration(): RealGenerationModule | null {
    const m = this.modules.get('real-generation')
    if (m && m.isReady()) return m as unknown as RealGenerationModule
    return null
  }

  /**
   * Gets the Workflow module (typed).
   */
  getWorkflow(): WorkflowModuleInterface | null {
    const m = this.modules.get('workflow')
    if (m && m.isReady()) return m as unknown as WorkflowModuleInterface
    return null
  }

  /**
   * Gets the Infrastructure module (typed).
   */
  getInfrastructure(): InfrastructureModule | null {
    const m = this.modules.get('infrastructure')
    if (m && m.isReady()) return m as unknown as InfrastructureModule
    return null
  }

  /**
   * Returns the capabilities of a module (Sprint 16).
   */
  getCapabilities(moduleId: string): string[] {
    return this.capabilityRegistry.getCapabilities(moduleId)
  }

  /**
   * Returns the list of module IDs that provide a given capability (Sprint 16).
   */
  getModulesByCapability(capability: string): string[] {
    return this.capabilityRegistry.getModulesByCapability(capability)
  }

  /**
   * Returns the metadata for a module (Sprint 16).
   */
  getMetadata(moduleId: string): PluginMetadata | null {
    const entry = this.entries.get(moduleId)
    return entry?.metadata || null
  }

  /**
   * Returns the full registry entry for a module (Sprint 16).
   */
  getEntry(moduleId: string): RegistryEntry | null {
    return this.entries.get(moduleId) || null
  }

  /**
   * Returns all registry entries (Sprint 16).
   */
  getEntries(): RegistryEntry[] {
    return Array.from(this.entries.values())
  }

  /**
   * Returns the capability registry (Sprint 16).
   */
  getCapabilityRegistry(): CapabilityRegistry {
    return this.capabilityRegistry
  }

  /**
   * Returns the status of all registered modules.
   * Defensive: modules that don't implement getStatus() get a synthesized status.
   */
  getStatus(): RuntimeStatus[] {
    return Array.from(this.modules.values()).map((m) => {
      if (typeof m.getStatus === 'function') {
        return m.getStatus()
      }
      return {
        name: m.name,
        ready: m.isReady(),
        version: m.version,
        details: { implemented: m.isReady(), synthesized: true },
      }
    })
  }

  /**
   * Initializes all registered modules that have an initialize() method.
   * Errors are logged but don't stop initialization of other modules.
   */
  async initializeAll(): Promise<void> {
    for (const [category, module] of this.modules) {
      try {
        if (module.initialize) {
          await module.initialize()
        }
      } catch (err) {
        logger.error(
          { category, error: err instanceof Error ? err.message : String(err) },
          'Module initialization failed',
        )
      }
    }
  }

  /**
   * Returns the health of all modules that implement health().
   * Modules without health() are reported as 'unhealthy' with ready=isReady().
   */
  async getHealth(): Promise<Array<{ name: string; category: RuntimeModuleCategory; health: ModuleHealth }>> {
    const results: Array<{ name: string; category: RuntimeModuleCategory; health: ModuleHealth }> = []
    for (const [category, module] of this.modules) {
      if (typeof module.health === 'function') {
        try {
          const health = await module.health()
          results.push({ name: module.name, category, health })
          // Update the entry's health
          const entry = this.entries.get(module.name)
          if (entry) {
            entry.health = health
          }
        } catch (err) {
          results.push({
            name: module.name,
            category,
            health: {
              ready: false,
              status: 'unhealthy',
              startupTime: '',
              dependencies: [],
              version: module.version,
              lastInitialization: '',
              lastError: err instanceof Error ? err.message : String(err),
            },
          })
        }
      } else {
        // Stub or non-lifecycle module — synthesize a minimal health report.
        results.push({
          name: module.name,
          category,
          health: {
            ready: module.isReady(),
            status: module.isReady() ? 'healthy' : 'unhealthy',
            startupTime: '',
            dependencies: [],
            version: module.version,
            lastInitialization: '',
          },
        })
      }
    }
    return results
  }
}
