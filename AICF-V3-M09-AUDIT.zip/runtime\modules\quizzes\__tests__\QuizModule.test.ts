// =============================================================================
// AICF V3 — QuizModule Tests (Épica 3 — Educational Factory)
// =============================================================================
// Verifies the QuizModule:
//   - generateQuiz fallback (no AI) — produces real multiple-choice
//     questions with 4 options each.
//   - Question structure: id, question, options (4), correctIndex,
//     explanation.
//   - gradeQuiz computes score correctly.
//   - Unknown job types produce a failed ExecutionResult.
//
// No `any`. The variable holding the module under test is named `testModule`.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { QuizModule, QUIZ_MODULE_METADATA } from '../QuizModule'
import type { GradedQuizQuestion } from '../QuizModule'
import { createBusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

class MockAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> {
    return {
      content: JSON.stringify({
        title: 'Mock Quiz',
        questions: [
          {
            id: 'q-1',
            question: 'Mock Q1?',
            options: ['A', 'B', 'C', 'D'],
            correctIndex: 1,
            explanation: 'B is correct.',
          },
          {
            id: 'q-2',
            question: 'Mock Q2?',
            options: ['W', 'X', 'Y', 'Z'],
            correctIndex: 3,
            explanation: 'Z is correct.',
          },
        ],
      }),
      model: 'mock',
      provider: 'mock',
      usage: null,
      durationMs: 1,
    }
  }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: true, provider: 'mock' } }
}

class FailingAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> { throw new Error('AI unavailable') }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: false, provider: 'failing' } }
}

const ctx = createBusinessContext({ jobId: 'job-test-quiz-1' })

describe('QuizModule (Épica 3)', () => {
  describe('metadata + lifecycle', () => {
    const testModule = new QuizModule()

    it('exposes the correct metadata', () => {
      expect(testModule.getMetadata()).toEqual(QUIZ_MODULE_METADATA)
      expect(testModule.name).toBe('quiz')
    })

    it('declares the expected capabilities', () => {
      const caps = testModule.getCapabilities().map((c) => c.name)
      expect(caps).toContain('createQuiz')
      expect(caps).toContain('generateQuiz')
      expect(caps).toContain('gradeQuiz')
    })
  })

  describe('executeJob — generateQuiz fallback (no AI)', () => {
    const testModule = new QuizModule()

    it('produces a quiz with the requested number of questions', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 5, difficulty: 'medium' },
        ctx,
      )
      expect(result.ok).toBe(true)
      const quiz = result.output!.quiz as Record<string, unknown>
      expect(quiz.topic).toBe('Algorithms')
      expect(quiz.difficulty).toBe('medium')
      const questions = quiz.questions as GradedQuizQuestion[]
      expect(questions).toHaveLength(5)
    })

    it('each question has the correct structure', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 3 },
        ctx,
      )
      const questions = (result.output!.quiz as Record<string, unknown>).questions as GradedQuizQuestion[]
      for (const q of questions) {
        expect(typeof q.id).toBe('string')
        expect((q.id as string).length).toBeGreaterThan(0)
        expect(typeof q.question).toBe('string')
        expect((q.question as string).length).toBeGreaterThan(0)
        expect(Array.isArray(q.options)).toBe(true)
        expect(q.options).toHaveLength(4)
        expect(Number.isInteger(q.correctIndex)).toBe(true)
        expect(q.correctIndex).toBeGreaterThanOrEqual(0)
        expect(q.correctIndex).toBeLessThan(4)
        expect(typeof q.explanation).toBe('string')
        expect((q.explanation as string).length).toBeGreaterThan(0)
      }
    })

    it('uses default difficulty=medium when not specified', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 2 },
        ctx,
      )
      expect((result.output!.quiz as Record<string, unknown>).difficulty).toBe('medium')
    })

    it('respects the difficulty knob', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 2, difficulty: 'hard' },
        ctx,
      )
      const quiz = result.output!.quiz as Record<string, unknown>
      expect(quiz.difficulty).toBe('hard')
      const questions = quiz.questions as GradedQuizQuestion[]
      expect(questions[0].explanation).toContain('[HARD]')
    })

    it('produces markdown + html', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 2 },
        ctx,
      )
      const quiz = result.output!.quiz as Record<string, unknown>
      expect(typeof quiz.markdown).toBe('string')
      expect((quiz.markdown as string)).toContain('## q-1')
      expect((quiz.html as string)).toContain('<!DOCTYPE html>')
      expect((quiz.html as string)).toContain('submit')
    })

    it('accepts the legacy "count" field', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', count: 3 },
        ctx,
      )
      const questions = (result.output!.quiz as Record<string, unknown>).questions as unknown[]
      expect(questions).toHaveLength(3)
    })
  })

  describe('executeJob — AI mode (mock)', () => {
    let testModule: QuizModule

    beforeEach(() => {
      testModule = new QuizModule(new MockAIAdapter())
    })

    it('parses AI JSON into typed questions', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 2 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const questions = (result.output!.quiz as Record<string, unknown>).questions as GradedQuizQuestion[]
      expect(questions).toHaveLength(2)
      expect(questions[0].id).toBe('q-1')
      expect(questions[0].question).toBe('Mock Q1?')
      expect(questions[0].correctIndex).toBe(1)
    })

    it('reports providerCalls=1', async () => {
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 2 },
        ctx,
      )
      expect(result.metrics?.providerCalls).toBe(1)
    })
  })

  describe('executeJob — AI failure degrades to fallback', () => {
    it('still produces a quiz when the AI adapter throws', async () => {
      const testModule = new QuizModule(new FailingAIAdapter())
      const result = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 3 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const questions = (result.output!.quiz as Record<string, unknown>).questions as unknown[]
      expect(questions.length).toBe(3)
      expect(testModule.getMetrics().errorCount).toBeGreaterThan(0)
    })
  })

  describe('executeJob — gradeQuiz', () => {
    const testModule = new QuizModule()

    it('grades a perfect submission', async () => {
      // First, generate a quiz to get the answer key.
      const genResult = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 3 },
        ctx,
      )
      const quiz = genResult.output!.quiz as Record<string, unknown>
      const questions = quiz.questions as GradedQuizQuestion[]
      const answers: Record<string, number> = {}
      for (const q of questions) answers[q.id] = q.correctIndex

      const gradeResult = await testModule.executeJob('gradeQuiz', { questions, answers, passingScore: 70 }, ctx)
      expect(gradeResult.ok).toBe(true)
      const grade = gradeResult.output!.grade as Record<string, unknown>
      expect(grade.total).toBe(3)
      expect(grade.correct).toBe(3)
      expect(grade.score).toBe(100)
      expect(grade.passed).toBe(true)
    })

    it('grades a failing submission', async () => {
      const genResult = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 4 },
        ctx,
      )
      const quiz = genResult.output!.quiz as Record<string, unknown>
      const questions = quiz.questions as GradedQuizQuestion[]
      const answers: Record<string, number> = {}
      // All wrong answers (offset by 1, modulo 4)
      for (const q of questions) answers[q.id] = (q.correctIndex + 1) % 4

      const gradeResult = await testModule.executeJob('gradeQuiz', { questions, answers, passingScore: 70 }, ctx)
      const grade = gradeResult.output!.grade as Record<string, unknown>
      expect(grade.correct).toBe(0)
      expect(grade.score).toBe(0)
      expect(grade.passed).toBe(false)
    })

    it('grades a partial submission', async () => {
      const genResult = await testModule.executeJob(
        'generateQuiz',
        { topic: 'Algorithms', questionCount: 4 },
        ctx,
      )
      const quiz = genResult.output!.quiz as Record<string, unknown>
      const questions = quiz.questions as GradedQuizQuestion[]
      const answers: Record<string, number> = {}
      // 2 correct, 2 wrong
      questions.forEach((q, i) => {
        answers[q.id] = i < 2 ? q.correctIndex : (q.correctIndex + 1) % 4
      })

      const gradeResult = await testModule.executeJob('gradeQuiz', { questions, answers }, ctx)
      const grade = gradeResult.output!.grade as Record<string, unknown>
      expect(grade.correct).toBe(2)
      expect(grade.total).toBe(4)
      expect(grade.score).toBe(50)
      expect(grade.passed).toBe(false)
    })

    it('throws on malformed input (returns failed ExecutionResult)', async () => {
      const gradeResult = await testModule.executeJob('gradeQuiz', { notQuestions: true }, ctx)
      expect(gradeResult.ok).toBe(false)
      expect(gradeResult.error).toContain('questions')
    })
  })

  describe('executeJob — unknown job type', () => {
    const testModule = new QuizModule()

    it('returns a failed ExecutionResult', async () => {
      const result = await testModule.executeJob('bogusJob', { topic: 'Algorithms' }, ctx)
      expect(result.ok).toBe(false)
      expect(result.error).toContain('Unknown job type')
    })
  })
})
