// =============================================================================
// AICF V3 — Chat Schemas (Zod)
// =============================================================================
// Request and response validation schemas for the /api/chat endpoint.
// =============================================================================

import { z } from 'zod'

/**
 * Validates a single chat message.
 */
export const chatMessageSchema = z.object({
  role: z.enum(['system', 'user', 'assistant']),
  content: z.string().min(1).max(32_768),
})

/**
 * Validates the POST /api/chat request body.
 */
export const chatRequestSchema = z.object({
  model: z.string().min(1).max(128),
  messages: z.array(chatMessageSchema).min(1).max(100),
  temperature: z.number().min(0).max(2).optional(),
  maxTokens: z.number().int().min(1).max(32_768).optional(),
  topP: z.number().min(0).max(1).optional(),
  stop: z.array(z.string().max(64)).max(4).optional(),
  stream: z.boolean().optional(),
})

/**
 * Inferred TypeScript type from the schema.
 */
export type ChatRequestBody = z.infer<typeof chatRequestSchema>

/**
 * Validates the API response shape.
 */
export const chatResponseSchema = z.object({
  content: z.string(),
  model: z.string(),
  provider: z.string(),
  usage: z
    .object({
      promptTokens: z.number(),
      completionTokens: z.number(),
      totalTokens: z.number(),
    })
    .nullable(),
  durationMs: z.number(),
})

export type ChatResponseBody = z.infer<typeof chatResponseSchema>
