// =============================================================================
// AICF V3 — Business Events Contract (Épica 2 — AI Factory Core)
// =============================================================================
// Business-layer events emitted by the BusinessModuleRegistry and by
// BusinessModuleBase subclasses. These are NOT RuntimeEvents (those flow on
// the RuntimeEventBus via envelopes). BusinessEvents are a smaller, dedicated
// channel for the AI Factory lifecycle so the dashboard can render a job
// timeline without parsing every EDA envelope.
//
// The BusinessEvent envelope is intentionally minimal:
//   - `type` is one of the 6 lifecycle milestones below.
//   - `timestamp` is an ISO string for human-readable dashboards.
//   - `jobId` / `jobType` / `moduleId` / `capability` are optional context
//     fields populated when relevant (e.g. CapabilityRegistered has no
//     jobId; JobCompleted has no capability).
//   - `data` is an open-ended `Record<string, unknown>` for per-event
//     payload (e.g. { durationMs, tokensUsed }).
//
// No `any`.
// =============================================================================

/**
 * The 6 lifecycle milestones the Business layer emits.
 */
export type BusinessEventType =
  | 'JobCreated'
  | 'JobStarted'
  | 'JobCompleted'
  | 'JobFailed'
  | 'CapabilityRegistered'
  | 'ModuleLoaded'

/**
 * A single Business-layer event.
 */
export interface BusinessEvent {
  /** The lifecycle milestone this event represents. */
  type: BusinessEventType

  /** ISO timestamp when the event was emitted. */
  timestamp: string

  /** Job ID (present for Job* events). */
  jobId?: string

  /** Job type (present for Job* events). */
  jobType?: string

  /** Module ID (present for ModuleLoaded + CapabilityRegistered). */
  moduleId?: string

  /** Capability name (present for CapabilityRegistered). */
  capability?: string

  /** Per-event payload (e.g. { durationMs, tokensUsed, error }). */
  data?: Record<string, unknown>
}

/**
 * Factory: creates a BusinessEvent with a default `timestamp: now`.
 *
 * @example
 * const ev = createBusinessEvent('JobCompleted', {
 *   jobId: 'job-1',
 *   jobType: 'createCourse',
 *   data: { durationMs: 1234 },
 * })
 */
export function createBusinessEvent(
  type: BusinessEventType,
  opts?: Partial<BusinessEvent>,
): BusinessEvent {
  return {
    type,
    timestamp: opts?.timestamp ?? new Date().toISOString(),
    jobId: opts?.jobId,
    jobType: opts?.jobType,
    moduleId: opts?.moduleId,
    capability: opts?.capability,
    data: opts?.data,
  }
}
