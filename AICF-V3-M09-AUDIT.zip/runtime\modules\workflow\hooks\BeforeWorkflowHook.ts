// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Before-Workflow Hook + HookRegistry
// =============================================================================
// Defines the `BeforeWorkflowHook` interface and the `HookRegistry` class
// that owns all four hook registration lists (before/after workflow, before/
// after step). The registry is the single place hooks are wired; the other
// three hook files re-export the registry for ergonomic imports.
//
// Sprint 13+14 spec requirements covered:
//   - `BeforeWorkflowHook.execute(ctx): Promise<void>`
//   - `HookRegistry.registerBeforeWorkflow(hook)` / `runBeforeWorkflow(ctx)`
//   - Hooks run in registration order
//   - Failures are logged but do NOT stop execution, UNLESS the thrown error
//     carries `fatal: true` (a `FatalHookError` instance)
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
  WorkflowResult,
} from '@/lib/runtime/contracts/workflow'
import type { StepExecutionResult } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * A hook executed before a workflow starts. Receives the freshly-created
 * `WorkflowContext`; may mutate `ctx.variables` / `ctx.metadata` (the
 * context is the executor's mutable working copy at this point).
 */
export interface BeforeWorkflowHook {
  /** Hook name (for logging / diagnostics). */
  name: string
  /** Execute the hook. Throw to signal failure. */
  execute(ctx: WorkflowContext): Promise<void>
}

/** Hook executed after a workflow reaches a terminal state. */
export interface AfterWorkflowHook {
  name: string
  execute(ctx: WorkflowContext, result: WorkflowResult): Promise<void>
}

/** Hook executed before a single step runs. */
export interface BeforeStepHook {
  name: string
  execute(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<void>
}

/** Hook executed after a single step completes. */
export interface AfterStepHook {
  name: string
  execute(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
    result: StepExecutionResult,
  ): Promise<void>
}

/**
 * Error thrown by a hook to signal a FATAL failure that MUST stop the
 * workflow. Non-fatal hook failures are logged and swallowed; fatal
 * failures propagate up to the executor.
 */
export class FatalHookError extends Error {
  readonly fatal = true
  constructor(message: string) {
    super(message)
    this.name = 'FatalHookError'
  }
}

/**
 * Registry that owns all four hook lists and exposes `run*` methods for
 * the workflow executor to invoke. Hooks run in registration order.
 *
 * Failure handling:
 *   - A hook throwing a `FatalHookError` (or any error with `fatal: true`)
 *     propagates out of the `run*` method and aborts the workflow.
 *   - Any other thrown error is logged at `warn` and the next hook runs.
 */
export class HookRegistry {
  private readonly beforeWorkflowHooks: BeforeWorkflowHook[] = []
  private readonly afterWorkflowHooks: AfterWorkflowHook[] = []
  private readonly beforeStepHooks: BeforeStepHook[] = []
  private readonly afterStepHooks: AfterStepHook[] = []

  // ----- Registration -----------------------------------------------------

  registerBeforeWorkflow(hook: BeforeWorkflowHook): void {
    this.beforeWorkflowHooks.push(hook)
  }
  registerAfterWorkflow(hook: AfterWorkflowHook): void {
    this.afterWorkflowHooks.push(hook)
  }
  registerBeforeStep(hook: BeforeStepHook): void {
    this.beforeStepHooks.push(hook)
  }
  registerAfterStep(hook: AfterStepHook): void {
    this.afterStepHooks.push(hook)
  }

  // ----- Execution --------------------------------------------------------

  /** Run every registered `BeforeWorkflowHook` in order. */
  async runBeforeWorkflow(ctx: WorkflowContext): Promise<void> {
    for (const hook of this.beforeWorkflowHooks) {
      await this.invoke(hook.name, () => hook.execute(ctx))
    }
  }

  /** Run every registered `AfterWorkflowHook` in order. */
  async runAfterWorkflow(
    ctx: WorkflowContext,
    result: WorkflowResult,
  ): Promise<void> {
    for (const hook of this.afterWorkflowHooks) {
      await this.invoke(hook.name, () => hook.execute(ctx, result))
    }
  }

  /** Run every registered `BeforeStepHook` in order. */
  async runBeforeStep(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<void> {
    for (const hook of this.beforeStepHooks) {
      await this.invoke(hook.name, () => hook.execute(ctx, step))
    }
  }

  /** Run every registered `AfterStepHook` in order. */
  async runAfterStep(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
    result: StepExecutionResult,
  ): Promise<void> {
    for (const hook of this.afterStepHooks) {
      await this.invoke(hook.name, () => hook.execute(ctx, step, result))
    }
  }

  // ----- Diagnostics ------------------------------------------------------

  /** Count of registered hooks (per phase). */
  counts(): Record<string, number> {
    return {
      beforeWorkflow: this.beforeWorkflowHooks.length,
      afterWorkflow: this.afterWorkflowHooks.length,
      beforeStep: this.beforeStepHooks.length,
      afterStep: this.afterStepHooks.length,
    }
  }

  // ----- Internal ---------------------------------------------------------

  /**
   * Invoke a single hook, logging + swallowing non-fatal errors. Fatal
   * errors propagate.
   */
  private async invoke(
    hookName: string,
    fn: () => Promise<void>,
  ): Promise<void> {
    try {
      await fn()
    } catch (err) {
      if (isFatal(err)) {
        logger.error(
          { hookName, err: err instanceof Error ? err.message : 'fatal' },
          'HookRegistry: fatal hook error; aborting',
        )
        throw err
      }
      logger.warn(
        {
          hookName,
          err: err instanceof Error ? err.message : 'non-fatal',
        },
        'HookRegistry: hook threw; continuing',
      )
    }
  }
}

/** Type guard: does the given value carry a `fatal: true` flag? */
function isFatal(err: unknown): boolean {
  if (err === null || typeof err !== 'object') return false
  return (err as { fatal?: unknown }).fatal === true
}
