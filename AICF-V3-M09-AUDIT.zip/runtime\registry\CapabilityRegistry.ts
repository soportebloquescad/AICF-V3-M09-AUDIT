// =============================================================================
// AICF V3 — Capability Registry (Sprint 16: Runtime Plugin Integration)
// Sprint 17: Discovery Engine (lookup, queries, best-match, version/tag filter)
// =============================================================================
// Indexes modules by their capabilities. Allows the Runtime to answer:
//   - "Which modules provide capability X?"
//   - "What capabilities does module Y have?"
//
// Sprint 17 additions:
//   - CapabilityQuery + CapabilityResult types
//   - lookupFirst / lookupAll / lookupByCapability / lookupByTag /
//     lookupByVersion / getBestMatch / getByPriority
//   - registerModuleInfo(moduleId, { version, priority, tags, health })
//   - Internal `moduleInfo` map for answering rich discovery queries
//
// The registry is populated when modules are registered in ModuleRegistry.
// =============================================================================

import type { CapabilityDescriptor } from '../contracts/Capabilities'
import { logger } from '@/lib/ai/logger'

/**
 * Discovery query for finding modules by capability + filters.
 */
export interface CapabilityQuery {
  /** Required capability string. */
  capability: string
  /** Optional version filter (exact match). */
  version?: string
  /** Optional exact-priority filter. */
  priority?: number
  /** Optional tag filter (module must have ALL listed tags). */
  tags?: string[]
  /** Optional minimum priority (inclusive). */
  minPriority?: number
  /** Optional maximum priority (inclusive). */
  maxPriority?: number
}

/**
 * Health level tracked per module for discovery queries.
 */
export type ModuleHealthLevel = 'healthy' | 'degraded' | 'unhealthy'

/**
 * A single discovery result: which module provides a capability, plus its
 * version, priority, tags, and current health.
 */
export interface CapabilityResult {
  moduleId: string
  capability: string
  version: string
  priority: number
  tags: string[]
  health: ModuleHealthLevel
}

/**
 * Extra per-module info tracked for discovery queries. Populated by the
 * bootstrap when a module is registered with metadata.
 */
interface ModuleInfo {
  version: string
  priority: number
  tags: string[]
  health: ModuleHealthLevel
}

/**
 * Registry that indexes modules by their capabilities.
 *
 * @example
 * const registry = new CapabilityRegistry()
 * registry.register('content-intelligence', ['routeModel', 'applyPolicy'])
 * registry.register('infrastructure', ['chatCompletion', 'health'])
 *
 * const modules = registry.getModulesByCapability('chatCompletion')
 * // → ['infrastructure']
 *
 * const caps = registry.getCapabilities('content-intelligence')
 * // → ['routeModel', 'applyPolicy']
 */
export class CapabilityRegistry {
  private readonly moduleToCapabilities = new Map<string, string[]>()
  private readonly capabilityToModules = new Map<string, Set<string>>()
  /** Sprint 17: per-module info for discovery queries. */
  private readonly moduleInfo = new Map<string, ModuleInfo>()

  /**
   * Registers a module's capabilities.
   * Overwrites any previous registration for the same module.
   */
  register(moduleId: string, capabilities: string[]): void {
    this.moduleToCapabilities.set(moduleId, [...capabilities])

    // Index: capability → modules
    for (const cap of capabilities) {
      let modules = this.capabilityToModules.get(cap)
      if (!modules) {
        modules = new Set()
        this.capabilityToModules.set(cap, modules)
      }
      modules.add(moduleId)
    }

    logger.debug(
      { moduleId, capabilities },
      'CapabilityRegistry: module registered',
    )
  }

  /**
   * Unregisters a module and all its capability mappings.
   */
  unregister(moduleId: string): void {
    const caps = this.moduleToCapabilities.get(moduleId)
    if (!caps) return

    for (const cap of caps) {
      const modules = this.capabilityToModules.get(cap)
      if (modules) {
        modules.delete(moduleId)
        if (modules.size === 0) {
          this.capabilityToModules.delete(cap)
        }
      }
    }

    this.moduleToCapabilities.delete(moduleId)
    this.moduleInfo.delete(moduleId)
    logger.debug({ moduleId }, 'CapabilityRegistry: module unregistered')
  }

  /**
   * Returns the capabilities of a module (or empty array if unknown).
   */
  getCapabilities(moduleId: string): string[] {
    return this.moduleToCapabilities.get(moduleId) || []
  }

  /**
   * Returns the list of module IDs that provide a given capability.
   */
  getModulesByCapability(capability: string): string[] {
    const modules = this.capabilityToModules.get(capability)
    return modules ? Array.from(modules) : []
  }

  /**
   * Returns all registered module IDs.
   */
  getModules(): string[] {
    return Array.from(this.moduleToCapabilities.keys())
  }

  /**
   * Returns all registered capabilities (across all modules).
   */
  getAllCapabilities(): string[] {
    return Array.from(this.capabilityToModules.keys())
  }

  /**
   * Returns true if a module provides a given capability.
   */
  hasCapability(moduleId: string, capability: string): boolean {
    const caps = this.moduleToCapabilities.get(moduleId)
    return Boolean(caps && caps.includes(capability))
  }

  /**
   * Returns full capability descriptors (for the /api/runtime/capabilities endpoint).
   */
  getDescriptors(): CapabilityDescriptor[] {
    const descriptors: CapabilityDescriptor[] = []
    for (const [moduleId, capabilities] of this.moduleToCapabilities) {
      for (const capability of capabilities) {
        descriptors.push({ capability, moduleId })
      }
    }
    return descriptors
  }

  /**
   * Returns a serializable snapshot (for the API endpoint).
   */
  snapshot(): Array<{ moduleId: string; capabilities: string[] }> {
    return Array.from(this.moduleToCapabilities.entries()).map(([moduleId, capabilities]) => ({
      moduleId,
      capabilities,
    }))
  }

  /**
   * Clears all registrations.
   */
  clear(): void {
    this.moduleToCapabilities.clear()
    this.capabilityToModules.clear()
    this.moduleInfo.clear()
  }

  // ===========================================================================
  // Sprint 17 — Discovery Engine
  // ===========================================================================

  /**
   * Registers per-module info needed for discovery queries (version, priority,
   * tags, health). Called by RuntimeBootstrap when a module is registered with
   * metadata. Overwrites any previous info for the same module.
   */
  registerModuleInfo(
    moduleId: string,
    info: { version: string; priority: number; tags: string[]; health: ModuleHealthLevel },
  ): void {
    this.moduleInfo.set(moduleId, {
      version: info.version,
      priority: info.priority,
      tags: [...info.tags],
      health: info.health,
    })
    logger.debug(
      { moduleId, version: info.version, priority: info.priority, tags: info.tags, health: info.health },
      'CapabilityRegistry: module info registered',
    )
  }

  /**
   * Updates the health of a registered module (without re-registering all info).
   */
  updateModuleHealth(moduleId: string, health: ModuleHealthLevel): void {
    const info = this.moduleInfo.get(moduleId)
    if (info) {
      info.health = health
    }
  }

  /**
   * Builds a CapabilityResult for a (moduleId, capability) pair. Returns null
   * if the module isn't registered or doesn't have that capability.
   */
  private buildResult(moduleId: string, capability: string): CapabilityResult | null {
    if (!this.hasCapability(moduleId, capability)) return null
    const info = this.moduleInfo.get(moduleId)
    return {
      moduleId,
      capability,
      version: info?.version || '0.0.0',
      priority: info?.priority ?? Number.MAX_SAFE_INTEGER,
      tags: info?.tags ? [...info.tags] : [],
      health: info?.health || 'unhealthy',
    }
  }

  /**
   * Returns the first module that provides the given capability, or null.
   * Order is the registry's internal iteration order.
   */
  lookupFirst(capability: string): CapabilityResult | null {
    const modules = this.getModulesByCapability(capability)
    for (const moduleId of modules) {
      const result = this.buildResult(moduleId, capability)
      if (result) return result
    }
    return null
  }

  /**
   * Returns all modules matching the discovery query (capability + filters).
   * Filters: version (exact), priority (exact), tags (subset match — module
   * must have all query tags), minPriority/maxPriority (inclusive range).
   */
  lookupAll(query: CapabilityQuery): CapabilityResult[] {
    const modules = this.getModulesByCapability(query.capability)
    const results: CapabilityResult[] = []
    for (const moduleId of modules) {
      const result = this.buildResult(moduleId, query.capability)
      if (!result) continue

      if (query.version !== undefined && result.version !== query.version) continue
      if (query.priority !== undefined && result.priority !== query.priority) continue
      if (query.minPriority !== undefined && result.priority < query.minPriority) continue
      if (query.maxPriority !== undefined && result.priority > query.maxPriority) continue
      if (query.tags && query.tags.length > 0) {
        const hasAll = query.tags.every((t) => result.tags.includes(t))
        if (!hasAll) continue
      }
      results.push(result)
    }
    return results
  }

  /**
   * Returns all modules that provide the given capability.
   */
  lookupByCapability(capability: string): CapabilityResult[] {
    return this.getModulesByCapability(capability)
      .map((id) => this.buildResult(id, capability))
      .filter((r): r is CapabilityResult => r !== null)
  }

  /**
   * Returns all modules that have the given tag (across all capabilities).
   * Each module appears once per capability it provides.
   */
  lookupByTag(tag: string): CapabilityResult[] {
    const results: CapabilityResult[] = []
    for (const [moduleId, capabilities] of this.moduleToCapabilities) {
      const info = this.moduleInfo.get(moduleId)
      if (!info?.tags.includes(tag)) continue
      for (const capability of capabilities) {
        const result = this.buildResult(moduleId, capability)
        if (result) results.push(result)
      }
    }
    return results
  }

  /**
   * Returns all modules whose registered version matches the given version
   * (exact string match). Each module appears once per capability it provides.
   */
  lookupByVersion(version: string): CapabilityResult[] {
    const results: CapabilityResult[] = []
    for (const [moduleId, capabilities] of this.moduleToCapabilities) {
      const info = this.moduleInfo.get(moduleId)
      if (!info || info.version !== version) continue
      for (const capability of capabilities) {
        const result = this.buildResult(moduleId, capability)
        if (result) results.push(result)
      }
    }
    return results
  }

  /**
   * Returns the best match for a capability: the module with the lowest
   * priority number that is currently 'healthy' or 'degraded'. Modules with
   * 'unhealthy' status are skipped. Returns null if no module provides the
   * capability or all are unhealthy.
   */
  getBestMatch(capability: string): CapabilityResult | null {
    const candidates = this.lookupByCapability(capability)
      .filter((r) => r.health !== 'unhealthy')
      .sort((a, b) => {
        // Lower priority = better. Ties broken by health (healthy > degraded).
        if (a.priority !== b.priority) return a.priority - b.priority
        const healthRank = (h: ModuleHealthLevel): number =>
          h === 'healthy' ? 0 : h === 'degraded' ? 1 : 2
        return healthRank(a.health) - healthRank(b.health)
      })
    return candidates[0] || null
  }

  /**
   * Returns all modules providing a capability whose priority is at least
   * `minPriority` (inclusive). Sorted by priority ascending.
   */
  getByPriority(capability: string, minPriority: number): CapabilityResult[] {
    return this.lookupByCapability(capability)
      .filter((r) => r.priority >= minPriority)
      .sort((a, b) => a.priority - b.priority)
  }
}
