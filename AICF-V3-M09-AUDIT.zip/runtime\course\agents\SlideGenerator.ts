// =============================================================================
// AICF V3 — Slide Generator Agent
// =============================================================================
// Generates presentation slides for the lessons. Reads `context.lessons`
// (produced by LessonWriter) to decide what to cover. Each lesson yields
// 4-5 slides with a title, 3-5 bullets, and speaker notes.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, normalizeLevel, readContext } from './agentUtils'

export interface SlideGeneratorDeps {
  aiAdapter: AIAdapter | null
}

interface Slide {
  title: string
  bullets: string[]
  notes: string
}

interface LessonSlides {
  lessonTitle: string
  slides: Slide[]
}

interface SlidesPayload {
  slides: Slide[]
}

interface LessonShape {
  title: string
  content?: string
}

export class SlideGenerator implements Agent {
  public readonly name = 'slide-generator'

  constructor(private readonly deps: SlideGeneratorDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const lessons = collectLessons(input)
      const ai = this.deps.aiAdapter
      const allSlides: Slide[] = []
      const byLesson: LessonSlides[] = []

      for (const lesson of lessons) {
        const aiResult = await callAI(ai, buildPrompt(input, lesson), {
          systemPrompt:
            'You are a presentation designer for educational content. Respond with valid JSON only.',
          temperature: 0.5,
          maxTokens: 1100,
        })
        let slides: Slide[]
        if (aiResult.ok && aiResult.content) {
          const parsed = extractJSON<{ slides?: unknown[] }>(aiResult.content)
          slides = coerceSlides(parsed)
          if (slides.length === 0) {
            slides = fallbackSlides(input, lesson)
          }
        } else {
          slides = fallbackSlides(input, lesson)
        }
        allSlides.push(...slides)
        byLesson.push({ lessonTitle: lesson.title, slides })
      }

      // The payload exposes a flat list of slides per the contract. We also
      // attach the per-lesson breakdown inside the result for downstream
      // consumers that need it.
      const payload: SlidesPayload & { byLesson: LessonSlides[] } = {
        slides: allSlides,
        byLesson,
      }

      return {
        agentName: this.name,
        result: payload as unknown as Record<string, unknown>,
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function collectLessons(input: AgentInput): LessonShape[] {
  const lessons = readContext<LessonShape[]>(input.context, 'lessons')
  if (Array.isArray(lessons) && lessons.length > 0) {
    return lessons.filter((l) => l && typeof l.title === 'string').slice(0, 12)
  }
  return [{ title: `${input.topic} - Overview` }]
}

function buildPrompt(input: AgentInput, lesson: LessonShape): string {
  return [
    `Generate 4-5 presentation slides for the lesson titled "${lesson.title}".`,
    `Course topic: "${input.topic}". Audience: ${input.audience}. Level: ${input.level}.`,
    `Lesson content excerpt: ${(lesson.content ?? '').slice(0, 400)}`,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "slides": [`,
    `    {`,
    `      "title": string,`,
    `      "bullets": string[],   // 3-5 concise bullets`,
    `      "notes": string        // speaker notes, 1-2 sentences`,
    `    }`,
    `  ]`,
    `}`,
  ].join('\n')
}

function coerceSlides(parsed: { slides?: unknown[] } | null): Slide[] {
  if (!parsed || !Array.isArray(parsed.slides)) return []
  const out: Slide[] = []
  for (const raw of parsed.slides) {
    if (!raw || typeof raw !== 'object') continue
    const r = raw as Record<string, unknown>
    const title = r.title
    const bullets = r.bullets
    const notes = r.notes
    if (
      typeof title === 'string' &&
      title.length > 0 &&
      Array.isArray(bullets) &&
      bullets.length >= 2 &&
      bullets.every((b) => typeof b === 'string' && b.length > 0) &&
      typeof notes === 'string' &&
      notes.length > 0
    ) {
      out.push({
        title,
        bullets: (bullets as string[]).slice(0, 6),
        notes,
      })
    }
  }
  return out.slice(0, 6)
}

function fallbackSlides(input: AgentInput, lesson: LessonShape): Slide[] {
  const topic = input.topic
  const level = normalizeLevel(input.level)
  const title = lesson.title
  return [
    {
      title: title,
      bullets: [
        `Introduction to ${title}`,
        `Why this matters in ${topic}`,
        `What you will learn`,
      ],
      notes: `Open with a hook that connects ${title} to the learners' goals. Establish relevance before diving into content. Aim the depth at the ${level} level.`,
    },
    {
      title: `Key Concepts`,
      bullets: [
        `Definition of ${title}`,
        `Core terminology`,
        `Relationship to ${topic}`,
      ],
      notes: `Anchor each term with a concrete example. Pause for questions after the second bullet to check understanding.`,
    },
    {
      title: `Worked Example`,
      bullets: [
        `Step 1: Identify the inputs`,
        `Step 2: Apply the core technique`,
        `Step 3: Verify the result`,
      ],
      notes: `Walk through each step deliberately. Invite learners to predict the next step before revealing it.`,
    },
    {
      title: `Common Pitfalls`,
      bullets: [
        `Misapplying the technique`,
        `Ignoring boundary conditions`,
        `Skipping validation`,
      ],
      notes: `Frame pitfalls as learning opportunities, not failures. Share a brief anecdote if available.`,
    },
    {
      title: `Summary and Next Steps`,
      bullets: [
        `Recap of key points`,
        `Practice exercise prompt`,
        `Preview of the next lesson`,
      ],
      notes: `Close with a clear call to action. Remind learners of the practice exercise and where to get help.`,
    },
  ]
}
