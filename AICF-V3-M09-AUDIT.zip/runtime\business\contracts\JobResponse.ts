// =============================================================================
// AICF V3 — Business Job Response Contract (Épica 2 — AI Factory Core)
// =============================================================================
// The payload that exits the Business layer for a JobRequest. Mirrors the
// RuntimeResponse shape, but specialized for jobs:
//   - `status` is a state machine ('pending' | 'running' | 'completed' |
//     'failed' | 'cancelled') rather than a boolean `ok`.
//   - `output` is the structured result (typed by DTOs in shared/dtos.ts).
//   - `artifacts` lists every artifact produced (id + type + name) — the
//     Business layer's equivalent of pipeline stage results.
//   - `metrics` reports token usage, cost, and provider call counts so the
//     caller can attribute consumption back to a job.
//
// All factories are fully functional (no stubs). No `any`.
// =============================================================================

/**
 * State machine for a job's lifecycle.
 */
export type JobStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled'

/**
 * A single artifact produced by a job. The Business layer tracks these for
 * the dashboard + audit trail.
 */
export interface JobArtifact {
  /** Unique artifact ID. */
  id: string
  /** Artifact type (e.g. 'course', 'slides', 'quiz', 'document', 'pdf'). */
  type: string
  /** Human-readable name (e.g. 'intro-to-rust.pdf'). */
  name: string
}

/**
 * Resource consumption metrics for a single job.
 */
export interface JobMetrics {
  /** Total tokens used across all provider calls. */
  tokensUsed?: number
  /** Estimated USD cost. */
  cost?: number
  /** Number of provider calls made (LLM + embedding). */
  providerCalls?: number
}

/**
 * The result of executing a JobRequest.
 */
export interface JobResponse {
  /** The job this response belongs to. */
  jobId: string

  /** Final status of the job. */
  status: JobStatus

  /** Structured output (present when status === 'completed'). */
  output?: Record<string, unknown>

  /** Error message (present when status === 'failed'). */
  error?: string

  /** ISO timestamp when the job started running. */
  startedAt: string

  /** ISO timestamp when the job finished (completed/failed/cancelled). */
  completedAt?: string

  /** Wall-clock duration in milliseconds. */
  durationMs: number

  /** Artifacts produced by the job. */
  artifacts?: JobArtifact[]

  /** Resource consumption metrics. */
  metrics?: JobMetrics
}

/**
 * Factory: creates a JobResponse from a jobId + status, with optional
 * overrides for every other field. `startedAt` defaults to now; `durationMs`
 * defaults to 0.
 *
 * @example
 * const res = createJobResponse('job-1', 'completed', {
 *   output: { title: 'Intro to Rust' },
 *   durationMs: 1234,
 * })
 */
export function createJobResponse(
  jobId: string,
  status: JobStatus,
  opts?: Partial<JobResponse>,
): JobResponse {
  const startedAt = opts?.startedAt ?? new Date().toISOString()
  const durationMs = opts?.durationMs ?? 0
  return {
    jobId,
    status,
    startedAt,
    durationMs,
    output: opts?.output,
    error: opts?.error,
    completedAt: opts?.completedAt,
    artifacts: opts?.artifacts,
    metrics: opts?.metrics,
  }
}
