// =============================================================================
// AICF V3 — Sprint 13+14 — Conditional Provider
// =============================================================================
// Provider that fulfills the `'conditional'` capability. Evaluates a
// condition expression against the runtime variables and returns which
// branch the workflow should take (`'true'` or `'false'`). Used by the
// orchestrator to implement branching DAGs without coupling condition
// logic to a specific step type.
//
// Sprint 13+14 spec requirements covered:
//   - `IProvider` interface compliance
//   - Reads `condition` from `input.condition`
//   - Reads variables from `input.variables` (falls back to `ctx.variables`)
//   - Returns `output: { branch: 'true' | 'false', value: boolean }`
// =============================================================================

import type {
  IProvider,
  ProviderCapability,
  ProviderManifest,
  StepExecutionResult,
} from '@/lib/runtime/interfaces'
import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/**
 * Provider that evaluates condition expressions. Thread-safe across
 * executions.
 */
export class ConditionalProvider implements IProvider {
  readonly name = 'conditional'
  readonly capabilities: ProviderCapability[] = ['conditional']
  private ready = false

  /** Initialize the provider. Marks itself ready. */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug({ provider: this.name }, 'conditional provider initialized')
  }

  /** Whether `initialize` has been called. */
  isReady(): boolean {
    return this.ready
  }

  /** Self-describing manifest for the registry / UI. */
  getManifest(): ProviderManifest {
    return {
      name: this.name,
      version: '1.0.0',
      capabilities: [...this.capabilities],
      config: {},
      description: 'Evaluates a condition expression and returns the branch to take',
    }
  }

  /**
   * Execute the `'conditional'` capability.
   *
   * Input shape (read from `input`):
   *   - `condition`: `string` (required) — the expression to evaluate
   *   - `variables`: `Record<string, unknown>` (optional; falls back to
   *     `ctx.variables`)
   *
   * Supported condition syntaxes (best-effort, intentionally minimal):
   *   - `'true'` / `'false'` literals
   *   - `'{{someVar}}'` — truthiness of the resolved value
   *   - `'{{a}} == {{b}}'` — string equality after resolution
   *   - `'{{a}} != {{b}}'` — string inequality after resolution
   *
   * Output shape:
   *   - `branch`: `'true'` | `'false'`
   *   - `value`: `boolean`
   */
  async execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    if (capability !== 'conditional') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `conditional provider cannot handle capability "${capability}"`,
      }
    }

    const start = Date.now()
    const condition =
      typeof input.condition === 'string' ? input.condition : ''
    if (!condition) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: Date.now() - start,
        error: 'input.condition is required',
      }
    }

    const variables =
      input.variables && typeof input.variables === 'object' &&
      !Array.isArray(input.variables)
        ? (input.variables as Record<string, unknown>)
        : ctx.variables

    const value = this.evaluate(condition, variables)

    return {
      ok: true,
      output: { branch: value ? 'true' : 'false', value },
      artifacts: [],
      durationMs: Date.now() - start,
    }
  }

  /**
   * Evaluate a condition expression. Resolves `{{var}}` placeholders first,
   * then applies the comparison operator (if any). Anything that cannot
   * be evaluated is treated as `false`.
   */
  private evaluate(
    condition: string,
    variables: Record<string, unknown>,
  ): boolean {
    const resolved = this.resolvePlaceholders(condition, variables)

    // Equality / inequality check.
    const eqMatch = /^(.+?)\s*(==|!=)\s*(.+)$/.exec(resolved)
    if (eqMatch) {
      const left = eqMatch[1].trim().replace(/^['"]|['"]$/g, '')
      const op = eqMatch[2]
      const right = eqMatch[3].trim().replace(/^['"]|['"]$/g, '')
      return op === '==' ? left === right : left !== right
    }

    if (resolved === 'true') return true
    if (resolved === 'false' || resolved === '') return false
    return resolved !== 'false' && resolved !== '0' && resolved.length > 0
  }

  /** Resolve `{{var|default}}` placeholders in `str`. */
  private resolvePlaceholders(
    str: string,
    variables: Record<string, unknown>,
  ): string {
    return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (full, expr: string) => {
      const value = this.lookup(expr, variables)
      if (value === undefined || value === null) return full
      if (typeof value === 'string') return value
      return JSON.stringify(value)
    })
  }

  /** Dot-notation lookup with optional `|default` suffix. */
  private lookup(
    expr: string,
    variables: Record<string, unknown>,
  ): unknown {
    const pipeIdx = expr.indexOf('|')
    let path: string
    let hasDefault = false
    let defaultValue = ''
    if (pipeIdx >= 0) {
      path = expr.slice(0, pipeIdx).trim()
      hasDefault = true
      defaultValue = expr.slice(pipeIdx + 1)
    } else {
      path = expr.trim()
    }

    const parts = path.split('.').filter((p) => p.length > 0)
    let cur: unknown = variables
    for (const p of parts) {
      if (cur && typeof cur === 'object' && !Array.isArray(cur)) {
        cur = (cur as Record<string, unknown>)[p]
      } else {
        cur = undefined
        break
      }
    }
    if (cur === undefined || cur === null) {
      return hasDefault ? defaultValue : undefined
    }
    return cur
  }
}
