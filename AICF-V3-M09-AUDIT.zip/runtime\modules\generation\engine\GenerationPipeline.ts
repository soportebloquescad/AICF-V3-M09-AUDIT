// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Generation Pipeline
// =============================================================================
// Runs a single generation request through a fixed four-stage pipeline:
//
//   prepare  → validate inputs + ensure the generator can handle the
//              requested content type (no AI calls).
//   generate → delegate to the underlying `IGenerator.generate(...)`.
//   validate → sanity-check the generator output (`ok` flag, non-empty
//              content body, at least one artifact).
//   finalize → emit `generation.completed` event (when an event bus is
//              supplied) and return the result.
//
// Also exposes `dryRun(...)`, which estimates token usage / cost / duration
// WITHOUT calling the AI adapter, using a simple heuristic:
//   - 500 prompt tokens baseline
//   - 200 tokens per requested module / slide / question / section
//   - 1.5x prompt tokens as the completion estimate
//   - estimated cost = total tokens * COST_PER_TOKEN
//
// Sprint 13+14 spec requirements covered:
//   - Predictable, observable execution path with stage logging
//   - `generation.completed` event emission (pluggable event bus)
//   - Side-effect-free dry-run that nonetheless returns a realistic
//     `DryRunResult` for budget / policy checks
// =============================================================================

import type {
  GeneratorInput,
  GeneratorOutput,
  IEventBus,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  DryRunResult,
  TokenUsage,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { createEvent } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Per-token cost estimate (platform currency units). */
const COST_PER_TOKEN = 0.000_002

/** Baseline prompt tokens for any generation (system + framing). */
const BASE_PROMPT_TOKENS = 500

/** Per-module prompt-token increment. */
const PER_MODULE_TOKENS = 200

/** Estimated duration per module / slide / question / section, in ms. */
const PER_MODULE_DURATION_MS = 1_500

/** Fixed duration baseline for the outline call. */
const BASE_DURATION_MS = 2_000

/**
 * Generation pipeline. Wraps a single `IGenerator` with stage logging,
 * post-generation validation, and `generation.completed` event emission.
 */
export class GenerationPipeline {
  private readonly generator: IGenerator
  private readonly eventBus: IEventBus | null

  constructor(generator: IGenerator, eventBus?: IEventBus) {
    this.generator = generator
    this.eventBus = eventBus ?? null
  }

  /**
   * Run the generator through the four-stage pipeline. Always returns a
   * `GeneratorOutput` (never throws — errors are captured in
   * `output.error`).
   */
  public async run(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const startMs = Date.now()

    // --- Stage 1: prepare ------------------------------------------------
    logger.debug(
      {
        stage: 'prepare',
        generator: this.generator.name,
        executionId: ctx.executionId,
        contentType: input.contentType,
        topic: input.topic,
      },
      'GenerationPipeline: prepare',
    )

    if (!this.generator.canHandle(input.contentType)) {
      const error = `generator "${this.generator.name}" cannot handle content type "${input.contentType}"`
      logger.warn(
        { generator: this.generator.name, contentType: input.contentType },
        'GenerationPipeline: cannot handle content type',
      )
      return {
        ok: false,
        content: '',
        artifacts: [],
        error,
      }
    }

    // --- Stage 2: generate ----------------------------------------------
    logger.debug(
      {
        stage: 'generate',
        generator: this.generator.name,
        executionId: ctx.executionId,
      },
      'GenerationPipeline: generate',
    )

    let output: GeneratorOutput
    try {
      output = await this.generator.generate(input, ctx)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.error(
        { generator: this.generator.name, executionId: ctx.executionId, error: message },
        'GenerationPipeline: generate threw',
      )
      output = { ok: false, content: '', artifacts: [], error: message }
    }

    // --- Stage 3: validate ----------------------------------------------
    logger.debug(
      {
        stage: 'validate',
        generator: this.generator.name,
        executionId: ctx.executionId,
        ok: output.ok,
        artifactCount: output.artifacts.length,
      },
      'GenerationPipeline: validate',
    )

    if (output.ok) {
      const validationWarnings: string[] = []
      if (output.content.length === 0) {
        validationWarnings.push('output.content is empty')
      }
      if (output.artifacts.length === 0) {
        validationWarnings.push('output.artifacts is empty')
      }
      if (validationWarnings.length > 0) {
        logger.warn(
          {
            generator: this.generator.name,
            executionId: ctx.executionId,
            warnings: validationWarnings,
          },
          'GenerationPipeline: validation warnings',
        )
      }
    }

    // --- Stage 4: finalize ----------------------------------------------
    logger.debug(
      {
        stage: 'finalize',
        generator: this.generator.name,
        executionId: ctx.executionId,
        durationMs: Date.now() - startMs,
      },
      'GenerationPipeline: finalize',
    )

    if (this.eventBus) {
      try {
        await this.eventBus.publish(
          createEvent(
            'generation.completed',
            {
              generator: this.generator.name,
              contentType: input.contentType,
              topic: input.topic,
              ok: output.ok,
              artifactIds: output.artifacts.map((a) => a.id),
              ...(output.tokensUsed !== undefined
                ? { tokens: output.tokensUsed.totalTokens }
                : {}),
              ...(output.cost !== undefined ? { cost: output.cost } : {}),
              durationMs: Date.now() - startMs,
            },
            {
              executionId: ctx.executionId,
              correlationId: ctx.correlationId,
              stepId: this.generator.name,
            },
          ),
        )
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err)
        logger.warn(
          {
            generator: this.generator.name,
            executionId: ctx.executionId,
            error: message,
          },
          'GenerationPipeline: event publish failed',
        )
      }
    }

    return output
  }

  /**
   * Estimate token usage / cost / duration WITHOUT calling the AI adapter.
   *
   * Heuristic:
   *   - prompt tokens  = 500 + 200 * modules
   *   - completion tokens = 1.5 * prompt tokens
   *   - total tokens   = prompt + completion
   *   - estimated cost = total tokens * COST_PER_TOKEN
   *   - estimated duration = 2000 + 1500 * modules
   *
   * Always returns `canExecute = true` when the generator claims the
   * content type; otherwise reports `canExecute = false` with a warning.
   */
  public async dryRun(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<DryRunResult> {
    const warnings: string[] = []
    const canHandle = this.generator.canHandle(input.contentType)
    if (!canHandle) {
      warnings.push(
        `generator "${this.generator.name}" cannot handle content type "${input.contentType}"`,
      )
    }

    const moduleCount = input.modules ?? defaultModuleCount(input.contentType)
    const promptTokens = BASE_PROMPT_TOKENS + PER_MODULE_TOKENS * moduleCount
    const completionTokens = Math.round(promptTokens * 1.5)
    const totalTokens = promptTokens + completionTokens
    const estimatedTokens: TokenUsage = {
      promptTokens,
      completionTokens,
      totalTokens,
    }
    const estimatedCost = totalTokens * COST_PER_TOKEN
    const estimatedDurationMs =
      BASE_DURATION_MS + PER_MODULE_DURATION_MS * moduleCount

    logger.debug(
      {
        generator: this.generator.name,
        executionId: ctx.executionId,
        contentType: input.contentType,
        moduleCount,
        canExecute: canHandle,
        estimatedTokens: totalTokens,
        estimatedCost,
      },
      'GenerationPipeline: dryRun',
    )

    return {
      canExecute: canHandle,
      estimatedTokens,
      estimatedCost,
      estimatedDurationMs,
      stepsPlanned: canHandle
        ? ['prepare', 'generate', 'validate', 'finalize']
        : [],
      providerSelection: canHandle
        ? {
            generate: this.generator.name,
          }
        : {},
      warnings,
    }
  }
}

/** Default module count per content type when `input.modules` is unset. */
function defaultModuleCount(contentType: string): number {
  switch (contentType) {
    case 'course':
      return 5
    case 'presentation':
      return 10
    case 'quiz':
      return 10
    case 'document':
      return 5
    default:
      return 5
  }
}
