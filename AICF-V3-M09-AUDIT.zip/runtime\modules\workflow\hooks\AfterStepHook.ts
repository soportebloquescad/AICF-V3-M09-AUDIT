// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — After-Step Hook
// =============================================================================
// Re-exports `HookRegistry` and `FatalHookError` from `BeforeWorkflowHook`
// (single source of truth) and defines the `AfterStepHook` interface.
// =============================================================================

export type { AfterStepHook } from './BeforeWorkflowHook'
export { HookRegistry, FatalHookError } from './BeforeWorkflowHook'
