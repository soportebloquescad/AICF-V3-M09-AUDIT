// =============================================================================
// AICF V3 — Subfase E — QualityEngine
// =============================================================================
// Validates a CourseResult from the CoursePipeline.
//
// REUSES the existing QualityAssurance (src/lib/runtime/course/
// QualityAssurance.ts) which has 6 validators + reasons + warnings.
// This engine is a thin facade that:
//   1. Delegates validation to QualityAssurance
//   2. Adds pipeline-level checks (placeholder detection, minimum word count)
//   3. Returns a QualityResult with score, threshold, errors, warnings
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { QualityAssurance } from '../course/QualityAssurance'
import type { CourseResult, QualityReport } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

/** The quality threshold (courses below this are considered failing). */
export const QUALITY_THRESHOLD = 80

/** Minimum total word count for a premium course. */
export const MIN_WORD_COUNT = 500

/**
 * The result of quality validation.
 */
export interface QualityResult {
  /** Overall score (0-100). */
  readonly score: number
  /** Whether the course passed the quality threshold. */
  readonly passed: boolean
  /** The threshold used. */
  readonly threshold: number
  /** Detailed error messages (empty when passed). */
  readonly errors: string[]
  /** Non-fatal warnings. */
  readonly warnings: string[]
  /** The full QualityReport from QualityAssurance (if available). */
  readonly report: QualityReport | null
  /** ISO timestamp of validation. */
  readonly timestamp: string
}

/**
 * The Quality Engine — validates CoursePipeline results.
 *
 * REUSES QualityAssurance for the 6-validator assessment, then adds
 * pipeline-level checks (placeholder detection, minimum word count).
 */
export class QualityEngine {
  private readonly qa: QualityAssurance
  private readonly log = logger.child({ component: 'QualityEngine' })

  constructor() {
    this.qa = new QualityAssurance({ aiAdapter: null })
  }

  /**
   * Validates a CourseResult and returns a QualityResult.
   *
   * Never throws — all errors are captured in the result.
   */
  validate(course: CourseResult): QualityResult {
    const errors: string[] = []
    const warnings: string[] = []
    let report: QualityReport | null = null

    // 1. Delegate to QualityAssurance (6 validators + reasons + warnings)
    try {
      report = this.qa.validateCourse(course)
      if (report.warnings.length > 0) {
        warnings.push(...report.warnings)
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      errors.push(`QualityAssurance validation failed: ${msg}`)
      this.log.error({ error: msg }, 'QualityEngine: QualityAssurance failed')
    }

    // 2. Pipeline-level checks

    // 2a. Minimum word count
    if (course.totalWordCount < MIN_WORD_COUNT) {
      errors.push(`Total word count (${course.totalWordCount}) is below minimum (${MIN_WORD_COUNT})`)
    }

    // 2b. Placeholder detection in lessons
    for (const lesson of course.lessons) {
      const content = lesson.content.toLowerCase()
      if (content.includes('[placeholder') || content.includes('todo:') || content.includes('lorem ipsum')) {
        warnings.push(`Lesson "${lesson.title}" contains placeholder text`)
      }
    }

    // 2c. Each lesson should have exercises
    if (course.lessons.length > 0 && course.exercises.length === 0) {
      warnings.push('No exercises generated — each lesson should have exercises')
    } else if (course.exercises.length < course.lessons.length) {
      warnings.push(`Only ${course.exercises.length} exercises for ${course.lessons.length} lessons`)
    }

    // 2d. Each module should have a quiz
    if (course.modules.length > 0 && course.quizzes.length === 0) {
      warnings.push('No quizzes generated — each module should have a quiz')
    } else if (course.quizzes.length < course.modules.length) {
      warnings.push(`Only ${course.quizzes.length} quizzes for ${course.modules.length} modules`)
    }

    // 2e. Empty content check
    if (course.lessons.length === 0) {
      errors.push('No lessons generated — course has no educational content')
    }

    // 2f. Broken markdown (unclosed code blocks)
    for (const lesson of course.lessons) {
      const codeBlockCount = (lesson.content.match(/```/g) ?? []).length
      if (codeBlockCount % 2 !== 0) {
        warnings.push(`Lesson "${lesson.title}" has an unclosed code block`)
      }
    }

    // 3. Compute final score
    const score = report?.overallScore ?? (errors.length === 0 ? 100 : 0)
    const passed = score >= QUALITY_THRESHOLD && errors.length === 0

    this.log.info(
      { courseId: course.id, score, passed, errors: errors.length, warnings: warnings.length },
      'QualityEngine: validation complete',
    )

    return {
      score,
      passed,
      threshold: QUALITY_THRESHOLD,
      errors,
      warnings,
      report,
      timestamp: new Date().toISOString(),
    }
  }
}

// --- Global singleton ---
const GLOBAL_QUALITY_ENGINE_KEY = '__AICF_QUALITY_ENGINE__'

export function getGlobalQualityEngine(): QualityEngine {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_QUALITY_ENGINE_KEY]) {
    g[GLOBAL_QUALITY_ENGINE_KEY] = new QualityEngine()
  }
  return g[GLOBAL_QUALITY_ENGINE_KEY] as QualityEngine
}
