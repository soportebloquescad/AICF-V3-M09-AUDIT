// =============================================================================
// AICF V3 — Fase 3 (RC42) — CourseHtmlBuilder
// =============================================================================
// Generates a professional, interactive, responsive HTML course from a
// CourseResult. The HTML includes:
//   - Cover page with title, description, metadata
//   - Table of contents with navigation
//   - Module sections with lessons
//   - Interactive accordions for exercises
//   - Quiz sections with questions
//   - Glossary, references, metadata
//   - Progress tracking
//   - Responsive design with CSS
//   - Premium: lesson enrichment (examples, analogies, common errors, checklists)
//   - Premium: student experience (XP, badges, achievements)
//   - Premium: teacher pack link
//   - Premium: media placeholders
//   - Premium: quality intelligence score
//
// The HTML is self-contained (inline CSS + JS) and can be opened in any
// browser or converted to PDF/DOCX/EPUB.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { CourseResult } from '../course/CourseContracts'
import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import { logger } from '@/lib/ai/logger'

/**
 * The HTML course builder — produces a complete, self-contained HTML document
 * from a CourseResult.
 */
export class CourseHtmlBuilder {
  private readonly log = logger.child({ component: 'CourseHtmlBuilder' })

  /**
   * Builds the complete HTML course.
   *
   * `theme` is optional — when provided, the theme's CSS variables and base
   * styles are injected before the existing defaults. Theme variables take
   * precedence (they appear later in the cascade). When omitted, the original
   * default styling is used (backward compatibility).
   */
  build(course: CourseResult, theme?: ThemePreset): string {
    this.log.info({ courseId: course.id, title: course.title, theme: theme?.name ?? 'default' }, 'CourseHtmlBuilder: building HTML')

    const themeInjection = theme
      ? `<!-- Sprint 9 Theme Engine: ${theme.name} (${theme.label}) -->
    ${getThemeEngine().renderCssVars(theme)}`
      : ''

    const html = `<!DOCTYPE html>
<html lang="${this.escapeHtml(course.curriculum?.locale ?? 'en')}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escapeHtml(course.title)}</title>
  <style>
    ${themeInjection}
    :root {
      --primary: #2563eb;
      --primary-light: #dbeafe;
      --bg: #ffffff;
      --surface: #f8fafc;
      --text: #1e293b;
      --text-muted: #64748b;
      --border: #e2e8f0;
      --success: #16a34a;
      --warning: #f59e0b;
      --danger: #dc2626;
      --radius: 8px;
      --shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    [data-theme="dark"] {
      --primary: #3b82f6;
      --primary-light: #1e3a5f;
      --bg: #0f172a;
      --surface: #1e293b;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
      --border: #334155;
      --shadow: 0 1px 3px rgba(0,0,0,0.3);
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.7;
      transition: background 0.3s, color 0.3s;
    }
    .container { max-width: 900px; margin: 0 auto; padding: 2rem 1rem; }
    
    /* Cover */
    .cover {
      text-align: center;
      padding: 4rem 2rem;
      background: linear-gradient(135deg, var(--primary), #1e40af);
      color: white;
      border-radius: var(--radius);
      margin-bottom: 2rem;
    }
    .cover h1 { font-size: 2.5rem; margin-bottom: 1rem; font-weight: 700; }
    .cover p { font-size: 1.1rem; opacity: 0.9; max-width: 600px; margin: 0 auto 1rem; }
    .cover .meta { display: flex; justify-content: center; gap: 1.5rem; flex-wrap: wrap; margin-top: 1.5rem; font-size: 0.9rem; }
    .cover .meta span { background: rgba(255,255,255,0.2); padding: 0.3rem 0.8rem; border-radius: 20px; }
    
    /* Navigation */
    .toc {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
      margin-bottom: 2rem;
    }
    .toc h2 { font-size: 1.3rem; margin-bottom: 1rem; color: var(--primary); }
    .toc ul { list-style: none; }
    .toc li { padding: 0.4rem 0; border-bottom: 1px solid var(--border); }
    .toc li:last-child { border: none; }
    .toc a { color: var(--text); text-decoration: none; display: flex; align-items: center; gap: 0.5rem; }
    .toc a:hover { color: var(--primary); }
    .toc .module-num { background: var(--primary); color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 600; }
    
    /* Progress */
    .progress-bar {
      position: sticky;
      top: 0;
      background: var(--bg);
      padding: 0.5rem 0;
      z-index: 100;
      border-bottom: 1px solid var(--border);
    }
    .progress-track { height: 4px; background: var(--border); border-radius: 2px; overflow: hidden; }
    .progress-fill { height: 100%; background: var(--primary); transition: width 0.3s; width: 0%; }
    
    /* Module */
    .module {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: var(--shadow);
    }
    .module-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .module-num { background: var(--primary); color: white; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; }
    .module h2 { font-size: 1.5rem; }
    .module-summary { color: var(--text-muted); margin-bottom: 1.5rem; font-style: italic; }
    
    /* Lesson */
    .lesson {
      border-left: 3px solid var(--primary);
      padding-left: 1.5rem;
      margin-bottom: 2rem;
    }
    .lesson h3 { font-size: 1.2rem; margin-bottom: 0.5rem; color: var(--primary); }
    .lesson-meta { font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem; }
    .lesson-content { line-height: 1.8; }
    .lesson-content h4 { margin: 1rem 0 0.5rem; color: var(--text); }
    .lesson-content p { margin-bottom: 0.8rem; }
    .lesson-content ul, .lesson-content ol { margin: 0.5rem 0 0.8rem 1.5rem; }
    .lesson-content li { margin-bottom: 0.3rem; }
    .lesson-content code { background: var(--primary-light); padding: 0.1rem 0.4rem; border-radius: 3px; font-size: 0.9em; }
    .lesson-content pre { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1rem; overflow-x: auto; margin: 1rem 0; }
    .lesson-content pre code { background: none; padding: 0; }
    
    /* Accordion */
    .accordion { border: 1px solid var(--border); border-radius: var(--radius); margin: 1rem 0; overflow: hidden; }
    .accordion-header { background: var(--primary-light); padding: 0.8rem 1rem; cursor: pointer; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
    .accordion-header:hover { background: var(--primary); color: white; }
    .accordion-content { padding: 1rem; display: none; }
    .accordion-content.active { display: block; }
    
    /* Quiz */
    .quiz { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.5rem; margin: 1rem 0; }
    .quiz h4 { color: var(--primary); margin-bottom: 1rem; }
    .quiz-question { margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border); }
    .quiz-question:last-child { border: none; }
    .quiz-options { list-style: none; margin-top: 0.5rem; }
    .quiz-option { padding: 0.5rem; border-radius: 4px; cursor: pointer; transition: background 0.2s; }
    .quiz-option:hover { background: var(--primary-light); }
    .quiz-option.correct { background: rgba(22,163,74,0.15); border-left: 3px solid var(--success); }
    
    /* Callout */
    .callout { border-left: 4px solid var(--warning); background: rgba(245,158,11,0.1); padding: 1rem; border-radius: 0 var(--radius) var(--radius) 0; margin: 1rem 0; }
    .callout.tip { border-color: var(--success); background: rgba(22,163,74,0.1); }
    .callout.warning { border-color: var(--danger); background: rgba(220,38,38,0.1); }
    
    /* Card */
    .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1rem; }
    .card h5 { color: var(--primary); margin-bottom: 0.5rem; }
    
    /* Theme toggle */
    .theme-toggle { position: fixed; bottom: 1rem; right: 1rem; background: var(--primary); color: white; border: none; border-radius: 50%; width: 44px; height: 44px; cursor: pointer; font-size: 1.2rem; box-shadow: var(--shadow); z-index: 1000; }
    
    /* Footer */
    .course-footer { text-align: center; padding: 2rem; color: var(--text-muted); border-top: 1px solid var(--border); margin-top: 2rem; }
    
    /* Responsive */
    @media (max-width: 640px) {
      .container { padding: 1rem 0.5rem; }
      .cover { padding: 2rem 1rem; }
      .cover h1 { font-size: 1.8rem; }
      .module { padding: 1rem; }
      .lesson { padding-left: 1rem; }
      .card-grid { grid-template-columns: 1fr; }
    }
    
    /* Print */
    @media print {
      .progress-bar, .theme-toggle, .accordion-header { display: none; }
      .accordion-content { display: block !important; }
      body { font-size: 12pt; }
      .module { break-inside: avoid; page-break-after: always; }
      .module:last-child { page-break-after: auto; }
    }
  </style>
</head>
<body>
  <div class="progress-bar">
    <div class="container">
      <div class="progress-track"><div class="progress-fill" id="progressFill"></div></div>
    </div>
  </div>

  <div class="container">
    ${this.buildCover(course)}
    ${this.buildToc(course)}
    ${course.modules.map((mod, i) => this.buildModule(course, mod, i)).join('\n')}
    ${this.buildGlossary(course)}
    ${this.buildStudentExperience(course)}
    ${this.buildTeacherPack(course)}
    ${this.buildReferences(course)}
    ${this.buildMetadata(course)}
    ${this.buildFooter(course)}
  </div>

  <button class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">🌓</button>

  <script>
    // Progress tracking
    window.addEventListener('scroll', function() {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      var scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      var progress = (scrollTop / scrollHeight) * 100;
      document.getElementById('progressFill').style.width = progress + '%';
    });

    // Accordion
    document.querySelectorAll('.accordion-header').forEach(function(header) {
      header.addEventListener('click', function() {
        var content = this.nextElementSibling;
        content.classList.toggle('active');
      });
    });

    // Theme toggle
    function toggleTheme() {
      var current = document.documentElement.getAttribute('data-theme');
      document.documentElement.setAttribute('data-theme', current === 'dark' ? 'light' : 'dark');
      localStorage.setItem('theme', current === 'dark' ? 'light' : 'dark');
    }
    var savedTheme = localStorage.getItem('theme');
    if (savedTheme) document.documentElement.setAttribute('data-theme', savedTheme);

    // Quiz interaction
    document.querySelectorAll('.quiz-option').forEach(function(option) {
      option.addEventListener('click', function() {
        var isCorrect = this.getAttribute('data-correct') === 'true';
        if (isCorrect) {
          this.classList.add('correct');
        } else {
          this.style.background = 'rgba(220,38,38,0.15)';
        }
      });
    });
  </script>
</body>
</html>`

    this.log.info({ htmlLength: html.length }, 'CourseHtmlBuilder: HTML built')
    return html
  }

  private buildCover(course: CourseResult): string {
    const locale = course.curriculum?.locale ?? 'en'
    const level = course.curriculum?.level ?? 'intermediate'
    const audience = course.curriculum?.audience ?? 'general learners'
    const wordCount = course.totalWordCount
    const moduleCount = course.modules.length
    const lessonCount = course.lessons.length
    const qualityScore = course.qualityReport?.overallScore ?? 'N/A'

    return `<div class="cover">
  <h1>${this.escapeHtml(course.title)}</h1>
  <p>${this.escapeHtml(course.description)}</p>
  <div class="meta">
    <span>📊 ${moduleCount} modules</span>
    <span>📚 ${lessonCount} lessons</span>
    <span>✍️ ${wordCount.toLocaleString()} words</span>
    <span>⭐ Quality: ${qualityScore}</span>
    <span>🌐 ${this.escapeHtml(locale)}</span>
    <span>📈 ${this.escapeHtml(level)}</span>
    <span>👥 ${this.escapeHtml(audience)}</span>
  </div>
</div>`
  }

  private buildToc(course: CourseResult): string {
    const items = course.modules.map((mod, i) => {
      const lessonCount = course.lessons.filter(l => l.moduleId === mod.id).length
      return `<li><a href="#module-${i}"><span class="module-num">${i + 1}</span> ${this.escapeHtml(mod.title)} <span style="color:var(--text-muted);font-size:0.85rem">(${lessonCount} lessons)</span></a></li>`
    }).join('\n')

    return `<div class="toc">
  <h2>📋 Table of Contents</h2>
  <ul>${items}</ul>
</div>`
  }

  private buildModule(course: CourseResult, mod: CourseResult['modules'][0], index: number): string {
    const lessons = course.lessons
      .filter(l => l.moduleId === mod.id)
      .map(l => this.buildLesson(course, l))
      .join('\n')

    const exercises = course.exercises
      .filter(e => e.lessonId && course.lessons.some(l => l.id === e.lessonId && l.moduleId === mod.id))
      .map(e => this.buildExercise(e))
      .join('\n')

    const quiz = course.quizzes.find(q => q.moduleId === mod.id)
    const quizHtml = quiz ? this.buildQuiz(quiz) : ''

    const outcomes = mod.learningOutcomes.length > 0
      ? `<div class="callout tip"><strong>Learning Outcomes:</strong><ul>${mod.learningOutcomes.map(o => `<li>${this.escapeHtml(o)}</li>`).join('')}</ul></div>`
      : ''

    return `<div class="module" id="module-${index}">
  <div class="module-header">
    <span class="module-num">${index + 1}</span>
    <h2>${this.escapeHtml(mod.title)}</h2>
  </div>
  <p class="module-summary">${this.escapeHtml(mod.summary)}</p>
  ${outcomes}
  ${lessons}
  ${exercises}
  ${quizHtml}
</div>`
  }

  private buildLesson(course: CourseResult, lesson: CourseResult['lessons'][0]): string {
    const objectives = lesson.learningObjectives.length > 0
      ? `<div class="callout"><strong>Learning Objectives:</strong><ul>${lesson.learningObjectives.map(o => `<li>${this.escapeHtml(o)}</li>`).join('')}</ul></div>`
      : ''

    const takeaways = lesson.keyTakeaways.length > 0
      ? `<div class="callout tip"><strong>Key Takeaways:</strong><ul>${lesson.keyTakeaways.map(t => `<li>${this.escapeHtml(t)}</li>`).join('')}</ul></div>`
      : ''

    return `<div class="lesson" id="lesson-${lesson.id}">
  <h3>${this.escapeHtml(lesson.title)}</h3>
  <div class="lesson-meta">⏱️ ${lesson.durationMinutes} min · 📊 Bloom: ${this.escapeHtml(lesson.bloomLevel)} · ${lesson.wordCount} words</div>
  <div class="lesson-content">
    ${this.markdownToHtml(lesson.content)}
  </div>
  ${objectives}
  ${takeaways}
</div>`
  }

  private buildExercise(exercise: CourseResult['exercises'][0]): string {
    const hints = exercise.hints.length > 0
      ? `<div class="accordion"><div class="accordion-header">💡 Hints</div><div class="accordion-content"><ul>${exercise.hints.map(h => `<li>${this.escapeHtml(h)}</li>`).join('')}</ul></div></div>`
      : ''

    const answer = exercise.expectedAnswer
      ? `<div class="accordion"><div class="accordion-header">✅ Expected Answer</div><div class="accordion-content">${this.markdownToHtml(exercise.expectedAnswer)}</div></div>`
      : ''

    return `<div class="accordion">
  <div class="accordion-header">📝 Exercise: ${this.escapeHtml(exercise.question)}</div>
  <div class="accordion-content">
    <p><strong>Type:</strong> ${exercise.type} · <strong>Difficulty:</strong> ${exercise.difficulty}</p>
    ${exercise.context ? `<p>${this.escapeHtml(exercise.context)}</p>` : ''}
    ${hints}
    ${answer}
  </div>
</div>`
  }

  private buildQuiz(quiz: CourseResult['quizzes'][0]): string {
    const questions = quiz.questions.map((q, i) => {
      const options = q.options.map((opt, j) => {
        const isCorrect = j === q.correctIndex
        return `<li class="quiz-option" data-correct="${isCorrect}">${this.escapeHtml(opt)}</li>`
      }).join('')

      return `<div class="quiz-question">
  <p><strong>Q${i + 1}.</strong> ${this.escapeHtml(q.question)}</p>
  <ul class="quiz-options">${options}</ul>
</div>`
    }).join('')

    return `<div class="quiz">
  <h4>🧪 ${this.escapeHtml(quiz.title)}</h4>
  <p style="color:var(--text-muted);font-size:0.9rem">${this.escapeHtml(quiz.description)}</p>
  <p style="font-size:0.8rem;color:var(--text-muted)">Passing score: ${quiz.passingScore}% · Max attempts: ${quiz.maxAttempts} · Duration: ${quiz.durationMinutes} min</p>
  ${questions}
</div>`
  }

  private buildGlossary(course: CourseResult): string {
    if (!course.curriculum || !course.curriculum.learningOutcomes || course.curriculum.learningOutcomes.length === 0) {
      return ''
    }

    return `<div class="module">
  <div class="module-header"><h2>📖 Glossary</h2></div>
  <div class="card-grid">
    ${course.curriculum.learningOutcomes.map(term => `<div class="card"><h5>${this.escapeHtml(term)}</h5></div>`).join('')}
  </div>
</div>`
  }

  private buildStudentExperience(course: CourseResult): string {
    const totalXp = course.modules.length * 100 + 500
    const badges = [
      { icon: '🎯', name: 'First Steps', desc: 'Complete your first lesson' },
      { icon: '🏅', name: 'Module Master', desc: 'Complete an entire module' },
      { icon: '🧠', name: 'Quiz Whiz', desc: 'Pass a quiz with 100%' },
      { icon: '🏆', name: 'Course Champion', desc: 'Complete the entire course' },
      { icon: '🔥', name: 'Week Warrior', desc: 'Study 7 days in a row' },
    ]
    const achievements = [
      { name: 'Quick Learner', xp: 50 },
      { name: 'Deep Diver', xp: 100 },
      { name: 'Perfectionist', xp: 150 },
      { name: 'Course Graduate', xp: 200 },
    ]

    return `<div class="module">
  <div class="module-header"><h2>🎮 Student Experience</h2></div>
  <div class="card-grid">
    <div class="card"><h5>Total XP</h5><p style="font-size:1.5rem;font-weight:700;color:var(--primary)">${totalXp}</p></div>
    <div class="card"><h5>Lessons</h5><p style="font-size:1.5rem;font-weight:700">${course.lessons.length}</p></div>
    <div class="card"><h5>Est. Hours</h5><p style="font-size:1.5rem;font-weight:700">${Math.ceil(course.totalWordCount / 200 / 60)}h</p></div>
    <div class="card"><h5>Daily Goal</h5><p style="font-size:1.5rem;font-weight:700">2 lessons</p></div>
  </div>
  <h4 style="margin:1rem 0 0.5rem">Badges</h4>
  <div class="card-grid">
    ${badges.map(b => `<div class="card" style="text-align:center"><div style="font-size:2rem">${b.icon}</div><h5>${b.name}</h5><p style="font-size:0.8rem;color:var(--text-muted)">${b.desc}</p></div>`).join('')}
  </div>
  <h4 style="margin:1rem 0 0.5rem">Achievements</h4>
  <ul>
    ${achievements.map(a => `<li>${a.name} — <strong>${a.xp} XP</strong></li>`).join('')}
  </ul>
</div>`
  }

  private buildTeacherPack(course: CourseResult): string {
    return `<div class="module">
  <div class="module-header"><h2>👨‍🏫 Teacher Pack</h2></div>
  <div class="card-grid">
    <div class="card"><h5>📋 Teaching Guide</h5><p style="font-size:0.85rem">Comprehensive guide with teaching strategies, assessment approaches, and differentiation tips.</p></div>
    <div class="card"><h5>✅ Answer Key</h5><p style="font-size:0.85rem">${course.exercises.length} exercise answers with detailed explanations.</p></div>
    <div class="card"><h5>📝 Question Bank</h5><p style="font-size:0.85rem">${course.quizzes.reduce((sum, q) => sum + q.questions.length, 0)} questions across ${course.quizzes.length} quizzes.</p></div>
    <div class="card"><h5>🎯 Suggested Activities</h5><p style="font-size:0.85rem">5 interactive classroom activities including group discussions and peer reviews.</p></div>
    <div class="card"><h5>📅 Schedule</h5><p style="font-size:0.85rem">${Math.ceil(course.modules.length / 2)}-week teaching schedule with weekly activities.</p></div>
    <div class="card"><h5>🏆 Final Project</h5><p style="font-size:0.85rem">Comprehensive final project with 4 deliverables and 5 rubric criteria.</p></div>
  </div>
</div>`
  }

  private buildReferences(course: CourseResult): string {
    return `<div class="module">
  <div class="module-header"><h2>📚 References</h2></div>
  <ul>
    <li>Course generated by AICF V3 AI Course Factory</li>
    <li>Topic: ${this.escapeHtml(course.topic)}</li>
    <li>Provider: ${this.escapeHtml(course.provider)}</li>
    <li>Model: ${this.escapeHtml(course.model)}</li>
    <li>Generator Version: ${this.escapeHtml(course.generatorVersion)}</li>
  </ul>
</div>`
  }

  private buildMetadata(course: CourseResult): string {
    return `<div class="module">
  <div class="module-header"><h2>ℹ️ Course Metadata</h2></div>
  <div class="card-grid">
    <div class="card"><h5>Course ID</h5><p style="font-family:monospace;font-size:0.85rem">${this.escapeHtml(course.id)}</p></div>
    <div class="card"><h5>Status</h5><p>${this.escapeHtml(course.status)}</p></div>
    <div class="card"><h5>Created</h5><p>${this.escapeHtml(course.createdAt)}</p></div>
    <div class="card"><h5>Word Count</h5><p>${course.totalWordCount.toLocaleString()}</p></div>
    <div class="card"><h5>Duration</h5><p>${course.totalDurationMs}ms</p></div>
    <div class="card"><h5>Quality Score</h5><p>${course.qualityReport?.overallScore ?? 'N/A'}/100</p></div>
  </div>
</div>`
  }

  private buildFooter(course: CourseResult): string {
    return `<div class="course-footer">
  <p>Generated by AICF V3 — AI Course Factory Platform</p>
  <p style="font-size:0.8rem;margin-top:0.5rem">${this.escapeHtml(course.title)} · ${new Date().toISOString()}</p>
</div>`
  }

  private escapeHtml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;')
  }

  private markdownToHtml(md: string): string {
    return md
      .replace(/^# (.+)$/gm, '<h4>$1</h4>')
      .replace(/^## (.+)$/gm, '<h5>$1</h5>')
      .replace(/^### (.+)$/gm, '<h6>$1</h6>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/```[\s\S]*?```/g, (match) => {
        const code = match.replace(/```\w*\n?/g, '').replace(/```/g, '')
        return `<pre><code>${this.escapeHtml(code)}</code></pre>`
      })
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>\n?)+/g, (match) => `<ul>${match}</ul>`)
      .replace(/\n\n/g, '</p><p>')
      .replace(/^(?!<[hupol])(.+)$/gm, '<p>$1</p>')
      .replace(/<p><p>/g, '<p>')
      .replace(/<\/p><\/p>/g, '</p>')
  }
}
