// =============================================================================
// AICF V3 — Runtime Request Contract
// =============================================================================
// The payload that enters the Runtime pipeline. Typed — no `any`.
// =============================================================================

import type { ChatMessage } from '@/lib/ai/AIAdapter'

/**
 * The type of operation the Runtime should perform.
 */
export type RuntimeOperation = 'chat' | 'workflow' | 'models' | 'status' | 'generate'

/**
 * A request entering the Runtime.
 */
export interface RuntimeRequest {
  /** Unique request identifier (generated if not provided). */
  requestId: string

  /** Correlation ID for distributed tracing. */
  correlationId: string

  /** The operation to perform. */
  operation: RuntimeOperation

  /** The model to use (for chat operations). */
  model?: string

  /** Chat messages (for chat operations). */
  messages?: ChatMessage[]

  /** Generation parameters. */
  parameters?: {
    temperature?: number
    maxTokens?: number
    topP?: number
    stop?: string[]
    stream?: boolean
  }

  /** Workflow ID (for workflow operations). */
  workflowId?: string

  /** Workflow input data. */
  input?: Record<string, unknown>

  /** Arbitrary metadata propagated through the pipeline. */
  metadata?: Record<string, unknown>
}

/**
 * Factory: creates a RuntimeRequest with auto-generated IDs.
 *
 * Sprint 4: uses the centralized createCorrelationId() and createRequestId()
 * from the CorrelationId middleware so all IDs follow the standard format:
 *   - requestId:      req-{timestamp}-{random}
 *   - correlationId:  corr-{timestamp}-{random}
 */
export function createRuntimeRequest(partial: Partial<RuntimeRequest> & Pick<RuntimeRequest, 'operation'>): RuntimeRequest {
  // Lazy import to avoid circular dependency at module load time
  // (CorrelationId imports RuntimeRequest for its type)
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return {
    requestId: partial.requestId || `req-${ts}-${rand}`,
    correlationId: partial.correlationId || `corr-${ts}-${rand}`,
    ...partial,
  }
}
