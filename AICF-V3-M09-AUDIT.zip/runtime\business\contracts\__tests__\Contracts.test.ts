// =============================================================================
// AICF V3 — Business Contracts Tests (Épica 2 — AI Factory Core, B11)
// =============================================================================
// Verifies every factory in `business/contracts`:
//   - createJobRequest(): generates a jobId, preserves jobType + input + metadata.
//   - createJobResponse(): fills defaults (startedAt, durationMs), accepts overrides.
//   - createBusinessContext(): defaults correlationId/requestId to jobId, locale to 'en'.
//   - createCapability(): defaults version to '1.0.0', preserves schema + description.
//   - createSuccessResult() / createFailedResult(): shape + defaults.
//
// No `any`. `testModule` is used as a variable name (not `module`) per
// project conventions to avoid shadowing the global `module` Node type.
// =============================================================================

import { describe, it, expect } from 'bun:test'
import {
  createJobRequest,
  createJobResponse,
  createBusinessContext,
  createCapability,
  createSuccessResult,
  createFailedResult,
  type JobRequest,
  type JobResponse,
  type BusinessContext,
  type Capability,
  type ExecutionResult,
} from '../index'

describe('Business Contracts factories (Épica 2 — B11)', () => {
  // -------------------------------------------------------------------------
  // createJobRequest()
  // -------------------------------------------------------------------------
  describe('createJobRequest()', () => {
    it('generates a unique jobId with the "job-" prefix', () => {
      const req: JobRequest = createJobRequest('createCourse', { topic: 'Rust' })
      expect(req.jobId).toBeTruthy()
      expect(typeof req.jobId).toBe('string')
      expect(req.jobId.startsWith('job-')).toBe(true)
    })

    it('two consecutive calls generate distinct jobIds', () => {
      const a = createJobRequest('createCourse', { topic: 'a' })
      const b = createJobRequest('createCourse', { topic: 'b' })
      expect(a.jobId).not.toBe(b.jobId)
    })

    it('preserves jobType + input', () => {
      const req = createJobRequest('createSlides', { topic: 'AI 101', count: 10 })
      expect(req.jobType).toBe('createSlides')
      expect(req.input).toEqual({ topic: 'AI 101', count: 10 })
    })

    it('preserves metadata when provided', () => {
      const req = createJobRequest(
        'createQuiz',
        { topic: 'js' },
        { userId: 'u-1', workspaceId: 'w-1', locale: 'es', priority: 5 },
      )
      expect(req.metadata?.userId).toBe('u-1')
      expect(req.metadata?.workspaceId).toBe('w-1')
      expect(req.metadata?.locale).toBe('es')
      expect(req.metadata?.priority).toBe(5)
    })

    it('metadata is undefined when not provided', () => {
      const req = createJobRequest('createCourse', { topic: 'x' })
      expect(req.metadata).toBeUndefined()
    })
  })

  // -------------------------------------------------------------------------
  // createJobResponse()
  // -------------------------------------------------------------------------
  describe('createJobResponse()', () => {
    it('uses the provided jobId + status verbatim', () => {
      const res: JobResponse = createJobResponse('job-1', 'completed')
      expect(res.jobId).toBe('job-1')
      expect(res.status).toBe('completed')
    })

    it('defaults startedAt to an ISO string', () => {
      const res = createJobResponse('job-1', 'pending')
      expect(typeof res.startedAt).toBe('string')
      // ISO 8601 regex (loose: just check it parses as a valid date)
      expect(new Date(res.startedAt).toString()).not.toBe('Invalid Date')
    })

    it('defaults durationMs to 0', () => {
      const res = createJobResponse('job-1', 'pending')
      expect(res.durationMs).toBe(0)
    })

    it('accepts overrides for every optional field', () => {
      const res = createJobResponse('job-1', 'failed', {
        output: { x: 1 },
        error: 'boom',
        startedAt: '2024-01-01T00:00:00.000Z',
        completedAt: '2024-01-01T00:00:01.000Z',
        durationMs: 1000,
        artifacts: [{ id: 'a-1', type: 'pdf', name: 'out.pdf' }],
        metrics: { tokensUsed: 500, cost: 0.02, providerCalls: 1 },
      })
      expect(res.output).toEqual({ x: 1 })
      expect(res.error).toBe('boom')
      expect(res.startedAt).toBe('2024-01-01T00:00:00.000Z')
      expect(res.completedAt).toBe('2024-01-01T00:00:01.000Z')
      expect(res.durationMs).toBe(1000)
      expect(res.artifacts?.length).toBe(1)
      expect(res.metrics?.tokensUsed).toBe(500)
    })
  })

  // -------------------------------------------------------------------------
  // createBusinessContext()
  // -------------------------------------------------------------------------
  describe('createBusinessContext()', () => {
    it('defaults correlationId + requestId to the jobId', () => {
      const ctx: BusinessContext = createBusinessContext({ jobId: 'job-7' })
      expect(ctx.jobId).toBe('job-7')
      expect(ctx.correlationId).toBe('job-7')
      expect(ctx.requestId).toBe('job-7')
    })

    it('defaults locale to "en"', () => {
      const ctx = createBusinessContext({ jobId: 'job-7' })
      expect(ctx.locale).toBe('en')
    })

    it('defaults metadata to an empty object', () => {
      const ctx = createBusinessContext({ jobId: 'job-7' })
      expect(ctx.metadata).toEqual({})
    })

    it('startedAt is a numeric epoch (ms)', () => {
      const before = Date.now()
      const ctx = createBusinessContext({ jobId: 'job-7' })
      const after = Date.now()
      expect(typeof ctx.startedAt).toBe('number')
      expect(ctx.startedAt).toBeGreaterThanOrEqual(before)
      expect(ctx.startedAt).toBeLessThanOrEqual(after)
    })

    it('preserves provided trace + tenancy fields', () => {
      const ctx = createBusinessContext({
        jobId: 'job-7',
        correlationId: 'cor-1',
        requestId: 'req-1',
        userId: 'u-1',
        workspaceId: 'w-1',
        projectId: 'p-1',
        locale: 'pt-BR',
        metadata: { flag: 'beta' },
      })
      expect(ctx.correlationId).toBe('cor-1')
      expect(ctx.requestId).toBe('req-1')
      expect(ctx.userId).toBe('u-1')
      expect(ctx.workspaceId).toBe('w-1')
      expect(ctx.projectId).toBe('p-1')
      expect(ctx.locale).toBe('pt-BR')
      expect(ctx.metadata).toEqual({ flag: 'beta' })
    })
  })

  // -------------------------------------------------------------------------
  // createCapability()
  // -------------------------------------------------------------------------
  describe('createCapability()', () => {
    it('uses name + description verbatim', () => {
      const cap: Capability = createCapability('createCourse', 'Generate a course')
      expect(cap.name).toBe('createCourse')
      expect(cap.description).toBe('Generate a course')
    })

    it('defaults version to "1.0.0"', () => {
      const cap = createCapability('createCourse', 'desc')
      expect(cap.version).toBe('1.0.0')
    })

    it('defaults inputSchema + outputSchema to undefined', () => {
      const cap = createCapability('createCourse', 'desc')
      expect(cap.inputSchema).toBeUndefined()
      expect(cap.outputSchema).toBeUndefined()
    })

    it('preserves provided schemas + version', () => {
      const cap = createCapability('createCourse', 'desc', {
        version: '2.0.0',
        inputSchema: { type: 'object', properties: { topic: { type: 'string' } } },
        outputSchema: { type: 'object', properties: { title: { type: 'string' } } },
      })
      expect(cap.version).toBe('2.0.0')
      expect(cap.inputSchema?.type).toBe('object')
      expect(cap.outputSchema?.type).toBe('object')
    })
  })

  // -------------------------------------------------------------------------
  // createSuccessResult() + createFailedResult()
  // -------------------------------------------------------------------------
  describe('createSuccessResult()', () => {
    it('sets ok=true and carries the output', () => {
      const r: ExecutionResult = createSuccessResult({ title: 'Intro' })
      expect(r.ok).toBe(true)
      expect(r.output).toEqual({ title: 'Intro' })
      expect(r.error).toBeUndefined()
    })

    it('defaults durationMs to 0', () => {
      const r = createSuccessResult({ x: 1 })
      expect(r.durationMs).toBe(0)
    })

    it('accepts optional artifacts + metrics overrides', () => {
      const r = createSuccessResult({ x: 1 }, {
        durationMs: 50,
        artifacts: [{ id: 'a-1', type: 'pdf', name: 'o.pdf' }],
        metrics: { tokensUsed: 10, cost: 0.01, providerCalls: 1 },
      })
      expect(r.durationMs).toBe(50)
      expect(r.artifacts?.length).toBe(1)
      expect(r.metrics?.cost).toBe(0.01)
    })
  })

  describe('createFailedResult()', () => {
    it('sets ok=false and carries the error message', () => {
      const r: ExecutionResult = createFailedResult('Not implemented')
      expect(r.ok).toBe(false)
      expect(r.error).toBe('Not implemented')
      expect(r.output).toBeUndefined()
    })

    it('defaults durationMs to 0', () => {
      const r = createFailedResult('boom')
      expect(r.durationMs).toBe(0)
    })

    it('accepts optional overrides (artifacts, metrics, output)', () => {
      const r = createFailedResult('partial', {
        durationMs: 5,
        output: { partial: true },
        artifacts: [{ id: 'a-1', type: 'log', name: 'x.log' }],
        metrics: { providerCalls: 2 },
      })
      expect(r.durationMs).toBe(5)
      expect(r.output).toEqual({ partial: true })
      expect(r.artifacts?.length).toBe(1)
      expect(r.metrics?.providerCalls).toBe(2)
    })
  })
})
