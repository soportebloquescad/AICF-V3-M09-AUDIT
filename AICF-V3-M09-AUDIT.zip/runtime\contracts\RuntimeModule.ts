// =============================================================================
// AICF V3 — Runtime Module Contract (Sprint 15: Plugin Architecture + Lifecycle)
// =============================================================================
// Interface for modules registered in the Module Registry.
// Each module represents an integration point (M08, M09, M18, M21, workflow,
// generation, observability, etc.).
//
// Sprint 15 additions (backward compatible):
//   - RuntimeModuleLifecycle: full lifecycle (initialize, health, dispose, shutdown)
//   - ModuleHealth: structured health report
//   - ModuleMetrics: per-module metrics
//   - RuntimeModule extended with optional lifecycle methods
// =============================================================================

/**
 * The status of a registered Runtime module.
 */
export interface RuntimeStatus {
  /** Module name (e.g., "content-intelligence"). */
  name: string

  /** Whether the module is initialized and ready. */
  ready: boolean

  /** Module version. */
  version: string

  /** Optional health details. */
  details?: Record<string, unknown>
}

/**
 * Per-module metrics (exposed by every module, but implementation can be minimal).
 */
export interface ModuleMetrics {
  /** Time spent in initialize() in milliseconds. */
  initLatencyMs: number

  /** Cumulative error count since startup. */
  errorCount: number

  /** Last time the module was used (ISO string), or null if never. */
  lastUsed: string | null

  /** Last error message, or null if no errors. */
  lastError: string | null

  /** Cumulative operation count since startup. */
  operationCount: number
}

/**
 * Structured health report returned by module.health().
 */
export interface ModuleHealth {
  /** Whether the module is ready to serve. */
  ready: boolean

  /** Coarse health status. */
  status: 'healthy' | 'degraded' | 'unhealthy'

  /** ISO timestamp when the module started up. */
  startupTime: string

  /** IDs of modules this module depends on. */
  dependencies: string[]

  /** Module version. */
  version: string

  /** ISO timestamp of the last initialize() call. */
  lastInitialization: string

  /** Last error message (if any). */
  lastError?: string

  /** Optional metrics snapshot. */
  metrics?: ModuleMetrics
}

/**
 * Full lifecycle interface for modules that want to participate in
 * health checks, graceful shutdown, and resource disposal.
 *
 * Sprint 15: all new modules SHOULD implement this. The base RuntimeModule
 * interface keeps `initialize`/`isReady`/`getStatus` for backward compat.
 */
export interface RuntimeModuleLifecycle {
  /** Initialize the module (idempotent). */
  initialize(): Promise<void>

  /** Return a structured health report. */
  health(): Promise<ModuleHealth>

  /** Dispose resources held by the module (called on shutdown). */
  dispose(): Promise<void>

  /** Gracefully shut down the module (called on process exit). */
  shutdown(): Promise<void>
}

/**
 * Interface that all Runtime modules must implement.
 * The lifecycle methods (health, dispose, shutdown) are optional — modules
 * that don't implement them will get default no-op behavior from the
 * RuntimeBootstrap.
 */
export interface RuntimeModule {
  /** Module name. */
  readonly name: string

  /** Module version. */
  readonly version: string

  /** Initialize the module. */
  initialize?(): Promise<void>

  /** Check if the module is ready. */
  isReady(): boolean

  /** Get module status. */
  getStatus(): RuntimeStatus

  /** Return structured health (optional — Sprint 15 lifecycle). */
  health?(): Promise<ModuleHealth>

  /** Dispose resources (optional — Sprint 15 lifecycle). */
  dispose?(): Promise<void>

  /** Graceful shutdown (optional — Sprint 15 lifecycle). */
  shutdown?(): Promise<void>

  /** Per-module metrics (optional — Sprint 15). */
  getMetrics?(): ModuleMetrics
}

/**
 * Categories of modules registered in the Runtime.
 * Sprint 15 adds 'observability' and 'generation' as first-class categories.
 */
export type RuntimeModuleCategory =
  | 'content-intelligence'
  | 'real-generation'
  | 'infrastructure'
  | 'workflow'
  | 'generation'
  | 'observability'
  | 'localization'
  | 'assets'
  | 'reports'

/**
 * Default metrics for a freshly-created module (all zeros).
 */
export function createDefaultModuleMetrics(): ModuleMetrics {
  return {
    initLatencyMs: 0,
    errorCount: 0,
    lastUsed: null,
    lastError: null,
    operationCount: 0,
  }
}

/**
 * Default health report for a module that hasn't been initialized yet.
 */
export function createUninitializedHealth(
  name: string,
  version: string,
  dependencies: string[] = [],
): ModuleHealth {
  return {
    ready: false,
    status: 'unhealthy',
    startupTime: '',
    dependencies,
    version,
    lastInitialization: '',
    lastError: undefined,
    metrics: createDefaultModuleMetrics(),
  }
}
