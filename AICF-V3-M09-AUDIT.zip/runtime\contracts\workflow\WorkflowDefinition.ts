// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Definition Contract
// =============================================================================
// Defines the static, declarative shape of a workflow: metadata, versioning,
// inputs, outputs, ordered steps (DAG via `dependsOn`), checkpoint markers,
// and runtime policies.
//
// Sprint 13+14 spec requirements covered:
//   - Workflow metadata + semver versioning + authorship
//   - Step DAG with declared inputs/outputs (variable mappings)
//   - Conditional execution (`condition`) and saga compensation
//   - Checkpoint markers for resumable / replayable executions
//   - Cost / token / retry / timeout guard rails via `WorkflowPolicies`
//
// This file declares NO runtime behavior — it is the schema that the workflow
// registry, validator, planner, and executor all consume.
// =============================================================================

/**
 * High-level metadata attached to every workflow definition.
 * Used for registry lookup, display, and audit.
 */
export interface WorkflowMetadata {
  /** Unique workflow identifier (kebab-case recommended). */
  id: string
  /** Human-readable name. */
  name: string
  /** Semver version of THIS definition (independent of `WorkflowDefinition.version`). */
  version: string
  /** Short description of what the workflow produces. */
  description: string
  /** Author or owning team. */
  author: string
  /** Creation timestamp (epoch ms). */
  createdAt: number
  /** Last-update timestamp (epoch ms). */
  updatedAt: number
  /** Free-form tags for search / categorization. */
  tags: string[]
  /** Category bucket (e.g. "course", "assessment", "report"). */
  category: string
}

/**
 * Compensation action executed during saga rollback when a step fails
 * after this step has already completed successfully.
 */
export interface CompensationAction {
  /** How to undo the side-effect of the step. */
  type: 'rollback' | 'cleanup' | 'notification'
  /** Provider-/action-specific config (e.g. endpoint to call, template to render). */
  config: Record<string, unknown>
}

/**
 * The category of operation a step performs. Drives provider selection
 * and executor dispatch.
 */
export type WorkflowStepType =
  | 'chat'
  | 'generate'
  | 'validate'
  | 'transform'
  | 'conditional'
  | 'action'

/**
 * A single node in the workflow DAG.
 *
 * `inputs` and `outputs` are variable-binding maps:
 *   - `inputs`: logical-name → expression that resolves against the
 *     execution context / upstream step outputs (e.g. `{ "topic": "$.inputs.topic" }`).
 *   - `outputs`: produced-name → output-variable name that downstream
 *     steps can reference.
 */
export interface WorkflowStepDefinition {
  /** Unique step id within the workflow. */
  id: string
  /** Human-readable step name. */
  name: string
  /** Operation category — drives executor dispatch. */
  type: WorkflowStepType
  /** Registered provider name that should handle this step. */
  provider: string
  /** Provider-/step-specific configuration. */
  config: Record<string, unknown>
  /** Variable mappings consumed by this step (logical name → source expression). */
  inputs: Record<string, string>
  /** Variable mappings produced by this step (produced name → output variable). */
  outputs: Record<string, string>
  /** Step ids that must complete before this step can run (DAG edges). */
  dependsOn: string[]
  /** Per-step retry count on transient failure (default 0). */
  retries: number
  /** Per-step hard timeout in milliseconds. Optional. */
  timeout?: number
  /** Optional boolean expression; when present and falsy, the step is skipped. */
  condition?: string
  /** Optional saga-compensation action invoked on rollback. */
  compensation?: CompensationAction
}

/**
 * Declared workflow input. Validated before execution begins.
 */
export interface WorkflowInput {
  /** Input variable name (matches a key in `WorkflowDefinition.inputs`). */
  name: string
  /** JSON-like type for validation. */
  type: 'string' | 'number' | 'boolean' | 'object'
  /** Whether the caller must supply this input. */
  required: boolean
  /** Default value when not supplied and `required` is false. */
  default?: unknown
  /** Optional human-readable description. */
  description?: string
}

/**
 * Declared workflow output. Bound to a producing step at definition time
 * so the executor knows where to source each final output value.
 */
export interface WorkflowOutput {
  /** Output variable name. */
  name: string
  /** JSON-like type. */
  type: 'string' | 'number' | 'boolean' | 'object'
  /** Human-readable description. */
  description: string
  /** Step id that produces this output. */
  fromStep: string
}

/**
 * Runtime-wide guard rails. Enforced by the planner, executor, and budget
 * manager.
 */
export interface WorkflowPolicies {
  /** Maximum total retries across all steps before the workflow fails. */
  maxRetries: number
  /** Hard wall-clock timeout for the entire workflow, in milliseconds. */
  timeoutMs: number
  /** Maximum total cost (in platform currency units) allowed. */
  maxCost: number
  /** Maximum total tokens (prompt + completion) allowed. */
  maxTokens: number
  /** When true, the planner reports a `DryRunResult` without executing. */
  dryRun?: boolean
}

/**
 * The full declarative workflow. This is what authors register and what
 * the executor consumes.
 */
export interface WorkflowDefinition {
  /** Identity, versioning, and audit metadata. */
  metadata: WorkflowMetadata
  /** Semver version of the workflow definition itself. */
  version: string
  /** Declared inputs (name → spec). */
  inputs: Record<string, WorkflowInput>
  /** Declared outputs (name → spec, including producing step). */
  outputs: Record<string, WorkflowOutput>
  /** Ordered DAG of steps. */
  steps: WorkflowStepDefinition[]
  /** Step ids at which the executor should persist a `Checkpoint`. */
  checkpoints: string[]
  /** Optional runtime-wide policies. */
  policies?: WorkflowPolicies
}
