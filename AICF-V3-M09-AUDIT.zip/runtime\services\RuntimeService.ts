// =============================================================================
// AICF V3 — Runtime Service (Sprint 15: Bootstrap + Lifecycle)
// =============================================================================
// The RuntimeService orchestrates the full pipeline for each operation.
// It also owns the ModuleRegistry + RuntimeBootstrap — the bootstrap reads the
// manifest, creates modules via ModuleFactory, initializes them, runs health
// checks, and registers them.
//
// Sprint 15 changes (backward compatible):
//   - Constructor accepts optional `bootstrap: RuntimeBootstrap` config.
//   - When bootstrap is configured, initialize() runs the bootstrap first
//     (creating + initializing all manifest modules), then initializes the
//     remaining stubs.
//   - New method: getRuntimeHealth() — returns the full health matrix.
//   - New method: getBootstrap() — returns the bootstrap instance.
//   - Existing behavior (no bootstrap) is preserved for tests.
//
// Épica 2 changes (backward compatible — additive only):
//   - Constructor accepts optional `businessModuleRegistry`.
//   - New method: executeJob(request: JobRequest): Promise<JobResponse> —
//     routes a Business-layer job to the registered BusinessModuleBase
//     subclass that handles the job's `jobType` (matched as a capability
//     name). Returns a failed JobResponse when no module handles the type.
//   - New method: getBusinessModuleRegistry() — exposes the registry so
//     callers (runtime-singleton, tests) can register modules.
//   - Existing methods (execute, initialize, getModuleStatus, etc.) are
//     unchanged.
// =============================================================================

import type { RuntimeRequest } from '../contracts/RuntimeRequest'
import type { RuntimeResponse } from '../contracts/RuntimeResponse'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import type { ModuleHealth } from '../contracts/RuntimeModule'
import { buildContext } from '../middleware/RuntimeContextMiddleware'
import { PipelineRegistry } from '../pipeline/PipelineRegistry'
import type { Pipeline } from '../pipeline/Pipeline'
import { ModuleRegistry } from '../registry/ModuleRegistry'
import { RuntimeBootstrap, type BootstrapResult } from '../bootstrap/RuntimeBootstrap'
import { RuntimeEventBus } from '../events/RuntimeEventBus'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import type { ModuleDeps } from '../factories/ModuleFactory'
import type { JobRequest } from '../business/contracts/JobRequest'
import type { JobResponse } from '../business/contracts/JobResponse'
import type { ExecutionResult } from '../business/contracts/ExecutionResult'
import { createBusinessContext } from '../business/contracts/BusinessContext'
import { createJobResponse } from '../business/contracts/JobResponse'
import { createFailedResult } from '../business/contracts/ExecutionResult'
import { BusinessModuleRegistry } from '../business/registry/BusinessModuleRegistry'
import { logger } from '@/lib/ai/logger'

/**
 * Best-effort: emits an envelope-wrapped EDA event from the RuntimeService.
 * Wraps in try/catch so emission failures never propagate to the caller.
 */
async function emitServiceEvent(
  eventBus: RuntimeEventBus,
  type: 'RequestReceived' | 'ResponseReturned',
  opts: {
    correlationId: string
    requestId: string
    operation: string
    stageOrder: number
    durationMs?: number
    payload: Record<string, unknown>
  },
): Promise<void> {
  try {
    const meta = createEventMetadata({
      correlationId: opts.correlationId,
      requestId: opts.requestId,
      operation: opts.operation,
      pipelineStage: 'RuntimeService',
      stageOrder: opts.stageOrder,
      durationMs: opts.durationMs,
    })
    await eventBus.publishEnvelope(createEnvelope(meta, opts.payload), type)
  } catch (err) {
    logger.debug(
      { type, error: err instanceof Error ? err.message : String(err) },
      'RuntimeService: event emission failed (best-effort)',
    )
  }
}

/**
 * Configuration for the RuntimeService.
 */
export interface RuntimeServiceConfig {
  /** Pre-built pipeline to use instead of the default. */
  pipeline?: Pipeline

  /** Custom module registry. */
  moduleRegistry?: ModuleRegistry

  /**
   * Sprint 15: when true, the RuntimeService runs the bootstrap on initialize().
   * This creates + initializes all manifest modules (workflow, generation,
   * observability) and registers them. Default: false (preserves old behavior).
   */
  useBootstrap?: boolean

  /** Dependencies to pass to the bootstrap (when useBootstrap is true). */
  bootstrapDeps?: ModuleDeps

  /** Custom event bus for bootstrap lifecycle events. */
  eventBus?: RuntimeEventBus

  /**
   * Épica 2: Business-layer module registry. When omitted, an empty
   * BusinessModuleRegistry is created — callers register modules via
   * `getBusinessModuleRegistry().register(module)`.
   */
  businessModuleRegistry?: BusinessModuleRegistry
}

// Singleton — shared across all RuntimeService instances.
let globalBootstrap: RuntimeBootstrap | null = null
let globalEventBus: RuntimeEventBus | null = null

/**
 * Gets the global bootstrap instance (singleton).
 * Created once on first use.
 */
export function getGlobalBootstrap(deps?: ModuleDeps, registry?: ModuleRegistry): RuntimeBootstrap {
  if (!globalBootstrap) {
    const reg = registry || new ModuleRegistry()
    const bus = getGlobalEventBus()
    globalBootstrap = new RuntimeBootstrap({
      registry: reg,
      eventBus: bus,
      deps: deps || {},
    })
  }
  return globalBootstrap
}

/**
 * Gets the global event bus (singleton).
 */
export function getGlobalEventBus(): RuntimeEventBus {
  if (!globalEventBus) {
    globalEventBus = new RuntimeEventBus()
  }
  return globalEventBus
}

/**
 * Resets the global singletons (for tests).
 * @internal
 */
export function _resetGlobalBootstrap(): void {
  globalBootstrap = null
  globalEventBus = null
}

/**
 * Sprint 3 — In-memory job tracker.
 *
 * Records every JobResponse produced by executeJob() so the service can
 * answer getStatus() / listJobs() / cancelJob() queries. The tracker is
 * intentionally minimal: it stores job metadata + status, supports
 * cancellation of 'pending'/'running' jobs, and is bounded to avoid
 * unbounded memory growth (oldest entries are evicted FIFO when the
 * cap is reached).
 *
 * This is the M09-compatible strategy: the tracker lives inside the
 * RuntimeService (no external dependency, no M08/M18 coupling) and
 * preserves the existing executeJob() contract.
 */
interface TrackedJob {
  jobId: string
  jobType: string
  status: import('../business/contracts/JobResponse').JobStatus
  startedAt: string
  completedAt?: string
  durationMs: number
  error?: string
  correlationId?: string
  requestId?: string
  cancelRequested: boolean
}

const JOB_TRACKER_MAX = 1000

/**
 * The RuntimeService orchestrates the full pipeline for each operation.
 */
export class RuntimeService {
  private readonly pipelineRegistry: PipelineRegistry
  private readonly moduleRegistry: ModuleRegistry
  private readonly eventBus: RuntimeEventBus
  private readonly bootstrap: RuntimeBootstrap | null
  /** Épica 2: Business-layer module registry used by executeJob(). */
  private readonly businessModuleRegistry: BusinessModuleRegistry
  private initialized = false
  /** Sprint 3: in-memory job tracker for getStatus/listJobs/cancelJob. */
  private readonly trackedJobs = new Map<string, TrackedJob>()
  private readonly jobOrder: string[] = []

  constructor(config?: RuntimeServiceConfig) {
    this.moduleRegistry = config?.moduleRegistry || new ModuleRegistry()
    this.eventBus = config?.eventBus || getGlobalEventBus()
    this.businessModuleRegistry = config?.businessModuleRegistry || new BusinessModuleRegistry()

    if (config?.pipeline) {
      this.pipelineRegistry = new PipelineRegistry()
      this.pipelineRegistry.register('default', config.pipeline)
    } else {
      this.pipelineRegistry = new PipelineRegistry()
    }

    // Sprint 15: optionally wire the bootstrap.
    if (config?.useBootstrap) {
      this.bootstrap = new RuntimeBootstrap({
        registry: this.moduleRegistry,
        eventBus: this.eventBus,
        deps: config?.bootstrapDeps || {},
      })
    } else {
      this.bootstrap = null
    }
  }

  /**
   * Initializes the Runtime (modules, connections).
   * If bootstrap is configured, runs it first (creates + initializes all
   * manifest modules). Then initializes any remaining stubs.
   */
  async initialize(): Promise<void> {
    if (this.initialized) return

    // Sprint 15: run bootstrap if configured.
    if (this.bootstrap && !this.bootstrap.hasRun()) {
      const result = await this.bootstrap.run()
      logger.info(
        {
          initialized: result.initialized,
          failed: result.failed.map((f) => f.moduleId),
          skipped: result.skipped,
          durationMs: result.durationMs,
        },
        'RuntimeService: bootstrap complete',
      )
    }

    // Initialize any remaining stubs (no-op for stubs, but calls initialize()
    // on any modules that weren't part of the bootstrap).
    await this.moduleRegistry.initializeAll()
    this.initialized = true
    logger.info('RuntimeService initialized')
  }

  /**
   * Executes a Runtime request through the pipeline.
   *
   * Sprint 21: emits RequestReceived before pipeline.run() and
   * ResponseReturned after. Both emissions are best-effort — wrapped in
   * try/catch, never throw, never block the request.
   */
  async execute(request: RuntimeRequest): Promise<RuntimeResponse> {
    if (!this.initialized) {
      await this.initialize()
    }

    const ctx: RuntimeContext = buildContext(request)
    const pipeline = this.pipelineRegistry.get('default')

    logger.info(
      { requestId: ctx.request.requestId, operation: request.operation, stages: pipeline.getStageNames() },
      'RuntimeService: executing pipeline',
    )

    // --- Sprint 21: emit RequestReceived (best-effort) ------------------
    await emitServiceEvent(this.eventBus, 'RequestReceived', {
      correlationId: ctx.request.correlationId,
      requestId: ctx.request.requestId,
      operation: request.operation,
      stageOrder: 1,
      payload: {
        requestId: ctx.request.requestId,
        correlationId: ctx.request.correlationId,
        operation: request.operation,
        model: request.model || null,
        messageCount: request.messages?.length ?? 0,
      },
    })

    const requestStartedAt = Date.now()
    let result: RuntimeContext
    try {
      result = await pipeline.run(ctx)
    } catch (err) {
      // The Pipeline normally catches stage errors itself; this catch is a
      // safety net for unexpected throws. We still emit ResponseReturned
      // (success:false) before re-throwing.
      await emitServiceEvent(this.eventBus, 'ResponseReturned', {
        correlationId: ctx.request.correlationId,
        requestId: ctx.request.requestId,
        operation: request.operation,
        stageOrder: 12,
        durationMs: Date.now() - requestStartedAt,
        payload: {
          requestId: ctx.request.requestId,
          ok: false,
          status: 500,
          durationMs: Date.now() - requestStartedAt,
        },
      })
      throw err
    }

    logger.info(
      { requestId: result.request.requestId, ok: result.response.ok, durationMs: result.response.durationMs },
      'RuntimeService: pipeline completed',
    )

    // --- Sprint 21: emit ResponseReturned (best-effort) -----------------
    await emitServiceEvent(this.eventBus, 'ResponseReturned', {
      correlationId: result.request.correlationId,
      requestId: result.request.requestId,
      operation: request.operation,
      stageOrder: 12,
      durationMs: result.response.durationMs,
      payload: {
        requestId: result.request.requestId,
        ok: result.response.ok,
        status: result.response.ok ? 200 : 500,
        durationMs: result.response.durationMs,
      },
    })

    return result.response
  }

  // ===========================================================================
  // Épica 2 — Business-layer entry point
  // ===========================================================================

  /**
   * Returns the Business-layer module registry. Callers (runtime-singleton,
   * tests, bootstrap code) register BusinessModuleBase subclasses here so
   * that `executeJob()` can route JobRequests to them.
   */
  getBusinessModuleRegistry(): BusinessModuleRegistry {
    return this.businessModuleRegistry
  }

  /**
   * Épica 2: executes a Business-layer JobRequest.
   *
   * Flow:
   *   1. Ensures the RuntimeService is initialized (calls initialize() once
   *      if not yet ready — same lazy-init contract as `execute()`).
   *   2. Builds a BusinessContext from the JobRequest's jobId + metadata.
   *   3. Looks up the BusinessModuleRegistry for the FIRST module that
   *      exposes a capability named `request.jobType` (capability names map
   *      1:1 to JobType values).
   *   4. If no module is found, returns a failed JobResponse with a
   *      descriptive error message. Does NOT throw.
   *   5. If the chosen module is not yet ready, initializes it (best-effort
   *      — on failure returns a failed JobResponse).
   *   6. Calls `module.executeJob(jobType, input, ctx)`. Catches any thrown
   *      error and converts it to a failed ExecutionResult so the registry
   *      contract ("modules MUST NOT throw from executeJob") is enforced
   *      defensively.
   *   7. Returns a JobResponse with status 'completed' (when result.ok) or
   *      'failed' (when !result.ok), carrying output/error/artifacts/metrics.
   *
   * This method is additive — existing `execute()` behavior is unchanged.
   */
  async executeJob(request: JobRequest): Promise<JobResponse> {
    if (!this.initialized) {
      await this.initialize()
    }

    const startedAtIso = new Date().toISOString()
    const startMs = Date.now()

    // Sprint 3: record the job as 'running' in the in-memory tracker.
    this.trackJob({
      jobId: request.jobId,
      jobType: request.jobType,
      status: 'running',
      startedAt: startedAtIso,
      durationMs: 0,
      correlationId: request.metadata?.correlationId,
      requestId: request.metadata?.requestId,
      cancelRequested: false,
    })

    // 1. Build the BusinessContext from the JobRequest's metadata bag.
    const ctx = createBusinessContext({
      jobId: request.jobId,
      correlationId: request.metadata?.correlationId,
      requestId: request.metadata?.requestId,
      userId: request.metadata?.userId,
      workspaceId: request.metadata?.workspaceId,
      projectId: request.metadata?.projectId,
      locale: request.metadata?.locale,
    })

    // 2. Find the first module that exposes the job type as a capability.
    const candidates = this.businessModuleRegistry.findByCapability(request.jobType)
    if (candidates.length === 0) {
      const completedAtIso = new Date().toISOString()
      this.trackJob({
        jobId: request.jobId,
        jobType: request.jobType,
        status: 'failed',
        startedAt: startedAtIso,
        completedAt: completedAtIso,
        durationMs: Date.now() - startMs,
        error: `No module registered for job type '${request.jobType}'`,
        correlationId: request.metadata?.correlationId,
        requestId: request.metadata?.requestId,
        cancelRequested: false,
      })
      return createJobResponse(request.jobId, 'failed', {
        startedAt: startedAtIso,
        completedAt: completedAtIso,
        durationMs: Date.now() - startMs,
        error: `No module registered for job type '${request.jobType}'`,
      })
    }

    // 3. Pick the first candidate (registry returns insertion order).
    const businessModule = candidates[0]

    // 4. Lazy-init the chosen module if it isn't ready yet.
    if (!businessModule.isReady()) {
      try {
        await businessModule.initialize()
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        const completedAtIso = new Date().toISOString()
        this.trackJob({
          jobId: request.jobId,
          jobType: request.jobType,
          status: 'failed',
          startedAt: startedAtIso,
          completedAt: completedAtIso,
          durationMs: Date.now() - startMs,
          error: `Module '${businessModule.name}' failed to initialize: ${msg}`,
          correlationId: request.metadata?.correlationId,
          requestId: request.metadata?.requestId,
          cancelRequested: false,
        })
        return createJobResponse(request.jobId, 'failed', {
          startedAt: startedAtIso,
          completedAt: completedAtIso,
          durationMs: Date.now() - startMs,
          error: `Module '${businessModule.name}' failed to initialize: ${msg}`,
        })
      }
    }

    // 5. Execute the job. The module contract says executeJob() MUST NOT
    //    throw, but we wrap defensively so a buggy module can never crash
    //    the RuntimeService path.
    let result: ExecutionResult
    try {
      result = await businessModule.executeJob(request.jobType, request.input, ctx)
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      result = createFailedResult(msg)
    }

    // 6. Build the JobResponse from the ExecutionResult.
    const completedAtIso = new Date().toISOString()
    const finalStatus = result.ok ? 'completed' : 'failed'
    // Sprint 3: if cancellation was requested while the job was running,
    // mark the tracked status as 'cancelled' regardless of the module result.
    const tracked = this.trackedJobs.get(request.jobId)
    const wasCancelled = tracked?.cancelRequested === true
    this.trackJob({
      jobId: request.jobId,
      jobType: request.jobType,
      status: wasCancelled ? 'cancelled' : finalStatus,
      startedAt: startedAtIso,
      completedAt: completedAtIso,
      durationMs: Date.now() - startMs,
      error: result.error,
      correlationId: request.metadata?.correlationId,
      requestId: request.metadata?.requestId,
      cancelRequested: tracked?.cancelRequested ?? false,
    })
    return createJobResponse(request.jobId, wasCancelled ? 'cancelled' : finalStatus, {
      startedAt: startedAtIso,
      completedAt: completedAtIso,
      durationMs: Date.now() - startMs,
      output: result.output,
      error: result.error,
      artifacts: result.artifacts,
      metrics: result.metrics,
    })
  }

  // ===========================================================================
  // Sprint 3 — Job management API (additive, backward compatible)
  // ===========================================================================

  /**
   * Sprint 3: Returns the status of a specific job by ID.
   *
   * Returns the tracked job metadata (status, timestamps, error, correlation
   * IDs) or null if the job is unknown to this RuntimeService instance.
   *
   * This is an in-memory view: jobs are tracked for the lifetime of the
   * RuntimeService process (bounded to the last 1000 jobs). For persistent
   * status across restarts, the tracker can be migrated to Prisma in a
   * future sprint without changing this method's signature.
   */
  getStatus(jobId: string): { jobId: string; jobType: string; status: string; startedAt: string; completedAt?: string; durationMs: number; error?: string; correlationId?: string; requestId?: string; cancelRequested: boolean } | null {
    const tracked = this.trackedJobs.get(jobId)
    if (!tracked) return null
    return { ...tracked }
  }

  /**
   * Sprint 3: Lists tracked jobs, optionally filtered by status.
   *
   * Returns jobs in reverse-chronological order (most recent first).
   * Each entry contains the same fields as getStatus().
   *
   * @param statusFilter - Optional status to filter by ('running', 'completed', 'failed', 'cancelled').
   * @param limit - Maximum number of jobs to return (default 100).
   */
  listJobs(statusFilter?: string, limit: number = 100): Array<{ jobId: string; jobType: string; status: string; startedAt: string; completedAt?: string; durationMs: number; error?: string; correlationId?: string; requestId?: string; cancelRequested: boolean }> {
    const all = Array.from(this.trackedJobs.values()).reverse()
    const filtered = statusFilter ? all.filter((j) => j.status === statusFilter) : all
    return filtered.slice(0, Math.max(0, limit)).map((j) => ({ ...j }))
  }

  /**
   * Sprint 3: Requests cancellation of a running or pending job.
   *
   * This sets a 'cancelRequested' flag on the tracked job. The actual
   * cancellation is cooperative: the executing module must check the flag
   * (or the job must complete naturally) for the cancellation to take
   * effect. When the job next reports its status, it will be marked as
   * 'cancelled' if cancelRequested was set.
   *
   * Returns true if the cancellation request was recorded (job exists and
   * was in a cancellable state), false otherwise.
   */
  cancelJob(jobId: string): boolean {
    const tracked = this.trackedJobs.get(jobId)
    if (!tracked) return false
    if (tracked.status !== 'running' && tracked.status !== 'pending') return false
    tracked.cancelRequested = true
    logger.info({ jobId, jobType: tracked.jobType }, 'RuntimeService.cancelJob: cancellation requested')
    return true
  }

  /**
   * Sprint 3: Internal helper — records or updates a tracked job.
   * Enforces the bounded-size invariant (FIFO eviction at JOB_TRACKER_MAX).
   */
  private trackJob(job: TrackedJob): void {
    // Evict oldest if we are at capacity and this is a new entry.
    if (!this.trackedJobs.has(job.jobId) && this.trackedJobs.size >= JOB_TRACKER_MAX) {
      const oldest = this.jobOrder.shift()
      if (oldest) this.trackedJobs.delete(oldest)
    }
    if (!this.trackedJobs.has(job.jobId)) {
      this.jobOrder.push(job.jobId)
    }
    this.trackedJobs.set(job.jobId, job)
  }

  /**
   * Returns the status of all registered modules.
   */
  getModuleStatus() {
    return this.moduleRegistry.getStatus()
  }

  /**
   * Returns the list of pipeline stage names.
   */
  getPipelineStages(): string[] {
    return this.pipelineRegistry.get('default').getStageNames()
  }

  /**
   * Returns the bootstrap instance (or null if not configured).
   */
  getBootstrap(): RuntimeBootstrap | null {
    return this.bootstrap
  }

  /**
   * Returns the bootstrap result (or null if bootstrap hasn't run).
   */
  getBootstrapResult(): BootstrapResult | null {
    return this.bootstrap?.getResult() || null
  }

  /**
   * Returns the event bus.
   */
  getEventBus(): RuntimeEventBus {
    return this.eventBus
  }

  /**
   * Returns the module registry.
   */
  getModuleRegistry(): ModuleRegistry {
    return this.moduleRegistry
  }

  /**
   * Returns the full health matrix for all modules.
   * Sprint 15: aggregates health() from every registered module.
   */
  async getRuntimeHealth(): Promise<{
    status: 'ready' | 'degraded' | 'unhealthy'
    startedAt: string
    uptimeMs: number
    totalModules: number
    readyModules: number
    modules: Array<{ name: string; category: string; health: ModuleHealth }>
  }> {
    const moduleHealths = await this.moduleRegistry.getHealth()
    const totalModules = moduleHealths.length
    const readyModules = moduleHealths.filter((m) => m.health.ready).length
    const bootstrapResult = this.bootstrap?.getResult()
    const startedAt = bootstrapResult?.startedAt || new Date().toISOString()
    const uptimeMs = Date.now() - new Date(startedAt).getTime()

    let status: 'ready' | 'degraded' | 'unhealthy' = 'ready'
    if (readyModules < totalModules) {
      status = readyModules === 0 ? 'unhealthy' : 'degraded'
    }

    return {
      status,
      startedAt,
      uptimeMs,
      totalModules,
      readyModules,
      modules: moduleHealths.map((m) => ({
        name: m.name,
        category: m.category,
        health: m.health,
      })),
    }
  }
}
