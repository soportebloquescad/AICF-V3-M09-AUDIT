// =============================================================================
// AICF V3 — LiteLLM Adapter
// =============================================================================
// Concrete implementation of AIAdapter that talks to the LiteLLM gateway.
// Uses process.env.LITELLM_BASE_URL and process.env.LITELLM_API_KEY.
//
// Features:
//   - Configurable timeout (default 120s)
//   - Automatic retry with exponential backoff (via p-retry)
//   - Typed errors (AIAdapterError)
//   - Response parsing & normalization
//   - Never exposes stack traces to callers
// =============================================================================

import pRetry from 'p-retry'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from './AIAdapter'
import { AIAdapterError } from './AIAdapter'
import { logger } from './logger'

const DEFAULT_TIMEOUT_MS = 120_000
const MAX_RETRIES = 2
const BASE_URL = process.env.LITELLM_BASE_URL || 'http://localhost:4000'
const API_KEY = process.env.LITELLM_API_KEY || ''

/**
 * Adapts the LiteLLM OpenAI-compatible API to the AIAdapter interface.
 *
 * @example
 * const adapter = new LiteLLMAdapter()
 * const response = await adapter.chat({ model: 'groq-llama-3.3-70b', messages: [...] })
 */
export class LiteLLMAdapter implements AIAdapter {
  private readonly baseUrl: string
  private readonly apiKey: string
  private readonly timeoutMs: number

  constructor(options?: {
    baseUrl?: string
    apiKey?: string
    timeoutMs?: number
  }) {
    this.baseUrl = (options?.baseUrl || BASE_URL).replace(/\/+$/, '')
    this.apiKey = options?.apiKey || API_KEY
    this.timeoutMs = options?.timeoutMs || DEFAULT_TIMEOUT_MS

    if (!this.apiKey) {
      logger.warn('LiteLLMAdapter initialized without LITELLM_API_KEY — requests will fail with AUTH error')
    }
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const startMs = Date.now()
    const url = `${this.baseUrl}/v1/chat/completions`

    const body = {
      model: request.model,
      messages: request.messages,
      ...(request.temperature !== undefined && { temperature: request.temperature }),
      ...(request.maxTokens !== undefined && { max_tokens: request.maxTokens }),
      ...(request.topP !== undefined && { top_p: request.topP }),
      ...(request.stop !== undefined && { stop: request.stop }),
      ...(request.stream !== undefined && { stream: request.stream }),
    }

    logger.debug({ url, model: request.model }, 'LiteLLM chat request')

    const raw = await pRetry(
      () => this.fetchWithTimeout(url, 'POST', body),
      {
        retries: MAX_RETRIES,
        onFailedAttempt: (err) => {
          logger.warn(
            { attempt: err.attemptNumber, message: err.message },
            'LiteLLM chat retry',
          )
        },
      },
    )

    const durationMs = Date.now() - startMs

    const typed = raw as { model?: string; choices?: Array<{ message?: { content?: unknown } }>; usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number } }
    const choice = typed?.choices?.[0]
    // NORMALIZE: siempre devolver un string para `content`.
    // Algunos proveedores devuelven content como array de bloques, null, o undefined.
    // El contrato ChatResponse exige `content: string` (non-null, non-optional).
    const rawContent = choice?.message?.content
    const content = typeof rawContent === 'string' ? rawContent : ''
    const usage = typed?.usage

    return {
      content,
      model: typeof typed?.model === 'string' ? typed.model : request.model,
      provider: 'litellm',
      usage: usage
        ? {
            promptTokens: usage.prompt_tokens ?? 0,
            completionTokens: usage.completion_tokens ?? 0,
            totalTokens: usage.total_tokens ?? 0,
          }
        : null,
      durationMs,
    }
  }

  async models(): Promise<AIModel[]> {
    const url = `${this.baseUrl}/v1/models`
    const raw = await this.fetchWithTimeout(url, 'GET')

    const data = raw?.data
    if (!Array.isArray(data)) return []

    return data.map((m: { id?: string; owned_by?: string }) => ({
      id: m.id || 'unknown',
      provider: 'litellm',
      ownedBy: m.owned_by,
    }))
  }

  async health(): Promise<AIHealth> {
    const url = `${this.baseUrl}/health`
    const startMs = Date.now()

    try {
      await this.fetchWithTimeout(url, 'GET')
      return {
        healthy: true,
        provider: 'litellm',
        latencyMs: Date.now() - startMs,
      }
    } catch (err) {
      return {
        healthy: false,
        provider: 'litellm',
        latencyMs: Date.now() - startMs,
        details: { error: err instanceof Error ? err.message : String(err) },
      }
    }
  }

  /**
   * Internal fetch with timeout and error mapping.
   * @throws {AIAdapterError}
   */
  private async fetchWithTimeout(url: string, method: string, body?: unknown): Promise<Record<string, unknown>> {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), this.timeoutMs)

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(this.apiKey && { Authorization: `Bearer ${this.apiKey}` }),
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      })

      if (!res.ok) {
        const text = await res.text().catch(() => '')
        throw this.mapHttpError(res.status, text)
      }

      const json = await res.json()
      return json as Record<string, unknown>
    } catch (err) {
      if (err instanceof AIAdapterError) throw err

      if (err instanceof DOMException && err.name === 'AbortError') {
        throw new AIAdapterError(
          `Request timed out after ${this.timeoutMs}ms`,
          'TIMEOUT',
          504,
          err,
        )
      }

      throw new AIAdapterError(
        err instanceof Error ? err.message : 'Network error',
        'NETWORK',
        502,
        err,
      )
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * Maps HTTP status codes to typed AIAdapterError.
   */
  private mapHttpError(status: number, body: string): AIAdapterError {
    if (status === 401 || status === 403) {
      return new AIAdapterError('Authentication failed — check LITELLM_API_KEY', 'AUTH', status)
    }
    if (status === 404) {
      return new AIAdapterError('Model not found — check model name', 'MODEL_NOT_FOUND', status)
    }
    if (status === 429) {
      return new AIAdapterError('Rate limit exceeded', 'RATE_LIMIT', status)
    }
    return new AIAdapterError(`LiteLLM returned ${status}: ${body.slice(0, 200)}`, 'UNKNOWN', status)
  }
}
