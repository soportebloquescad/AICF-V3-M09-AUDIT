// =============================================================================
// AICF V3 — Sprint 13+14 — Runtime Interfaces Barrel
// =============================================================================
// Re-exports every interface, type, and supporting shape declared by the ten
// runtime interface modules. Consumers should import from this barrel only:
//
//   import {
//     type IWorkflowEngine,
//     type IStepExecutor,
//     type StepExecutionResult,
//     type IProvider,
//   } from '@/lib/runtime/interfaces'
//
// Sprint 13+14 spec: the barrel is the single public surface for runtime
// interfaces. Internal modules should never deep-import the underlying files.
// =============================================================================

// --- IWorkflowEngine.ts ----------------------------------------------------
export type { ExecutionTrace, IWorkflowEngine } from './IWorkflowEngine'

// --- IStepExecutor.ts ------------------------------------------------------
export type {
  StepExecutionContext,
  StepExecutionResult,
  IStepExecutor,
} from './IStepExecutor'

// --- IProvider.ts ----------------------------------------------------------
export type {
  ProviderCapability,
  ProviderManifest,
  IProvider,
} from './IProvider'

// --- ITemplate.ts ----------------------------------------------------------
export type { ITemplate } from './ITemplate'

// --- IGenerator.ts ---------------------------------------------------------
export type {
  GeneratorType,
  GeneratorInput,
  GeneratorOutput,
  IGenerator,
} from './IGenerator'

// --- IArtifactStorage.ts ---------------------------------------------------
export type { IArtifactStorage } from './IArtifactStorage'

// --- IEventBus.ts ----------------------------------------------------------
export type { EventHandler, IEventBus } from './IEventBus'

// --- IWorkflowStateStore.ts ------------------------------------------------
export type { IWorkflowStateStore } from './IWorkflowStateStore'

// --- ICacheProvider.ts -----------------------------------------------------
export type { ICacheProvider } from './ICacheProvider'

// --- ISecretsResolver.ts ---------------------------------------------------
export type {
  SecretSource,
  SecretResolverFn,
  ISecretsResolver,
} from './ISecretsResolver'
