// =============================================================================
// AICF V3 — Sprint 7 (RC34.1) — Workflow Module Barrel
// =============================================================================

export { WorkflowRegistry, getGlobalWorkflowRegistry, type WorkflowRegistryResult } from './WorkflowRegistry'
export { WorkflowEventBus, getGlobalWorkflowEventBus, type WorkflowEvent, type WorkflowEventType, type WorkflowEventSubscriber } from './WorkflowEventBus'
export { WorkflowHistory, getGlobalWorkflowHistory, type WorkflowHistoryEntry } from './WorkflowHistory'

// Re-export existing workflow contracts
export type { WorkflowDefinition, WorkflowStepDefinition, WorkflowStepType, WorkflowMetadata } from '../contracts/workflow/WorkflowDefinition'
export type { WorkflowResult } from '../contracts/workflow/WorkflowResult'
export type { WorkflowContext } from '../contracts/workflow/WorkflowContext'
