// =============================================================================
// AICF V3 — DocumentModule Tests (Épica 3 — Educational Factory)
// =============================================================================
// Verifies the DocumentModule:
//   - generateDocument fallback (no AI) — produces real structured markdown
//     for every supported document type.
//   - Document types: workbook, teacher-guide, student-guide,
//     implementation-guide, glossary, checklist, resources.
//   - HTML output is valid HTML5 with embedded CSS.
//   - Unknown job types produce a failed ExecutionResult.
//
// No `any`. The variable holding the module under test is named `testModule`.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { DocumentModule, DOCUMENT_MODULE_METADATA } from '../DocumentModule'
import type { DocumentType } from '../DocumentModule'
import { createBusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

class MockAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> {
    return {
      content: JSON.stringify({
        title: 'Mock Document',
        sections: [
          { heading: 'Mock Heading 1', body: 'Mock body 1.' },
          { heading: 'Mock Heading 2', body: 'Mock body 2.' },
        ],
      }),
      model: 'mock',
      provider: 'mock',
      usage: null,
      durationMs: 1,
    }
  }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: true, provider: 'mock' } }
}

class FailingAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> { throw new Error('AI unavailable') }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: false, provider: 'failing' } }
}

const ctx = createBusinessContext({ jobId: 'job-test-doc-1' })

const ALL_TYPES: DocumentType[] = [
  'workbook',
  'teacher-guide',
  'student-guide',
  'implementation-guide',
  'glossary',
  'checklist',
  'resources',
]

describe('DocumentModule (Épica 3)', () => {
  describe('metadata + lifecycle', () => {
    const testModule = new DocumentModule()

    it('exposes the correct metadata', () => {
      expect(testModule.getMetadata()).toEqual(DOCUMENT_MODULE_METADATA)
      expect(testModule.name).toBe('document')
    })

    it('declares the expected capabilities', () => {
      const caps = testModule.getCapabilities().map((c) => c.name)
      expect(caps).toContain('generateDocument')
      expect(caps).toContain('exportDocument')
    })
  })

  describe('executeJob — fallback (no AI)', () => {
    const testModule = new DocumentModule()

    it('produces a workbook with structured sections', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      expect(result.ok).toBe(true)
      const doc = result.output!.document as Record<string, unknown>
      expect(doc.type).toBe('workbook')
      expect(doc.format).toBe('markdown')
      const sections = doc.sectionList as Array<Record<string, unknown>>
      expect(sections.length).toBeGreaterThan(0)
      const headings = sections.map((s) => s.heading as string)
      expect(headings).toContain('Overview')
      expect(headings).toContain('Exercises')
      expect(headings).toContain('Answer Key')
    })

    it('each section has a non-empty heading + body', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'teacher-guide' },
        ctx,
      )
      const sections = (result.output!.document as Record<string, unknown>).sectionList as Array<Record<string, unknown>>
      for (const s of sections) {
        expect(typeof s.heading).toBe('string')
        expect((s.heading as string).length).toBeGreaterThan(0)
        expect(typeof s.body).toBe('string')
        expect((s.body as string).length).toBeGreaterThan(0)
      }
    })

    it('produces markdown + html', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      const doc = result.output!.document as Record<string, unknown>
      expect(typeof doc.content).toBe('string')
      expect((doc.content as string)).toContain('# Workbook: Rust')
      expect((doc.html as string)).toContain('<!DOCTYPE html>')
      expect((doc.html as string)).toContain('<style>')
    })

    it('accepts the "documentType" alias', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', documentType: 'glossary' },
        ctx,
      )
      expect((result.output!.document as Record<string, unknown>).type).toBe('glossary')
    })

    it('defaults to workbook when type is missing or invalid', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'not-a-real-type' },
        ctx,
      )
      expect((result.output!.document as Record<string, unknown>).type).toBe('workbook')
    })

    it('respects the "sections" knob', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook', sections: 3 },
        ctx,
      )
      const doc = result.output!.document as Record<string, unknown>
      const sections = doc.sectionList as unknown[]
      expect(sections).toHaveLength(3)
      expect(doc.sections).toBe(3)
    })
  })

  describe('executeJob — every document type produces real content', () => {
    const testModule = new DocumentModule()

    for (const type of ALL_TYPES) {
      it(`type=${type} produces a document with at least one section`, async () => {
        const result = await testModule.executeJob(
          'generateDocument',
          { topic: 'Rust', type },
          ctx,
        )
        expect(result.ok).toBe(true)
        const doc = result.output!.document as Record<string, unknown>
        expect(doc.type).toBe(type)
        const sections = doc.sectionList as Array<Record<string, unknown>>
        expect(sections.length).toBeGreaterThan(0)
        for (const s of sections) {
          expect((s.body as string).length).toBeGreaterThan(20)
        }
      })
    }
  })

  describe('executeJob — HTML output', () => {
    const testModule = new DocumentModule()

    it('renders tables for the teacher-guide rubric', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'teacher-guide' },
        ctx,
      )
      const html = (result.output!.document as Record<string, unknown>).html as string
      expect(html).toContain('<table>')
      expect(html).toContain('<td>')
      expect(html).toContain('Criterion')
      expect(html).toContain('Conceptual grasp')
    })

    it('renders task-list checkboxes for the checklist', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'checklist' },
        ctx,
      )
      const html = (result.output!.document as Record<string, unknown>).html as string
      expect(html).toContain('type="checkbox"')
    })

    it('renders bullet lists', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'student-guide' },
        ctx,
      )
      const html = (result.output!.document as Record<string, unknown>).html as string
      expect(html).toContain('<ul>')
      expect(html).toContain('<li>')
    })

    it('renders bold + italic inline formatting', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'glossary' },
        ctx,
      )
      const html = (result.output!.document as Record<string, unknown>).html as string
      expect(html).toContain('<strong>')
      expect(html).toContain('<em>')
    })

    it('includes print styles', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      const html = (result.output!.document as Record<string, unknown>).html as string
      expect(html).toContain('@media print')
    })
  })

  describe('executeJob — AI mode (mock)', () => {
    let testModule: DocumentModule

    beforeEach(() => {
      testModule = new DocumentModule(new MockAIAdapter())
    })

    it('parses the AI JSON into typed sections', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      expect(result.ok).toBe(true)
      const doc = result.output!.document as Record<string, unknown>
      const sections = doc.sectionList as Array<Record<string, unknown>>
      expect(sections).toHaveLength(2)
      expect(sections[0].heading).toBe('Mock Heading 1')
    })

    it('reports providerCalls=1', async () => {
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      expect(result.metrics?.providerCalls).toBe(1)
    })
  })

  describe('executeJob — AI failure degrades to fallback', () => {
    it('still produces a document when the AI adapter throws', async () => {
      const testModule = new DocumentModule(new FailingAIAdapter())
      const result = await testModule.executeJob(
        'generateDocument',
        { topic: 'Rust', type: 'workbook' },
        ctx,
      )
      expect(result.ok).toBe(true)
      const doc = result.output!.document as Record<string, unknown>
      const sections = doc.sectionList as unknown[]
      expect(sections.length).toBeGreaterThan(0)
      expect(testModule.getMetrics().errorCount).toBeGreaterThan(0)
    })
  })

  describe('executeJob — exportDocument alias', () => {
    const testModule = new DocumentModule()

    it('exportDocument works identically to generateDocument', async () => {
      const result = await testModule.executeJob(
        'exportDocument',
        { topic: 'Rust', type: 'checklist' },
        ctx,
      )
      expect(result.ok).toBe(true)
      expect((result.output!.document as Record<string, unknown>).type).toBe('checklist')
    })
  })

  describe('executeJob — unknown job type', () => {
    const testModule = new DocumentModule()

    it('returns a failed ExecutionResult', async () => {
      const result = await testModule.executeJob('bogusJob', { topic: 'Rust' }, ctx)
      expect(result.ok).toBe(false)
      expect(result.error).toContain('Unknown job type')
    })
  })
})
