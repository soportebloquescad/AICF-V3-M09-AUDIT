// =============================================================================
// AICF V3 — Sprint 13+14 — Chat Provider
// =============================================================================
// Provider that fulfills the `'chat'` capability by delegating to an
// injected `AIAdapter` (e.g. LiteLLMAdapter, RuntimeAdapter). This is the
// primary provider for chat-completion steps in a workflow: it accepts a
// list of messages and a model spec, calls the AI backend, and returns a
// `StepExecutionResult` with the assistant's content.
//
// Sprint 13+14 spec requirements covered:
//   - `IProvider` interface compliance (`name`, `capabilities`,
//     `initialize`, `execute`, `isReady`, `getManifest`)
//   - Reads `messages` / `model` / `temperature` from the step input or
//     the runtime context
//   - Returns `output: { content, model, provider, usage }`, `tokensUsed`,
//     `cost`, `durationMs`
//   - Cost calculation: trivial per-token-rate heuristic (default
//     $0.000002 per token — adjustable via constructor config)
//   - No `any` — open values typed as `unknown` with explicit guards
// =============================================================================

import type { AIAdapter, ChatMessage } from '@/lib/ai/AIAdapter'
import type { WorkflowContext, TokenUsage } from '@/lib/runtime/contracts/workflow'
import type {
  IProvider,
  ProviderCapability,
  ProviderManifest,
  StepExecutionResult,
} from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/** Constructor options for `ChatProvider`. */
export interface ChatProviderOptions {
  /** Per-token cost (platform currency units). Default: 0.000002. */
  costPerToken?: number
  /** Provider display name. Default: `'chat'`. */
  name?: string
}

/**
 * Provider that fulfills the `'chat'` capability by calling an injected
 * `AIAdapter`. Thread-safe across executions: all per-execution state
 * lives in `WorkflowContext`, not in the provider.
 */
export class ChatProvider implements IProvider {
  readonly name: string
  readonly capabilities: ProviderCapability[] = ['chat']
  private ready = false
  private readonly costPerToken: number

  /**
   * @param aiAdapter The AI backend adapter (LiteLLM, Runtime, ...).
   * @param opts      Optional config (cost rate, name override).
   */
  constructor(
    private readonly aiAdapter: AIAdapter,
    opts: ChatProviderOptions = {},
  ) {
    this.name = opts.name ?? 'chat'
    this.costPerToken = opts.costPerToken ?? 0.000002
  }

  /** Initialize the provider. Marks itself ready; does not block. */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug({ provider: this.name }, 'chat provider initialized')
  }

  /** Whether `initialize` has been called. */
  isReady(): boolean {
    return this.ready
  }

  /** Self-describing manifest for the registry / UI. */
  getManifest(): ProviderManifest {
    return {
      name: this.name,
      version: '1.0.0',
      capabilities: [...this.capabilities],
      config: { costPerToken: this.costPerToken },
      description: 'Chat-completion provider backed by an AIAdapter',
    }
  }

  /**
   * Execute the `'chat'` capability.
   *
   * Input shape (read from `input`):
   *   - `messages`: `ChatMessage[]` (required)
   *   - `model`: `string` (falls back to `ctx.model`)
   *   - `temperature`: `number` (optional)
   *   - `maxTokens`: `number` (optional)
   *
   * Output shape:
   *   - `content`: assistant's reply text
   *   - `model`: resolved model name
   *   - `provider`: adapter-reported provider name
   *   - `usage`: `ChatUsage` (or null)
   */
  async execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<StepExecutionResult> {
    if (capability !== 'chat') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: `chat provider cannot handle capability "${capability}"`,
      }
    }

    const messages = this.extractMessages(input.messages)
    if (messages.length === 0) {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: 'input.messages is empty or malformed',
      }
    }

    const model =
      typeof input.model === 'string' && input.model.length > 0
        ? input.model
        : ctx.model ?? 'gpt-4o-mini'
    const temperature =
      typeof input.temperature === 'number' ? input.temperature : undefined
    const maxTokens =
      typeof input.maxTokens === 'number' ? input.maxTokens : undefined

    try {
      const response = await this.aiAdapter.chat({
        model,
        messages,
        ...(temperature !== undefined ? { temperature } : {}),
        ...(maxTokens !== undefined ? { maxTokens } : {}),
      })

      const tokensUsed: TokenUsage | undefined = response.usage
        ? {
            promptTokens: response.usage.promptTokens,
            completionTokens: response.usage.completionTokens,
            totalTokens: response.usage.totalTokens,
          }
        : undefined

      const cost = tokensUsed
        ? tokensUsed.totalTokens * this.costPerToken
        : 0

      return {
        ok: true,
        output: {
          content: response.content,
          model: response.model,
          provider: response.provider,
          usage: response.usage,
        },
        artifacts: [],
        durationMs: response.durationMs,
        tokensUsed,
        cost,
        provider: response.provider,
        model: response.model,
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'unknown chat adapter error'
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 0,
        error: message,
      }
    }
  }

  /**
   * Coerce `raw` into a `ChatMessage[]`. Accepts an array of objects with
   * `role` and `content` string fields. Malformed entries are dropped.
   */
  private extractMessages(raw: unknown): ChatMessage[] {
    if (!Array.isArray(raw)) return []
    const out: ChatMessage[] = []
    for (const item of raw) {
      if (
        item &&
        typeof item === 'object' &&
        typeof (item as { role?: unknown }).role === 'string' &&
        typeof (item as { content?: unknown }).content === 'string'
      ) {
        const r = (item as { role: string }).role
        if (r === 'system' || r === 'user' || r === 'assistant') {
          out.push({
            role: r,
            content: (item as { content: string }).content,
          })
        }
      }
    }
    return out
  }
}
