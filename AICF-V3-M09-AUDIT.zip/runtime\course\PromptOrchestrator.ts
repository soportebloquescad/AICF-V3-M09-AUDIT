// =============================================================================
// AICF V3 — Épica 6 — Prompt Orchestrator
// =============================================================================
export interface PromptVariables {
  topic?: string
  locale?: string
  audience?: string
  level?: string
  moduleCount?: number
  language?: string
  country?: string
  bloomLevel?: string
  length?: string
  context?: string
  terminology?: string
  examples?: string
  institutions?: string
  [key: string]: unknown
}

export interface PromptTemplate {
  id: string
  name: string
  template: string
  variables: string[]
}

const DEFAULTS: Record<string, string> = {
  topic: 'the requested topic',
  locale: 'en-US',
  audience: 'general learners',
  level: 'intermediate',
  moduleCount: '5',
  language: 'English',
  country: 'Global',
  bloomLevel: 'Understand',
  length: 'standard',
  context: '',
  terminology: '',
  examples: 'relevant examples',
  institutions: '',
}

const TEMPLATES: Record<string, PromptTemplate> = {
  research: { id: 'research', name: 'Research', template: 'SYSTEM:\nYou are a research assistant. Research {{topic}} for {{locale}}.\n\nUSER:\nResearch {{topic}} comprehensively. Return key facts as JSON.', variables: ['topic', 'locale'] },
  curriculum: { id: 'curriculum', name: 'Curriculum Design', template: 'SYSTEM:\nYou are an instructional designer. Create a {{moduleCount}}-module curriculum for {{topic}} at {{level}} level.\n\nTerminology: {{terminology}}\nInstitutions: {{institutions}}\n\nUSER:\nDesign the curriculum with modules and lessons.', variables: ['topic', 'moduleCount', 'level', 'terminology', 'institutions'] },
  lesson: { id: 'lesson', name: 'Lesson Writing', template: 'SYSTEM:\nYou are a lesson writer. Write a {{length}} lesson about {{topic}} for {{audience}}.\nLevel: {{level}}\nBloom: {{bloomLevel}}\nLanguage: {{language}}\n\nUSER:\nWrite the lesson content in Markdown.', variables: ['topic', 'length', 'audience', 'level', 'bloomLevel', 'language'] },
  exercise: { id: 'exercise', name: 'Exercise Writing', template: 'SYSTEM:\nYou are an exercise designer. Create an exercise for {{topic}}.\nLevel: {{level}}\n\nUSER:\nCreate the exercise with question and answer.', variables: ['topic', 'level'] },
  assessment: { id: 'assessment', name: 'Assessment', template: 'SYSTEM:\nYou are an assessment designer. Create quiz questions for {{topic}}.\nLevel: {{level}}\n\nUSER:\nReturn JSON with questions, options, correctIndex, explanation.', variables: ['topic', 'level'] },
  slides: { id: 'slides', name: 'Slide Generation', template: 'SYSTEM:\nYou are a slide designer. Create slides for {{topic}}.\nAudience: {{audience}}\n\nUSER:\nReturn JSON with slides array containing title, bullets, notes.', variables: ['topic', 'audience'] },
  document: { id: 'document', name: 'Document Generation', template: 'SYSTEM:\nYou are a document writer. Create a document about {{topic}}.\nLanguage: {{language}}\n\nUSER:\nWrite the document in Markdown.', variables: ['topic', 'language'] },
  consistency: { id: 'consistency', name: 'Consistency Check', template: 'SYSTEM:\nYou are a consistency editor. Check the following content for terminology and style consistency.\n\nTerminology: {{terminology}}\n\nUSER:\nReview the content and list any inconsistencies.', variables: ['terminology'] },
}

export class PromptOrchestrator {
  private readonly templates: Map<string, PromptTemplate> = new Map(Object.entries(TEMPLATES))

  build(templateId: string, variables: PromptVariables): { system: string; user: string } {
    const tpl = this.templates.get(templateId)
    if (!tpl) throw new Error(`PromptOrchestrator: template "${templateId}" not found`)
    const rendered = this.render(tpl.template, variables)
    const parts = rendered.split('\nUSER:\n')
    return {
      system: (parts[0] ?? '').replace(/^SYSTEM:\n/, ''),
      user: parts[1] ?? rendered,
    }
  }

  registerTemplate(template: PromptTemplate): void {
    this.templates.set(template.id, template)
  }

  getTemplate(id: string): PromptTemplate | null {
    return this.templates.get(id) ?? null
  }

  listTemplates(): string[] {
    return Array.from(this.templates.keys())
  }

  render(template: string, variables: PromptVariables): string {
    return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
      const v = variables[key]
      if (typeof v === 'string' && v.length > 0) return v
      if (typeof v === 'number') return String(v)
      return DEFAULTS[key] ?? `{{${key}}}`
    })
  }
}
