// =============================================================================
// AICF V3 — Sprint 8 RC54 — InteractiveEngine
// =============================================================================
// Generates interactive HTML elements: quizzes, flashcards, drag & drop,
// timelines, accordions, tabs, popup definitions.
// REUSES: Quiz, Exercise from CourseContracts.
// =============================================================================

import type { CourseResult, Quiz, Exercise } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

export interface InteractiveElement {
  type: 'quiz' | 'flashcard' | 'drag-drop' | 'timeline' | 'accordion' | 'tabs' | 'popup-glossary'
  html: string
  data: Record<string, unknown>
}

export class InteractiveEngine {
  private readonly log = logger.child({ component: 'InteractiveEngine' })

  buildAll(course: CourseResult): InteractiveElement[] {
    const elements: InteractiveElement[] = []
    for (const quiz of course.quizzes) elements.push(this.buildQuiz(quiz))
    elements.push(this.buildFlashcards(course))
    elements.push(this.buildDragDrop(course))
    elements.push(this.buildTimeline(course))
    elements.push(this.buildAccordion(course))
    elements.push(this.buildPopupGlossary(course))
    return elements
  }

  buildQuiz(quiz: Quiz): InteractiveElement {
    const questionsHtml = quiz.questions.map((q, i) => `
      <div class="iq-question" data-question="${i}">
        <p class="iq-text"><strong>Q${i + 1}.</strong> ${this.escape(q.question)}</p>
        <div class="iq-options">
          ${q.options.map((opt, j) => `<div class="iq-option" data-correct="${j === q.correctIndex}" onclick="this.classList.add(this.dataset.correct === 'true' ? 'correct' : 'wrong')">${this.escape(opt)}</div>`).join('')}
        </div>
        <div class="iq-feedback" style="display:none;margin-top:0.5rem;padding:0.5rem;border-radius:6px;background:rgba(34,197,94,0.1);color:#22c55e;font-size:0.85rem;">
          ✅ Correct answer: ${this.escape(q.options[q.correctIndex])}
        </div>
      </div>`).join('')

    return {
      type: 'quiz',
      html: `<div class="interactive-quiz"><h4>🧪 ${this.escape(quiz.title)}</h4><p style="color:var(--muted);font-size:0.85rem">${this.escape(quiz.description)}</p>${questionsHtml}</div>`,
      data: { quizId: quiz.id, questionCount: quiz.questions.length, passingScore: quiz.passingScore },
    }
  }

  buildFlashcards(course: CourseResult): InteractiveElement {
    const cards = course.lessons.slice(0, 10).map((l, i) => `
      <div class="flashcard" onclick="this.classList.toggle('flipped')">
        <div class="flashcard-front"><strong>${this.escape(l.title)}</strong><p style="color:var(--muted);font-size:0.85rem">Click to reveal</p></div>
        <div class="flashcard-back"><p>${l.keyTakeaways.slice(0, 2).map(t => `• ${this.escape(t)}`).join('<br>')}</p></div>
      </div>`).join('')

    return {
      type: 'flashcard',
      html: `<div class="flashcards"><h4>📇 Flashcards</h4><div class="flashcard-grid">${cards}</div></div>`,
      data: { cardCount: Math.min(10, course.lessons.length) },
    }
  }

  buildDragDrop(course: CourseResult): InteractiveElement {
    const items = course.modules.slice(0, 5).map((m, i) => `<div class="dd-item" draggable="true" data-id="${i}">${this.escape(m.title)}</div>`).join('')
    return {
      type: 'drag-drop',
      html: `<div class="drag-drop-exercise"><h4>🔀 Drag & Drop: Order the Modules</h4><div class="dd-source">${items}</div><div class="dd-target" style="min-height:60px;border:2px dashed var(--border);border-radius:8px;padding:0.5rem;">Drop here</div></div>`,
      data: { itemCount: Math.min(5, course.modules.length) },
    }
  }

  buildTimeline(course: CourseResult): InteractiveElement {
    const events = course.modules.map((m, i) => `
      <div class="tl-event">
        <div class="tl-dot">${i + 1}</div>
        <div class="tl-content"><strong>${this.escape(m.title)}</strong><p style="font-size:0.85rem;color:var(--muted)">${this.escape(m.summary)}</p></div>
      </div>`).join('')
    return {
      type: 'timeline',
      html: `<div class="timeline"><h4>📅 Course Timeline</h4><div class="tl-track">${events}</div></div>`,
      data: { eventCount: course.modules.length },
    }
  }

  buildAccordion(course: CourseResult): InteractiveElement {
    const items = course.lessons.slice(0, 8).map(l => `
      <div class="acc-item">
        <div class="acc-title" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='block'?'none':'block'">▸ ${this.escape(l.title)}</div>
        <div class="acc-body" style="display:none;padding:0.5rem;">${this.escape(l.content.slice(0, 200))}...</div>
      </div>`).join('')
    return {
      type: 'accordion',
      html: `<div class="accordion-section"><h4>📂 Lesson Quick Access</h4>${items}</div>`,
      data: { itemCount: Math.min(8, course.lessons.length) },
    }
  }

  buildPopupGlossary(course: CourseResult): InteractiveElement {
    const terms = (course.curriculum?.learningOutcomes ?? []).slice(0, 10).map(t => `<span class="glossary-term" onclick="alert('${this.escape(t)}')" style="cursor:pointer;text-decoration:underline dotted;">${this.escape(t)}</span>`).join(' ')
    return {
      type: 'popup-glossary',
      html: `<div class="popup-glossary"><h4>📖 Glossary (click terms)</h4><p>${terms}</p></div>`,
      data: { termCount: Math.min(10, course.curriculum?.learningOutcomes.length ?? 0) },
    }
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;')
  }
}
