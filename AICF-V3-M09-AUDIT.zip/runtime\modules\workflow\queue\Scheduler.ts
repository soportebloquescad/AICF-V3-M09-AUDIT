// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Scheduler (stub for future cron/delayed/retry)
// =============================================================================
// EMPTY-but-structured scheduler. The public API is in place so that the
// rest of the runtime can be wired against it TODAY; the actual cron
// parsing, delayed-execution, and retry logic will be added in a future
// sprint (likely backed by Redis sorted sets / RabbitMQ delayed exchanges /
// Temporal workflows).
//
// Sprint 13+14 spec requirements covered:
//   - ScheduledJob interface (id, type, executionId, runAt, config, status)
//   - schedule(job, runAt)  — stores a job for future execution
//   - cancel(jobId)         — removes a scheduled job
//   - listScheduled()       — every scheduled job (any status)
//   - tick()                — processes due jobs, returns count processed
//   - start(intervalMs?)    — periodic timer that calls tick()
//   - stop()                — stops the periodic timer
//
// The scheduler is EMPTY: `tick()` simply marks due jobs as `'processed'`
// without actually invoking the workflow engine. The structure is ready
// for a real backend to be plugged in.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/** Type of scheduled job. */
export type ScheduledJobType = 'cron' | 'delayed' | 'retry'

/** Lifecycle status of a scheduled job. */
export type ScheduledJobStatus = 'pending' | 'running' | 'processed' | 'cancelled' | 'failed'

/** A scheduled (future) job. */
export interface ScheduledJob {
  /** Unique job id. */
  id: string
  /** Job type — drives the future backend's processing semantics. */
  type: ScheduledJobType
  /** Execution id this job targets (when applicable). */
  executionId: string
  /** Epoch ms when the job should next run. */
  runAt: number
  /** Job-specific config (cron expression, retry count, etc.). */
  config: Record<string, unknown>
  /** Current lifecycle status. */
  status: ScheduledJobStatus
}

/** Default tick interval: 60 seconds. */
const DEFAULT_TICK_INTERVAL_MS = 60_000

/**
 * Stub scheduler. Maintains an in-memory `Map<jobId, ScheduledJob>`. The
 * `tick()` method iterates due jobs and marks them `'processed'` — a real
 * backend would dispatch them to the workflow engine here.
 */
export class Scheduler {
  /** Map<jobId, ScheduledJob>. */
  private readonly jobs = new Map<string, ScheduledJob>()
  /** Handle for the periodic tick timer (null when stopped). */
  private timer: NodeJS.Timeout | null = null

  /**
   * Schedule a job for future execution. Overwrites `job.runAt` with the
   * provided `runAt` (epoch ms).
   */
  async schedule(job: ScheduledJob, runAt: Date): Promise<void> {
    const clone: ScheduledJob = {
      ...job,
      runAt: runAt.getTime(),
      status: 'pending',
    }
    this.jobs.set(job.id, clone)
    logger.debug(
      {
        jobId: job.id,
        type: job.type,
        executionId: job.executionId,
        runAt: clone.runAt,
      },
      'Scheduler: job scheduled',
    )
  }

  /**
   * Cancel a scheduled job. Sets status to `'cancelled'` (the job record
   * is retained for audit). No-op if the job is unknown.
   */
  async cancel(jobId: string): Promise<void> {
    const job = this.jobs.get(jobId)
    if (!job) return
    job.status = 'cancelled'
    logger.debug({ jobId }, 'Scheduler: job cancelled')
  }

  /**
   * List every scheduled job (any status). Returns shallow copies.
   */
  listScheduled(): ScheduledJob[] {
    return Array.from(this.jobs.values()).map((j) => ({ ...j }))
  }

  /**
   * Process due jobs. A job is "due" when `job.runAt <= Date.now()` AND
   * `job.status === 'pending'`. Due jobs are marked `'processed'`.
   *
   * Returns the number of jobs processed in this tick.
   *
   * NOTE: This is a STUB. A real implementation would dispatch each due
   * job to the workflow engine (for `retry` / `delayed` types) or to the
   * cron interpreter (for `cron` types) here.
   */
  async tick(): Promise<number> {
    const now = Date.now()
    let processed = 0
    for (const job of this.jobs.values()) {
      if (job.status !== 'pending') continue
      if (job.runAt > now) continue
      // STUB: a real backend dispatches the job here.
      job.status = 'processed'
      processed += 1
      logger.debug(
        { jobId: job.id, type: job.type, executionId: job.executionId },
        'Scheduler: job processed (stub)',
      )
    }
    if (processed > 0) {
      logger.info(
        { processed, remaining: this.jobs.size - processed },
        'Scheduler: tick complete',
      )
    }
    return processed
  }

  /**
   * Start the periodic tick timer. Safe to call multiple times — the
   * prior timer (if any) is cleared first.
   *
   * @param intervalMs Tick interval in milliseconds. Default 60_000.
   */
  start(intervalMs: number = DEFAULT_TICK_INTERVAL_MS): void {
    this.stop()
    this.timer = setInterval(() => {
      // Fire-and-forget: errors are caught inside `tick()`.
      void this.tick().catch((err) => {
        logger.error(
          { err: err instanceof Error ? err.message : 'tick failed' },
          'Scheduler: tick threw',
        )
      })
    }, intervalMs)
    if (typeof this.timer.unref === 'function') {
      this.timer.unref()
    }
    logger.debug({ intervalMs }, 'Scheduler: started')
  }

  /** Stop the periodic tick timer. Safe to call when not started. */
  stop(): void {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
      logger.debug('Scheduler: stopped')
    }
  }

  /** Number of jobs currently held (any status). */
  get size(): number {
    return this.jobs.size
  }
}
