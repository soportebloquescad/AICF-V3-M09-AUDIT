# Course Module — Business-layer course generation, assembly, and export

Real Business-layer module (Épica 3 — Educational Factory). Extends
`BusinessModuleBase` and exposes three capabilities:

- `createCourse` — Create a new course from a topic + level + audience.
- `generateCourse` — Generate course content (modules, lessons, outline).
- `exportCourse` — Export a course (returns markdown + HTML).

## Status

IMPLEMENTED. `executeJob()` produces real courses via two paths:

1. **AI mode** (when an `AIAdapter` is injected via the constructor): a
   two-step pipeline that first prompts the LLM for the outline (title,
   description, outline), then prompts for the modules + lessons.
2. **Fallback mode** (no adapter, or AI call fails): a deterministic
   generator produces real, structured content — title, description,
   outline, modules each with 3 lessons.

Output includes a standalone HTML5 document with embedded CSS (responsive +
print styles) plus markdown source.

## Metadata

| Field | Value |
| --- | --- |
| id | `course` |
| version | `1.0.0` |
| mission | `course` |
| priority | 30 |
| dependencies | (none) |
| capabilities | `createCourse`, `generateCourse`, `exportCourse` |

## Lifecycle

Inherited from `BusinessModuleBase`:

- `initialize()` — idempotent, flips `initialized = true`, records startup time.
- `isReady()` — `initialized && !disposed`.
- `health()` — returns `ModuleHealth` with metrics snapshot.
- `dispose()` / `shutdown()` — flips `disposed = true`.
- `getMetrics()` — returns operation count, error count, last-used, last-error.

## Constructor

```typescript
new CourseModule(aiAdapter?, model?)
```

- `aiAdapter` — optional `AIAdapter` from `@/lib/ai/AIAdapter`. When omitted,
  the module always uses the deterministic fallback.
- `model` — model id passed to the adapter (default `groq-llama-3.3-70b`).

## Input shape (JobRequest.input)

| Field | Type | Default | Notes |
| --- | --- | --- | --- |
| `topic` | string | `'Untitled Course'` | Course topic. |
| `level` | string | `'beginner'` | Beginner / intermediate / advanced. |
| `modules` (or `moduleCount`) | number | `5` | Clamped to 1–30. |
| `language` | string | `'English'` | Used in the prompt + the HTML `lang` attribute. |
