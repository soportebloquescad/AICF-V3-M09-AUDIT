// =============================================================================
// AICF V3 — Sprint 2 — Validate Stage
// =============================================================================
// Validates the incoming RuntimeRequest: checks operation, model, messages.
//
// Sprint 4 — Immutability: never mutates the passed ctx. When validation
// fails, clones ctx via cloneRuntimeContext, mutates the clone's response,
// and returns the clone. On success, returns ctx unchanged (the Pipeline
// will clone it).
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'

export function createValidateStage(): PipelineStage {
  return createPipelineStage('Validate', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const req = ctx.request

    if (!req.operation) {
      const next = cloneRuntimeContext(ctx)
      next.response = {
        ...next.response,
        ok: false,
        error: 'Validate: operation is required',
        errorCode: 'VALIDATION_ERROR',
      }
      return next
    }

    if (req.operation === 'chat') {
      if (!req.model) {
        const next = cloneRuntimeContext(ctx)
        next.response = {
          ...next.response,
          ok: false,
          error: 'Validate: model is required for chat operation',
          errorCode: 'VALIDATION_ERROR',
        }
        return next
      }
      if (!req.messages || req.messages.length === 0) {
        const next = cloneRuntimeContext(ctx)
        next.response = {
          ...next.response,
          ok: false,
          error: 'Validate: messages array is required for chat operation',
          errorCode: 'VALIDATION_ERROR',
        }
        return next
      }
    }

    return ctx
  })
}
