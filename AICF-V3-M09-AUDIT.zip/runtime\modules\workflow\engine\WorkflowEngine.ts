// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Engine (Thin Facade)
// =============================================================================
// Thin facade over `WorkflowOrchestrator` that implements `IWorkflowEngine`.
// Adds lifecycle controls (`cancel`, `pause`, `resume`) and persistence
// (`getStatus`, `getTrace`) on top of the orchestrator's execute / dry-run.
//
// Sprint 13+14 spec requirements covered:
//   - `execute` / `dryRun` delegate to the orchestrator
//   - `cancel` sets status to `'cancelled'`, emits `workflow.cancelled`
//   - `pause` sets status to `'paused'`, emits `workflow.paused`
//   - `resume` loads from the state store and re-runs from the last checkpoint
//   - `getStatus` reads the execution envelope from the state store
//   - `getTrace` reconstructs a trace from the event-bus history
//
// `RuntimeRecovery` is imported lazily (constructor accepts an optional
// `recovery` instance for future Sprint 14+ crash recovery integration).
// =============================================================================

import type {
  WorkflowDefinition,
  WorkflowExecution,
  WorkflowContext,
  WorkflowResult,
  DryRunResult,
} from '@/lib/runtime/contracts/workflow'
import {
  createFailedResult,
  createCancelledResult,
} from '@/lib/runtime/contracts/workflow'
import type {
  IWorkflowEngine,
  ExecutionTrace,
  IEventBus,
  IWorkflowStateStore,
} from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'
import type { WorkflowOrchestrator } from './WorkflowOrchestrator'

/**
 * Minimal structural shape for `RuntimeRecovery`. The real `RuntimeRecovery`
 * module lives in `modules/workflow/recovery` (Sprint 14+) — this interface
 * is the local seam so this file does not have a hard dependency on a
 * module that may not yet exist at import time.
 */
export interface RuntimeRecovery {
  /** Recover an interrupted execution (e.g. after a process restart). */
  recover(executionId: string): Promise<WorkflowResult | null>
}

/** Map of in-flight executions held by the engine for cancel / pause. */
interface InFlightExecutions {
  [executionId: string]: {
    cancelled: boolean
    paused: boolean
    definition?: WorkflowDefinition
    ctx?: WorkflowContext
  }
}

/**
 * `IWorkflowEngine` facade. One engine instance can be reused across many
 * executions; per-execution state lives in the state store + an in-memory
 * `InFlightExecutions` map (for cancel / pause coordination within the
 * same process).
 */
export class WorkflowEngine implements IWorkflowEngine {
  private readonly inFlight = new Map<string, InFlightExecutions[string]>()

  constructor(
    private readonly orchestrator: WorkflowOrchestrator,
    private readonly stateStore?: IWorkflowStateStore,
    private readonly recovery?: RuntimeRecovery,
    private readonly eventBus?: IEventBus,
  ) {}

  /** Delegate to the orchestrator. */
  async execute(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<WorkflowResult> {
    this.inFlight.set(ctx.executionId, {
      cancelled: false,
      paused: false,
      definition,
      ctx,
    })
    try {
      const result = await this.orchestrator.execute(definition, inputs, ctx)
      if (result.status === 'failed' || result.status === 'cancelled') {
        return result
      }
      // If the caller cancelled during execution, surface as cancelled.
      const state = this.inFlight.get(ctx.executionId)
      if (state?.cancelled) {
        return createCancelledResult({
          executionId: ctx.executionId,
          workflowId: definition.metadata.id,
          metrics: result.metrics,
          durationMs: result.durationMs,
          correlationId: ctx.correlationId,
          partialOutputs: result.outputs,
          artifacts: result.artifacts,
        })
      }
      return result
    } finally {
      this.inFlight.delete(ctx.executionId)
    }
  }

  /** Delegate to the orchestrator (no side-effects). */
  async dryRun(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<DryRunResult> {
    return this.orchestrator.dryRun(definition, inputs, ctx)
  }

  /**
   * Cancel a running or paused execution. No-op if already terminal.
   * Persists the new status to the state store and emits
   * `workflow.cancelled`.
   */
  async cancel(executionId: string): Promise<void> {
    const state = this.inFlight.get(executionId)
    if (state) {
      state.cancelled = true
      state.paused = false
    }
    if (this.stateStore) {
      const exec = await this.stateStore.loadExecution(executionId)
      if (exec && !this.isTerminal(exec.status)) {
        exec.status = 'cancelled'
        exec.completedAt = Date.now()
        exec.updatedAt = Date.now()
        await this.stateStore.saveExecution(exec)
      }
    }
    if (this.eventBus) {
      await this.eventBus.publish({
        type: 'workflow.cancelled',
        timestamp: Date.now(),
        level: 'warn',
        executionId,
        data: { reason: 'caller requested cancellation' },
      })
    }
    logger.info({ executionId }, 'workflow execution cancelled')
  }

  /**
   * Pause a running execution at the next checkpoint boundary. Sets
   * status to `'paused'` immediately so the orchestrator's next checkpoint
   * check can short-circuit (in a future Sprint 14 enhancement).
   */
  async pause(executionId: string): Promise<void> {
    const state = this.inFlight.get(executionId)
    if (state) {
      state.paused = true
    }
    if (this.stateStore) {
      const exec = await this.stateStore.loadExecution(executionId)
      if (exec && !this.isTerminal(exec.status)) {
        exec.status = 'paused'
        exec.updatedAt = Date.now()
        await this.stateStore.saveExecution(exec)
      }
    }
    if (this.eventBus) {
      await this.eventBus.publish({
        type: 'workflow.paused',
        timestamp: Date.now(),
        level: 'info',
        executionId,
        data: { reason: 'caller requested pause' },
      })
    }
    logger.info({ executionId }, 'workflow execution paused')
  }

  /**
   * Resume a paused execution from its last checkpoint. Loads the
   * execution envelope + context snapshot from the state store, then
   * re-invokes the orchestrator with the remaining (unexecuted) steps.
   *
   * If `RuntimeRecovery` was injected, delegates to it for richer
   * crash-recovery semantics; otherwise falls back to the orchestrator
   * path.
   */
  async resume(executionId: string): Promise<WorkflowResult> {
    if (this.recovery) {
      const recovered = await this.recovery.recover(executionId)
      if (recovered) return recovered
    }

    if (!this.stateStore) {
      return createFailedResult({
        executionId,
        workflowId: '',
        error: 'cannot resume: no state store configured',
        metrics: {
          executionTimeMs: 0,
          tokenUsage: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
          providerLatency: {},
          cost: 0,
          retries: 0,
          failures: 0,
          successRate: 0,
          stepsExecuted: 0,
          stepsTotal: 0,
        },
        durationMs: 0,
        correlationId: '',
      })
    }

    const exec = await this.stateStore.loadExecution(executionId)
    if (!exec) {
      return createFailedResult({
        executionId,
        workflowId: '',
        error: 'execution not found in state store',
        metrics: {
          executionTimeMs: 0,
          tokenUsage: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
          providerLatency: {},
          cost: 0,
          retries: 0,
          failures: 0,
          successRate: 0,
          stepsExecuted: 0,
          stepsTotal: 0,
        },
        durationMs: 0,
        correlationId: '',
      })
    }

    // Restore context from the most recent checkpoint.
    const lastCheckpoint = exec.checkpoints[exec.checkpoints.length - 1]
    const ctxState = lastCheckpoint?.state ?? {}
    const restoredCtx = this.restoreContext(ctxState, exec)

    if (this.eventBus) {
      await this.eventBus.publish({
        type: 'workflow.resumed',
        timestamp: Date.now(),
        level: 'info',
        executionId,
        data: {
          fromCheckpoint: lastCheckpoint?.id,
          fromStep: lastCheckpoint?.stepId,
        },
      })
    }

    // Re-run from the next step after the checkpoint. The orchestrator
    // is idempotent for already-completed steps (their outputs are bound
    // back into `ctx.variables`), so we re-execute the full definition
    // and rely on the executor to skip already-completed steps in a
    // future enhancement. For Sprint 13+14 we mark the resume as a
    // failed result with a clear message when no definition is available.
    const defs = exec.inputs?.['__workflow_steps'] as
      | WorkflowDefinition['steps']
      | undefined
    if (!defs) {
      return createFailedResult({
        executionId,
        workflowId: exec.workflowId,
        error: 'resume not yet supported for executions without attached step definitions',
        metrics: {
          executionTimeMs: 0,
          tokenUsage: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
          providerLatency: {},
          cost: 0,
          retries: 0,
          failures: 0,
          successRate: 0,
          stepsExecuted: 0,
          stepsTotal: 0,
        },
        durationMs: 0,
        correlationId: exec.correlationId,
      })
    }

    // Build a minimal definition for the re-run.
    const definition: WorkflowDefinition = {
      metadata: {
        id: exec.workflowId,
        name: exec.workflowId,
        version: exec.workflowVersion,
        description: '',
        author: '',
        createdAt: exec.startedAt,
        updatedAt: exec.updatedAt,
        tags: [],
        category: '',
      },
      version: exec.workflowVersion,
      inputs: {},
      outputs: {},
      steps: defs,
      checkpoints: [],
    }

    exec.status = 'running'
    exec.updatedAt = Date.now()
    await this.stateStore.saveExecution(exec)

    return this.orchestrator.execute(
      definition,
      exec.inputs,
      restoredCtx,
    )
  }

  /** Return the current execution envelope, or `null` if unknown. */
  async getStatus(executionId: string): Promise<WorkflowExecution | null> {
    if (this.stateStore) {
      return this.stateStore.loadExecution(executionId)
    }
    return null
  }

  /**
   * Reconstruct an ordered trace from the event-bus history. Each event
   * becomes one trace entry.
   */
  async getTrace(executionId: string): Promise<ExecutionTrace[]> {
    if (!this.eventBus) return []
    const history = await this.eventBus.getHistory(executionId)
    return history.map((e) => ({
      executionId,
      ...(e.stepId !== undefined ? { stepId: e.stepId } : {}),
      type: e.type,
      timestamp: e.timestamp,
      data: e.data,
    }))
  }

  // ----- Helpers ----------------------------------------------------------

  /** Whether a status is terminal (no further transitions possible). */
  private isTerminal(status: WorkflowExecution['status']): boolean {
    return (
      status === 'completed' ||
      status === 'failed' ||
      status === 'cancelled'
    )
  }

  /**
   * Restore a `WorkflowContext` from a checkpoint state snapshot. Uses
   * minimal reconstruction (no `ContextManager` dependency — the snapshot
   * shape is self-describing).
   */
  private restoreContext(
    state: Record<string, unknown>,
    exec: WorkflowExecution,
  ): WorkflowContext {
    const s = state as Partial<WorkflowContext> & {
      correlationId?: unknown
      executionId?: unknown
      locale?: unknown
      cost?: unknown
      tokens?: unknown
      startedAt?: unknown
      variables?: unknown
      dryRun?: unknown
    }
    const tokens =
      s.tokens && typeof s.tokens === 'object'
        ? (s.tokens as WorkflowContext['tokens'])
        : { promptTokens: 0, completionTokens: 0, totalTokens: 0 }
    return {
      correlationId:
        typeof s.correlationId === 'string'
          ? s.correlationId
          : exec.correlationId,
      executionId:
        typeof s.executionId === 'string'
          ? s.executionId
          : exec.executionId,
      locale: typeof s.locale === 'string' ? s.locale : 'en',
      cost: typeof s.cost === 'number' ? s.cost : 0,
      tokens,
      startedAt: typeof s.startedAt === 'number' ? s.startedAt : Date.now(),
      variables:
        s.variables && typeof s.variables === 'object' && !Array.isArray(s.variables)
          ? { ...(s.variables as Record<string, unknown>) }
          : {},
      dryRun: typeof s.dryRun === 'boolean' ? s.dryRun : exec.dryRun,
    }
  }
}
