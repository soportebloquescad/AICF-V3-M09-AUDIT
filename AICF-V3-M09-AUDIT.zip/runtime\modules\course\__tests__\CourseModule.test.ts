// =============================================================================
// AICF V3 — CourseModule Tests (Épica 3 — Educational Factory)
// =============================================================================
// Verifies the CourseModule:
//   - generateCourse with AI (mock) — outline + modules are parsed from the
//     mock AI's JSON response.
//   - generateCourse fallback (no AI) — produces a real, structured course
//     even when no adapter is provided.
//   - exportCourse and createCourse are accepted job types.
//   - Unknown job types produce a failed ExecutionResult.
//   - Lifecycle (initialize / isReady / health / getMetrics) is inherited
//     from BusinessModuleBase.
//
// No `any`. The variable holding the module under test is named `testModule`
// per project conventions.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { CourseModule, COURSE_MODULE_METADATA } from '../CourseModule'
import { createBusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

// ---------------------------------------------------------------------------
// Mock AI adapter — returns canned JSON for the outline + modules prompts.
// ---------------------------------------------------------------------------

class MockAIAdapter implements AIAdapter {
  calls: ChatRequest[] = []

  async chat(request: ChatRequest): Promise<ChatResponse> {
    this.calls.push(request)
    const userMsg = request.messages.find((m) => m.role === 'user')?.content ?? ''

    if (userMsg.includes('Generate a course outline')) {
      return {
        content: JSON.stringify({
          title: 'Mock Course Title',
          description: 'A mock course description.',
          outline: 'Module 1: Intro\nModule 2: Core',
        }),
        model: 'mock',
        provider: 'mock',
        usage: null,
        durationMs: 1,
      }
    }
    if (userMsg.includes('modules for the course')) {
      return {
        content: JSON.stringify({
          modules: [
            {
              title: 'Mock Module 1',
              summary: 'First mock module.',
              lessons: [
                { title: 'Lesson A', content: 'Content A', duration: 10 },
                { title: 'Lesson B', content: 'Content B', duration: 20 },
              ],
            },
            {
              title: 'Mock Module 2',
              summary: 'Second mock module.',
              lessons: [{ title: 'Lesson C', content: 'Content C' }],
            },
          ],
        }),
        model: 'mock',
        provider: 'mock',
        usage: null,
        durationMs: 1,
      }
    }
    return {
      content: '{}',
      model: 'mock',
      provider: 'mock',
      usage: null,
      durationMs: 1,
    }
  }

  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: true, provider: 'mock' } }
}

/** AI adapter that always throws — used to exercise the fallback path. */
class FailingAIAdapter implements AIAdapter {
  async chat(): Promise<ChatResponse> {
    throw new Error('AI unavailable')
  }
  async models(): Promise<AIModel[]> { return [] }
  async health(): Promise<AIHealth> { return { healthy: false, provider: 'failing' } }
}

const ctx = createBusinessContext({ jobId: 'job-test-1' })

describe('CourseModule (Épica 3)', () => {
  describe('metadata + lifecycle', () => {
    const testModule = new CourseModule()

    it('exposes the correct metadata', () => {
      expect(testModule.getMetadata()).toEqual(COURSE_MODULE_METADATA)
      expect(testModule.name).toBe('course')
      expect(testModule.version).toBe('1.0.0')
    })

    it('declares the expected capabilities', () => {
      const caps = testModule.getCapabilities().map((c) => c.name)
      expect(caps).toContain('createCourse')
      expect(caps).toContain('generateCourse')
      expect(caps).toContain('exportCourse')
    })

    it('starts not-ready, becomes ready after initialize()', async () => {
      expect(testModule.isReady()).toBe(false)
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
    })
  })

  describe('executeJob — generateCourse with AI (mock)', () => {
    let testModule: CourseModule
    let mockAdapter: MockAIAdapter

    beforeEach(() => {
      mockAdapter = new MockAIAdapter()
      testModule = new CourseModule(mockAdapter)
    })

    it('returns a successful ExecutionResult with the parsed course', async () => {
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', level: 'intermediate', modules: 2, language: 'English' },
        ctx,
      )

      expect(result.ok).toBe(true)
      expect(result.error).toBeUndefined()
      expect(result.output).toBeDefined()
      const course = result.output!.course as Record<string, unknown>
      expect(course.title).toBe('Mock Course Title')
      expect(course.description).toBe('A mock course description.')
      expect(course.outline).toBe('Module 1: Intro\nModule 2: Core')
      expect(course.level).toBe('intermediate')
      expect(course.language).toBe('English')
      const modules = course.modules as Array<Record<string, unknown>>
      expect(modules).toHaveLength(2)
      expect(modules[0].title).toBe('Mock Module 1')
      const lessons = modules[0].lessons as Array<Record<string, unknown>>
      expect(lessons).toHaveLength(2)
      expect(lessons[0].title).toBe('Lesson A')
      expect(lessons[0].duration).toBe(10)
    })

    it('calls the AI adapter twice (outline + modules)', async () => {
      await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', modules: 2 },
        ctx,
      )
      expect(mockAdapter.calls).toHaveLength(2)
    })

    it('returns markdown + html in the output', async () => {
      const result = await testModule.executeJob(
        'createCourse',
        { topic: 'Rust', modules: 2 },
        ctx,
      )
      const course = result.output!.course as Record<string, unknown>
      expect(typeof course.markdown).toBe('string')
      expect((course.markdown as string).length).toBeGreaterThan(0)
      expect(typeof course.html).toBe('string')
      expect((course.html as string)).toContain('<!DOCTYPE html>')
    })

    it('records an artifact with type=course', async () => {
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', modules: 1 },
        ctx,
      )
      expect(result.artifacts).toBeDefined()
      expect(result.artifacts!.length).toBe(1)
      expect(result.artifacts![0].type).toBe('course')
    })

    it('reports providerCalls=2 in metrics', async () => {
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', modules: 2 },
        ctx,
      )
      expect(result.metrics?.providerCalls).toBe(2)
    })
  })

  describe('executeJob — fallback (no AI adapter)', () => {
    const testModule = new CourseModule()

    it('produces a structured course from the topic', async () => {
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Quantum Computing', modules: 3 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const course = result.output!.course as Record<string, unknown>
      expect(course.title).toBe('Quantum Computing Course')
      expect(typeof course.description).toBe('string')
      expect((course.description as string).length).toBeGreaterThan(0)
      expect(typeof course.outline).toBe('string')
      expect((course.outline as string)).toContain('Module 1:')
      const modules = course.modules as Array<Record<string, unknown>>
      expect(modules).toHaveLength(3)
      const firstModule = modules[0]
      expect(typeof firstModule.title).toBe('string')
      expect((firstModule.title as string).length).toBeGreaterThan(0)
      const lessons = firstModule.lessons as Array<Record<string, unknown>>
      expect(lessons.length).toBeGreaterThanOrEqual(1)
    })

    it('uses default values when input fields are missing', async () => {
      const result = await testModule.executeJob('createCourse', {}, ctx)
      expect(result.ok).toBe(true)
      const course = result.output!.course as Record<string, unknown>
      expect(course.level).toBe('beginner')
      expect(course.language).toBe('English')
      const modules = course.modules as unknown[]
      expect(modules).toHaveLength(5)
    })

    it('includes markdown + html in fallback output', async () => {
      const result = await testModule.executeJob(
        'exportCourse',
        { topic: 'Rust', modules: 2 },
        ctx,
      )
      const course = result.output!.course as Record<string, unknown>
      expect((course.markdown as string)).toContain('# Rust Course')
      expect((course.html as string)).toContain('<!DOCTYPE html>')
    })

    it('reports providerCalls=0 in fallback metrics', async () => {
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', modules: 1 },
        ctx,
      )
      expect(result.metrics?.providerCalls).toBe(0)
    })
  })

  describe('executeJob — AI failure degrades to fallback', () => {
    it('still produces a course when the AI adapter throws', async () => {
      const testModule = new CourseModule(new FailingAIAdapter())
      const result = await testModule.executeJob(
        'generateCourse',
        { topic: 'Rust', modules: 2 },
        ctx,
      )
      expect(result.ok).toBe(true)
      const course = result.output!.course as Record<string, unknown>
      expect(course.title).toBe('Rust Course')
      // errorCount increments because recordError() was called in the catch
      const metrics = testModule.getMetrics()
      expect(metrics.errorCount).toBeGreaterThan(0)
    })
  })

  describe('executeJob — unknown job type', () => {
    const testModule = new CourseModule()

    it('returns a failed ExecutionResult with a descriptive error', async () => {
      const result = await testModule.executeJob('bogusJob', { topic: 'Rust' }, ctx)
      expect(result.ok).toBe(false)
      expect(result.error).toContain('Unknown job type')
      expect(result.error).toContain('bogusJob')
    })
  })

  describe('executeJob — records metrics', () => {
    it('increments operationCount on every call', async () => {
      const testModule = new CourseModule()
      await testModule.executeJob('generateCourse', { topic: 'Rust', modules: 1 }, ctx)
      await testModule.executeJob('generateCourse', { topic: 'Rust', modules: 1 }, ctx)
      expect(testModule.getMetrics().operationCount).toBe(2)
    })
  })
})
