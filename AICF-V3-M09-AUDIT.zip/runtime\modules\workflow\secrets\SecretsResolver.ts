// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Secrets Resolver
// =============================================================================
// Resolves secret references (e.g. `${env:OPENAI_API_KEY}`) into concrete
// secret values at runtime. Implements `ISecretsResolver`.
//
// Reference syntax: `${<source>:<key>}`
//   - `${env:KEY}`           — reads from `process.env`
//   - `${vault:path}`        — registered externally (Vault backend)
//   - `${docker-secrets:NAME}` — registered externally (Docker secrets)
//   - `plaintext`            — values WITHOUT the `${}` prefix are returned
//                              as-is (treated as inline literals)
//
// Sprint 13+14 spec requirements covered:
//   - `resolve(reference)` — parses `${source:key}`, throws on unknown source
//     or missing key
//   - `has(reference)` — safe preflight check (does not throw)
//   - `listSources()` — diagnostic list of registered sources
//   - `registerSource(source, resolver)` — pluggable backends
//   - NEVER logs resolved secret values — only reference strings + outcomes
// =============================================================================

import type {
  ISecretsResolver,
  SecretSource,
  SecretResolverFn,
} from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/** Regex that parses `${<source>:<key>}` references. */
const REFERENCE_PATTERN = /^\$\{([^:}]+):([^}]+)\}$/

/**
 * Pluggable secrets resolver. Constructed with a default `env` source that
 * reads from `process.env`; additional sources (`vault`, `docker-secrets`,
 * custom) are registered via `registerSource`.
 */
export class SecretsResolver implements ISecretsResolver {
  /** Map<source, resolver fn>. */
  private readonly sources = new Map<SecretSource, SecretResolverFn>()

  constructor() {
    // Default 'env' source — reads from process.env.
    this.registerSource('env', (key) => {
      const v = process.env[key]
      return Promise.resolve(v ?? null)
    })
  }

  /**
   * Resolve a secret reference into its value.
   *
   * @param reference Either a `${source:key}` reference or a plain string.
   *                  Plain strings are returned as-is.
   * @throws If the source is unknown or the key is missing.
   */
  async resolve(reference: string): Promise<string> {
    // Plain values (no `${}` prefix) — return as-is.
    const match = reference.match(REFERENCE_PATTERN)
    if (!match) {
      return reference
    }
    const [, source, key] = match
    const resolver = this.sources.get(source as SecretSource)
    if (!resolver) {
      const err = `unknown secret source: '${source}'`
      logger.warn({ source, reference }, `SecretsResolver: ${err}`)
      throw new Error(err)
    }
    const value = await resolver(key)
    if (value === null || value === undefined) {
      const err = `secret not found: ${reference}`
      logger.warn({ reference }, `SecretsResolver: ${err}`)
      throw new Error(err)
    }
    // Do NOT log the value — only the resolution outcome.
    logger.debug(
      { source, keyLength: key.length },
      'SecretsResolver: resolved',
    )
    return value
  }

  /**
   * Whether a reference is resolvable (source known + key present). Never
   * throws — returns `false` on any resolution failure.
   */
  async has(reference: string): Promise<boolean> {
    try {
      const value = await this.resolve(reference)
      return value.length > 0
    } catch {
      return false
    }
  }

  /** List registered secret sources (for diagnostics / UI). */
  listSources(): SecretSource[] {
    return Array.from(this.sources.keys())
  }

  /**
   * Register a resolver for a given source. Overwrites any prior resolver
   * registered under the same source name.
   */
  registerSource(source: SecretSource, resolver: SecretResolverFn): void {
    this.sources.set(source, resolver)
    logger.debug(
      { source },
      'SecretsResolver: source registered',
    )
  }
}
