// =============================================================================
// AICF V3 — Sprint 7 (RC34.1) — WorkflowEventBus
// =============================================================================
// Event bus for workflow lifecycle events.
//
// REUSES the BFF logger — does NOT create a new logger.
// In-memory pub/sub, synchronous, fault-tolerant (subscriber errors don't
// break the pipeline).
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * Workflow event types.
 */
export type WorkflowEventType =
  | 'workflow.started'
  | 'workflow.step.started'
  | 'workflow.step.completed'
  | 'workflow.step.failed'
  | 'workflow.completed'
  | 'workflow.failed'
  | 'workflow.cancelled'

/**
 * A workflow event.
 */
export interface WorkflowEvent {
  readonly type: WorkflowEventType
  readonly workflowId: string
  readonly executionId: string
  readonly stepId?: string
  readonly timestamp: string
  readonly data?: Record<string, unknown>
  readonly error?: string
  readonly durationMs?: number
}

/**
 * Subscriber function.
 */
export type WorkflowEventSubscriber = (event: WorkflowEvent) => void

/**
 * In-memory event bus for workflow lifecycle events.
 *
 * Events: started, stepStarted, stepCompleted, stepFailed, completed, failed, cancelled.
 * Subscribers are called synchronously; errors are caught and logged.
 */
export class WorkflowEventBus {
  private readonly subscribers = new Map<WorkflowEventType, WorkflowEventSubscriber[]>()
  private readonly history: WorkflowEvent[] = []
  private readonly maxHistory: number
  private readonly log = logger.child({ component: 'WorkflowEventBus' })

  constructor(maxHistory: number = 500) {
    this.maxHistory = maxHistory
  }

  /**
   * Subscribes to an event type.
   * @returns An unsubscribe function.
   */
  on(type: WorkflowEventType, subscriber: WorkflowEventSubscriber): () => void {
    const list = this.subscribers.get(type) ?? []
    list.push(subscriber)
    this.subscribers.set(type, list)
    return () => {
      const l = this.subscribers.get(type)
      if (l) {
        const idx = l.indexOf(subscriber)
        if (idx >= 0) l.splice(idx, 1)
      }
    }
  }

  /**
   * Emits an event to all subscribers of its type.
   * Subscriber errors are caught and logged.
   */
  emit(event: WorkflowEvent): void {
    this.history.push(event)
    if (this.history.length > this.maxHistory) {
      this.history.shift()
    }

    const list = this.subscribers.get(event.type) ?? []
    for (const subscriber of list) {
      try {
        subscriber(event)
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        this.log.warn({ eventType: event.type, error: msg }, 'WorkflowEventBus: subscriber threw (caught)')
      }
    }
  }

  /**
   * Returns the event history (newest last).
   */
  getHistory(workflowId?: string): WorkflowEvent[] {
    if (workflowId) {
      return this.history.filter((e) => e.workflowId === workflowId)
    }
    return [...this.history]
  }

  /**
   * Returns events for a specific execution.
   */
  getByExecution(executionId: string): WorkflowEvent[] {
    return this.history.filter((e) => e.executionId === executionId)
  }

  /**
   * Clears all history.
   */
  clearHistory(): void {
    this.history.length = 0
  }

  /**
   * Returns the number of subscribers.
   */
  subscriberCount(type?: WorkflowEventType): number {
    if (type) return this.subscribers.get(type)?.length ?? 0
    let total = 0
    for (const list of this.subscribers.values()) total += list.length
    return total
  }
}

// --- Global singleton ---
const GLOBAL_WORKFLOW_EVENT_BUS_KEY = '__AICF_WORKFLOW_EVENT_BUS__'

export function getGlobalWorkflowEventBus(): WorkflowEventBus {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_WORKFLOW_EVENT_BUS_KEY]) {
    g[GLOBAL_WORKFLOW_EVENT_BUS_KEY] = new WorkflowEventBus()
  }
  return g[GLOBAL_WORKFLOW_EVENT_BUS_KEY] as WorkflowEventBus
}
