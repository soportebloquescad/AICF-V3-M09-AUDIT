// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — CourseManifest
// =============================================================================
// The CourseManifest is the human-readable index of a generated course:
//   - metadata (title, description, level, locale, etc.)
//   - modules (title, summary, lesson count, duration)
//   - lessons (title, module, word count)
//   - artifacts (id, type, name, size, producedBy)
//   - statistics (total modules, lessons, words, artifacts, duration)
//
// The manifest is serialized to JSON and included as the top-level
// `manifest.json` in the exported ZIP.
// =============================================================================

import type { CourseResult, ModulePlan, Lesson } from '@/lib/runtime/course/CourseContracts'
import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import type { RegisteredArtifact } from '../artifacts/ArtifactRegistry'
import { logger } from '@/lib/ai/logger'

/**
 * Course-level metadata included in the manifest.
 */
export interface CourseMetadata {
  courseId: string
  title: string
  description: string
  topic: string
  audience: string
  level: string
  locale: string
  country: string
  moduleCount: number
  researchDepth: string
  mode: string
  status: string
  createdAt: string
  updatedAt: string
  generatorVersion: string
  provider: string
  model: string
  runtimeVersion: string
}

/**
 * A module entry in the manifest.
 */
export interface ManifestModule {
  id: string
  index: number
  title: string
  summary: string
  lessonCount: number
  durationHours: number
  bloomLevels: string[]
}

/**
 * A lesson entry in the manifest.
 */
export interface ManifestLesson {
  id: string
  moduleId: string
  moduleTitle: string
  index: number
  title: string
  wordCount: number
  durationMinutes: number
  bloomLevel: string
}

/**
 * A reference to an artifact in the manifest.
 */
export interface ManifestArtifactRef {
  id: string
  type: string
  name: string
  sizeBytes: number
  producedBy: string
}

/**
 * Aggregated statistics about the course.
 */
export interface CourseStatistics {
  totalModules: number
  totalLessons: number
  totalWords: number
  totalExercises: number
  totalQuizzes: number
  totalAssessments: number
  totalArtifacts: number
  totalDurationHours: number
  totalSizeBytes: number
  qualityScore: number
}

/**
 * The complete course manifest.
 */
export interface CourseManifest {
  version: string
  generatedAt: string
  metadata: CourseMetadata
  modules: ManifestModule[]
  lessons: ManifestLesson[]
  artifacts: ManifestArtifactRef[]
  statistics: CourseStatistics
}

/**
 * Build a CourseManifest from a CourseResult + the original request + the
 * list of artifacts registered during the run.
 */
export function buildCourseManifest(input: {
  courseResult: CourseResult
  request: RuntimeRequest | { metadata?: Record<string, unknown>; topic?: string } | null
  artifacts: RegisteredArtifact[]
}): CourseManifest {
  const { courseResult, request, artifacts } = input

  const meta = (request?.metadata ?? {}) as Record<string, unknown>

  const metadata: CourseMetadata = {
    courseId: courseResult.id,
    title: courseResult.title,
    description: courseResult.description,
    topic: courseResult.topic,
    audience: courseResult.curriculum?.audience ?? 'general learners',
    level: courseResult.curriculum?.level ?? 'intermediate',
    locale: courseResult.curriculum?.locale ?? 'en-US',
    country: typeof meta.country === 'string' ? meta.country : 'Global',
    moduleCount: courseResult.modules.length,
    researchDepth: typeof meta.researchDepth === 'string' ? meta.researchDepth : 'standard',
    mode: typeof meta.mode === 'string' ? meta.mode : (courseResult as { mode?: string }).mode ?? 'balanced',
    status: courseResult.status,
    createdAt: courseResult.createdAt,
    updatedAt: courseResult.updatedAt,
    generatorVersion: courseResult.generatorVersion,
    provider: courseResult.provider,
    model: courseResult.model,
    runtimeVersion: courseResult.runtimeVersion,
  }

  const modules: ManifestModule[] = courseResult.modules.map((m: ModulePlan, idx: number) => ({
    id: m.id,
    index: idx,
    title: m.title,
    summary: m.summary,
    lessonCount: m.lessonCount,
    durationHours: m.durationHours,
    bloomLevels: m.bloomLevels,
  }))

  const lessons: ManifestLesson[] = courseResult.lessons.map((l: Lesson, idx: number) => ({
    id: l.id,
    moduleId: l.moduleId,
    moduleTitle: l.moduleTitle,
    index: idx,
    title: l.title,
    wordCount: l.wordCount,
    durationMinutes: l.durationMinutes,
    bloomLevel: l.bloomLevel,
  }))

  const artifactRefs: ManifestArtifactRef[] = artifacts.map((a) => ({
    id: a.id,
    type: a.type,
    name: a.name,
    sizeBytes: a.sizeBytes,
    producedBy: a.producedBy,
  }))

  const totalWords = courseResult.lessons.reduce((sum, l) => sum + l.wordCount, 0)
  const totalDurationHours = courseResult.modules.reduce((sum, m) => sum + m.durationHours, 0)
  const totalSizeBytes = artifacts.reduce((sum, a) => sum + a.sizeBytes, 0)
  const qualityScore = courseResult.qualityReport?.overallScore ?? 0

  const statistics: CourseStatistics = {
    totalModules: courseResult.modules.length,
    totalLessons: courseResult.lessons.length,
    totalWords,
    totalExercises: courseResult.exercises.length,
    totalQuizzes: courseResult.quizzes.length,
    totalAssessments: courseResult.assessments.length,
    totalArtifacts: artifacts.length,
    totalDurationHours,
    totalSizeBytes,
    qualityScore,
  }

  const manifest: CourseManifest = {
    version: '1.0.0',
    generatedAt: new Date().toISOString(),
    metadata,
    modules,
    lessons,
    artifacts: artifactRefs,
    statistics,
  }

  logger.debug(
    {
      courseId: courseResult.id,
      modules: modules.length,
      lessons: lessons.length,
      artifacts: artifacts.length,
      totalWords,
    },
    'CourseManifest: built',
  )

  return manifest
}

/**
 * Serialize a CourseManifest to a JSON string (pretty-printed).
 */
export function manifestToJson(manifest: CourseManifest): string {
  return JSON.stringify(manifest, null, 2)
}
