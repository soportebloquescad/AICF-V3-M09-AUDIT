// =============================================================================
// AICF V3 — Sprint 13+14 — Cache Provider Interface
// =============================================================================
// Generic key/value cache for prompt-completion deduplication, intermediate
// step output memoization, and idempotent-provider-call caching.
//
// Sprint 13+14 spec requirements covered:
//   - Typed `get<T>` / `set<T>` with optional TTL
//   - `has` for membership checks without deserializing values
//   - `clear` for forced invalidation (e.g. on workflow definition update)
//   - Implementations may back this with in-memory LRU, Redis, or a DB
// =============================================================================

/**
 * Generic cache contract. Implementations MUST be safe to call concurrently;
 * per-key writes are atomic.
 *
 * The generic parameter is on each method (not the interface) so a single
 * cache instance can hold values of different shapes.
 */
export interface ICacheProvider {
  /** Get a cached value by key, or null if absent / expired. */
  get<T>(key: string): Promise<T | null>
  /** Set a cached value with an optional TTL in milliseconds. */
  set<T>(key: string, value: T, ttlMs?: number): Promise<void>
  /** Delete a cached value by key. No-op if absent. */
  delete(key: string): Promise<void>
  /** Clear all cached values. */
  clear(): Promise<void>
  /** Whether a key is present and not expired. */
  has(key: string): Promise<boolean>
}
