// =============================================================================
// AICF V3 — Epica 7 — Pre-Publish Validators
// =============================================================================
// 8 real validators that run before publishing a course.
// =============================================================================

import { logger } from '@/lib/ai/logger'
import type { CourseResult, Lesson, Quiz, Assessment, Curriculum } from './CourseContracts'

export interface ValidationIssue {
  code: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  message: string
  location?: string
}

export interface ValidationReport {
  passed: boolean
  score: number
  validators: Array<{
    name: string
    passed: boolean
    issues: ValidationIssue[]
    durationMs: number
  }>
  totalIssues: number
  criticalCount: number
  highCount: number
}

export class PrePublishValidatorsImpl {
  validate(course: CourseResult): ValidationReport {
    const validators: ValidationReport['validators'] = []
    const start = Date.now()

    const v1 = this.validateStructure(course)
    validators.push({ name: 'structure', passed: v1.length === 0, issues: v1, durationMs: Date.now() - start })

    const s2 = Date.now()
    const v2 = this.validateContent(course.lessons)
    validators.push({ name: 'content', passed: v2.length === 0, issues: v2, durationMs: Date.now() - s2 })

    const s3 = Date.now()
    const v3 = this.validateAssessments(course.quizzes, course.assessments)
    validators.push({ name: 'assessments', passed: v3.length === 0, issues: v3, durationMs: Date.now() - s3 })

    const s4 = Date.now()
    const v4 = this.validateMetadata(course)
    validators.push({ name: 'metadata', passed: v4.length === 0, issues: v4, durationMs: Date.now() - s4 })

    const s5 = Date.now()
    const v5 = this.validateConsistency(course)
    validators.push({ name: 'consistency', passed: v5.length === 0, issues: v5, durationMs: Date.now() - s5 })

    const s6 = Date.now()
    const v6 = this.validateCompleteness(course)
    validators.push({ name: 'completeness', passed: v6.length === 0, issues: v6, durationMs: Date.now() - s6 })

    const s7 = Date.now()
    const v7 = this.validateExportReadiness(course)
    validators.push({ name: 'export-readiness', passed: v7.length === 0, issues: v7, durationMs: Date.now() - s7 })

    const s8 = Date.now()
    const v8 = this.validatePedagogy(course)
    validators.push({ name: 'pedagogy', passed: v8.length === 0, issues: v8, durationMs: Date.now() - s8 })

    const allIssues = validators.flatMap((v) => v.issues)
    const criticalCount = allIssues.filter((i) => i.severity === 'critical').length
    const highCount = allIssues.filter((i) => i.severity === 'high').length
    const totalIssues = allIssues.length
    const passed = criticalCount === 0 && highCount === 0
    const score = Math.max(0, 100 - criticalCount * 25 - highCount * 10 - (totalIssues - criticalCount - highCount) * 2)

    logger.info({ passed, score, totalIssues, criticalCount, highCount }, 'PrePublishValidators: validation complete')

    return { passed, score, validators, totalIssues, criticalCount, highCount }
  }

  // 1. Structure: required fields, IDs, versioning
  private validateStructure(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    if (!course.id) issues.push({ code: 'STRUCT_NO_ID', severity: 'critical', message: 'CourseResult.id is missing' })
    if (!course.topic) issues.push({ code: 'STRUCT_NO_TOPIC', severity: 'critical', message: 'CourseResult.topic is missing' })
    if (!course.title) issues.push({ code: 'STRUCT_NO_TITLE', severity: 'high', message: 'CourseResult.title is missing' })
    if (!course.version) issues.push({ code: 'STRUCT_NO_VERSION', severity: 'medium', message: 'CourseResult.version is missing' })
    if (!course.createdAt) issues.push({ code: 'STRUCT_NO_CREATED', severity: 'low', message: 'CourseResult.createdAt is missing' })
    if (!course.generatorVersion) issues.push({ code: 'STRUCT_NO_GEN', severity: 'low', message: 'generatorVersion is missing' })
    if (!course.provider) issues.push({ code: 'STRUCT_NO_PROVIDER', severity: 'medium', message: 'provider is missing' })
    if (!course.runtimeVersion) issues.push({ code: 'STRUCT_NO_RUNTIME', severity: 'low', message: 'runtimeVersion is missing' })
    if (course.modules.length === 0) issues.push({ code: 'STRUCT_NO_MODULES', severity: 'high', message: 'No modules defined' })
    return issues
  }

  // 2. Content: lessons non-empty, word count, no placeholders
  private validateContent(lessons: Lesson[]): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    if (lessons.length === 0) {
      issues.push({ code: 'CONTENT_NO_LESSONS', severity: 'critical', message: 'No lessons generated' })
      return issues
    }
    for (const lesson of lessons) {
      if (!lesson.content || lesson.content.trim().length === 0) {
        issues.push({ code: 'CONTENT_EMPTY', severity: 'critical', message: `Lesson ${lesson.id} has empty content`, location: lesson.id })
      }
      if (lesson.wordCount < 100) {
        issues.push({ code: 'CONTENT_SHORT', severity: 'high', message: `Lesson ${lesson.title} has only ${lesson.wordCount} words (minimum 100)`, location: lesson.id })
      }
      if (/lorem ipsum|TODO|FIXME|placeholder content|<insert|<your/i.test(lesson.content)) {
        issues.push({ code: 'CONTENT_PLACEHOLDER', severity: 'high', message: `Lesson ${lesson.title} contains placeholder text`, location: lesson.id })
      }
      if (!lesson.title) {
        issues.push({ code: 'CONTENT_NO_TITLE', severity: 'high', message: `Lesson ${lesson.id} has no title`, location: lesson.id })
      }
    }
    return issues
  }

  // 3. Assessments: correct answers exist, options non-empty, explanations present
  private validateAssessments(quizzes: Quiz[], assessments: Assessment[]): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    for (const quiz of quizzes) {
      if (quiz.questions.length === 0) {
        issues.push({ code: 'QUIZ_NO_QUESTIONS', severity: 'high', message: `Quiz ${quiz.title} has no questions`, location: quiz.id })
      }
      for (const q of quiz.questions) {
        if (q.options.length < 2) {
          issues.push({ code: 'QUIZ_FEW_OPTIONS', severity: 'high', message: `Question ${q.id} has fewer than 2 options`, location: q.id })
        }
        if (q.correctIndex < 0 || q.correctIndex >= q.options.length) {
          issues.push({ code: 'QUIZ_BAD_INDEX', severity: 'critical', message: `Question ${q.id} has invalid correctIndex`, location: q.id })
        }
        if (!q.explanation) {
          issues.push({ code: 'QUIZ_NO_EXPLANATION', severity: 'medium', message: `Question ${q.id} has no explanation`, location: q.id })
        }
      }
    }
    for (const assessment of assessments) {
      if (assessment.questions.length === 0) {
        issues.push({ code: 'ASSESS_NO_QUESTIONS', severity: 'high', message: `Assessment ${assessment.title} has no questions`, location: assessment.id })
      }
      if (!assessment.rubric || assessment.rubric.criteria.length === 0) {
        issues.push({ code: 'ASSESS_NO_RUBRIC', severity: 'medium', message: `Assessment ${assessment.title} has no rubric criteria`, location: assessment.id })
      }
    }
    return issues
  }

  // 4. Metadata: provider, model, timestamps valid
  private validateMetadata(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    const validProviders = ['groq', 'gemini', 'claude', 'openai', 'openrouter', 'litellm', 'runtime-adapter']
    if (!validProviders.includes(course.provider)) {
      issues.push({ code: 'META_BAD_PROVIDER', severity: 'medium', message: `Unknown provider: ${course.provider}` })
    }
    if (!course.model) {
      issues.push({ code: 'META_NO_MODEL', severity: 'medium', message: 'model is missing' })
    }
    const createdDate = new Date(course.createdAt)
    if (isNaN(createdDate.getTime())) {
      issues.push({ code: 'META_BAD_CREATED', severity: 'low', message: 'createdAt is not a valid ISO date' })
    }
    const updatedDate = new Date(course.updatedAt)
    if (isNaN(updatedDate.getTime())) {
      issues.push({ code: 'META_BAD_UPDATED', severity: 'low', message: 'updatedAt is not a valid ISO date' })
    }
    if (updatedDate.getTime() < createdDate.getTime()) {
      issues.push({ code: 'META_TIME_TRAVEL', severity: 'medium', message: 'updatedAt is before createdAt' })
    }
    return issues
  }

  // 5. Consistency: lesson titles unique, no duplicate IDs, terminology alignment
  private validateConsistency(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    const lessonIds = new Set<string>()
    const lessonTitles = new Set<string>()
    for (const lesson of course.lessons) {
      if (lessonIds.has(lesson.id)) {
        issues.push({ code: 'CONS_DUP_LESSON_ID', severity: 'high', message: `Duplicate lesson ID: ${lesson.id}` })
      }
      lessonIds.add(lesson.id)
      if (lessonTitles.has(lesson.title.toLowerCase())) {
        issues.push({ code: 'CONS_DUP_LESSON_TITLE', severity: 'medium', message: `Duplicate lesson title: ${lesson.title}` })
      }
      lessonTitles.add(lesson.title.toLowerCase())
    }
    const moduleIds = new Set<string>()
    for (const mod of course.modules) {
      if (moduleIds.has(mod.id)) {
        issues.push({ code: 'CONS_DUP_MODULE_ID', severity: 'high', message: `Duplicate module ID: ${mod.id}` })
      }
      moduleIds.add(mod.id)
    }
    return issues
  }

  // 6. Completeness: all modules have lessons, all lessons have exercises
  private validateCompleteness(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    const lessonsByModule = new Map<string, Lesson[]>()
    for (const lesson of course.lessons) {
      const arr = lessonsByModule.get(lesson.moduleId) ?? []
      arr.push(lesson)
      lessonsByModule.set(lesson.moduleId, arr)
    }
    for (const mod of course.modules) {
      const lessons = lessonsByModule.get(mod.id) ?? []
      if (lessons.length === 0) {
        issues.push({ code: 'COMPLETE_NO_LESSONS', severity: 'high', message: `Module ${mod.title} has no lessons`, location: mod.id })
      }
    }
    const lessonsWithExercises = new Set(course.exercises.map((e) => e.lessonId))
    for (const lesson of course.lessons) {
      if (!lessonsWithExercises.has(lesson.id)) {
        issues.push({ code: 'COMPLETE_NO_EXERCISE', severity: 'medium', message: `Lesson ${lesson.title} has no exercises`, location: lesson.id })
      }
    }
    if (!course.curriculum) {
      issues.push({ code: 'COMPLETE_NO_CURRICULUM', severity: 'high', message: 'No curriculum defined' })
    } else {
      this.validateCurriculumCompleteness(course.curriculum, course, issues)
    }
    return issues
  }

  private validateCurriculumCompleteness(curriculum: Curriculum, course: CourseResult, issues: ValidationIssue[]): void {
    if (curriculum.moduleCount !== course.modules.length) {
      issues.push({
        code: 'COMPLETE_MODULE_MISMATCH',
        severity: 'medium',
        message: `Curriculum expects ${curriculum.moduleCount} modules, found ${course.modules.length}`,
      })
    }
    if (curriculum.topic !== course.topic) {
      issues.push({
        code: 'COMPLETE_TOPIC_MISMATCH',
        severity: 'medium',
        message: `Curriculum topic "${curriculum.topic}" differs from course topic "${course.topic}"`,
      })
    }
  }

  // 7. Export readiness: zipBuffer present, ZIP non-empty
  private validateExportReadiness(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    if (!course.zipBuffer) {
      issues.push({ code: 'EXPORT_NO_ZIP', severity: 'high', message: 'No ZIP buffer generated' })
    } else if (course.zipBuffer.byteLength === 0) {
      issues.push({ code: 'EXPORT_EMPTY_ZIP', severity: 'high', message: 'ZIP buffer is empty' })
    } else if (course.zipBuffer.byteLength < 100) {
      issues.push({ code: 'EXPORT_TINY_ZIP', severity: 'medium', message: `ZIP buffer is suspiciously small (${course.zipBuffer.byteLength} bytes)` })
    }
    if (!course.zipUrl) {
      issues.push({ code: 'EXPORT_NO_URL', severity: 'low', message: 'No ZIP URL set' })
    }
    return issues
  }

  // 8. Pedagogy: learning objectives, Bloom levels, progression
  private validatePedagogy(course: CourseResult): ValidationIssue[] {
    const issues: ValidationIssue[] = []
    const bloomLevels = ['remember', 'understand', 'apply', 'analyze', 'evaluate', 'create']
    for (const lesson of course.lessons) {
      if (lesson.learningObjectives.length === 0) {
        issues.push({ code: 'PED_NO_OBJECTIVES', severity: 'medium', message: `Lesson ${lesson.title} has no learning objectives`, location: lesson.id })
      }
      if (!lesson.bloomLevel || !bloomLevels.includes(lesson.bloomLevel.toLowerCase())) {
        issues.push({ code: 'PED_BAD_BLOOM', severity: 'low', message: `Lesson ${lesson.title} has invalid Bloom level: ${lesson.bloomLevel}`, location: lesson.id })
      }
    }
    const levels = course.lessons.map((l) => l.bloomLevel.toLowerCase())
    const hasProgression = levels.some((l, i) => i > 0 && bloomLevels.indexOf(l) > bloomLevels.indexOf(levels[i - 1] ?? 'remember'))
    if (course.lessons.length > 3 && !hasProgression) {
      issues.push({ code: 'PED_NO_PROGRESSION', severity: 'medium', message: 'No Bloom-level progression detected across lessons' })
    }
    if (course.curriculum && course.curriculum.learningOutcomes.length === 0) {
      issues.push({ code: 'PED_NO_OUTCOMES', severity: 'medium', message: 'Curriculum has no learning outcomes' })
    }
    return issues
  }
}

export const prePublishValidators = new PrePublishValidatorsImpl()
export { PrePublishValidatorsImpl as PrePublishValidators }
