// =============================================================================
// AICF V3 — Sprint 2 — Response Stage
// =============================================================================
// Finalizes the RuntimeResponse: sets durationMs, stages list.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'

export function createResponseStage(): PipelineStage {
  return createPipelineStage('Response', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    ctx.response.durationMs = Date.now() - (ctx.metrics.pipelineTimeMs || Date.now())
    ctx.response.stages = [...(ctx.response.stages ?? []), 'Response']
    if (ctx.response.ok === undefined) {
      ctx.response.ok = true
    }
    return ctx
  })
}
