// =============================================================================
// AICF V3 — GET /api/runtime/metrics (Sprint 22: PR 2 — Observability)
// =============================================================================
// Returns runtime call metrics aggregated by the MetricsSubscriber +
// MetricsRegistry, plus the MetricsSubscriber's internal per-stage event
// counters and the EventBus telemetry snapshot.
//
// Response shape:
//   {
//     metrics:      Record<string, ModuleMetrics>,  // per-stage call metrics
//     eventCounts:  Record<string, number>,         // per-stage event counts
//     totalEvents:  number,                          // grand total events received
//     telemetry:    RuntimeEventBusTelemetry         // bus publish counters
//   }
//
// All four pieces are pulled from the observability-singleton stack:
//   - metrics      → MetricsRegistry.getAllMetrics()
//   - eventCounts  → MetricsSubscriber.getEventCounts()
//   - totalEvents  → MetricsSubscriber.getTotalEvents()
//   - telemetry    → getGlobalEventBus().getTelemetry()
// =============================================================================

import { NextResponse } from 'next/server'
import {
  getMetricsRegistry,
  getMetricsSubscriber,
} from '@/lib/runtime/observability-singleton'
import { getGlobalEventBus } from '@/lib/runtime/services/RuntimeService'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  const reqLogger = logger.child({ endpoint: '/runtime/metrics', method: 'GET' })

  try {
    const metricsRegistry = getMetricsRegistry()
    const metricsSubscriber = getMetricsSubscriber()
    const bus = getGlobalEventBus()

    const metrics = metricsRegistry.getAllMetrics()
    const eventCounts = metricsSubscriber.getEventCounts()
    const totalEvents = metricsSubscriber.getTotalEvents()
    const telemetry = bus.getTelemetry()

    reqLogger.info(
      {
        moduleCount: Object.keys(metrics).length,
        totalEvents,
        eventsPublished: telemetry.eventsPublished,
      },
      'Runtime metrics retrieved',
    )

    return NextResponse.json({ metrics, eventCounts, totalEvents, telemetry })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to retrieve runtime metrics',
    )
    return NextResponse.json(
      {
        metrics: {},
        eventCounts: {},
        totalEvents: 0,
        telemetry: {
          eventsPublished: 0,
          eventsFailed: 0,
          eventsDeduplicated: 0,
          eventsPerStage: {},
          averagePublishTimeMs: 0,
        },
        error: 'Failed to retrieve runtime metrics',
      },
      { status: 500 },
    )
  }
}
