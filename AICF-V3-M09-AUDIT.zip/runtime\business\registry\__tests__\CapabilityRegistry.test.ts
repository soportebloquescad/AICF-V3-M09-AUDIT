// =============================================================================
// AICF V3 — Business Capability Registry Tests (Épica 2 — AI Factory Core, B11)
// =============================================================================
// Verifies `BusinessCapabilityRegistry`:
//   - register(): indexes a Capability for a module.
//   - register(): throws when a second module tries to claim a taken name.
//   - unregister(): drops every capability owned by the module.
//   - getCapability(): returns the descriptor or null.
//   - getModuleForCapability(): returns the owning module id or null.
//   - listCapabilities(): returns every descriptor (insertion order).
//   - listByModule(): returns every descriptor owned by a module.
//   - listModuleIds() + clear(): diagnostic helpers.
//
// No `any`. Variables under test are named `testModule*` (not `module`).
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { BusinessCapabilityRegistry } from '../CapabilityRegistry'
import { createCapability, type Capability } from '../../contracts/Capability'

describe('BusinessCapabilityRegistry (Épica 2 — B11)', () => {
  let registry: BusinessCapabilityRegistry

  beforeEach(() => {
    registry = new BusinessCapabilityRegistry()
  })

  // -------------------------------------------------------------------------
  // register() + getCapability() + getModuleForCapability()
  // -------------------------------------------------------------------------
  describe('register() + getCapability() + getModuleForCapability()', () => {
    it('register() makes the capability retrievable via getCapability()', () => {
      const cap: Capability = createCapability('createCourse', 'Generate a course')
      registry.register('course', cap)
      expect(registry.getCapability('createCourse')).toBe(cap)
    })

    it('register() records the owning module id', () => {
      registry.register('course', createCapability('createCourse', 'Generate a course'))
      expect(registry.getModuleForCapability('createCourse')).toBe('course')
    })

    it('getCapability() returns null for an unknown name', () => {
      expect(registry.getCapability('nope')).toBeNull()
    })

    it('getModuleForCapability() returns null for an unknown name', () => {
      expect(registry.getModuleForCapability('nope')).toBeNull()
    })

    it('register() the SAME module can register multiple capabilities', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      registry.register('course', createCapability('generateCourse', 'b'))
      registry.register('course', createCapability('exportCourse', 'c'))
      expect(registry.listByModule('course').length).toBe(3)
      expect(registry.getModuleForCapability('createCourse')).toBe('course')
      expect(registry.getModuleForCapability('exportCourse')).toBe('course')
    })

    it('register() re-registering the SAME capability by the SAME module is a no-op (no throw)', () => {
      const cap = createCapability('createCourse', 'Generate a course')
      registry.register('course', cap)
      // Re-registering the same capability by the same module is allowed.
      expect(() => registry.register('course', cap)).not.toThrow()
    })

    it('register() THROWS when a different module tries to claim a taken capability', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      expect(() =>
        registry.register('other', createCapability('createCourse', 'b')),
      ).toThrow(/already owned/)
    })
  })

  // -------------------------------------------------------------------------
  // unregister()
  // -------------------------------------------------------------------------
  describe('unregister()', () => {
    it('drops every capability owned by the module', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      registry.register('course', createCapability('exportCourse', 'b'))
      registry.register('quiz', createCapability('createQuiz', 'c'))

      registry.unregister('course')

      expect(registry.getCapability('createCourse')).toBeNull()
      expect(registry.getCapability('exportCourse')).toBeNull()
      expect(registry.getModuleForCapability('createCourse')).toBeNull()
      // The quiz module's capabilities are untouched.
      expect(registry.getCapability('createQuiz')).not.toBeNull()
    })

    it('is a no-op for an unknown module id', () => {
      expect(() => registry.unregister('nope')).not.toThrow()
    })

    it('allows re-registering a capability after its owner is unregistered', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      registry.unregister('course')
      // Now a different module can claim 'createCourse'.
      expect(() =>
        registry.register('other', createCapability('createCourse', 'b')),
      ).not.toThrow()
      expect(registry.getModuleForCapability('createCourse')).toBe('other')
    })
  })

  // -------------------------------------------------------------------------
  // listCapabilities()
  // -------------------------------------------------------------------------
  describe('listCapabilities()', () => {
    it('returns every registered Capability (insertion order)', () => {
      const a = createCapability('createCourse', 'a')
      const b = createCapability('createQuiz', 'b')
      const c = createCapability('createSlides', 'c')
      registry.register('course', a)
      registry.register('quiz', b)
      registry.register('presentation', c)
      expect(registry.listCapabilities()).toEqual([a, b, c])
    })

    it('returns an empty array when the registry is empty', () => {
      expect(registry.listCapabilities()).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // listByModule()
  // -------------------------------------------------------------------------
  describe('listByModule()', () => {
    it('returns every Capability owned by the module', () => {
      const a = createCapability('createCourse', 'a')
      const b = createCapability('generateCourse', 'b')
      const c = createCapability('createQuiz', 'c') // belongs to quiz, not course
      registry.register('course', a)
      registry.register('course', b)
      registry.register('quiz', c)

      const byCourse = registry.listByModule('course')
      expect(byCourse.length).toBe(2)
      expect(byCourse.map((cap) => cap.name).sort()).toEqual(['createCourse', 'generateCourse'])
    })

    it('returns an empty array for an unknown module id', () => {
      expect(registry.listByModule('nope')).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // listModuleIds() + clear()
  // -------------------------------------------------------------------------
  describe('listModuleIds() + clear()', () => {
    it('listModuleIds() returns every module id that has at least one capability', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      registry.register('quiz', createCapability('createQuiz', 'b'))
      expect(registry.listModuleIds()).toEqual(['course', 'quiz'])
    })

    it('clear() empties every index', () => {
      registry.register('course', createCapability('createCourse', 'a'))
      registry.register('quiz', createCapability('createQuiz', 'b'))
      registry.clear()
      expect(registry.listCapabilities().length).toBe(0)
      expect(registry.listModuleIds().length).toBe(0)
      expect(registry.getCapability('createCourse')).toBeNull()
    })
  })
})
