// =============================================================================
// AICF V3 — Sprint 10 — Theme Catalog (6 themes)
// =============================================================================
export type ThemeName = 'profesional' | 'corporativo' | 'academico' | 'minimalista' | 'moderno' | 'creativo'

export interface ThemePreset {
  name: ThemeName
  label: string
  description: string
  mode: 'light' | 'dark' | 'auto'
  colors: {
    primary: string; primaryFg: string; background: string; surface: string
    border: string; text: string; textMuted: string; accent: string
    success: string; warning: string; danger: string
  }
  typography: { headingFont: string; bodyFont: string; baseSize: string; lineHeight: number }
  radius: string
}

export const THEME_CATALOG: ThemePreset[] = [
  {
    name: 'profesional', label: 'Profesional', mode: 'light',
    description: 'Tono sobrio, alta legibilidad, ideal para cursos corporativos y técnicos.',
    colors: {
      primary: '#1f2937', primaryFg: '#ffffff', background: '#ffffff', surface: '#f9fafb',
      border: '#e5e7eb', text: '#111827', textMuted: '#6b7280', accent: '#0f766e',
      success: '#16a34a', warning: '#d97706', danger: '#dc2626',
    },
    typography: { headingFont: "'Inter', sans-serif", bodyFont: "'Inter', sans-serif", baseSize: '16px', lineHeight: 1.6 },
    radius: '0.5rem',
  },
  {
    name: 'corporativo', label: 'Corporativo', mode: 'light',
    description: 'Azul marino y acentos dorados. Apto para informes ejecutivos y MBA.',
    colors: {
      primary: '#0c2d6b', primaryFg: '#ffffff', background: '#f8fafc', surface: '#ffffff',
      border: '#cbd5e1', text: '#0f172a', textMuted: '#475569', accent: '#b45309',
      success: '#15803d', warning: '#ca8a04', danger: '#b91c1c',
    },
    typography: { headingFont: "'Source Sans 3', sans-serif", bodyFont: "'Source Sans 3', sans-serif", baseSize: '16px', lineHeight: 1.6 },
    radius: '0.375rem',
  },
  {
    name: 'academico', label: 'Académico', mode: 'light',
    description: 'Serif clásica y márgenes amplios. Ideal para tesis y material universitario.',
    colors: {
      primary: '#3b0764', primaryFg: '#ffffff', background: '#fdfdf9', surface: '#faf8f3',
      border: '#e7e2d6', text: '#1f1b16', textMuted: '#6b5f4f', accent: '#92400e',
      success: '#166534', warning: '#a16207', danger: '#991b1b',
    },
    typography: { headingFont: "'Merriweather', serif", bodyFont: "'Lora', serif", baseSize: '17px', lineHeight: 1.7 },
    radius: '0.25rem',
  },
  {
    name: 'minimalista', label: 'Minimalista', mode: 'light',
    description: 'Blanco y negro con tipografía limpia. Máximo foco en el contenido.',
    colors: {
      primary: '#000000', primaryFg: '#ffffff', background: '#ffffff', surface: '#ffffff',
      border: '#e5e5e5', text: '#0a0a0a', textMuted: '#737373', accent: '#525252',
      success: '#16a34a', warning: '#ca8a04', danger: '#dc2626',
    },
    typography: { headingFont: "'Inter', sans-serif", bodyFont: "'Inter', sans-serif", baseSize: '16px', lineHeight: 1.65 },
    radius: '0px',
  },
  {
    name: 'moderno', label: 'Moderno', mode: 'dark',
    description: 'Tema oscuro con acentos vibrantes. Para cursos de tecnología y diseño.',
    colors: {
      primary: '#10b981', primaryFg: '#052e22', background: '#0b1220', surface: '#111827',
      border: '#374151', text: '#f9fafb', textMuted: '#9ca3af', accent: '#06b6d4',
      success: '#22c55e', warning: '#eab308', danger: '#ef4444',
    },
    typography: { headingFont: "'Space Grotesk', sans-serif", bodyFont: "'Inter', sans-serif", baseSize: '16px', lineHeight: 1.6 },
    radius: '0.5rem',
  },
  {
    name: 'creativo', label: 'Creativo', mode: 'light',
    description: 'Paleta cálida con tipografía expresiva. Para marketing y diseño.',
    colors: {
      primary: '#db2777', primaryFg: '#ffffff', background: '#fff7ed', surface: '#ffffff',
      border: '#fed7aa', text: '#431407', textMuted: '#9a3412', accent: '#9333ea',
      success: '#16a34a', warning: '#ea580c', danger: '#dc2626',
    },
    typography: { headingFont: "'Poppins', sans-serif", bodyFont: "'Nunito', sans-serif", baseSize: '16px', lineHeight: 1.6 },
    radius: '0.75rem',
  },
]

const MAP: ReadonlyMap<ThemeName, ThemePreset> = new Map(THEME_CATALOG.map((t) => [t.name, t]))
export const DEFAULT_THEME_NAME: ThemeName = 'profesional'

export function getThemeByName(name: string): ThemePreset {
  return MAP.get((name || '').toLowerCase() as ThemeName) ?? MAP.get(DEFAULT_THEME_NAME)!
}
export function listAllThemes(): ThemePreset[] { return THEME_CATALOG.slice() }
