// =============================================================================
// AICF V3 — Épica 6 — Course Memory
// =============================================================================
export interface MemoryCheckpoint {
  id: string
  courseId: string
  stage: string
  data: Record<string, unknown>
  createdAt: Date
}

export interface MemoryDiff {
  added: string[]
  removed: string[]
  changed: string[]
}

export class CourseMemory {
  private readonly checkpoints: MemoryCheckpoint[] = []

  constructor(private readonly opts: { courseId: string }) {}

  async checkpoint(stage: string, data: Record<string, unknown>): Promise<MemoryCheckpoint> {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const cp: MemoryCheckpoint = {
      id: `cp-${ts}-${rand}`,
      courseId: this.opts.courseId,
      stage,
      data,
      createdAt: new Date(),
    }
    this.checkpoints.push(cp)
    return cp
  }

  async rollback(checkpointId: string): Promise<boolean> {
    const idx = this.checkpoints.findIndex((c) => c.id === checkpointId)
    if (idx < 0) return false
    this.checkpoints.splice(idx + 1)
    return true
  }

  async resume(): Promise<MemoryCheckpoint | null> {
    return this.checkpoints.length > 0 ? this.checkpoints[this.checkpoints.length - 1] : null
  }

  async incremental(checkpointId: string): Promise<{ completed: string[]; remaining: string[] }> {
    const idx = this.checkpoints.findIndex((c) => c.id === checkpointId)
    if (idx < 0) return { completed: [], remaining: [] }
    const completed = this.checkpoints.slice(0, idx + 1).map((c) => c.stage)
    const all = this.checkpoints.map((c) => c.stage)
    const remaining = all.filter((s) => !completed.includes(s))
    return { completed, remaining }
  }

  async diff(cp1: string, cp2: string): Promise<MemoryDiff> {
    const c1 = this.checkpoints.find((c) => c.id === cp1)
    const c2 = this.checkpoints.find((c) => c.id === cp2)
    if (!c1 || !c2) return { added: [], removed: [], changed: [] }
    const k1 = new Set(Object.keys(c1.data))
    const k2 = new Set(Object.keys(c2.data))
    const added = Array.from(k2).filter((k) => !k1.has(k))
    const removed = Array.from(k1).filter((k) => !k2.has(k))
    const changed = Array.from(k1).filter((k) => k2.has(k) && JSON.stringify(c1.data[k]) !== JSON.stringify(c2.data[k]))
    return { added, removed, changed }
  }

  async listCheckpoints(): Promise<MemoryCheckpoint[]> {
    return [...this.checkpoints].reverse()
  }
}
