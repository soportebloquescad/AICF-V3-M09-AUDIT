// =============================================================================
// AICF V3 — Real Generation Module (M21) — Sprint 16 Plugin
// =============================================================================
// Wraps the M21 facade (download/real-generation/) as a first-class
// Runtime plugin.
//
// Capabilities: generateCourse, generateLesson, generateSlides, generateQuiz, generateDocument
// Mission: M21
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { REAL_GENERATION_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * The shape of the M21 facade (from download/real-generation/).
 */
export interface M21Facade {
  startGeneration(request: unknown): Promise<{
    ok: boolean
    content: string | null
    model: string
    provider: string
    usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number } | null
    durationMs: number
    cached: boolean
    error?: string
  }>
  getGenerationHistory(limit?: number): unknown[]
  getTokenUsage(): unknown
  getGenerationCost(): unknown
}

/**
 * Plugin metadata for the Real Generation module.
 */
export const REAL_GENERATION_METADATA: PluginMetadata = {
  id: 'real-generation',
  name: 'Real Generation',
  description: 'AI content generation: courses, lessons, slides, quizzes, documents',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M21',
  priority: 25,
  dependencies: ['content-intelligence', 'infrastructure'],
  capabilities: [...REAL_GENERATION_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['generation.started', 'generation.completed', 'generation.failed', 'generation.cached'],
}

/**
 * Real Generation Runtime Module (M21).
 */
export class RealGenerationRuntimeModule implements RuntimeModule, HotReloadable {
  readonly name = REAL_GENERATION_METADATA.name
  readonly version = REAL_GENERATION_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(private readonly gen: M21Facade) {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
    logger.info({ initLatencyMs: this.initLatencyMs }, 'RealGenerationModule: initialized')
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'download/real-generation',
        capabilities: REAL_GENERATION_CAPABILITIES,
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: REAL_GENERATION_METADATA.dependencies,
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    logger.info('RealGenerationModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('RealGenerationModule: shut down')
  }

  // --- HotReloadable ---
  async load(): Promise<void> { await this.initialize() }
  async unload(): Promise<void> { await this.dispose() }
  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    await this.initialize()
  }

  // --- M21 capabilities ---
  async startGeneration(request: unknown) { return this.gen.startGeneration(request) }
  getGenerationHistory(limit?: number) { return this.gen.getGenerationHistory(limit) }
  getTokenUsage() { return this.gen.getTokenUsage() }
  getGenerationCost() { return this.gen.getGenerationCost() }

  getMetadata(): PluginMetadata {
    return REAL_GENERATION_METADATA
  }
}

/**
 * Factory: creates a RealGenerationRuntimeModule from the M21 facade.
 */
export function createRealGenerationModule(gen: M21Facade): RealGenerationRuntimeModule {
  return new RealGenerationRuntimeModule(gen)
}
