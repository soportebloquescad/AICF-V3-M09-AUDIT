// =============================================================================
// AICF V3 — Sprint 13+14 — Execution Trace Contract (Batch C2)
// =============================================================================
// Defines the trace-module's canonical `ExecutionTrace` shape — a richer
// envelope than the minimal `ExecutionTrace` on `IWorkflowEngine`. The
// trace subsystem (storage, replay, audit export) uses THIS shape; the
// engine's `getTrace` surface uses the minimal shape. The two are
// structurally compatible: a trace-module `ExecutionTrace` is assignable
// to an `IWorkflowEngine.ExecutionTrace` (the trace-module shape is a
// strict superset).
//
// Sprint 13+14 spec requirements covered:
//   - `ExecutionTrace` interface with id / executionId / stepId / type /
//     timestamp / data / durationMs / level
//   - `createTrace(executionId, type, data, opts?)` factory
//
// Design notes:
//   - `id` is unique per trace entry (within the process). It is
//     generated as `trace-<timestamp>-<random>` so it is sortable and
//     collision-resistant without a global counter.
//   - `level` mirrors `WorkflowEventLevel` (`info` / `warn` / `error`)
//     so trace entries can be filtered by severity the same way events
//     are.
//   - `durationMs` is optional and only set for span-like traces
//     (`step.completed`, `workflow.completed`) where the duration is
//     known at emit time.
//   - `data` is intentionally `Record<string, unknown>` so type-specific
//     payloads can be attached without widening this interface.
// =============================================================================

/** Severity level for a trace entry. Mirrors `WorkflowEventLevel`. */
export type TraceLevel = 'info' | 'warn' | 'error'

/**
 * Optional fields for `createTrace`.
 */
export interface CreateTraceOptions {
  /** Step id the trace pertains to (absent for workflow-level traces). */
  stepId?: string
  /** Elapsed wall-clock time in milliseconds (span-like traces only). */
  durationMs?: number
  /** Severity. Defaults to `'info'`. */
  level?: TraceLevel
  /** Override the auto-generated trace id. */
  id?: string
  /** Override the auto-generated timestamp. */
  timestamp?: number
}

/**
 * A single execution trace entry. The trace subsystem retains an
 * ordered list of these per execution; together they form a full
 * execution timeline suitable for audit, replay, and UI rendering.
 */
export interface ExecutionTrace {
  /** Unique trace entry id. */
  id: string
  /** Execution id the trace entry belongs to. */
  executionId: string
  /** Step id the trace entry pertains to (absent for workflow-level traces). */
  stepId?: string
  /** Trace entry type (e.g. `'workflow.started'`, `'step.completed'`). */
  type: string
  /** Epoch ms when the trace entry was recorded. */
  timestamp: number
  /** Type-specific payload. */
  data: Record<string, unknown>
  /** Elapsed wall-clock time in milliseconds (span-like traces only). */
  durationMs?: number
  /** Severity level for filtering / routing. */
  level: TraceLevel
}

/**
 * Generate a unique, sortable trace id. Format: `trace-<ts>-<rand>`.
 * The timestamp prefix makes ids roughly sortable by creation time
 * without a global counter; the random suffix prevents collisions
 * between traces emitted in the same millisecond.
 */
function generateTraceId(now: number): string {
  const rand = Math.random().toString(36).slice(2, 10)
  return `trace-${now}-${rand}`
}

/**
 * Factory: create a new `ExecutionTrace` with sensible defaults.
 *
 *   const t = createTrace('exec-1', 'step.completed', { stepId: 's1' }, { durationMs: 42 })
 *
 * - `id` defaults to `trace-<ts>-<rand>`.
 * - `timestamp` defaults to `Date.now()`.
 * - `level` defaults to `'info'`.
 * - `stepId` / `durationMs` are only set when provided.
 *
 * @param executionId  Execution id the trace belongs to.
 * @param type         Trace entry type (e.g. `'workflow.started'`).
 * @param data         Type-specific payload.
 * @param opts         Optional overrides (stepId, durationMs, level, id, timestamp).
 */
export function createTrace(
  executionId: string,
  type: string,
  data: Record<string, unknown>,
  opts?: CreateTraceOptions,
): ExecutionTrace {
  const timestamp = opts?.timestamp ?? Date.now()
  const trace: ExecutionTrace = {
    id: opts?.id ?? generateTraceId(timestamp),
    executionId,
    type,
    timestamp,
    data,
    level: opts?.level ?? 'info',
  }
  if (opts?.stepId !== undefined) {
    trace.stepId = opts.stepId
  }
  if (opts?.durationMs !== undefined) {
    trace.durationMs = opts.durationMs
  }
  return trace
}

/**
 * Type guard: narrow an unknown value to `ExecutionTrace`. Validates
 * the structural minimum so corrupt payloads are rejected cleanly at
 * consumer boundaries (e.g. when reading traces back from a serialized
 * store).
 */
export function isExecutionTrace(value: unknown): value is ExecutionTrace {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  return (
    typeof v.id === 'string' &&
    typeof v.executionId === 'string' &&
    typeof v.type === 'string' &&
    typeof v.timestamp === 'number' &&
    typeof v.data === 'object' &&
    v.data !== null &&
    typeof v.level === 'string' &&
    (v.level === 'info' || v.level === 'warn' || v.level === 'error')
  )
}
