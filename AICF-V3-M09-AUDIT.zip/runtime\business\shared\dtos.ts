// =============================================================================
// AICF V3 — Shared DTOs (Épica 2 — AI Factory Core, B7)
// =============================================================================
// Typed Data Transfer Objects for the Business layer. These narrow the
// `input: Record<string, unknown>` field on JobRequest + the `output` field
// on JobResponse / ExecutionResult.
//
// Each DTO is a plain interface — no factories, no behavior. Module authors
// cast `input` to the relevant DTO after running the matching validator
// from `shared/validators.ts`.
//
// The set is intentionally small + domain-focused. New DTOs are added here
// as new job types appear.
//
// No `any` — `unknown` is used for arrays-of-arbitrary-shape (e.g. course
// modules, slide bullets' auxiliary fields).
// =============================================================================

/**
 * Input: a topic with an optional description.
 */
export interface TopicInput {
  topic: string
  description?: string
}

/**
 * Input: difficulty level.
 */
export interface LevelInput {
  level: 'beginner' | 'intermediate' | 'advanced'
}

/**
 * Input: number of modules/sections/questions.
 */
export interface ModuleCountInput {
  modules: number
}

/**
 * Input: target language (BCP-47 tag preferred, e.g. 'en', 'es', 'pt-BR').
 */
export interface LanguageInput {
  language: string
}

/**
 * Input: target export format.
 */
export interface FormatInput {
  format: 'markdown' | 'docx' | 'pdf' | 'pptx'
}

/**
 * Input: target audience (free-text, e.g. 'engineering managers').
 */
export interface AudienceInput {
  audience: string
}

/**
 * Output: a single artifact with content + mime type. Returned by export
 * jobs (exportPDF, exportDOCX, etc.).
 */
export interface ArtifactOutput {
  /** Unique artifact ID. */
  id: string
  /** Artifact type (matches the format, e.g. 'pdf', 'docx'). */
  type: string
  /** Human-readable name (e.g. 'intro-to-rust.pdf'). */
  name: string
  /** The artifact content (base64 for binary formats, plain text for markdown). */
  content: string
  /** MIME type (e.g. 'application/pdf', 'text/markdown'). */
  mimeType: string
}

/**
 * Output: a generated course. The `modules` field is `unknown[]` because
 * each module's shape depends on the generator (use a more specific
 * interface inside the Course module if you need to narrow it).
 */
export interface CourseOutput {
  title: string
  description: string
  modules: unknown[]
  outline: string
}

/**
 * Output: a generated slide deck.
 */
export interface SlidesOutput {
  slides: Array<{
    title: string
    bullets: string[]
    notes?: string
  }>
}

/**
 * Output: a generated quiz.
 */
export interface QuizOutput {
  questions: Array<{
    id: string
    question: string
    options: string[]
    correctIndex: number
  }>
}

/**
 * Output: a generated document.
 */
export interface DocumentOutput {
  title: string
  content: string
  sections: number
}
