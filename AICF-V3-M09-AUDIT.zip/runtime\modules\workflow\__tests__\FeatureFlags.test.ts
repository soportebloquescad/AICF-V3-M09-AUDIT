// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — FeatureFlags Tests
// =============================================================================
// Tests for FeatureFlags. Verifies default flag values, enable/disable/
// toggle, isEnabled, registerFlag, and list.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { FeatureFlags } from '../features/FeatureFlags'

describe('FeatureFlags', () => {
  let flags: FeatureFlags

  beforeEach(() => {
    flags = new FeatureFlags()
  })

  it('defaults: scheduler=false, queue=true, cache=true, audit=true, plugins=false', () => {
    expect(flags.isEnabled('scheduler')).toBe(false)
    expect(flags.isEnabled('queue')).toBe(true)
    expect(flags.isEnabled('cache')).toBe(true)
    expect(flags.isEnabled('audit')).toBe(true)
    expect(flags.isEnabled('plugins')).toBe(false)
  })

  it('enable turns a flag on', () => {
    expect(flags.isEnabled('scheduler')).toBe(false)
    flags.enable('scheduler')
    expect(flags.isEnabled('scheduler')).toBe(true)
  })

  it('disable turns a flag off', () => {
    expect(flags.isEnabled('queue')).toBe(true)
    flags.disable('queue')
    expect(flags.isEnabled('queue')).toBe(false)
  })

  it('toggle flips the current value', () => {
    expect(flags.isEnabled('cache')).toBe(true)
    flags.toggle('cache')
    expect(flags.isEnabled('cache')).toBe(false)
    flags.toggle('cache')
    expect(flags.isEnabled('cache')).toBe(true)
  })

  it('isEnabled returns false for unknown flags', () => {
    expect(flags.isEnabled('does-not-exist')).toBe(false)
  })

  it('registerFlag adds a new flag with the given default', () => {
    flags.registerFlag('my-experiment', true)
    expect(flags.isEnabled('my-experiment')).toBe(true)
    flags.registerFlag('another', false)
    expect(flags.isEnabled('another')).toBe(false)
  })

  it('registerFlag is a no-op if the flag already exists (preserves value)', () => {
    flags.registerFlag('queue', false) // 'queue' already exists as true.
    expect(flags.isEnabled('queue')).toBe(true)
  })

  it('list returns all known flags', () => {
    const all = flags.list()
    expect(Object.keys(all).sort()).toEqual([
      'audit',
      'cache',
      'plugins',
      'queue',
      'scheduler',
    ])
    expect(all.scheduler).toBe(false)
    expect(all.queue).toBe(true)
    expect(all.cache).toBe(true)
    expect(all.audit).toBe(true)
    expect(all.plugins).toBe(false)
  })
})
