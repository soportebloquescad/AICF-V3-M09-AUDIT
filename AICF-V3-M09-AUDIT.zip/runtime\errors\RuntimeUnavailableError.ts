// =============================================================================
// AICF V3 — Sprint 4 — Runtime Unavailable Error
// =============================================================================
// Specialized error thrown when the Runtime is not available (not initialized,
// singleton creation failed, or the RuntimeService itself is null). This is
// the ONLY error type that triggers the RuntimeAdapter's fallback to
// LiteLLMAdapter.
//
// Functional errors (stage failures, module not registered, validation
// errors) do NOT trigger fallback — they are surfaced to the caller as
// operational failures. Only RuntimeUnavailableError indicates the Runtime
// infrastructure itself is down, justifying a fallback to the direct
// LiteLLM path.
// =============================================================================

/**
 * Error thrown when the Runtime is not available.
 *
 * Scenarios:
 *   - RuntimeService singleton is null (initialization failed)
 *   - RuntimeService.execute() throws before the pipeline runs
 *   - RuntimeService is not initialized and initialize() fails
 *
 * This is NOT thrown for:
 *   - Pipeline stage failures (those set response.ok = false)
 *   - Module not registered (that's a functional error)
 *   - Validation errors (those set response.error)
 */
export class RuntimeUnavailableError extends Error {
  constructor(
    message: string,
    public readonly cause?: unknown,
  ) {
    super(message)
    this.name = 'RuntimeUnavailableError'
  }
}
