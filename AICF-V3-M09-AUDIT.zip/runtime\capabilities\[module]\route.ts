// =============================================================================
// AICF V3 — GET /api/runtime/capabilities/[module] (Sprint 16)
// =============================================================================
// Returns the capabilities of a specific module.
// Uses the same singleton RuntimeService as /api/runtime/capabilities.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

async function getService() {
  return await getRuntimeService()
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ module: string }> },
) {
  const { module: moduleId } = await params
  const reqLogger = logger.child({
    endpoint: '/api/runtime/capabilities/[module]',
    method: 'GET',
    moduleId,
  })

  try {
    const service = await getService()

    if (!service) {
      return NextResponse.json(
        { error: 'Runtime not available' },
        { status: 503 },
      )
    }

    const registry = service.getModuleRegistry()
    const entry = registry.getEntry(moduleId)

    if (!entry) {
      return NextResponse.json(
        { error: `Module '${moduleId}' not found` },
        { status: 404 },
      )
    }

    const result = {
      id: entry.metadata?.id || entry.module.name,
      name: entry.metadata?.name || entry.module.name,
      description: entry.metadata?.description || null,
      mission: entry.metadata?.mission || null,
      version: entry.module.version,
      ready: entry.module.isReady(),
      capabilities: entry.capabilities,
      dependencies: entry.metadata?.dependencies || [],
      priority: entry.metadata?.priority || null,
      contracts: entry.contracts,
      events: entry.events,
      statistics: entry.statistics,
      health: entry.health,
    }

    reqLogger.info(
      { capabilityCount: entry.capabilities.length },
      'Module capabilities retrieved',
    )

    return NextResponse.json(result)
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to get module capabilities',
    )
    return NextResponse.json(
      { error: 'Failed to get module capabilities' },
      { status: 500 },
    )
  }
}
