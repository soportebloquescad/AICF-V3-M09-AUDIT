// =============================================================================
// AICF V3 — Sprint 10 — CountryAdapter (per-country slide adaptation)
// =============================================================================
import type { LocaleContext } from '../locale/CountryEngine'
import type { ThemePreset } from '../theme/ThemeCatalog'
import type { GeneratedSlide } from './SlideGenerator'
import { SlideGenerator } from './SlideGenerator'

export interface CountrySlideSet {
  countryCode: string
  countryName: string
  slides: GeneratedSlide[]
}

export class CountryAdapter {
  private readonly generator = new SlideGenerator()

  adaptForCountries(opts: {
    title: string
    description: string
    moduleCount: number
    theme: ThemePreset
    locales: LocaleContext[]
    includeImages: boolean
  }): CountrySlideSet[] {
    return opts.locales.map((locale) => ({
      countryCode: locale.country.code,
      countryName: locale.country.name,
      slides: this.generator.generateSlides({
        title: opts.title,
        description: opts.description,
        moduleCount: opts.moduleCount,
        theme: opts.theme,
        locale,
        includeImages: opts.includeImages,
      }),
    }))
  }
}
