// =============================================================================
// AICF V3 — Plugin SDK Tests (Épica 2 — AI Factory Core, B11)
// =============================================================================
// Verifies `defineModule()` from `business/plugin/PluginSDK.ts`:
//   - Returns a BusinessModuleBase instance.
//   - The returned instance carries name + version from the config.
//   - getMetadata() returns the metadata from the config (defensively copied).
//   - getCapabilities() returns the capabilities from the config (defensively
//     copied — mutation of the source array must NOT leak in).
//   - executeJob() delegates to the config's executeJob function with the
//     exact (jobType, input, ctx) tuple.
//   - Lifecycle (initialize / isReady / health / getMetrics / dispose) is
//     inherited from BusinessModuleBase and works out of the box.
//
// No `any`. The variable holding the module under test is named `testModule`
// (not `module`) per project conventions.
// =============================================================================

import { describe, it, expect } from 'bun:test'
import { defineModule } from '../PluginSDK'
import { BusinessModuleBase } from '../BusinessModuleBase'
import { createCapability } from '../../contracts/Capability'
import { createSuccessResult, createFailedResult } from '../../contracts/ExecutionResult'
import { createBusinessContext } from '../../contracts/BusinessContext'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import type { BusinessContext } from '../../contracts/BusinessContext'
import type { ExecutionResult } from '../../contracts/ExecutionResult'

/**
 * Builds a minimal PluginMetadata for tests.
 */
function makeMetadata(id: string): PluginMetadata {
  return {
    id,
    name: id,
    description: `Test module ${id}`,
    author: 'test',
    version: '1.0.0',
    mission: id,
    priority: 50,
    dependencies: [],
    capabilities: ['ping'],
    contracts: createVersionedContract('1.0.0', 'compatible'),
  }
}

describe('defineModule() (Épica 2 — B11)', () => {
  it('returns a BusinessModuleBase instance', () => {
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async () => createSuccessResult({ ok: true }),
    })
    expect(testModule).toBeInstanceOf(BusinessModuleBase)
  })

  it('carries name + version from the config', () => {
    const testModule = defineModule({
      name: 'demo',
      version: '3.2.1',
      metadata: makeMetadata('demo'),
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async () => createSuccessResult({ ok: true }),
    })
    expect(testModule.name).toBe('demo')
    expect(testModule.version).toBe('3.2.1')
  })

  it('getMetadata() returns the metadata from the config', () => {
    const meta = makeMetadata('demo')
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: meta,
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async () => createSuccessResult({ ok: true }),
    })
    expect(testModule.getMetadata()).toBe(meta)
  })

  it('getCapabilities() returns a defensive copy (mutation does not leak)', () => {
    const caps = [createCapability('ping', 'Pings'), createCapability('pong', 'Pongs')]
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: caps,
      executeJob: async () => createSuccessResult({ ok: true }),
    })
    const out1 = testModule.getCapabilities()
    expect(out1.length).toBe(2)
    expect(out1.map((c) => c.name)).toEqual(['ping', 'pong'])

    // Mutate the source array — getCapabilities() must NOT reflect this.
    caps.push(createCapability('extra', 'extra'))
    const out2 = testModule.getCapabilities()
    expect(out2.length).toBe(2)
    expect(out2.map((c) => c.name)).toEqual(['ping', 'pong'])

    // Mutate the returned array — the next call must NOT reflect this either.
    out1.push(createCapability('mutated', 'mutated'))
    const out3 = testModule.getCapabilities()
    expect(out3.length).toBe(2)
  })

  it('executeJob() delegates to the config function with (jobType, input, ctx)', async () => {
    // Use a holder array so TypeScript's control-flow analysis doesn't
    // narrow `captured` to `null` at the read sites below (assignments
    // happen inside an async callback, which CFA can't track).
    const captured: Array<{
      jobType: string
      input: Record<string, unknown>
      ctx: BusinessContext
    }> = []
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async (
        jobType: string,
        input: Record<string, unknown>,
        ctx: BusinessContext,
      ): Promise<ExecutionResult> => {
        captured.push({ jobType, input, ctx })
        return createSuccessResult({ echoed: input })
      },
    })
    const ctx = createBusinessContext({ jobId: 'job-1' })
    const result = await testModule.executeJob('ping', { hello: 'world' }, ctx)

    expect(result.ok).toBe(true)
    expect(result.output).toEqual({ echoed: { hello: 'world' } })
    expect(captured.length).toBe(1)
    expect(captured[0].jobType).toBe('ping')
    expect(captured[0].input).toEqual({ hello: 'world' })
    expect(captured[0].ctx.jobId).toBe('job-1')
  })

  it('inherited lifecycle works (initialize → isReady → health → dispose)', async () => {
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async () => createSuccessResult({ ok: true }),
    })

    expect(testModule.isReady()).toBe(false)
    await testModule.initialize()
    expect(testModule.isReady()).toBe(true)

    const health = await testModule.health()
    expect(health.ready).toBe(true)
    expect(health.status).toBe('healthy')
    expect(health.version).toBe('1.0.0')

    await testModule.dispose()
    expect(testModule.isReady()).toBe(false)
    const healthAfterDispose = await testModule.health()
    expect(healthAfterDispose.status).toBe('unhealthy')
  })

  it('executeJob returning a failed result is forwarded as-is', async () => {
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: [createCapability('ping', 'Pings')],
      executeJob: async () => createFailedResult('Not implemented'),
    })
    const ctx = createBusinessContext({ jobId: 'job-1' })
    const r = await testModule.executeJob('ping', {}, ctx)
    expect(r.ok).toBe(false)
    expect(r.error).toBe('Not implemented')
  })

  it('getStatus() returns the capabilities in details', async () => {
    const testModule = defineModule({
      name: 'demo',
      version: '1.0.0',
      metadata: makeMetadata('demo'),
      capabilities: [
        createCapability('ping', 'Pings'),
        createCapability('pong', 'Pongs'),
      ],
      executeJob: async () => createSuccessResult({ ok: true }),
    })
    await testModule.initialize()
    const status = testModule.getStatus()
    expect(status.name).toBe('demo')
    expect(status.ready).toBe(true)
    expect(status.details?.capabilities).toEqual(['ping', 'pong'])
  })
})
