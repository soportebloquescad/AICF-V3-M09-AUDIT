// =============================================================================
// AICF V3 — Metrics Registry Barrel (Sprint 17)
// =============================================================================

export {
  MetricsRegistry,
  createEmptyModuleMetrics,
  type ModuleMetrics,
} from './MetricsRegistry'
