// =============================================================================
// AICF V3 — Workflow Module (Sprint 15: Full Lifecycle)
// =============================================================================
// Implements the RuntimeModule interface with full lifecycle:
//   - initialize(): idempotent, marks ready
//   - health(): returns ModuleHealth with metrics
//   - dispose(): releases resources
//   - shutdown(): graceful shutdown
//   - getMetrics(): returns per-module metrics
// =============================================================================

import type { RuntimeModule, RuntimeStatus, ModuleHealth, ModuleMetrics } from '@/lib/runtime/contracts/RuntimeModule'
import { createDefaultModuleMetrics } from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { WORKFLOW_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { WorkflowContext, WorkflowResult, DryRunResult, WorkflowDefinition, WorkflowExecution } from '@/lib/runtime/contracts/workflow'
import type { IWorkflowEngine } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Plugin metadata for the Workflow module (M09).
 * Sprint 17: declares capabilities, contracts, events, priority, mission.
 */
export const WORKFLOW_METADATA: PluginMetadata = {
  id: 'workflow',
  name: 'Workflow Runtime',
  description: 'Durable workflow execution with Saga compensation, checkpoints, and recovery',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M09',
  priority: 12,
  dependencies: [],
  capabilities: [...WORKFLOW_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'workflow.started',
    'workflow.completed',
    'workflow.failed',
    'workflow.cancelled',
    'workflow.paused',
    'workflow.resumed',
  ],
}

/**
 * Public interface of the Workflow Module.
 */
export interface WorkflowModuleInterface {
  execute(definition: WorkflowDefinition, inputs: Record<string, unknown>, ctx: WorkflowContext): Promise<WorkflowResult>
  dryRun(definition: WorkflowDefinition, inputs: Record<string, unknown>, ctx: WorkflowContext): Promise<DryRunResult>
  cancel(executionId: string): Promise<void>
  pause(executionId: string): Promise<void>
  resume(executionId: string): Promise<WorkflowResult>
  getStatusById(executionId: string): Promise<WorkflowExecution | null>
  getEngine(): IWorkflowEngine
}

/**
 * Workflow Runtime Module — registered in ModuleRegistry.
 * Wraps the WorkflowEngine and exposes the RuntimeModule interface.
 */
export class WorkflowModule implements RuntimeModule, WorkflowModuleInterface {
  readonly name = 'workflow-runtime'
  readonly version = '1.0.0'

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(private readonly engine: IWorkflowEngine) {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
    logger.info({ initLatencyMs: this.initLatencyMs }, 'WorkflowModule: initialized')
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'src/lib/runtime/modules/workflow',
        startupTime: this.startupTime,
        lastInitialization: this.lastInitialization,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    logger.info('WorkflowModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('WorkflowModule: shut down')
  }

  /**
   * Gets the plugin metadata (Sprint 17).
   */
  getMetadata(): PluginMetadata {
    return WORKFLOW_METADATA
  }

  private markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  private recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }

  async execute(definition: WorkflowDefinition, inputs: Record<string, unknown>, ctx: WorkflowContext): Promise<WorkflowResult> {
    this.markUsed()
    try {
      return await this.engine.execute(definition, inputs, ctx)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  async dryRun(definition: WorkflowDefinition, inputs: Record<string, unknown>, ctx: WorkflowContext): Promise<DryRunResult> {
    this.markUsed()
    try {
      return await this.engine.dryRun(definition, inputs, ctx)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  async cancel(executionId: string): Promise<void> {
    this.markUsed()
    try {
      return await this.engine.cancel(executionId)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  async pause(executionId: string): Promise<void> {
    this.markUsed()
    try {
      return await this.engine.pause(executionId)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  async resume(executionId: string): Promise<WorkflowResult> {
    this.markUsed()
    try {
      return await this.engine.resume(executionId)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  async getStatusById(executionId: string): Promise<WorkflowExecution | null> {
    return this.engine.getStatus(executionId)
  }

  getEngine(): IWorkflowEngine {
    return this.engine
  }
}
