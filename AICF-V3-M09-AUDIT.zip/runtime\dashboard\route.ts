// =============================================================================
// AICF V3 — GET /api/runtime/dashboard (Sprint 22: PR 2 — Observability)
// =============================================================================
// Returns the most recent EDA events buffered by the DashboardSubscriber's
// ring buffer. Intended for live dashboards / polling consumers that want
// to display a tail of the runtime's event stream.
//
// Query params:
//   - limit : max events to return (default 50; max 1000)
//
// Response shape:
//   {
//     events:        RuntimeEventEnvelope<unknown>[],  // most recent N events
//     totalReceived: number                            // grand total events received
//   }
//
// The events are returned in chronological order (oldest first within the
// returned window). `totalReceived` is the total number of events the
// subscriber has seen since process start — it may exceed the ring buffer
// capacity (overwritten events are still counted).
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getDashboardSubscriber } from '@/lib/runtime/observability-singleton'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Default + hard cap on the number of events returned per call. */
const DEFAULT_LIMIT = 50
const MAX_LIMIT = 1000

/**
 * Parses the `limit` query param into a positive integer clamped to
 * [1, MAX_LIMIT]. Falls back to DEFAULT_LIMIT on missing/invalid input.
 */
function parseLimit(raw: string | null): number {
  const parsed = Number.parseInt(raw ?? '', 10)
  if (!Number.isFinite(parsed) || parsed <= 0) return DEFAULT_LIMIT
  return Math.min(parsed, MAX_LIMIT)
}

export async function GET(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/runtime/dashboard', method: 'GET' })

  try {
    const params = request.nextUrl.searchParams
    const limit = parseLimit(params.get('limit'))

    const dashboardSubscriber = getDashboardSubscriber()
    const events = dashboardSubscriber.getRecentEvents(limit)
    const totalReceived = dashboardSubscriber.getEventCount()

    reqLogger.info(
      { returned: events.length, totalReceived, limit },
      'Dashboard events retrieved',
    )

    return NextResponse.json({ events, totalReceived })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to retrieve dashboard events',
    )
    return NextResponse.json(
      { events: [], totalReceived: 0, error: 'Failed to retrieve dashboard events' },
      { status: 500 },
    )
  }
}
