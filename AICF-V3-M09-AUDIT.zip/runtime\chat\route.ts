// =============================================================================
// AICF V3 — POST /runtime/chat
// =============================================================================
// Runtime endpoint for chat completions via the pipeline.
//
// Épica 1 — Stabilization (H2): uses getRuntimeService() singleton instead of
// `new RuntimeService()` so the bootstrap + M08/M18/M21 modules + EventBus
// are properly wired. Previously this route created a fresh RuntimeService
// per request with no modules registered, causing empty 200 responses.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

export async function POST(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/runtime/chat', method: 'POST' })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  // Basic validation
  if (!body || typeof body !== 'object' || !('model' in body) || !('messages' in body)) {
    return NextResponse.json({ error: 'Missing model or messages' }, { status: 422 })
  }

  const req = body as { model: string; messages: unknown[] }

  const runtimeRequest = createRuntimeRequest({
    operation: 'chat',
    model: req.model,
    messages: req.messages as import('@/lib/ai/AIAdapter').ChatMessage[],
    parameters: 'temperature' in body ? { temperature: (body as { temperature: number }).temperature } : undefined,
  })

  const service = await getRuntimeService()
  if (!service) {
    return NextResponse.json({ error: 'Runtime not initialized' }, { status: 503 })
  }
  const response = await service.execute(runtimeRequest)

  reqLogger.info({ requestId: response.requestId, ok: response.ok, durationMs: response.durationMs }, 'Runtime chat completed')

  return NextResponse.json(response, { status: response.ok ? 200 : 500 })
}
