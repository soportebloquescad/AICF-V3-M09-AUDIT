// =============================================================================
// AICF V3 — Course Module Barrel (Épica 3 — Educational Factory)
// =============================================================================
// Re-exports the CourseModule class + its metadata + capabilities + types.
// =============================================================================

export {
  CourseModule,
  COURSE_MODULE_METADATA,
  COURSE_CAPABILITIES,
} from './CourseModule'

export type {
  Course,
  CourseModuleItem,
  Lesson,
} from './CourseModule'
