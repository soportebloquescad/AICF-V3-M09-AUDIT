// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Event Contract
// =============================================================================
// Defines the event stream emitted by the workflow executor. Events are the
// single source of truth for workflow observability — they feed:
//   - The audit log (every state transition is recorded)
//   - The UI progress surface (live step status, retries, artifacts)
//   - The metrics aggregator (latency, token usage, cost)
//   - The saga-compensation tracker (compensation lifecycle)
//
// Sprint 13+14 spec requirements covered:
//   - One discriminated union (`WorkflowEventType`) covering every state
//     transition in the execution model
//   - Structured payload (`data`) carrying type-specific fields
//   - Severity level (`info` | `warn` | `error`) for routing
//   - Correlation id + execution id + step id for fan-out tracing
//   - Helpers: `createEvent` (auto-fills timestamp) and `isWorkflowEvent`
//     (type guard for input validation at consumer boundaries)
// =============================================================================

/**
 * Every state transition the workflow executor can emit. Grouped by scope:
 *   - `workflow.*`   : whole-execution lifecycle
 *   - `step.*`       : per-step lifecycle
 *   - `artifact.*`   : artifact production
 *   - `provider.*`   : routing decisions
 *   - `generation.*` : underlying generation completions
 *   - `workflow.compensation.*` : saga rollback lifecycle
 */
export type WorkflowEventType =
  | 'workflow.started'
  | 'workflow.completed'
  | 'workflow.failed'
  | 'workflow.cancelled'
  | 'workflow.paused'
  | 'workflow.resumed'
  | 'step.started'
  | 'step.completed'
  | 'step.failed'
  | 'step.retrying'
  | 'artifact.created'
  | 'provider.selected'
  | 'generation.completed'
  | 'workflow.checkpoint'
  | 'workflow.compensation.started'
  | 'workflow.compensation.completed'

/** Severity level for event routing / filtering. */
export type WorkflowEventLevel = 'info' | 'warn' | 'error'

/**
 * Structured event envelope. The `data` payload is intentionally typed as
 * `Record<string, unknown>` so that consumers can attach type-specific
 * narrowers without forcing a per-event-type explosion in the contract.
 */
export interface WorkflowEvent {
  /** Event discriminator. */
  type: WorkflowEventType
  /** Execution id the event pertains to (absent for pre-execution events). */
  executionId?: string
  /** Step id the event pertains to (absent for whole-execution events). */
  stepId?: string
  /** Cross-service correlation id for distributed tracing. */
  correlationId?: string
  /** Epoch ms when the event was emitted. */
  timestamp: number
  /** Type-specific payload. */
  data: Record<string, unknown>
  /** Severity level. */
  level: WorkflowEventLevel
}

/** Optional fields for `createEvent`. */
export interface CreateEventOptions {
  executionId?: string
  stepId?: string
  correlationId?: string
  level?: WorkflowEventLevel
  timestamp?: number
}

/**
 * Default severity for each event type. Events that imply a problem
 * (`*.failed`, `*.retrying`, `*.cancelled`) default to `warn` or `error`;
 * everything else defaults to `info`.
 */
const DEFAULT_LEVEL: Readonly<Record<WorkflowEventType, WorkflowEventLevel>> =
  Object.freeze({
    'workflow.started': 'info',
    'workflow.completed': 'info',
    'workflow.failed': 'error',
    'workflow.cancelled': 'warn',
    'workflow.paused': 'info',
    'workflow.resumed': 'info',
    'step.started': 'info',
    'step.completed': 'info',
    'step.failed': 'error',
    'step.retrying': 'warn',
    'artifact.created': 'info',
    'provider.selected': 'info',
    'generation.completed': 'info',
    'workflow.checkpoint': 'info',
    'workflow.compensation.started': 'warn',
    'workflow.compensation.completed': 'warn',
  })

/**
 * Factory: creates a `WorkflowEvent` with sensible defaults.
 * - `timestamp` defaults to `Date.now()`.
 * - `level` defaults to the per-type severity (see `DEFAULT_LEVEL`).
 *
 * @param type  Event discriminator.
 * @param data  Type-specific payload.
 * @param opts  Optional overrides (executionId, stepId, correlationId,
 *              level, timestamp).
 */
export function createEvent(
  type: WorkflowEventType,
  data: Record<string, unknown>,
  opts?: CreateEventOptions,
): WorkflowEvent {
  const level = opts?.level ?? DEFAULT_LEVEL[type]
  const timestamp = opts?.timestamp ?? Date.now()
  const event: WorkflowEvent = {
    type,
    timestamp,
    data,
    level,
  }
  if (opts?.executionId !== undefined) event.executionId = opts.executionId
  if (opts?.stepId !== undefined) event.stepId = opts.stepId
  if (opts?.correlationId !== undefined)
    event.correlationId = opts.correlationId
  return event
}

/**
 * Type guard: narrows an unknown value to `WorkflowEvent`.
 * Validates the structural minimum (type, timestamp, level, data).
 */
export function isWorkflowEvent(value: unknown): value is WorkflowEvent {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  if (typeof v.type !== 'string') return false
  if (typeof v.timestamp !== 'number') return false
  if (typeof v.level !== 'string') return false
  if (v.level !== 'info' && v.level !== 'warn' && v.level !== 'error')
    return false
  if (typeof v.data !== 'object' || v.data === null) return false
  return true
}
