// =============================================================================
// AICF V3 — Epica 8 — Case Study Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { ModulePlan, CaseStudy, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class CaseStudyBuilder implements EngineContract {
  readonly name = 'case-study-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('CaseStudyBuilder: invalid input — expected ModulePlan[]')
    }
    const modules = input as ModulePlan[]
    const studies: CaseStudy[] = []
    for (const mod of modules) {
      if (this.opts.aiAdapter) {
        try {
          studies.push(await this.buildWithAI(mod))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'CaseStudyBuilder: AI failed, using fallback')
        }
      }
      studies.push(this.buildDeterministic(mod))
    }
    return studies
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(mod: ModulePlan): Promise<CaseStudy> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a case study designer. Create a realistic scenario with background, challenge, questions, learning objectives, and a suggested approach. Respond as JSON.',
        },
        {
          role: 'user',
          content: `Module: ${mod.title}\nSummary: ${mod.summary}\nOutcomes: ${mod.learningOutcomes.join('; ')}\n\nCreate a case study. Return JSON: { "title": string, "scenario": string, "background": string, "challenge": string, "questions": string[], "learningObjectives": string[], "suggestedApproach": string }`,
        },
      ],
      temperature: 0.6,
      maxTokens: 4096,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; scenario?: string; background?: string; challenge?: string; questions?: string[]; learningObjectives?: string[]; suggestedApproach?: string }
    return this.assembleCaseStudy(
      mod,
      {
        title: parsed.title ?? `Case Study: ${mod.title}`,
        scenario: parsed.scenario ?? `A scenario applying ${mod.title}.`,
        background: parsed.background ?? `Background context for ${mod.title}.`,
        challenge: parsed.challenge ?? `The challenge is to apply ${mod.title} concepts effectively.`,
        questions: parsed.questions ?? [],
        learningObjectives: parsed.learningObjectives ?? mod.learningOutcomes,
        suggestedApproach: parsed.suggestedApproach ?? `Apply the concepts from ${mod.title} systematically.`,
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(mod: ModulePlan): CaseStudy {
    const parsed = {
      title: `Case Study: Applying ${mod.title} in Practice`,
      scenario: `A mid-sized organization is implementing the concepts from ${mod.title} to address a strategic challenge. The leadership team has allocated resources and assembled a cross-functional team, but they face decisions about how to apply the module's principles effectively in their specific context.`,
      background: `The organization operates in a competitive environment where ${mod.title.toLowerCase()} plays a critical role. Team members have varying levels of experience with the concepts covered in this module. Some have theoretical knowledge but limited practical application; others have hands-on experience but lack the broader strategic perspective. The organization's culture values data-driven decision-making and iterative improvement.`,
      challenge: `The primary challenge is to translate the theoretical concepts from ${mod.title} into actionable strategies that the organization can implement within the next quarter. Specifically, the team must: (1) identify which concepts are most relevant to their context; (2) develop a phased implementation plan; (3) establish metrics for success; and (4) anticipate and mitigate potential risks. Resource constraints and competing priorities add complexity to the decision-making process.`,
      questions: [
        `Which concepts from ${mod.title} are most applicable to the organization's situation, and why?`,
        'How would you prioritize the implementation of these concepts given the resource constraints described?',
        'What metrics would you use to measure the success of the implementation, and how would you collect the necessary data?',
        'What potential risks do you foresee, and how would you mitigate them?',
        'How would you adapt the approach if the initial implementation does not produce the expected results?',
      ],
      learningObjectives: mod.learningOutcomes.length > 0
        ? mod.learningOutcomes.map((o) => `Apply: ${o}`)
        : ['Apply module concepts to a realistic organizational scenario', 'Develop a structured implementation plan', 'Identify and mitigate risks'],
      suggestedApproach: `A structured approach to this case study involves: (1) Carefully reading the background to understand the organizational context; (2) Reviewing the module's key concepts and identifying which are most relevant; (3) Developing a prioritized implementation plan with clear phases; (4) Defining specific, measurable success metrics aligned with the organization's goals; (5) Conducting a risk assessment and developing mitigation strategies; (6) Considering contingency plans for different scenarios. The response should demonstrate both theoretical understanding and practical judgment, integrating multiple concepts from ${mod.title} into a coherent strategy.`,
    }
    return this.assembleCaseStudy(mod, parsed, 'runtime-adapter', 'deterministic-fallback')
  }

  private assembleCaseStudy(
    mod: ModulePlan,
    parsed: { title: string; scenario: string; background: string; challenge: string; questions: string[]; learningObjectives: string[]; suggestedApproach: string },
    provider: Provider,
    model: string,
  ): CaseStudy {
    const now = new Date().toISOString()
    return {
      id: makeId('cs'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      moduleId: mod.id,
      moduleTitle: mod.title,
      title: parsed.title,
      scenario: parsed.scenario,
      background: parsed.background,
      challenge: parsed.challenge,
      questions: parsed.questions,
      learningObjectives: parsed.learningObjectives,
      suggestedApproach: parsed.suggestedApproach,
      durationMinutes: 60,
    }
  }
}
