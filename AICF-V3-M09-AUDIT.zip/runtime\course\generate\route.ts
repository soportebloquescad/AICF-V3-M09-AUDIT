// =============================================================================
// AICF V3 — Épica 7 — POST /api/runtime/course/generate
// =============================================================================
// Thin Route Handler: validates input with Zod, delegates to CourseWorker,
// returns HTTP response. No business logic here.
//
// Flow: Dashboard → POST /api/runtime/course/generate → CourseWorker.run()
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { CourseWorker } from '@/lib/runtime/course/CourseWorker'
import type { CourseJobRequest } from '@/lib/runtime/course/CourseJobStore'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

const generateSchema = z.object({
  title: z.string().min(1).max(512),
  locale: z.string().max(16).default('en'),
  country: z.string().max(64).default('global'),
  audience: z.string().max(256).default('learners'),
  level: z.enum(['Principiante', 'Intermedio', 'Avanzado', 'Experto']).default('Intermedio'),
  objective: z.string().max(1024).default(''),
  certification: z.object({
    finalExam: z.boolean().default(true),
    rubrics: z.boolean().default(true),
    certificate: z.boolean().default(false),
    badges: z.boolean().default(false),
    finalProject: z.boolean().default(false),
  }).default({ finalExam: true, rubrics: true, certificate: false, badges: false, finalProject: false }),
  contentTypes: z.array(z.enum([
    'pdf', 'presentation', 'videos', 'scripts', 'quizzes', 'labs', 'cases', 'templates', 'resources', 'prompts',
  ])).default(['pdf', 'presentation', 'quizzes']),
  premiumLevel: z.enum(['Standard', 'Premium', 'Enterprise']).default('Standard'),
  model: z.enum(['Auto', 'Groq', 'Gemini', 'Claude', 'OpenAI', 'OpenRouter']).default('Auto'),
  budget: z.number().positive().max(100).default(1.0),
  mode: z.enum(['Rápido', 'Balanceado', 'Premium', 'Investigación profunda']).default('Balanceado'),
  modules: z.number().int().min(1).max(20).optional(),
  idempotencyKey: z.string().max(128).optional(),
})

export async function POST(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/api/runtime/course/generate', method: 'POST' })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const parsed = generateSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten() },
      { status: 422 },
    )
  }

  const { idempotencyKey, ...requestData } = parsed.data
  const jobRequest: CourseJobRequest = {
    title: requestData.title,
    locale: requestData.locale,
    country: requestData.country,
    audience: requestData.audience,
    level: requestData.level,
    objective: requestData.objective,
    certification: requestData.certification,
    contentTypes: requestData.contentTypes,
    premiumLevel: requestData.premiumLevel,
    model: requestData.model,
    budget: requestData.budget,
    mode: requestData.mode,
    modules: requestData.modules,
  }

  reqLogger.info({ title: jobRequest.title, level: jobRequest.level, modules: jobRequest.modules ?? 5 }, 'Course generation requested')

  try {
    const worker = new CourseWorker()
    const result = await worker.run(jobRequest, idempotencyKey)

    reqLogger.info(
      { jobId: result.job.id, status: result.job.status, artifactCount: result.artifacts.length },
      'Course generation completed',
    )

    return NextResponse.json(
      {
        ok: result.job.status === 'completed',
        jobId: result.job.id,
        courseId: result.job.courseId,
        status: result.job.status,
        stage: result.job.stage,
        progress: result.job.progress,
        error: result.job.error,
        artifactCount: result.artifacts.length,
        artifacts: result.artifacts.map((a) => ({
          artifactId: a.artifactId,
          type: a.type,
          format: a.format,
          name: a.name,
          sizeBytes: a.sizeBytes,
        })),
        zipUrl: result.zipUrl,
        startedAt: result.job.startedAt,
        completedAt: result.job.completedAt,
      },
      { status: result.job.status === 'completed' ? 201 : 202 },
    )
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Course generation failed',
    )
    return NextResponse.json(
      { error: 'Failed to generate course', message: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    )
  }
}
