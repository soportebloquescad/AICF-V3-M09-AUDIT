// =============================================================================
// AICF V3 — Versioned Contract (Sprint 16: Runtime Plugin Integration)
// =============================================================================
// Every module contract is versioned. The Runtime validates compatibility
// before initializing a module.
// =============================================================================

/**
 * Compatibility level between a module's contract and the Runtime.
 * - 'strict': exact version match required
 * - 'compatible': minor/patch differences allowed (semver)
 * - 'deprecated': module works but will be removed in a future release
 */
export type ContractCompatibility = 'strict' | 'compatible' | 'deprecated'

/**
 * Versioned contract information.
 * Every module exposes this so the Runtime can validate compatibility
 * before initialization.
 */
export interface VersionedContract {
  /** Schema version of the contract format itself (e.g., '1.0.0'). */
  schemaVersion: string

  /** Semantic version of this specific contract. */
  contractVersion: string

  /** Version of the Runtime that this module is designed for. */
  runtimeVersion: string

  /** Compatibility level. */
  compatibility: ContractCompatibility
}

/**
 * The current Runtime version. Modules must declare this in their contract.
 */
export const RUNTIME_VERSION = '3.0.0'

/**
 * The current contract schema version.
 */
export const CONTRACT_SCHEMA_VERSION = '1.0.0'

/**
 * Creates a default VersionedContract for the current Runtime.
 */
export function createVersionedContract(
  contractVersion: string,
  compatibility: ContractCompatibility = 'compatible',
): VersionedContract {
  return {
    schemaVersion: CONTRACT_SCHEMA_VERSION,
    contractVersion,
    runtimeVersion: RUNTIME_VERSION,
    compatibility,
  }
}

/**
 * Validates that a module's contract is compatible with the current Runtime.
 * Returns { valid: boolean, reason?: string }.
 */
export function validateContractCompatibility(
  contract: VersionedContract,
  runtimeVersion: string = RUNTIME_VERSION,
): { valid: boolean; reason?: string } {
  if (contract.compatibility === 'deprecated') {
    return {
      valid: true,
      reason: `Module contract is deprecated (runtimeVersion=${contract.runtimeVersion}, current=${runtimeVersion})`,
    }
  }

  if (contract.compatibility === 'strict') {
    if (contract.runtimeVersion !== runtimeVersion) {
      return {
        valid: false,
        reason: `Strict compatibility required: module expects runtime ${contract.runtimeVersion}, got ${runtimeVersion}`,
      }
    }
    return { valid: true }
  }

  // 'compatible' — check major version match
  const moduleMajor = contract.runtimeVersion.split('.')[0]
  const runtimeMajor = runtimeVersion.split('.')[0]
  if (moduleMajor !== runtimeMajor) {
    return {
      valid: false,
      reason: `Major version mismatch: module expects runtime ${contract.runtimeVersion} (major ${moduleMajor}), got ${runtimeVersion} (major ${runtimeMajor})`,
    }
  }

  return { valid: true }
}
