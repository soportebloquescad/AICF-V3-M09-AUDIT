// =============================================================================
// AICF V3 — Stage Registry (Sprint Foundation-Core)
// =============================================================================
// Registry for pipeline stages. A pipeline stage is a named function that
// transforms a RuntimeContext (see `@/lib/runtime/pipeline/PipelineStage`).
// This registry allows stages to be looked up by name and composed into
// ordered pipelines at runtime.
//
// The registry is intentionally minimal: it does not validate stage
// semantics or enforce ordering constraints — those concerns belong to the
// caller that assembles the pipeline via `createPipeline(stageNames)`.
// =============================================================================

import type { PipelineStage } from '@/lib/runtime/pipeline/PipelineStage'
import { logger } from '@/lib/ai/logger'

/**
 * StageRegistry — name-indexed map of PipelineStage instances.
 *
 * @example
 * const reg = new StageRegistry()
 * reg.register('validate', validateStage)
 * reg.register('policy', policyStage)
 * const pipeline = reg.createPipeline(['validate', 'policy'])
 */
export class StageRegistry {
  private readonly stages = new Map<string, PipelineStage>()

  /**
   * Registers a stage by name. Overwrites any previous stage with the same
   * name.
   */
  register(name: string, stage: PipelineStage): void {
    this.stages.set(name, stage)
    logger.debug({ stageName: name }, 'StageRegistry: stage registered')
  }

  /**
   * Unregisters a stage by name. No-op if not registered.
   */
  unregister(name: string): void {
    if (!this.stages.has(name)) return
    this.stages.delete(name)
    logger.debug({ stageName: name }, 'StageRegistry: stage unregistered')
  }

  /**
   * Returns the stage registered under `name`, or null if not found.
   */
  get(name: string): PipelineStage | null {
    return this.stages.get(name) || null
  }

  /**
   * Returns the names of all registered stages (insertion order).
   */
  list(): string[] {
    return Array.from(this.stages.keys())
  }

  /**
   * Returns all registered stage instances (insertion order).
   */
  getAll(): PipelineStage[] {
    return Array.from(this.stages.values())
  }

  /**
   * Builds an ordered pipeline from a list of stage names. Throws if any
   * name is not registered.
   *
   * @param stageNames Ordered list of stage names.
   * @returns Array of PipelineStage instances in the requested order.
   * @throws Error if any stage name is not registered.
   */
  createPipeline(stageNames: string[]): PipelineStage[] {
    const pipeline: PipelineStage[] = []
    const missing: string[] = []
    for (const name of stageNames) {
      const stage = this.stages.get(name)
      if (stage) {
        pipeline.push(stage)
      } else {
        missing.push(name)
      }
    }
    if (missing.length > 0) {
      const message = `StageRegistry: missing stages: ${missing.join(', ')}`
      logger.error({ missing }, 'StageRegistry: createPipeline failed')
      throw new Error(message)
    }
    return pipeline
  }
}
