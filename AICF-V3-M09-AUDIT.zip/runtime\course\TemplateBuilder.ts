// =============================================================================
// AICF V3 — Epica 8 — Template Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Lesson, Template, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class TemplateBuilder implements EngineContract {
  readonly name = 'template-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('TemplateBuilder: invalid input — expected Lesson[]')
    }
    const lessons = input as Lesson[]
    const templates: Template[] = []
    for (const lesson of lessons) {
      if (this.opts.aiAdapter) {
        try {
          templates.push(await this.buildWithAI(lesson))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'TemplateBuilder: AI failed, using fallback')
        }
      }
      templates.push(this.buildDeterministic(lesson))
    }
    return templates
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return input.length > 0
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(lesson: Lesson): Promise<Template> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a template designer. Create a reusable Markdown template with placeholders. Respond as JSON.',
        },
        {
          role: 'user',
          content: `Lesson: ${lesson.title}\nObjectives: ${lesson.learningObjectives.join('; ')}\n\nCreate a reusable lesson-notes template. Return JSON: { "name": string, "description": string, "format": "markdown", "body": string, "placeholders": [{name, description, required}], "useCase": string }`,
        },
      ],
      temperature: 0.4,
      maxTokens: 2048,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { name?: string; description?: string; format?: Template['format']; body?: string; placeholders?: Array<{ name: string; description: string; required: boolean }>; useCase?: string }
    return this.assembleTemplate(
      lesson,
      {
        name: parsed.name ?? `Template: ${lesson.title}`,
        description: parsed.description ?? `A reusable template for ${lesson.title}.`,
        format: parsed.format ?? 'markdown',
        body: parsed.body ?? `# ${lesson.title}\n\n{{content}}`,
        placeholders: parsed.placeholders ?? [{ name: 'content', description: 'The content', required: true }],
        useCase: parsed.useCase ?? `Use with lesson ${lesson.title}.`,
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(lesson: Lesson): Template {
    const body = [
      `# Lesson Notes: {{lesson_title}}`,
      '',
      '## Lesson Metadata',
      '- **Module:** {{module_title}}',
      '- **Date studied:** {{date}}',
      '- **Time spent:** {{duration}}',
      '- **Bloom level:** {{bloom_level}}',
      '',
      '## Learning Objectives',
      '{{objectives_list}}',
      '',
      '## Key Concepts',
      '{{key_concepts}}',
      '',
      '## Notes',
      'Use this section to capture your understanding of the material in your own words. Focus on explaining concepts as if teaching someone else — this reinforces learning and reveals gaps in understanding.',
      '',
      '{{my_notes}}',
      '',
      '## Practical Application',
      'How does this lesson apply to your work or goals? Identify at least one concrete scenario where you can use these concepts.',
      '',
      '{{application_notes}}',
      '',
      '## Questions & Gaps',
      'List any questions that arose during your study or concepts that remain unclear. Plan how to address them (review, research, ask a colleague, etc.).',
      '',
      '{{questions}}',
      '',
      '## Key Takeaways',
      '{{takeaways}}',
      '',
      '## Action Items',
      '1. {{action_1}}',
      '2. {{action_2}}',
      '3. {{action_3}}',
      '',
      '## Reflection',
      'What worked well in your study of this lesson? What would you do differently next time?',
      '',
      '{{reflection}}',
    ].join('\n')

    const parsed = {
      name: `Lesson Notes Template: ${lesson.title}`,
      description: `A structured note-taking template designed for use with "${lesson.title}". Captures metadata, objectives, key concepts, personal notes, application, questions, takeaways, action items, and reflection.`,
      format: 'markdown' as const,
      body,
      placeholders: [
        { name: 'lesson_title', description: 'The title of the lesson', required: true },
        { name: 'module_title', description: 'The title of the parent module', required: true },
        { name: 'date', description: 'The date the lesson was studied (YYYY-MM-DD)', required: false },
        { name: 'duration', description: 'Time spent studying, in minutes', required: false },
        { name: 'bloom_level', description: 'Bloom taxonomy level targeted by the lesson', required: false },
        { name: 'objectives_list', description: 'Bulleted list of learning objectives', required: true },
        { name: 'key_concepts', description: 'List or description of key concepts covered', required: true },
        { name: 'my_notes', description: 'Personal notes summarizing understanding', required: true },
        { name: 'application_notes', description: 'Notes on how the lesson applies to real scenarios', required: false },
        { name: 'questions', description: 'Questions or gaps identified during study', required: false },
        { name: 'takeaways', description: 'Key takeaways from the lesson', required: true },
        { name: 'action_1', description: 'First action item to apply the learning', required: true },
        { name: 'action_2', description: 'Second action item', required: false },
        { name: 'action_3', description: 'Third action item', required: false },
        { name: 'reflection', description: 'Reflection on study approach', required: false },
      ],
      useCase: `Use this template after studying "${lesson.title}" to consolidate learning, identify gaps, and plan application. Suitable for individual study, study groups, or instructor-led debriefs.`,
    }
    return this.assembleTemplate(lesson, parsed, 'runtime-adapter', 'deterministic-fallback')
  }

  private assembleTemplate(
    lesson: Lesson,
    parsed: { name: string; description: string; format: Template['format']; body: string; placeholders: Array<{ name: string; description: string; required: boolean }>; useCase: string },
    provider: Provider,
    model: string,
  ): Template {
    const now = new Date().toISOString()
    return {
      id: makeId('tmpl'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      name: parsed.name,
      description: parsed.description,
      format: parsed.format,
      body: parsed.body,
      placeholders: parsed.placeholders,
      useCase: parsed.useCase,
    }
  }
}
