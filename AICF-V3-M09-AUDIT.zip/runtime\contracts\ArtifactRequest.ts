// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — ArtifactRequest (Universal)
// =============================================================================
// The universal request contract for ALL artifact types in the Runtime.
//
// Every artifact-generating operation (course, ebook, presentation, document,
// video, prompt) starts from an ArtifactRequest. Specific artifact types
// (CourseRequest, etc.) EXTEND this interface — they never redeclare the
// common fields.
//
// This is the foundation contract. It does NOT replace the legacy
// src/lib/course/CourseRequest.ts (which is the BFF-layer course request used
// by CourseService). The new contract in runtime/contracts/ is the
// Runtime-layer universal artifact request.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

/**
 * The type of artifact to generate.
 */
export type ArtifactType =
  | 'course'
  | 'ebook'
  | 'presentation'
  | 'document'
  | 'video'
  | 'prompt'

/**
 * The target proficiency level of the audience.
 */
export type ArtifactLevel = 'beginner' | 'intermediate' | 'advanced' | 'expert'

/**
 * The universal request contract for any artifact generation.
 *
 * Specific artifact requests (CourseRequest, EbookRequest, etc.) extend this
 * interface with type-specific fields.
 */
export interface ArtifactRequest {
  /** The type of artifact to generate. */
  type: ArtifactType

  /** The topic / subject of the artifact. */
  topic: string

  /** Target proficiency level of the audience. */
  level: ArtifactLevel

  /** Language code (e.g. 'en', 'es', 'fr'). */
  language: string

  /** Human-readable description of the target audience. */
  audience: string

  /** Arbitrary metadata propagated through the pipeline. */
  metadata: Record<string, unknown>

  /** Generation parameters (temperature, maxTokens, etc.). */
  parameters: Record<string, unknown>
}

/**
 * Factory: creates an ArtifactRequest with sensible defaults.
 *
 * @example
 * const req = createArtifactRequest({ type: 'course', topic: 'Intro to Rust' })
 */
export function createArtifactRequest(
  partial: Partial<ArtifactRequest> & Pick<ArtifactRequest, 'type' | 'topic'>,
): ArtifactRequest {
  return {
    level: 'intermediate',
    language: 'en',
    audience: 'general learners',
    metadata: {},
    parameters: {},
    ...partial,
  }
}
