// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — VariableResolver Tests
// =============================================================================
// Tests for the VariableResolver. Verifies simple `{{var}}` substitution,
// dot-notation, default-value fallback, missing-variable behavior,
// recursive resolution of arrays / objects, and non-string passthrough.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { VariableResolver } from '../context/VariableResolver'

describe('VariableResolver', () => {
  let resolver: VariableResolver

  beforeEach(() => {
    resolver = new VariableResolver()
  })

  it('resolves a simple {{var}} placeholder', () => {
    const out = resolver.resolveString('Hello {{name}}!', { name: 'Ada' })
    expect(out).toBe('Hello Ada!')
  })

  it('resolves dot-notation {{user.name}} placeholders', () => {
    const out = resolver.resolveString('Hello {{user.name}}!', {
      user: { name: 'Ada', email: 'ada@example.com' },
    })
    expect(out).toBe('Hello Ada!')
  })

  it('resolves with a default value via {{var|default}}', () => {
    const out = resolver.resolveString('Hello {{name|stranger}}!', {})
    expect(out).toBe('Hello stranger!')
  })

  it('resolves missing variable (no default) to the literal placeholder', () => {
    const out = resolver.resolveString('Hello {{name}}!', {})
    expect(out).toBe('Hello {{name}}!')
  })

  it('resolves empty-default {{var|}} to empty string', () => {
    const out = resolver.resolveString('Hello {{name|}}!', {})
    expect(out).toBe('Hello !')
  })

  it('recursively resolves placeholders in nested objects and arrays', () => {
    const input = {
      greeting: 'Hello {{user.name}}',
      tags: ['{{user.name}}', '{{topic|unknown}}'],
      meta: { author: '{{user.name}}', count: 3 },
    }
    const out = resolver.resolve(input, {
      user: { name: 'Ada' },
      topic: 'AI',
    }) as Record<string, unknown>
    expect(out.greeting).toBe('Hello Ada')
    expect(out.tags).toEqual(['Ada', 'AI'])
    expect((out.meta as Record<string, unknown>).author).toBe('Ada')
    expect((out.meta as Record<string, unknown>).count).toBe(3)
  })

  it('passes through non-string values (numbers, booleans, null) unchanged', () => {
    expect(resolver.resolve(42, {})).toBe(42)
    expect(resolver.resolve(true, {})).toBe(true)
    expect(resolver.resolve(null, {})).toBe(null)
    expect(resolver.resolve(undefined, {})).toBe(undefined)
  })

  it('resolveString vs resolve: resolve walks structures, resolveString only handles strings', () => {
    // `resolve` on a string delegates to `resolveString`.
    expect(resolver.resolve('Hi {{x}}', { x: 'A' })).toBe('Hi A')
    // `resolve` on an object recurses; `resolveString` on an object would
    // never happen because the contract types forbid it — but we can still
    // confirm the structural recursion produces a new object.
    const input = { k: '{{x}}' }
    const out = resolver.resolve(input, { x: 'A' }) as Record<string, unknown>
    expect(out).toEqual({ k: 'A' })
    expect(out).not.toBe(input)
  })

  it('whole-string single-placeholder returns the raw structured value', () => {
    const out = resolver.resolveString('{{items}}', {
      items: ['a', 'b', 'c'],
    })
    // Object/array single-placeholder is JSON-stringified.
    expect(out).toBe(JSON.stringify(['a', 'b', 'c']))
  })

  it('whole-string single-placeholder returns raw string when resolved value is a string', () => {
    expect(resolver.resolveString('{{name}}', { name: 'Ada' })).toBe('Ada')
  })
})
