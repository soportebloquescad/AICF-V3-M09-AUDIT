// =============================================================================
// AICF V3 — Sprint 10 — ZipBuilder (multi-format ZIP bundler)
// =============================================================================
import { ZipArchive } from 'archiver'
import { logger } from '@/lib/ai/logger'

export interface ZipEntry {
  name: string
  content: Buffer | string
}

export class ZipBuilder {
  private readonly log = logger.child({ component: 'ZipBuilder' })

  async build(entries: ZipEntry[], rootFolder: string): Promise<Buffer> {
    this.log.info({ entryCount: entries.length, rootFolder }, 'ZipBuilder: building ZIP')
    return new Promise<Buffer>((resolve, reject) => {
      const archive = new ZipArchive({ zlib: { level: 6 } })
      const chunks: Buffer[] = []
      archive.on('data', (chunk: Buffer) => chunks.push(chunk))
      archive.on('end', () => {
        const buf = Buffer.concat(chunks)
        this.log.info({ size: buf.byteLength }, 'ZipBuilder: ZIP built')
        resolve(buf)
      })
      archive.on('error', (err: Error) => reject(err))

      for (const entry of entries) {
        const name = `${rootFolder}/${entry.name}`
        if (typeof entry.content === 'string') {
          archive.append(entry.content, { name })
        } else {
          archive.append(entry.content, { name })
        }
      }
      archive.finalize()
    })
  }
}

let singleton: ZipBuilder | null = null
export function getZipBuilder(): ZipBuilder {
  if (!singleton) singleton = new ZipBuilder()
  return singleton
}
