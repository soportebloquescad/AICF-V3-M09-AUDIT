// =============================================================================
// AICF V3 — Sprint 8 RC54 — SlideBuilderPro
// =============================================================================
// Generates professional HTML slides from a Storyboard.
// REUSES: Storyboard from StoryboardEngine, Mermaid diagrams, SVG icons.
// =============================================================================

import type { Storyboard, StoryboardSlide } from './StoryboardEngine'
import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import { logger } from '@/lib/ai/logger'

export class SlideBuilderPro {
  private readonly log = logger.child({ component: 'SlideBuilderPro' })

  /**
   * Build the slide deck HTML.
   *
   * `theme` is optional — when provided, the theme's CSS variables are
   * injected before the default `:root` block, overriding the default
   * palette while preserving the existing layout. When omitted, the original
   * styling is used (backward compatibility).
   */
  build(storyboard: Storyboard, theme?: ThemePreset): string {
    this.log.info({ slides: storyboard.totalSlides, theme: theme?.name ?? 'default' }, 'SlideBuilderPro: building slides')

    const themeInjection = theme
      ? `<!-- Sprint 9 Theme Engine: ${theme.name} (${theme.label}) -->
    ${getThemeEngine().renderCssVars(theme)}`
      : ''

    const slidesHtml = storyboard.slides.map(s => this.buildSlide(s)).join('\n')

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${storyboard.title} — Professional Slides</title>
  <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
  <style>
    ${themeInjection}
    :root { --primary: #2563eb; --bg: #0f172a; --surface: #1e293b; --text: #f1f5f9; --muted: #94a3b8; --border: #334155; --accent: #3b82f6; }
    [data-theme="light"] { --bg: #ffffff; --surface: #f8fafc; --text: #1e293b; --muted: #64748b; --border: #e2e8f0; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); overflow: hidden; }
    .slide-deck { height: 100vh; display: flex; flex-direction: column; }
    .progress-bar { height: 4px; background: var(--border); }
    .progress-fill { height: 100%; background: var(--accent); transition: width 0.3s; }
    .slide-container { flex: 1; position: relative; overflow: hidden; }
    .slide { position: absolute; inset: 0; display: none; flex-direction: column; padding: 3rem; animation: slideIn 0.5s; }
    .slide.active { display: flex; }
    @keyframes slideIn { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
    .slide h1 { font-size: 2.5rem; color: var(--accent); margin-bottom: 0.5rem; }
    .slide h2 { font-size: 1.8rem; color: var(--accent); margin-bottom: 1rem; }
    .slide .subtitle { font-size: 1.2rem; color: var(--muted); margin-bottom: 2rem; }
    .slide .content { font-size: 1.1rem; line-height: 1.8; flex: 1; }
    .slide .content pre { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 1rem; overflow-x: auto; margin: 1rem 0; }
    .slide .image-placeholder { background: var(--surface); border: 2px dashed var(--border); border-radius: 12px; padding: 2rem; text-align: center; color: var(--muted); margin: 1rem 0; }
    .slide .image-placeholder .icon { font-size: 3rem; margin-bottom: 0.5rem; }
    .slide .speaker-notes { background: var(--surface); border-top: 1px solid var(--border); padding: 1rem; font-size: 0.85rem; color: var(--muted); display: none; }
    .slide .speaker-notes.visible { display: block; }
    .slide.split-left { flex-direction: row; gap: 2rem; }
    .slide.split-left .text-col { flex: 1.4; }
    .slide.split-left .visual-col { flex: 1; display: flex; align-items: center; }
    .slide.split-right { flex-direction: row; gap: 2rem; }
    .slide.split-right .text-col { flex: 1; display: flex; flex-direction: column; justify-content: center; }
    .slide.split-right .visual-col { flex: 1.4; }
    .slide.centered { justify-content: center; align-items: center; text-align: center; }
    .slide.image-focus .visual-col { flex: 2; }
    .slide.image-focus .text-col { flex: 1; }
    .controls { padding: 0.5rem 2rem; background: var(--surface); border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
    .btn { background: var(--accent); color: white; border: none; padding: 0.5rem 1.5rem; border-radius: 8px; cursor: pointer; font-size: 0.9rem; }
    .btn:disabled { opacity: 0.3; cursor: not-allowed; }
    .counter { color: var(--muted); font-size: 0.85rem; }
    .interactive-badge { background: rgba(59,130,246,0.2); color: var(--accent); padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.75rem; margin: 0.2rem; }
    .theme-btn { position: fixed; top: 1rem; right: 1rem; background: var(--accent); color: white; border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 1.2rem; z-index: 100; }
    .notes-btn { position: fixed; top: 1rem; right: 4rem; background: var(--surface); color: var(--text); border: 1px solid var(--border); border-radius: 8px; padding: 0.4rem 0.8rem; cursor: pointer; font-size: 0.85rem; z-index: 100; }
    .mermaid { background: var(--surface); border-radius: 8px; padding: 1rem; }
    @media (max-width: 768px) { .slide { padding: 1.5rem; } .slide.split-left, .slide.split-right { flex-direction: column; } .slide h1 { font-size: 1.8rem; } }
    @media print { .slide { position: relative; page-break-after: always; display: flex !important; } .controls, .theme-btn, .notes-btn { display: none; } }
  </style>
</head>
<body>
  <button class="theme-btn" onclick="toggleTheme()">🌓</button>
  <button class="notes-btn" onclick="toggleNotes()">📝 Notes</button>
  <div class="slide-deck">
    <div class="progress-bar"><div class="progress-fill" id="progress" style="width: 0%"></div></div>
    <div class="slide-container" id="container">
      ${slidesHtml}
    </div>
    <div class="controls">
      <button class="btn" id="prev" onclick="prev()" disabled>← Prev</button>
      <span class="counter" id="counter">1 / ${storyboard.totalSlides}</span>
      <button class="btn" id="next" onclick="next()">Next →</button>
    </div>
  </div>
  <script>
    if (typeof mermaid !== 'undefined') mermaid.initialize({ startOnLoad: true, theme: 'dark' });
    var current = 0; var total = ${storyboard.totalSlides};
    function show(i) {
      document.querySelectorAll('.slide').forEach(function(s) { s.classList.remove('active'); });
      var slide = document.getElementById('slide-' + i);
      if (slide) slide.classList.add('active');
      current = i;
      document.getElementById('prev').disabled = i === 0;
      document.getElementById('next').disabled = i === total - 1;
      document.getElementById('counter').textContent = (i + 1) + ' / ' + total;
      document.getElementById('progress').style.width = ((i + 1) / total * 100) + '%';
    }
    function next() { if (current < total - 1) show(current + 1); }
    function prev() { if (current > 0) show(current - 1); }
    document.addEventListener('keydown', function(e) {
      if (e.key === 'ArrowRight' || e.key === ' ') next();
      if (e.key === 'ArrowLeft') prev();
    });
    function toggleTheme() {
      var cur = document.documentElement.getAttribute('data-theme');
      document.documentElement.setAttribute('data-theme', cur === 'light' ? '' : 'light');
      localStorage.setItem('slide-theme', cur === 'light' ? '' : 'light');
      if (typeof mermaid !== 'undefined') mermaid.initialize({ startOnLoad: false, theme: cur === 'light' ? 'dark' : 'default' });
    }
    function toggleNotes() { document.querySelectorAll('.speaker-notes').forEach(function(n) { n.classList.toggle('visible'); }); }
    var saved = localStorage.getItem('slide-theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
    show(0);
  </script>
</body>
</html>`
  }

  private buildSlide(slide: StoryboardSlide): string {
    const imageHtml = slide.imagePrompt
      ? `<div class="image-placeholder"><div class="icon">🖼️</div><p>${this.escape(slide.imagePrompt)}</p></div>`
      : ''
    const mermaidHtml = slide.mermaidDiagram
      ? `<div class="mermaid">${slide.mermaidDiagram}</div>`
      : ''
    const interactiveHtml = slide.interactiveElements.length > 0
      ? `<div>${slide.interactiveElements.map(e => `<span class="interactive-badge">${e}</span>`).join('')}</div>`
      : ''

    const visualCol = imageHtml || mermaidHtml
      ? `<div class="visual-col">${imageHtml}${mermaidHtml}</div>`
      : ''
    const textCol = `<div class="text-col"><h1>${this.escape(slide.title)}</h1><div class="subtitle">${this.escape(slide.subtitle)}</div><div class="content">${this.markdownToHtml(slide.content)}</div>${interactiveHtml}</div>`

    const inner = slide.layout === 'split-left'
      ? `${textCol}${visualCol}`
      : slide.layout === 'split-right'
      ? `${visualCol}${textCol}`
      : slide.layout === 'centered'
      ? `${textCol}${visualCol}`
      : `${textCol}${visualCol}`

    return `<div class="slide ${slide.layout}" id="slide-${slide.index}">${inner}<div class="speaker-notes">📝 ${this.escape(slide.speakerNotes)}</div></div>`
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }

  private markdownToHtml(md: string): string {
    return md
      .replace(/^# (.+)$/gm, '<h2>$1</h2>')
      .replace(/^## (.+)$/gm, '<h3>$1</h3>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>\n?)+/g, m => `<ul>${m}</ul>`)
      .replace(/\n\n/g, '</p><p>')
      .replace(/^(?!<[hupol])(.+)$/gm, '<p>$1</p>')
  }
}
