// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Artifact Registry (lineage tracking)
// =============================================================================
// Tracks artifact lineage on top of an `IArtifactStorage`. Wraps the storage
// with convenience methods for walking the provenance graph:
//   - get / getLineage / getChildren / listByExecution — pass-through
//   - getParent(id)         — load the parent artifact (if any)
//   - getFullLineage(id)    — walk UP the parent chain, return all ancestors
//   - linkChild(parentId, childId) — update parent's lineage.children array
//
// All reads return deep clones (delegated to the storage implementation).
//
// Sprint 13+14 spec requirements covered:
//   - Provenance graph queries (regenerate-from-prompt, "what produced this")
//   - Two-way lineage: parent links down (children) AND child links up (parent)
// =============================================================================

import type {
  WorkflowArtifact,
  ArtifactLineage,
} from '@/lib/runtime/contracts/workflow'
import type { IArtifactStorage } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Registry that tracks artifact lineage on top of an `IArtifactStorage`.
 * The registry owns NO state of its own — every read / write is delegated
 * to the injected storage. This keeps the storage contract authoritative
 * while the registry provides higher-level provenance queries.
 */
export class ArtifactRegistry {
  /**
   * @param storage Backing storage. The registry delegates all CRUD to it.
   */
  constructor(private readonly storage: IArtifactStorage) {}

  /**
   * Persist an artifact and log the registration.
   */
  async register(artifact: WorkflowArtifact): Promise<void> {
    await this.storage.save(artifact)
    logger.info(
      {
        artifactId: artifact.id,
        executionId: artifact.executionId,
        stepId: artifact.stepId,
        type: artifact.type,
        parentArtifact: artifact.lineage.parentArtifact ?? null,
      },
      'ArtifactRegistry: artifact registered',
    )
  }

  /** Load an artifact by id, or null if not found. */
  async get(id: string): Promise<WorkflowArtifact | null> {
    return this.storage.load(id)
  }

  /** Return the provenance graph for an artifact, or null if not found. */
  async getLineage(id: string): Promise<ArtifactLineage | null> {
    return this.storage.getLineage(id)
  }

  /**
   * Find all artifacts whose `lineage.parentArtifact === id`.
   * Delegates to `storage.getChildren` when available; falls back to
   * scanning `listByExecution(parent.lineage.workflowExecution)` for older
   * storage implementations.
   */
  async getChildren(id: string): Promise<WorkflowArtifact[]> {
    if (typeof (this.storage as { getChildren?: unknown }).getChildren === 'function') {
      return (
        this.storage as unknown as {
          getChildren: (id: string) => Promise<WorkflowArtifact[]>
        }
      ).getChildren(id)
    }
    // Fallback: load the parent, then scan its execution for children.
    const parent = await this.storage.load(id)
    if (!parent) return []
    const all = await this.storage.listByExecution(parent.executionId)
    return all.filter((a) => a.lineage.parentArtifact === id)
  }

  /**
   * Load the parent artifact (via `lineage.parentArtifact`), or null if
   * this artifact has no parent or the parent id is unknown to the storage.
   */
  async getParent(id: string): Promise<WorkflowArtifact | null> {
    const lineage = await this.storage.getLineage(id)
    if (!lineage || lineage.parentArtifact === undefined) return null
    return this.storage.load(lineage.parentArtifact)
  }

  /**
   * Walk UP the parent chain from `id`, returning every ancestor in order
   * (immediate parent first, then grandparent, ...). Stops at the root or
   * when a parent id cannot be resolved by storage (broken link).
   *
   * The starting artifact itself is NOT included in the result.
   */
  async getFullLineage(id: string): Promise<WorkflowArtifact[]> {
    const out: WorkflowArtifact[] = []
    const visited = new Set<string>()
    let currentId: string | undefined = id
    while (true) {
      if (currentId === undefined) break
      if (visited.has(currentId)) {
        // Cycle guard — should not happen with well-formed lineage, but
        // never trust a graph walk without a visited set.
        logger.warn(
          { startId: id, cycleAt: currentId },
          'ArtifactRegistry.getFullLineage: cycle detected; stopping walk',
        )
        break
      }
      visited.add(currentId)
      const lineage = await this.storage.getLineage(currentId)
      if (!lineage || lineage.parentArtifact === undefined) break
      const parent = await this.storage.load(lineage.parentArtifact)
      if (!parent) {
        logger.warn(
          { startId: id, missingParent: lineage.parentArtifact },
          'ArtifactRegistry.getFullLineage: parent not found; stopping walk',
        )
        break
      }
      out.push(parent)
      currentId = parent.id
    }
    return out
  }

  /**
   * Bidirectionally link a child to a parent. The child's
   * `lineage.parentArtifact` is expected to already reference the parent
   * (callers typically set it at creation time). This method updates the
   * PARENT's `lineage.children` array to include the child id, keeping
   * the two directions of the provenance graph in sync.
   *
   * Idempotent: if the child id is already in the parent's children list,
   * the parent is not re-saved.
   */
  async linkChild(parentId: string, childId: string): Promise<void> {
    const parent = await this.storage.load(parentId)
    if (!parent) {
      logger.warn(
        { parentId, childId },
        'ArtifactRegistry.linkChild: parent not found',
      )
      return
    }
    if (parent.lineage.children.includes(childId)) {
      // Already linked — nothing to do.
      return
    }
    parent.lineage.children = [...parent.lineage.children, childId]
    await this.storage.save(parent)
    logger.debug(
      { parentId, childId },
      'ArtifactRegistry.linkChild: parent.children updated',
    )
  }

  /** List all artifacts produced by an execution. */
  async listByExecution(
    executionId: string,
  ): Promise<WorkflowArtifact[]> {
    return this.storage.listByExecution(executionId)
  }
}
