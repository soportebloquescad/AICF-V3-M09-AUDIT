// =============================================================================
// AICF V3 — Sprint 3: Middleware Tests
// =============================================================================
// Tests the runtime middleware layer:
//   - CorrelationId: ensureRequestId / ensureCorrelationId
//   - Metrics: createEmptyMetrics / createMetricsCollector
//   - Context: buildContext (creates RuntimeContext with tracing IDs)
//
// Verifies that every RuntimeRequest gets a correlationId and requestId,
// that metrics are recorded per stage, and that the context carries the
// tracing context through the pipeline.
// =============================================================================
import { describe, it, expect } from 'bun:test'
import {
  ensureRequestId,
  ensureCorrelationId,
  ensureTracingIds,
  createCorrelationId,
  createRequestId,
  extractCorrelationIdFromHeaders,
  CORRELATION_ID_HEADER,
  REQUEST_ID_HEADER,
} from '../CorrelationId'
import { createEmptyMetrics, createMetricsCollector } from '../Metrics'
import { buildContext } from '../RuntimeContextMiddleware'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'

describe('CorrelationId Middleware', () => {
  it('ensureRequestId generates a requestId when missing', () => {
    const request: RuntimeRequest = {
      requestId: '',
      correlationId: '',
      operation: 'chat',
      model: 'test-model',
      messages: [{ role: 'user', content: 'hi' }],
    }

    const id = ensureRequestId(request)
    expect(id).toBeTruthy()
    expect(id).toMatch(/^req-/)
    expect(request.requestId).toBe(id)
  })

  it('ensureRequestId preserves an existing requestId', () => {
    const request: RuntimeRequest = {
      requestId: 'req-existing-123',
      correlationId: '',
      operation: 'chat',
    }

    const id = ensureRequestId(request)
    expect(id).toBe('req-existing-123')
    expect(request.requestId).toBe('req-existing-123')
  })

  it('ensureCorrelationId generates a distinct corr- ID when correlationId is missing', () => {
    // Sprint 4: correlationId is now distinct from requestId.
    // Previously it defaulted to requestId; now it generates corr-{ts}-{rand}.
    const request: RuntimeRequest = {
      requestId: 'req-abc-456',
      correlationId: '',
      operation: 'chat',
    }

    const corrId = ensureCorrelationId(request)
    expect(corrId).toBeTruthy()
    expect(corrId).toMatch(/^corr-/)
    expect(corrId).not.toBe('req-abc-456')
    expect(request.correlationId).toBe(corrId)
  })

  it('ensureCorrelationId preserves an existing correlationId', () => {
    const request: RuntimeRequest = {
      requestId: 'req-1',
      correlationId: 'corr-custom-789',
      operation: 'chat',
    }

    const corrId = ensureCorrelationId(request)
    expect(corrId).toBe('corr-custom-789')
    expect(request.correlationId).toBe('corr-custom-789')
  })

  it('every request gets a unique requestId', () => {
    const ids = new Set<string>()
    for (let i = 0; i < 100; i++) {
      const req: RuntimeRequest = { requestId: '', correlationId: '', operation: 'chat' }
      ids.add(ensureRequestId(req))
    }
    expect(ids.size).toBe(100)
  })

  // --- Sprint 4: new CorrelationId features ---

  it('createCorrelationId generates a corr-{timestamp}-{random} format ID', () => {
    const id = createCorrelationId()
    expect(id).toMatch(/^corr-[a-z0-9]+-[a-z0-9]+$/)
  })

  it('createRequestId generates a req-{timestamp}-{random} format ID', () => {
    const id = createRequestId()
    expect(id).toMatch(/^req-[a-z0-9]+-[a-z0-9]+$/)
  })

  it('createCorrelationId generates unique IDs', () => {
    const ids = new Set<string>()
    for (let i = 0; i < 100; i++) {
      ids.add(createCorrelationId())
    }
    expect(ids.size).toBe(100)
  })

  it('createRequestId generates unique IDs', () => {
    const ids = new Set<string>()
    for (let i = 0; i < 100; i++) {
      ids.add(createRequestId())
    }
    expect(ids.size).toBe(100)
  })

  it('CORRELATION_ID_HEADER is "x-correlation-id"', () => {
    expect(CORRELATION_ID_HEADER).toBe('x-correlation-id')
  })

  it('REQUEST_ID_HEADER is "x-request-id"', () => {
    expect(REQUEST_ID_HEADER).toBe('x-request-id')
  })

  it('extractCorrelationIdFromHeaders reads X-Correlation-Id from Headers object', () => {
    const headers = new Headers({ 'x-correlation-id': 'corr-from-header-123' })
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('corr-from-header-123')
  })

  it('extractCorrelationIdFromHeaders falls back to X-Request-Id when X-Correlation-Id is absent', () => {
    const headers = new Headers({ 'x-request-id': 'req-from-header-456' })
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('req-from-header-456')
  })

  it('extractCorrelationIdFromHeaders prefers X-Correlation-Id over X-Request-Id', () => {
    const headers = new Headers({
      'x-correlation-id': 'corr-priority',
      'x-request-id': 'req-secondary',
    })
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('corr-priority')
  })

  it('extractCorrelationIdFromHeaders returns null when neither header is present', () => {
    const headers = new Headers({})
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBeNull()
  })

  it('extractCorrelationIdFromHeaders returns null for undefined input', () => {
    const id = extractCorrelationIdFromHeaders(undefined)
    expect(id).toBeNull()
  })

  it('extractCorrelationIdFromHeaders reads from a plain record object (case-insensitive)', () => {
    const headers = { 'X-Correlation-Id': 'corr-from-record-789' }
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('corr-from-record-789')
  })

  it('extractCorrelationIdFromHeaders reads from a plain record object with X-Request-Id fallback', () => {
    const headers = { 'X-Request-Id': 'req-from-record-012' }
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('req-from-record-012')
  })

  it('extractCorrelationIdFromHeaders handles array header values', () => {
    const headers = { 'x-correlation-id': ['corr-array-1', 'corr-array-2'] }
    const id = extractCorrelationIdFromHeaders(headers)
    expect(id).toBe('corr-array-1')
  })

  it('extractCorrelationIdFromHeaders returns null for empty record object', () => {
    const id = extractCorrelationIdFromHeaders({})
    expect(id).toBeNull()
  })

  it('ensureTracingIds fills in both requestId and correlationId when both are missing', () => {
    const request: RuntimeRequest = { requestId: '', correlationId: '', operation: 'chat' }
    const result = ensureTracingIds(request)
    expect(result.requestId).toMatch(/^req-/)
    expect(result.correlationId).toMatch(/^corr-/)
    expect(result.requestId).not.toBe(result.correlationId)
  })

  it('ensureTracingIds preserves existing requestId and correlationId', () => {
    const request: RuntimeRequest = {
      requestId: 'req-existing',
      correlationId: 'corr-existing',
      operation: 'chat',
    }
    const result = ensureTracingIds(request)
    expect(result.requestId).toBe('req-existing')
    expect(result.correlationId).toBe('corr-existing')
  })

  it('ensureTracingIds fills only correlationId when requestId is present', () => {
    const request: RuntimeRequest = {
      requestId: 'req-present-123',
      correlationId: '',
      operation: 'chat',
    }
    const result = ensureTracingIds(request)
    expect(result.requestId).toBe('req-present-123')
    expect(result.correlationId).toMatch(/^corr-/)
  })
})

describe('Metrics Middleware', () => {
  it('createEmptyMetrics returns a metrics object with zeroed fields', () => {
    const metrics = createEmptyMetrics()
    expect(metrics.latencyMs).toBe(0)
    expect(metrics.tokensPrompt).toBe(0)
    expect(metrics.tokensCompletion).toBe(0)
    expect(metrics.tokensTotal).toBe(0)
    expect(metrics.provider).toBeNull()
    expect(metrics.model).toBeNull()
    expect(metrics.cost).toBe(0)
    expect(metrics.estimatedCost).toBe(0)
    expect(metrics.cacheHit).toBe(false)
    expect(metrics.retryCount).toBe(0)
  })

  it('createMetricsCollector records and retrieves per-stage durations', () => {
    const collector = createMetricsCollector()
    collector.record('Validate', 5)
    collector.record('Execution', 120)
    collector.record('PostProcessing', 8)

    expect(collector.get('Validate')).toBe(5)
    expect(collector.get('Execution')).toBe(120)
    expect(collector.get('PostProcessing')).toBe(8)
  })

  it('createMetricsCollector get() returns undefined for unknown stages', () => {
    const collector = createMetricsCollector()
    expect(collector.get('Nonexistent')).toBeUndefined()
  })

  it('createMetricsCollector getAll() returns all recorded stages', () => {
    const collector = createMetricsCollector()
    collector.record('Validate', 5)
    collector.record('Execution', 120)

    const all = collector.getAll()
    expect(Object.keys(all).length).toBe(2)
    expect(all.Validate).toBe(5)
    expect(all.Execution).toBe(120)
  })

  it('createMetricsCollector overwrites on re-record', () => {
    const collector = createMetricsCollector()
    collector.record('Validate', 5)
    collector.record('Validate', 15)

    expect(collector.get('Validate')).toBe(15)
  })
})

describe('Context Middleware (buildContext)', () => {
  it('buildContext ensures requestId and correlationId are present', () => {
    const request = createRuntimeRequest({ operation: 'chat', model: 'test-model' })
    // Clear them to test the middleware fills them in
    request.requestId = ''
    request.correlationId = ''

    const ctx = buildContext(request)

    expect(ctx.request.requestId).toBeTruthy()
    expect(ctx.request.requestId).toMatch(/^req-/)
    expect(ctx.request.correlationId).toBeTruthy()
    // Sprint 4: correlationId is now distinct from requestId (corr- format)
    expect(ctx.request.correlationId).toMatch(/^corr-/)
    expect(ctx.request.correlationId).not.toBe(ctx.request.requestId)
  })

  it('buildContext preserves existing requestId and correlationId', () => {
    const request = createRuntimeRequest({ operation: 'chat' })
    request.requestId = 'req-preserved'
    request.correlationId = 'corr-preserved'

    const ctx = buildContext(request)

    expect(ctx.request.requestId).toBe('req-preserved')
    expect(ctx.request.correlationId).toBe('corr-preserved')
  })

  it('buildContext creates a RuntimeContext with traceId', () => {
    const request = createRuntimeRequest({ operation: 'chat' })

    const ctx = buildContext(request)

    expect(ctx.traceId).toBeTruthy()
    expect(typeof ctx.traceId).toBe('string')
  })

  it('buildContext initializes response and metrics objects', () => {
    const request = createRuntimeRequest({ operation: 'chat' })

    const ctx = buildContext(request)

    expect(ctx.response).toBeDefined()
    expect(ctx.metrics).toBeDefined()
    expect(ctx.metrics.latencyMs).toBe(0)
  })

  it('buildContext carries the operation through the context', () => {
    const request = createRuntimeRequest({ operation: 'models' })

    const ctx = buildContext(request)

    expect(ctx.request.operation).toBe('models')
  })

  it('buildContext correlationId is stable across multiple calls (same request)', () => {
    const request = createRuntimeRequest({ operation: 'chat' })

    const ctx1 = buildContext(request)
    const corrId1 = ctx1.request.correlationId
    const ctx2 = buildContext(request)

    expect(ctx2.request.correlationId).toBe(corrId1)
  })
})
