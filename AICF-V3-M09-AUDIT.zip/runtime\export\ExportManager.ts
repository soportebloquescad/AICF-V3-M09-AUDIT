// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure + Sprint 10 + 11B + 11C — ExportManager
// =============================================================================
// The ExportManager produces final export artifacts (ZIP / JSON / Markdown /
// HTML / multi-format ZIP) from a CourseResult + its registered artifacts.
//
// Sprint 10 additions:
//   - exportHtml: generates premium interactive HTML slides
//   - exportMulti: builds a ZIP with ALL selected formats bundled
//   - Uses ZipBuilder for multi-format bundling
//   - Uses InteractiveHtmlEngine + SlideGenerator for premium slides
//
// Sprint 11B additions:
//   - exportPremiumBundle: coordinates ALL engines (CertificateEngine,
//     DownloadableEngine, LandingEngine, InteractiveHtmlEngine, MediaGenerator)
//     to produce a complete ZIP with every artifact.
//
// Sprint 11C: ExportFormat type now imported from canonical ExportFormat.ts.
//
// ZIP export uses the `archiver` library, producing a single Buffer that
// can be served as an HTTP response or stored on disk.
// =============================================================================

import { ZipArchive } from 'archiver'
import type { CourseResult } from '@/lib/runtime/course/CourseContracts'
import type { RegisteredArtifact } from '../artifacts/ArtifactRegistry'
import type { ThemePreset } from '../theme/ThemeCatalog'
import { InteractiveHtmlEngine } from '../presentation/InteractiveHtmlEngine'
import { SlideGenerator } from '../presentation/SlideGenerator'
import { CountryAdapter } from '../presentation/CountryAdapter'
import { ZipBuilder, type ZipEntry } from './ZipBuilder'
import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

/**
 * Supported export formats.
 * Sprint 11C: uses the canonical ExportFormat from ExportFormat.ts.
 */
export type { ExportFormat } from './ExportFormat'
import type { ExportFormat } from './ExportFormat'

/**
 * Result of an export operation.
 */
export interface ExportResult {
  courseId: string
  format: ExportFormat
  content: Buffer | string
  sizeBytes: number
  mimeType: string
  filename: string
}

/**
 * The ExportManager. Produces ZIP / JSON / Markdown / HTML exports from a
 * CourseResult + its registered artifacts.
 */
export class ExportManager {
  private readonly htmlEngine = new InteractiveHtmlEngine()
  private readonly slideGenerator = new SlideGenerator()
  private readonly countryAdapter = new CountryAdapter()
  private readonly zipBuilder = new ZipBuilder()

  async exportZip(
    courseId: string,
    courseResult: CourseResult,
    artifacts: RegisteredArtifact[],
    manifestJson?: string,
  ): Promise<ExportResult> {
    logger.info({ courseId, artifactCount: artifacts.length }, 'ExportManager: exportZip starting')

    const buffer = await new Promise<Buffer>((resolve, reject) => {
      const archive = new ZipArchive({ zlib: { level: 6 } })
      const chunks: Buffer[] = []
      archive.on('data', (chunk: Buffer) => chunks.push(chunk))
      archive.on('end', () => resolve(Buffer.concat(chunks)))
      archive.on('error', (err: Error) => reject(err))

      const manifestBody = manifestJson ?? JSON.stringify(
        { version: '1.0.0', generatedAt: new Date().toISOString(), courseId, title: courseResult.title, artifactCount: artifacts.length },
        null, 2,
      )
      archive.append(manifestBody, { name: `${courseId}/manifest.json` })

      const sanitizedCourse = this.sanitizeForJson(courseResult)
      archive.append(JSON.stringify(sanitizedCourse, null, 2), { name: `${courseId}/course.json` })

      for (const art of artifacts) {
        const name = `${courseId}/${art.name}`
        if (typeof art.content === 'string') {
          archive.append(art.content, { name })
        } else {
          archive.append(art.content, { name })
        }
      }
      archive.finalize()
    })

    const result: ExportResult = {
      courseId, format: 'zip', content: buffer,
      sizeBytes: buffer.byteLength, mimeType: 'application/zip', filename: `${courseId}.zip`,
    }
    logger.info({ courseId, zipSize: result.sizeBytes }, 'ExportManager: exportZip complete')
    return result
  }

  async exportJson(courseId: string, courseResult: CourseResult): Promise<ExportResult> {
    const sanitized = this.sanitizeForJson(courseResult)
    const content = JSON.stringify(sanitized, null, 2)
    const result: ExportResult = {
      courseId, format: 'json', content,
      sizeBytes: Buffer.byteLength(content, 'utf-8'),
      mimeType: 'application/json; charset=utf-8', filename: `${courseId}.json`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes }, 'ExportManager: exportJson complete')
    return result
  }

  async exportMarkdown(courseId: string, courseResult: CourseResult): Promise<ExportResult> {
    const lines: string[] = []
    lines.push(`# ${courseResult.title}`)
    lines.push('')
    lines.push(`> ${courseResult.description}`)
    lines.push('')
    lines.push(`- **Topic:** ${courseResult.topic}`)
    lines.push(`- **Audience:** ${courseResult.curriculum?.audience ?? 'general learners'}`)
    lines.push(`- **Level:** ${courseResult.curriculum?.level ?? 'intermediate'}`)
    lines.push(`- **Locale:** ${courseResult.curriculum?.locale ?? 'en-US'}`)
    lines.push(`- **Modules:** ${courseResult.modules.length}`)
    lines.push(`- **Lessons:** ${courseResult.lessons.length}`)
    lines.push(`- **Total words:** ${courseResult.lessons.reduce((s, l) => s + l.wordCount, 0)}`)
    lines.push('')
    for (const m of courseResult.modules) {
      lines.push(`## ${m.title}`)
      lines.push('')
      lines.push(m.summary)
      lines.push('')
      const moduleLessons = courseResult.lessons.filter((l) => l.moduleId === m.id)
      for (const lesson of moduleLessons) {
        lines.push(`### ${lesson.title}`)
        lines.push('')
        lines.push(lesson.content)
        lines.push('')
      }
    }
    const content = lines.join('\n')
    const result: ExportResult = {
      courseId, format: 'markdown', content,
      sizeBytes: Buffer.byteLength(content, 'utf-8'),
      mimeType: 'text/markdown; charset=utf-8', filename: `${courseId}.md`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes }, 'ExportManager: exportMarkdown complete')
    return result
  }

  async exportHtml(
    courseId: string,
    courseResult: CourseResult,
    theme: ThemePreset,
    locales: LocaleContext[],
    includeImages: boolean,
  ): Promise<ExportResult> {
    logger.info({ courseId, theme: theme.name, localeCount: locales.length }, 'ExportManager: exportHtml starting')

    const primaryLocale = locales[0] ?? locales[0]
    if (!primaryLocale) {
      throw new Error('ExportManager.exportHtml: no locales provided')
    }

    const slides = this.slideGenerator.generateSlides({
      title: courseResult.title,
      description: courseResult.description,
      moduleCount: courseResult.modules.length,
      theme,
      locale: primaryLocale,
      includeImages,
    })

    const html = this.htmlEngine.build({
      title: courseResult.title,
      slides,
      theme,
      countryName: primaryLocale.country.name,
    })

    const buffer = Buffer.from(html, 'utf8')
    const result: ExportResult = {
      courseId, format: 'html', content: buffer,
      sizeBytes: buffer.byteLength, mimeType: 'text/html',
      filename: `slides-${courseId}.html`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes }, 'ExportManager: exportHtml complete')
    return result
  }

  async exportMultiCountry(
    courseId: string,
    courseResult: CourseResult,
    theme: ThemePreset,
    locales: LocaleContext[],
    includeImages: boolean,
  ): Promise<ExportResult> {
    logger.info({ courseId, countryCount: locales.length }, 'ExportManager: exportMultiCountry starting')

    const countrySets = this.countryAdapter.adaptForCountries({
      title: courseResult.title,
      description: courseResult.description,
      moduleCount: courseResult.modules.length,
      theme,
      locales,
      includeImages,
    })

    const entries: ZipEntry[] = countrySets.map((set) => {
      const html = this.htmlEngine.build({
        title: courseResult.title,
        slides: set.slides,
        theme,
        countryName: set.countryName,
      })
      return { name: `slides-${set.countryCode}.html`, content: html }
    })

    entries.push({
      name: 'manifest.json',
      content: JSON.stringify({
        version: '1.0.0',
        courseId,
        title: courseResult.title,
        countries: countrySets.map((s) => ({ code: s.countryCode, name: s.countryName, slideCount: s.slides.length })),
        generatedAt: new Date().toISOString(),
      }, null, 2),
    })

    const buffer = await this.zipBuilder.build(entries, `${courseId}-multi-country`)
    const result: ExportResult = {
      courseId, format: 'zip', content: buffer,
      sizeBytes: buffer.byteLength, mimeType: 'application/zip',
      filename: `${courseId}-multi-country.zip`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes }, 'ExportManager: exportMultiCountry complete')
    return result
  }

  async exportAllFormats(
    courseId: string,
    courseResult: CourseResult,
    theme: ThemePreset,
    locales: LocaleContext[],
    formats: string[],
    includeImages: boolean,
  ): Promise<ExportResult> {
    logger.info({ courseId, formats, localeCount: locales.length }, 'ExportManager: exportAllFormats starting')

    const entries: ZipEntry[] = []

    for (const fmt of formats) {
      switch (fmt) {
        case 'markdown': {
          const md = await this.exportMarkdown(courseId, courseResult)
          entries.push({ name: `${courseId}.md`, content: md.content as string })
          break
        }
        case 'json': {
          const json = await this.exportJson(courseId, courseResult)
          entries.push({ name: `${courseId}.json`, content: json.content as string })
          break
        }
        case 'html':
        case 'slides-html': {
          if (locales.length > 1) {
            const countrySets = this.countryAdapter.adaptForCountries({
              title: courseResult.title,
              description: courseResult.description,
              moduleCount: courseResult.modules.length,
              theme, locales, includeImages,
            })
            for (const set of countrySets) {
              const html = this.htmlEngine.build({
                title: courseResult.title, slides: set.slides, theme, countryName: set.countryName,
              })
              entries.push({ name: `slides-${set.countryCode}.html`, content: html })
            }
          } else if (locales.length === 1) {
            const html = await this.exportHtml(courseId, courseResult, theme, locales, includeImages)
            entries.push({ name: `slides.html`, content: html.content as Buffer })
          }
          break
        }
        default:
          break
      }
    }

    entries.push({
      name: 'manifest.json',
      content: JSON.stringify({
        version: '1.0.0', courseId, title: courseResult.title,
        formats, localeCount: locales.length,
        countries: locales.map((l) => l.country.name),
        generatedAt: new Date().toISOString(),
      }, null, 2),
    })

    const buffer = await this.zipBuilder.build(entries, `${courseId}-all-formats`)
    const result: ExportResult = {
      courseId, format: 'zip', content: buffer,
      sizeBytes: buffer.byteLength, mimeType: 'application/zip',
      filename: `${courseId}-all-formats.zip`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes, entryCount: entries.length }, 'ExportManager: exportAllFormats complete')
    return result
  }

  async export(
    format: ExportFormat,
    courseId: string,
    courseResult: CourseResult,
    artifacts: RegisteredArtifact[] = [],
    manifestJson?: string,
  ): Promise<ExportResult> {
    switch (format) {
      case 'zip':
        return this.exportZip(courseId, courseResult, artifacts, manifestJson)
      case 'json':
        return this.exportJson(courseId, courseResult)
      case 'markdown':
        return this.exportMarkdown(courseId, courseResult)
      case 'html':
      case 'slides-html':
        throw new Error('ExportManager: html format requires theme + locales — use exportHtml() or exportAllFormats()')
      case 'docx':
        throw new Error('ExportManager: docx format not implemented — use the legacy ExportDOCX')
      default:
        throw new Error(`ExportManager: unsupported format "${format}"`)
    }
  }

  private sanitizeForJson(courseResult: CourseResult): Record<string, unknown> {
    return JSON.parse(
      JSON.stringify(courseResult, (_key, value) => {
        if (value instanceof Buffer) {
          return { __buffer: true, length: value.byteLength }
        }
        return value
      }),
    ) as Record<string, unknown>
  }

  // ===========================================================================
  // Sprint 11B — Premium bundle export
  // ===========================================================================
  // Coordinates ALL engines to produce a complete ZIP with every artifact.
  // ExportManager ONLY orchestrates — each artifact is delegated to its
  // dedicated engine (CertificateEngine, DownloadableEngine, LandingEngine,
  // InteractiveHtmlEngine, MediaGenerator).
  // ===========================================================================

  async exportPremiumBundle(opts: {
    courseId: string
    title: string
    description: string
    moduleCount: number
    price: number
    currency: string
    studentName: string
    instructorName?: string
    theme: ThemePreset
    locales: LocaleContext[]
    includeImages: boolean
    includeExercises: boolean
    includeLabs: boolean
    includeCertificate: boolean
    includeDownloadable: boolean
  }): Promise<ExportResult> {
    const {
      courseId, title, description, moduleCount, price, currency,
      studentName, instructorName, theme, locales, includeImages,
      includeExercises, includeCertificate, includeDownloadable,
    } = opts

    logger.info({ courseId, title, localeCount: locales.length }, 'ExportManager: exportPremiumBundle starting')

    const entries: ZipEntry[] = []

    // 1. slides.html — delegate to InteractiveHtmlEngine
    const primaryLocale = locales[0]
    if (primaryLocale) {
      const slides = await this.slideGenerator.generatePremiumSlides({
        title, description, topic: title, moduleIndex: 1, moduleCount,
        theme, locale: primaryLocale, includeImages,
      })
      const slidesHtml = this.htmlEngine.buildPremium({ title, slides, theme, countryName: primaryLocale.country.name })
      entries.push({ name: 'slides.html', content: slidesHtml })
    }

    // 2. Multi-country slides (if more than one locale)
    if (locales.length > 1) {
      const countrySets = this.countryAdapter.adaptForCountries({
        title, description, moduleCount, theme, locales, includeImages,
      })
      for (const set of countrySets) {
        const html = this.htmlEngine.build({ title, slides: set.slides, theme, countryName: set.countryName })
        entries.push({ name: `slides-${set.countryCode}.html`, content: html })
      }
    }

    // 3. Certificate — delegate to CertificateEngine
    if (includeCertificate) {
      const { CertificateEngine } = await import('../certificate/CertificateEngine')
      const certEngine = new CertificateEngine()
      const cert = certEngine.generate({
        studentName, courseTitle: title, instructorName, theme,
      })
      entries.push({ name: 'certificado.html', content: cert.html })
    }

    // 4. Landing page — delegate to LandingEngine
    if (primaryLocale) {
      const { LandingEngine } = await import('../marketing/LandingEngine')
      const landingEngine = new LandingEngine()
      const landing = landingEngine.generate({
        title, subtitle: description.slice(0, 80), description,
        moduleCount, price, currency, locale: primaryLocale, theme,
      })
      entries.push({ name: 'landing.html', content: landing.html })
    }

    // 5. Downloadable material — delegate to DownloadableEngine
    if (includeDownloadable && primaryLocale) {
      const { DownloadableEngine } = await import('./DownloadableEngine')
      const dlEngine = new DownloadableEngine()
      for (let m = 1; m <= moduleCount; m++) {
        const guide = dlEngine.generateStudyGuide({ topic: title, moduleIndex: m, locale: primaryLocale, theme })
        entries.push({ name: `guia-estudio-modulo-${m}.html`, content: guide.content })

        if (includeExercises) {
          const ex = dlEngine.generateExercises({ topic: title, moduleIndex: m, locale: primaryLocale, theme })
          entries.push({ name: `ejercicios-modulo-${m}.html`, content: ex.content })

          const sol = dlEngine.generateSolutions({ topic: title, moduleIndex: m, locale: primaryLocale, theme })
          entries.push({ name: `soluciones-modulo-${m}.html`, content: sol.content })
        }

        const cheat = dlEngine.generateCheatSheet({ topic: title, moduleIndex: m, locale: primaryLocale, theme })
        entries.push({ name: `cheat-sheet-modulo-${m}.html`, content: cheat.content })
      }
    }

    // 6. Assets — delegate to MediaGenerator (SVGs)
    if (includeImages && primaryLocale) {
      const { MediaGenerator } = await import('../media/MediaGenerator')
      const media = new MediaGenerator()
      entries.push({ name: 'assets/hero.svg', content: media.generateHero(title, theme) })
      entries.push({ name: 'assets/concept.svg', content: media.generateConcept(title, 1, theme) })
      entries.push({ name: 'assets/icon.svg', content: media.generateIcon(title, theme) })
      entries.push({ name: 'assets/infographic.svg', content: media.generateInfographic(primaryLocale, theme) })
    }

    // 7. Markdown + JSON (reuse existing methods)
    const minimalCourse = {
      id: courseId, topic: title, title, description, status: 'completed' as const,
      modules: [], lessons: [], exercises: [], quizzes: [], assessments: [],
      caseStudies: [], checklists: [], templates: [], presentation: null,
      guides: [], qualityReport: null, stages: [], zipBuffer: null, zipUrl: '',
      totalWordCount: 0, totalDurationMs: 0, totalCost: 0,
      curriculum: null,
    } as unknown as CourseResult

    const md = await this.exportMarkdown(courseId, minimalCourse)
    entries.push({ name: `${courseId}.md`, content: md.content as string })

    const json = await this.exportJson(courseId, minimalCourse)
    entries.push({ name: `${courseId}.json`, content: json.content as string })

    // 8. Manifest
    entries.push({
      name: 'manifest.json',
      content: JSON.stringify({
        version: '1.0.0', courseId, title, description,
        moduleCount, price, currency, studentName,
        localeCount: locales.length,
        countries: locales.map((l) => l.country.name),
        theme: theme.name,
        artifacts: entries.map((e) => e.name),
        generatedAt: new Date().toISOString(),
      }, null, 2),
    })

    const buffer = await this.zipBuilder.build(entries, `${courseId}-premium-bundle`)
    const result: ExportResult = {
      courseId, format: 'zip', content: buffer,
      sizeBytes: buffer.byteLength, mimeType: 'application/zip',
      filename: `${courseId}-premium-bundle.zip`,
    }
    logger.info({ courseId, sizeBytes: result.sizeBytes, entryCount: entries.length }, 'ExportManager: exportPremiumBundle complete')
    return result
  }
}

/**
 * Singleton ExportManager.
 */
let singleton: ExportManager | null = null

export function getExportManager(): ExportManager {
  if (!singleton) {
    singleton = new ExportManager()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetExportManager(): void {
  singleton = null
}