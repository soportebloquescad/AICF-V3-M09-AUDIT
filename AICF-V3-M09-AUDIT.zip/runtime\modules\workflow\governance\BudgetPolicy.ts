// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Budget Policy
// =============================================================================
// Enforces a GLOBAL budget across ALL executions. Total spend is read from
// the injected `MetricsCollector` (via `getAggregateMetrics().totalCost`).
//
// Sprint 13+14 spec requirements covered:
//   - name: 'budget-policy'
//   - Constructor takes budgetLimit + metricsCollector
//   - Denies when total spend across all executions exceeds budgetLimit
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import type { IPolicy, PolicyDecision } from '@/lib/runtime/modules/workflow/policies/PolicyMiddleware'
import type { MetricsCollector } from '@/lib/runtime/modules/workflow/metrics/MetricsCollector'

/**
 * Enforces a global budget across all executions. Implements `IPolicy`.
 *
 * The policy is intentionally simple: it compares the current aggregate
 * spend (across all executions observed by the metrics collector) against
 * the configured limit and denies any further step execution when the
 * limit is exceeded. Per-step cost is NOT projected — once the budget is
 * exceeded, all subsequent steps are denied until the budget is reset.
 */
export class BudgetPolicy implements IPolicy {
  readonly name = 'budget-policy'

  /**
   * @param budgetLimit       Total budget (platform currency units) across
   *                          all executions.
   * @param metricsCollector  Source of truth for current aggregate spend.
   */
  constructor(
    private readonly budgetLimit: number,
    private readonly metricsCollector: MetricsCollector,
  ) {}

  async check(
    _ctx: WorkflowContext,
    _step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const totalCost = this.metricsCollector.getAggregateMetrics().totalCost
    if (totalCost > this.budgetLimit) {
      return {
        allowed: false,
        violations: [
          `total spend (${totalCost}) exceeds budget limit (${this.budgetLimit})`,
        ],
        reason: 'global budget exceeded',
      }
    }
    return { allowed: true, violations: [] }
  }
}
