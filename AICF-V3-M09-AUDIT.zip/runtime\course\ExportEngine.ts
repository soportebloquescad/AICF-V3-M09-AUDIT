// =============================================================================
// AICF V3 — Épica 6 — Export Engine
// =============================================================================
import { HTMLExporter } from './exporters/HTMLExporter'
import { DOCXExporter } from './exporters/DOCXExporter'
import { PDFExporter } from './exporters/PDFExporter'
import { PPTXExporter } from './exporters/PPTXExporter'
import { SCORMExporter } from './exporters/SCORMExporter'
import { MoodleExporter } from './exporters/MoodleExporter'

export type ExportFormat = 'markdown' | 'html' | 'docx' | 'pdf' | 'pptx' | 'json' | 'scorm12' | 'scorm2004' | 'xapi' | 'moodle' | 'canvas'

export interface ExportResult {
  format: ExportFormat
  content: string
  mimeType: string
  sizeBytes: number
}

const MIME_TYPES: Record<ExportFormat, string> = {
  markdown: 'text/markdown',
  html: 'text/html',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pdf: 'application/pdf',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  json: 'application/json',
  scorm12: 'application/xml',
  scorm2004: 'application/xml',
  xapi: 'application/json',
  moodle: 'application/xml',
  canvas: 'application/json',
}

export class ExportEngine {
  private readonly htmlExporter = new HTMLExporter()
  private readonly docxExporter = new DOCXExporter()
  private readonly pdfExporter = new PDFExporter()
  private readonly pptxExporter = new PPTXExporter()
  private readonly scormExporter = new SCORMExporter()
  private readonly moodleExporter = new MoodleExporter()

  export(input: { content: string; format: ExportFormat; metadata?: Record<string, unknown> }): ExportResult {
    const { content, format, metadata } = input
    let exported: string

    switch (format) {
      case 'markdown': exported = content; break
      case 'html': exported = this.htmlExporter.export(content, metadata); break
      case 'docx': exported = this.docxExporter.export(content, metadata); break
      case 'pdf': exported = this.pdfExporter.export(content, metadata); break
      case 'pptx': exported = this.pptxExporter.export(content, metadata); break
      case 'json': exported = JSON.stringify({ content, metadata }, null, 2); break
      case 'scorm12': exported = this.scormExporter.export(content, metadata, '1.2'); break
      case 'scorm2004': exported = this.scormExporter.export(content, metadata, '2004'); break
      case 'xapi': exported = JSON.stringify({
        actor: { name: 'Course Student', mbox: 'mailto:student@example.com' },
        verb: { id: 'http://adlnet.gov/expapi/verbs/completed', display: { 'en-US': 'completed' } },
        object: { id: 'http://aicf.example.com/course', definition: { name: { 'en-US': metadata?.title ?? 'Course' } } },
        result: { success: true, completion: true },
        timestamp: new Date().toISOString(),
      }, null, 2); break
      case 'moodle': exported = this.moodleExporter.export(content, metadata); break
      case 'canvas': exported = JSON.stringify({
        course: { title: metadata?.title ?? 'Course', content, format: 'markdown' },
        modules: [],
        assignments: [],
        quizzes: [],
      }, null, 2); break
    }

    return {
      format,
      content: exported,
      mimeType: MIME_TYPES[format],
      sizeBytes: Buffer.byteLength(exported, 'utf-8'),
    }
  }

  exportAll(input: { content: string; metadata?: Record<string, unknown> }): ExportResult[] {
    const formats: ExportFormat[] = ['markdown', 'html', 'docx', 'pdf', 'pptx', 'json', 'scorm12', 'scorm2004', 'xapi', 'moodle', 'canvas']
    return formats.map((format) => this.export({ ...input, format }))
  }
}


