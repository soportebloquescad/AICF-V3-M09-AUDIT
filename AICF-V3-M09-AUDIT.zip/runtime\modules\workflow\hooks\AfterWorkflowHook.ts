// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — After-Workflow Hook
// =============================================================================
// Re-exports `HookRegistry` and `FatalHookError` from `BeforeWorkflowHook`
// (single source of truth) and defines the `AfterWorkflowHook` interface.
// =============================================================================

export type { AfterWorkflowHook } from './BeforeWorkflowHook'
export { HookRegistry, FatalHookError } from './BeforeWorkflowHook'
