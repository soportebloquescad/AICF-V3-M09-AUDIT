// =============================================================================
// AICF V3 — Sprint 10 — Country Catalog (data-driven locale engine)
// =============================================================================
export interface CountryCurrency { code: string; symbol: string; formatLocale: string }

export interface CountryEntry {
  code: string
  name: string
  nameEn: string
  language: string
  region: 'LATAM' | 'NORTH_AMERICA' | 'EUROPE' | 'ASIA' | 'AFRICA' | 'OCEANIA' | 'GLOBAL'
  currency: CountryCurrency
  culturalAdaptation: string[]
  legislation: Array<{ name: string; reference: string; topic: string }>
  companies: string[]
  terminology: Record<string, string>
  realCases: string[]
  examples: string[]
  exercises: string[]
  datasets: Array<{ name: string; url: string; description: string }>
  statistics: Array<{ metric: string; value: string; year: string; source: string }>
  references: Array<{ title: string; url: string; publisher: string }>
}

export const COUNTRY_CATALOG: CountryEntry[] = [
  {
    code: 'pe', name: 'Perú', nameEn: 'Peru', language: 'es-PE', region: 'LATAM',
    currency: { code: 'PEN', symbol: 'S/', formatLocale: 'es-PE' },
    culturalAdaptation: ['Trato de "tú" o "usted" según contexto.', 'Sectores: minería, agroexportación, gastronomía, fintech.'],
    legislation: [
      { name: 'Ley N° 29733 — Protección de Datos Personales', reference: 'https://www.datospersonales.gob.pe', topic: 'data-protection' },
      { name: 'Ley N° 27444 — Procedimiento Administrativo General', reference: 'https://www.gob.pe', topic: 'administrative-law' },
    ],
    companies: ['Credicorp', 'Alicorp', 'Buenaventura', 'Ferreyros', 'AJE Group', 'Inka Moss'],
    terminology: { computer: 'computadora', mobile: 'celular', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['Yape y Plin: inclusión financiera móvil.', 'Rappi: logística urbana en Lima.', 'Cementos Pacasmayo: digitalización industrial.'],
    examples: ['Startup limeña procesa 50K transacciones/día con Yape.', 'Cooperativa agraria en Ica exporta espárragos vía ERP cloud.'],
    exercises: ['Diseñe flujo de pagos QR interoperable Yape↔Plin.', 'Calcule ROI de campaña digital para marca en Lima.'],
    datasets: [
      { name: 'INEI', url: 'https://www.inei.gob.pe', description: 'Datos demográficos y económicos del Perú.' },
      { name: 'Datos Abiertos Perú', url: 'https://www.datosabiertos.gob.pe', description: 'Datasets abiertos del Estado.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '71%', year: '2024', source: 'INEI' },
      { metric: 'Penetración smartphone', value: '68%', year: '2024', source: 'INEI' },
      { metric: 'Inflación anual', value: '2.4%', year: '2024', source: 'BCRP' },
    ],
    references: [{ title: 'INEI', url: 'https://www.inei.gob.pe', publisher: 'Gobierno del Perú' }],
  },
  {
    code: 'mx', name: 'México', nameEn: 'Mexico', language: 'es-MX', region: 'LATAM',
    currency: { code: 'MXN', symbol: '$', formatLocale: 'es-MX' },
    culturalAdaptation: ['Trato de "tú" informal, "usted" formal.', 'Sectores: manufactura automotriz, fintech, nearshoring, retail.'],
    legislation: [
      { name: 'LFPDPPP — Protección de Datos', reference: 'https://home.inai.org.mx', topic: 'data-protection' },
      { name: 'Ley Federal del Trabajo', reference: 'https://www.dof.gob.mx', topic: 'labor-law' },
    ],
    companies: ['Cemex', 'Banorte', 'Grupo Bimbo', 'América Móvil', 'FEMSA', 'Grupo Modelo', 'Kavak'],
    terminology: { computer: 'computadora', mobile: 'celular', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['BBVA México: banca digital BBVA Wallet.', 'Nearshoring norte de México: plantas manufactureras.', 'Kavak: retail automotriz digital.'],
    examples: ['Fintech CDMX procesa 1M transacciones con CoDi.', 'Retail Monterrey usa SAP S/4HANA para 200 sucursales.'],
    exercises: ['Diseñe arquitectura app banca móvil compatible con CoDi.', 'Calcule tasa adopción marketplace B2B en CDMX.'],
    datasets: [
      { name: 'INEGI', url: 'https://www.inegi.org.mx', description: 'Estadística y Geografía.' },
      { name: 'Datos Abiertos México', url: 'https://datos.gob.mx', description: 'Portal de datos abiertos.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '75%', year: '2024', source: 'INEGI' },
      { metric: 'Penetración smartphone', value: '74%', year: '2024', source: 'INEGI' },
      { metric: 'Inflación anual', value: '4.7%', year: '2024', source: 'Banxico' },
    ],
    references: [{ title: 'INEGI', url: 'https://www.inegi.org.mx', publisher: 'Gobierno de México' }],
  },
  {
    code: 'ar', name: 'Argentina', nameEn: 'Argentina', language: 'es-AR', region: 'LATAM',
    currency: { code: 'ARS', symbol: '$', formatLocale: 'es-AR' },
    culturalAdaptation: ['Trato de "vos" (voseo rioplatense).', 'Sectores: agroindustria, software, fintech, turismo.'],
    legislation: [
      { name: 'Ley 25.326 — Protección de Datos', reference: 'https://www.argentina.gob.ar/aaip', topic: 'data-protection' },
      { name: 'Ley de Contrato de Trabajo 20.744', reference: 'https://www.argentina.gob.ar', topic: 'labor-law' },
    ],
    companies: ['Mercado Libre', 'Globant', 'YPF', 'Banco Galicia', 'Techint', 'Arcor', 'Ualá'],
    terminology: { computer: 'computadora', mobile: 'celular', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['Mercado Pago: inclusión financiera.', 'Globant: software nearshore Fortune 500.', 'Ualá: disrupción banca digital.'],
    examples: ['Fintech BA usa IA para credit scoring 200K usuarios.', 'Bodega Mendoza exporta vinos vía marketplace propio.'],
    exercises: ['Diseñe scoring crediticio para usuarios sin historial bancario.', 'Modele logística e-commerce CABA y GBA.'],
    datasets: [
      { name: 'INDEC', url: 'https://www.indec.gob.ar', description: 'Estadística y Censos.' },
      { name: 'Datos Abiertos Argentina', url: 'https://datos.gob.ar', description: 'Portal de datos abiertos.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '87%', year: '2024', source: 'INDEC' },
      { metric: 'Penetración smartphone', value: '82%', year: '2024', source: 'INDEC' },
    ],
    references: [{ title: 'INDEC', url: 'https://www.indec.gob.ar', publisher: 'Gobierno de Argentina' }],
  },
  {
    code: 'cl', name: 'Chile', nameEn: 'Chile', language: 'es-CL', region: 'LATAM',
    currency: { code: 'CLP', symbol: '$', formatLocale: 'es-CL' },
    culturalAdaptation: ['Trato de "tú". Formalidad moderada.', 'Sectores: minería cobre, retail, fintech, salmonicultura.'],
    legislation: [
      { name: 'Ley 19.628 — Protección de Datos', reference: 'https://www.consejotransparencia.cl', topic: 'data-protection' },
      { name: 'Código del Trabajo', reference: 'https://www.dt.gob.cl', topic: 'labor-law' },
    ],
    companies: ['Codelco', 'Banco de Chile', 'Falabella', 'Banco Santander Chile', 'CCU', 'Cencosud'],
    terminology: { computer: 'computador', mobile: 'celular', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['Codelco: digitalización minería del cobre.', 'Banco de Chile: banca digital multicliente.', 'Falabella: omnicanalidad retail.'],
    examples: ['Minera Antofagasta usa IoT para 5000 sensores tiempo real.', 'Fintech Santiago lanza wallet 300K usuarios en 6 meses.'],
    exercises: ['Diseñe red IoT para mina cobre latencia < 100ms.', 'Modele data lake cadena retail 100 sucursales.'],
    datasets: [
      { name: 'INE Chile', url: 'https://www.ine.gob.cl', description: 'Estadísticas.' },
      { name: 'Datos Abiertos Chile', url: 'https://datos.gob.cl', description: 'Portal de datos.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '90%', year: '2024', source: 'INE' },
      { metric: 'Penetración smartphone', value: '85%', year: '2024', source: 'INE' },
    ],
    references: [{ title: 'INE Chile', url: 'https://www.ine.gob.cl', publisher: 'Gobierno de Chile' }],
  },
  {
    code: 'co', name: 'Colombia', nameEn: 'Colombia', language: 'es-CO', region: 'LATAM',
    currency: { code: 'COP', symbol: '$', formatLocale: 'es-CO' },
    culturalAdaptation: ['Trato de "tú". "Usted" en banca y legal.', 'Sectores: café, fintech, BPO, retail, software.'],
    legislation: [
      { name: 'Ley 1581 de 2012 — Protección de Datos', reference: 'https://www.sic.gov.co', topic: 'data-protection' },
      { name: 'Código Sustantivo del Trabajo', reference: 'https://www.mintrabajo.gov.co', topic: 'labor-law' },
    ],
    companies: ['Ecopetrol', 'Bancolombia', 'Grupo Éxito', 'Grupo Aval', 'Nutresa', 'Davivienda', 'Rappi'],
    terminology: { computer: 'computador', mobile: 'celular', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['Rappi: super-app colombiana.', 'Bancolombia: banca digital PYMES.', 'Ecopetrol: digitalización petrolera.'],
    examples: ['Fintech Medellín procesa 100K transacciones/mes con PSE.', 'Cafetera Caldas exporta con trazabilidad blockchain.'],
    exercises: ['Diseñe integración PSE para pasarela pagos.', 'Calcule huella carbono cadena café IDEAM.'],
    datasets: [
      { name: 'DANE', url: 'https://www.dane.gov.co', description: 'Estadística Nacional.' },
      { name: 'Datos Abiertos Colombia', url: 'https://www.datos.gov.co', description: 'Portal de datos.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '70%', year: '2024', source: 'DANE' },
      { metric: 'Penetración smartphone', value: '72%', year: '2024', source: 'DANE' },
    ],
    references: [{ title: 'DANE', url: 'https://www.dane.gov.co', publisher: 'Gobierno de Colombia' }],
  },
  {
    code: 'br', name: 'Brasil', nameEn: 'Brazil', language: 'pt-BR', region: 'LATAM',
    currency: { code: 'BRL', symbol: 'R$', formatLocale: 'pt-BR' },
    culturalAdaptation: ['Portugués brasileño. "Você" / "senhor".', 'Sectores: agronegócio, fintech (Pix), banca digital, retail.'],
    legislation: [
      { name: 'LGPD — Lei 13.709/2018', reference: 'https://www.gov.br/anpd', topic: 'data-protection' },
      { name: 'CLT — Consolidação das Leis do Trabalho', reference: 'https://www.gov.br/trabalho-e-emprego', topic: 'labor-law' },
    ],
    companies: ['Nubank', 'Itaú', 'Petrobras', 'Vale', 'Magazine Luiza', 'iFood', 'Stone'],
    terminology: { computer: 'computador', mobile: 'celular', file: 'arquivo', folder: 'pasta', browser: 'navegador' },
    realCases: ['Nubank: disrupción banca digital.', 'Pix: instantaneidad de pagamentos.', 'iFood: logística urbana delivery.'],
    examples: ['Fintech SP processa 10M transações Pix/dia.', 'Agronegócio MT usa IoT 50K hectares.'],
    exercises: ['Modele arquitetura integração API do Pix.', 'Projete data warehouse varejo 500 lojas.'],
    datasets: [
      { name: 'IBGE', url: 'https://www.ibge.gov.br', description: 'Geografia e Estatística.' },
      { name: 'Dados Abertos Brasil', url: 'https://dados.gov.br', description: 'Portal de dados.' },
    ],
    statistics: [
      { metric: 'Penetração internet', value: '84%', year: '2024', source: 'IBGE' },
      { metric: 'Penetração smartphone', value: '80%', year: '2024', source: 'IBGE' },
    ],
    references: [{ title: 'IBGE', url: 'https://www.ibge.gov.br', publisher: 'Governo do Brasil' }],
  },
  {
    code: 'es', name: 'España', nameEn: 'Spain', language: 'es-ES', region: 'EUROPE',
    currency: { code: 'EUR', symbol: '€', formatLocale: 'es-ES' },
    culturalAdaptation: ['"Tú" informal, "usted" formal. "Vosotros" plural.', 'Sectores: turismo, banca, retail, energía renovable.'],
    legislation: [
      { name: 'RGPD (UE) 2016/679', reference: 'https://www.aepd.es', topic: 'data-protection' },
      { name: 'LOPDGDD 3/2018', reference: 'https://www.aepd.es', topic: 'data-protection' },
    ],
    companies: ['Santander', 'BBVA', 'Iberdrola', 'Inditex', 'Telefónica', 'El Corte Inglés', 'Mercadona'],
    terminology: { computer: 'ordenador', mobile: 'móvil', file: 'archivo', folder: 'carpeta', browser: 'navegador' },
    realCases: ['Inditex: cadena suministro digital Zara.', 'Santander: banca digital global.', 'Iberdrola: energías renovables.'],
    examples: ['Fintech Madrid usa Open Banking para crédito.', 'Cadena hotelera Mallorca usa IA pricing dinámico.'],
    exercises: ['Diseñe arquitectura PSD2/Open Banking.', 'Modele gestión hotelera 50 hoteles.'],
    datasets: [
      { name: 'INE España', url: 'https://www.ine.es', description: 'Estadística.' },
      { name: 'datos.gob.es', url: 'https://datos.gob.es', description: 'Datos abiertos.' },
    ],
    statistics: [
      { metric: 'Penetración internet', value: '93%', year: '2024', source: 'INE' },
      { metric: 'Penetración smartphone', value: '87%', year: '2024', source: 'INE' },
    ],
    references: [{ title: 'INE España', url: 'https://www.ine.es', publisher: 'Gobierno de España' }],
  },
  {
    code: 'us', name: 'Estados Unidos', nameEn: 'United States', language: 'en-US', region: 'NORTH_AMERICA',
    currency: { code: 'USD', symbol: '$', formatLocale: 'en-US' },
    culturalAdaptation: ['English primary. Direct communication.', 'Sectores: SaaS, fintech, big-tech, healthcare, retail.'],
    legislation: [
      { name: 'CCPA / CPRA', reference: 'https://oag.ca.gov/privacy/ccpa', topic: 'data-protection' },
      { name: 'HIPAA', reference: 'https://www.hhs.gov/hipaa', topic: 'healthcare-privacy' },
    ],
    companies: ['Apple', 'Microsoft', 'Google', 'Amazon', 'Meta', 'Salesforce', 'Stripe', 'Netflix'],
    terminology: { computer: 'computer', mobile: 'phone', file: 'file', folder: 'folder', browser: 'browser' },
    realCases: ['Stripe: developer-first payments.', 'Salesforce: enterprise SaaS CRM.', 'Netflix: global streaming.'],
    examples: ['SaaS SF procesa $100M ARR con Stripe.', 'Retail NY usa Shopify Plus 500 SKUs.'],
    exercises: ['Design multi-tenant SaaS on AWS.', 'Calculate CAC payback B2B SaaS $5K ACV.'],
    datasets: [
      { name: 'US Census Bureau', url: 'https://www.census.gov', description: 'Demographic data.' },
      { name: 'data.gov', url: 'https://www.data.gov', description: 'US open data.' },
    ],
    statistics: [
      { metric: 'Internet penetration', value: '92%', year: '2024', source: 'Census' },
      { metric: 'Smartphone penetration', value: '85%', year: '2024', source: 'Pew' },
    ],
    references: [{ title: 'US Census', url: 'https://www.census.gov', publisher: 'US Government' }],
  },
  {
    code: 'global', name: 'Global', nameEn: 'Global', language: 'en-US', region: 'GLOBAL',
    currency: { code: 'USD', symbol: '$', formatLocale: 'en-US' },
    culturalAdaptation: ['Neutral international tone.', 'ISO standards + internationally recognized examples.'],
    legislation: [
      { name: 'GDPR (EU)', reference: 'https://gdpr.eu', topic: 'data-protection' },
      { name: 'ISO/IEC 27001', reference: 'https://www.iso.org', topic: 'information-security' },
    ],
    companies: ['Google', 'Microsoft', 'Amazon', 'Apple', 'Meta', 'IBM', 'Oracle', 'SAP'],
    terminology: { computer: 'computer', mobile: 'mobile', file: 'file', folder: 'folder', browser: 'browser' },
    realCases: ['Cloud-native transformation enterprises.', 'API-first design multinational platforms.'],
    examples: ['SaaS platform 50K customers 30 countries.', 'Multinational retailer single ERP multi-currency.'],
    exercises: ['Design multi-region active-active.', 'Model content moderation global social network.'],
    datasets: [
      { name: 'World Bank', url: 'https://data.worldbank.org', description: 'Global indicators.' },
      { name: 'UN Data', url: 'https://data.un.org', description: 'UN statistics.' },
    ],
    statistics: [
      { metric: 'Global internet', value: '67%', year: '2024', source: 'ITU' },
      { metric: 'Global smartphone', value: '70%', year: '2024', source: 'GSMA' },
    ],
    references: [{ title: 'World Bank', url: 'https://www.worldbank.org', publisher: 'World Bank' }],
  },
]

const MAP: ReadonlyMap<string, CountryEntry> = new Map(COUNTRY_CATALOG.map((c) => [c.code, c]))

export function getCountryByCode(code: string): CountryEntry | null {
  return MAP.get((code || '').toLowerCase()) ?? null
}

export function listAllCountries(): CountryEntry[] {
  return COUNTRY_CATALOG.slice()
}
