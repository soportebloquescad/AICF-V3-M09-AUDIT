// =============================================================================
// AICF V3 — AI Service
// =============================================================================
// The AIService is the ONLY entry point for AI operations from Route Handlers.
// It depends solely on the AIAdapter interface — never on LiteLLM directly.
//
// Architecture:
//   Route Handler → AIService → AIAdapter (LiteLLMAdapter | RuntimeAdapter)
//
// To swap backends, change exactly one line:
//   new LiteLLMAdapter()  →  new RuntimeAdapter()
//
// Feature flag: AI_RUNTIME_ENABLED
//   When set to 'true' (env var), AIService uses RuntimeAdapter instead of
//   LiteLLMAdapter. This enables the full Runtime pipeline (Validate → Policy
//   → Routing → Execution → PostProcessing → Audit → Cache → Metrics →
//   Response). Default: off (LiteLLMAdapter, backward compatible).
// =============================================================================

import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from './AIAdapter'
import { LiteLLMAdapter } from './LiteLLMAdapter'
import { logger } from './logger'

/**
 * Feature flag: when process.env.AI_RUNTIME_ENABLED === 'true', the AIService
 * uses RuntimeAdapter (full Runtime pipeline) instead of LiteLLMAdapter.
 * Default: off (LiteLLMAdapter — backward compatible).
 */
const AI_RUNTIME_ENABLED = process.env.AI_RUNTIME_ENABLED === 'true'

/**
 * Default adapter singleton.
 * In production, this is a LiteLLMAdapter (default) or RuntimeAdapter (when
 * AI_RUNTIME_ENABLED=true).
 * In tests, this can be swapped via the constructor.
 */
let defaultAdapter: AIAdapter | null = null

/**
 * Gets the default adapter (lazy singleton).
 * When AI_RUNTIME_ENABLED is true, dynamically imports and uses RuntimeAdapter.
 * Otherwise, uses LiteLLMAdapter (default, backward compatible).
 */
async function getDefaultAdapter(): Promise<AIAdapter> {
  if (!defaultAdapter) {
    if (AI_RUNTIME_ENABLED) {
      const { RuntimeAdapter } = await import('./RuntimeAdapter')
      defaultAdapter = new RuntimeAdapter()
      logger.info('AIService initialized with RuntimeAdapter (AI_RUNTIME_ENABLED=true)')
    } else {
      defaultAdapter = new LiteLLMAdapter()
      logger.info('AIService initialized with LiteLLMAdapter')
    }
  }
  return defaultAdapter
}

/**
 * The AIService provides a clean API for Route Handlers to call AI backends.
 *
 * @example
 * const service = new AIService()
 * const response = await service.chat({ model: 'groq-llama-3.3-70b', messages: [...] })
 */
export class AIService {
  private readonly adapter: AIAdapter | null
  private readonly adapterPromise: Promise<AIAdapter> | null

  constructor(adapter?: AIAdapter) {
    if (adapter) {
      this.adapter = adapter
      this.adapterPromise = null
    } else {
      this.adapter = null
      this.adapterPromise = getDefaultAdapter()
    }
  }

  /**
   * Resolves the adapter (handles the async RuntimeAdapter import when
   * AI_RUNTIME_ENABLED is true).
   */
  private async resolveAdapter(): Promise<AIAdapter> {
    if (this.adapter) return this.adapter
    return this.adapterPromise!
  }

  /**
   * Perform a chat completion.
   * @throws {AIAdapterError} on any failure.
   */
  async chat(request: ChatRequest): Promise<ChatResponse> {
    logger.info({ model: request.model, messageCount: request.messages.length }, 'AIService.chat called')
    const adapter = await this.resolveAdapter()
    return adapter.chat(request)
  }

  /**
   * List available models.
   * @throws {AIAdapterError} on failure.
   */
  async models(): Promise<AIModel[]> {
    logger.debug('AIService.models called')
    const adapter = await this.resolveAdapter()
    return adapter.models()
  }

  /**
   * Check AI backend health.
   */
  async health(): Promise<AIHealth> {
    logger.debug('AIService.health called')
    const adapter = await this.resolveAdapter()
    return adapter.health()
  }
}

/**
 * Resets the default adapter. Useful for testing.
 * @internal
 */
export function _resetDefaultAdapter(): void {
  defaultAdapter = null
}