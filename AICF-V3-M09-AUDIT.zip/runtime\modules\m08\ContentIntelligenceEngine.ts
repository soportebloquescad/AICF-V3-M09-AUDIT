// =============================================================================
// AICF V3 — M08 Content Intelligence — ContentIntelligenceEngine
// =============================================================================
// The ContentIntelligenceEngine is the orchestrator of M08. Given a
// RuntimeRequest, it runs a 9-stage pipeline that produces a fully-resolved
// DecisionPlan:
//
//   1. analyze-request    — extract intent, message count, estimated tokens
//   2. load-policies       — ensure the PolicyEngine has the requested mode
//   3. detect-intent       — classify the request (chat / generation / ...)
//   4. evaluate-context    — apply policy temperature/maxTokens clamps
//   5. select-provider     — ProviderRouter.select(mode)
//   6. select-model        — ModelSelector.select(provider, policy, task)
//   7. apply-rules         — merge cache/retry/fallback from the policy
//   8. generate-plan       — assemble the DecisionPlan
//   9. audit-decision      — record the audit trail
//
// The engine is intentionally synchronous-friendly — every stage records
// timing in the audit trail but no stage performs I/O. This makes the
// engine trivially testable and fast (sub-millisecond per decision).
// =============================================================================

import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { logger } from '@/lib/ai/logger'
import {
  type DecisionPlan,
  type DecisionAudit,
  createDecisionPlan,
} from './DecisionPlan'
import {
  type PolicyEngine as PolicyEngineType,
  type PolicyEvaluationResult,
  PolicyEngine,
  getPolicyEngine,
} from './PolicyEngine'
import {
  type ProviderRouter as ProviderRouterType,
  type RoutingResult,
  ProviderRouter,
  getProviderRouter,
} from './ProviderRouter'
import {
  type ModelSelector as ModelSelectorType,
  type ModelSelectionResult,
  type ModelTask,
  ModelSelector,
  getModelSelector,
} from './ModelSelector'

/**
 * The type of operation the request is performing. Used by the intent
 * detection stage to choose a task hint for the ModelSelector.
 */
export type RequestIntent = 'chat' | 'generation' | 'research' | 'status' | 'models' | 'unknown'

/**
 * Result of the analyze-request stage.
 */
export interface RequestAnalysis {
  /** Detected intent. */
  intent: RequestIntent
  /** Task hint derived from the intent (passed to the ModelSelector). */
  task: ModelTask
  /** The policy mode requested (or 'balanced' if unspecified). */
  mode: string
  /** Whether the request includes chat messages. */
  hasMessages: boolean
  /** Number of messages in the request. */
  messageCount: number
  /** Estimated input token count (rough heuristic: 4 chars per token). */
  estimatedInputTokens: number
}

/**
 * The ContentIntelligenceEngine. Runs the 9-stage decision pipeline.
 */
export class ContentIntelligenceEngine {
  private readonly policyEngine: PolicyEngineType
  private readonly providerRouter: ProviderRouterType
  private readonly modelSelector: ModelSelectorType

  constructor(
    policyEngine?: PolicyEngineType,
    providerRouter?: ProviderRouterType,
    modelSelector?: ModelSelectorType,
  ) {
    this.policyEngine = policyEngine ?? getPolicyEngine()
    this.providerRouter = providerRouter ?? getProviderRouter()
    this.modelSelector = modelSelector ?? getModelSelector()
  }

  /** Access the underlying PolicyEngine (for registration / inspection). */
  getPolicyEngine(): PolicyEngineType {
    return this.policyEngine
  }

  /** Access the underlying ProviderRouter. */
  getProviderRouter(): ProviderRouterType {
    return this.providerRouter
  }

  /** Access the underlying ModelSelector. */
  getModelSelector(): ModelSelectorType {
    return this.modelSelector
  }

  /**
   * Run the 9-stage pipeline and produce a DecisionPlan.
   */
  async decide(request: RuntimeRequest): Promise<DecisionPlan> {
    const pipelineStart = Date.now()
    logger.info(
      { requestId: request.requestId, correlationId: request.correlationId },
      'ContentIntelligenceEngine: decide() starting',
    )

    // Stage 1: analyze-request
    const stage1Start = Date.now()
    const analysis = this.analyzeRequest(request)
    const stage1Ms = Date.now() - stage1Start

    // Stage 2: load-policies
    const stage2Start = Date.now()
    const policyEval = this.loadPolicies(request)
    const stage2Ms = Date.now() - stage2Start

    // Stage 3: detect-intent (already done in stage 1; record timing here)
    const stage3Start = Date.now()
    const intent = this.detectIntent(request, analysis)
    const stage3Ms = Date.now() - stage3Start

    // Stage 4: evaluate-context
    const stage4Start = Date.now()
    const context = this.evaluateContext(policyEval, analysis)
    const stage4Ms = Date.now() - stage4Start

    // Stage 5: select-provider
    const stage5Start = Date.now()
    const routing = this.selectProvider(policyEval.mode)
    const stage5Ms = Date.now() - stage5Start

    // Stage 6: select-model
    const stage6Start = Date.now()
    const modelSelection = this.selectModel(routing, policyEval.policy, analysis.task)
    const stage6Ms = Date.now() - stage6Start

    // Stage 7: apply-rules
    const stage7Start = Date.now()
    const rules = this.applyRules(policyEval.policy)
    const stage7Ms = Date.now() - stage7Start

    // Stage 8: generate-plan
    const stage8Start = Date.now()
    const plan = this.generatePlan(request, analysis, policyEval, routing, modelSelection, rules)
    const stage8Ms = Date.now() - stage8Start

    // Stage 9: audit-decision
    const stage9Start = Date.now()
    const audit = this.auditDecision(request, analysis, policyEval, routing, modelSelection, [
      { stage: 'analyze-request', durationMs: stage1Ms },
      { stage: 'load-policies', durationMs: stage2Ms },
      { stage: 'detect-intent', durationMs: stage3Ms },
      { stage: 'evaluate-context', durationMs: stage4Ms },
      { stage: 'select-provider', durationMs: stage5Ms },
      { stage: 'select-model', durationMs: stage6Ms },
      { stage: 'apply-rules', durationMs: stage7Ms },
      { stage: 'generate-plan', durationMs: stage8Ms },
      { stage: 'audit-decision', durationMs: 0 },
    ])
    const stage9Ms = Date.now() - stage9Start
    audit.stages[audit.stages.length - 1]!.durationMs = stage9Ms
    plan.audit = audit

    const totalMs = Date.now() - pipelineStart
    logger.info(
      {
        requestId: request.requestId,
        correlationId: request.correlationId,
        mode: policyEval.mode,
        provider: routing?.provider.name ?? null,
        model: modelSelection?.model.id ?? null,
        totalMs,
      },
      'ContentIntelligenceEngine: decide() complete',
    )

    return plan
  }

  // --- Stage 1: analyze-request ---------------------------------------------

  private analyzeRequest(request: RuntimeRequest): RequestAnalysis {
    const messages = request.messages ?? []
    const messageCount = messages.length
    const totalChars = messages.reduce((sum, m) => sum + (typeof m.content === 'string' ? m.content.length : 0), 0)
    const estimatedInputTokens = Math.ceil(totalChars / 4)

    const meta = (request.metadata ?? {}) as Record<string, unknown>
    const rawMode = (meta.mode ?? meta.policyMode) as string | undefined
    const mode = typeof rawMode === 'string' ? rawMode : 'balanced'

    return {
      intent: 'unknown', // refined in detectIntent
      task: 'chat',
      mode,
      hasMessages: messageCount > 0,
      messageCount,
      estimatedInputTokens,
    }
  }

  // --- Stage 2: load-policies ------------------------------------------------

  private loadPolicies(request: RuntimeRequest): PolicyEvaluationResult {
    return this.policyEngine.evaluate(request)
  }

  // --- Stage 3: detect-intent ------------------------------------------------

  private detectIntent(request: RuntimeRequest, analysis: RequestAnalysis): RequestIntent {
    let intent: RequestIntent
    const op = request.operation
    if (op === 'chat') {
      intent = 'chat'
    } else if (op === 'generate') {
      intent = 'generation'
    } else if (op === 'status') {
      intent = 'status'
    } else if (op === 'models') {
      intent = 'models'
    } else if (analysis.mode === 'deep-research') {
      intent = 'research'
    } else if (analysis.hasMessages) {
      intent = 'chat'
    } else {
      intent = 'unknown'
    }
    analysis.intent = intent
    analysis.task = this.intentToTask(intent)
    return intent
  }

  private intentToTask(intent: RequestIntent): ModelTask {
    switch (intent) {
      case 'chat':
        return 'chat'
      case 'generation':
        return 'generation'
      case 'research':
        return 'research'
      default:
        return 'chat'
    }
  }

  // --- Stage 4: evaluate-context --------------------------------------------

  private evaluateContext(
    policyEval: PolicyEvaluationResult,
    analysis: RequestAnalysis,
  ): { temperature: number; maxTokens: number; topP: number } {
    const policy = policyEval.policy
    const temp = clampNumber(
      policy.defaultTemperature,
      policy.temperatureRange.min,
      policy.temperatureRange.max,
    )
    return {
      temperature: temp,
      maxTokens: policy.defaultMaxTokens,
      topP: policy.defaultTopP,
    }
  }

  // --- Stage 5: select-provider ---------------------------------------------

  private selectProvider(mode: string): RoutingResult | null {
    return this.providerRouter.select(mode)
  }

  // --- Stage 6: select-model -------------------------------------------------

  private selectModel(
    routing: RoutingResult | null,
    policy: PolicyEvaluationResult['policy'],
    task: ModelTask,
  ): ModelSelectionResult | null {
    if (!routing) return null
    return this.modelSelector.select(routing.provider.name, policy, task)
  }

  // --- Stage 7: apply-rules --------------------------------------------------

  private applyRules(policy: PolicyEvaluationResult['policy']): {
    cachePolicy: DecisionPlan['cachePolicy']
    retryPolicy: DecisionPlan['retryPolicy']
    fallbackStrategy: DecisionPlan['fallbackStrategy']
  } {
    return {
      cachePolicy: { ...policy.cachePolicy },
      retryPolicy: { ...policy.retryPolicy },
      fallbackStrategy: { ...policy.fallbackStrategy },
    }
  }

  // --- Stage 8: generate-plan ------------------------------------------------

  private generatePlan(
    request: RuntimeRequest,
    analysis: RequestAnalysis,
    policyEval: PolicyEvaluationResult,
    routing: RoutingResult | null,
    modelSelection: ModelSelectionResult | null,
    rules: ReturnType<ContentIntelligenceEngine['applyRules']>,
  ): DecisionPlan {
    const provider = routing?.provider.name ?? 'litellm'
    const model = modelSelection?.model.id ?? 'litellm-auto'
    const temperature = modelSelection?.temperature ?? policyEval.policy.defaultTemperature
    const topP = modelSelection?.topP ?? policyEval.policy.defaultTopP
    const maxTokens = modelSelection?.maxTokens ?? policyEval.policy.defaultMaxTokens
    const stop = modelSelection?.stop ?? []
    const estimatedTokens = (modelSelection?.estimatedTokens ?? 0) + analysis.estimatedInputTokens
    const estimatedCost = routing
      ? (estimatedTokens / 1000) * routing.estimatedCostPer1k
      : 0

    return createDecisionPlan({
      requestId: request.requestId,
      correlationId: request.correlationId,
      provider,
      model,
      temperature,
      topP,
      maxTokens,
      stop,
      priority: policyEval.policy.priority,
      cachePolicy: rules.cachePolicy,
      retryPolicy: rules.retryPolicy,
      fallbackStrategy: rules.fallbackStrategy,
      audit: {
        policyMode: policyEval.policy.mode,
        intent: analysis.intent,
        providerReason: routing?.reason ?? 'no provider available',
        modelReason: modelSelection?.reason ?? 'no model selected',
        estimatedCost,
        estimatedTokens,
        timestamp: new Date().toISOString(),
        stages: [],
      },
    })
  }

  // --- Stage 9: audit-decision ----------------------------------------------

  private auditDecision(
    request: RuntimeRequest,
    analysis: RequestAnalysis,
    policyEval: PolicyEvaluationResult,
    routing: RoutingResult | null,
    modelSelection: ModelSelectionResult | null,
    stages: DecisionAudit['stages'],
  ): DecisionAudit {
    const estimatedTokens = (modelSelection?.estimatedTokens ?? 0) + analysis.estimatedInputTokens
    const estimatedCost = routing
      ? (estimatedTokens / 1000) * routing.estimatedCostPer1k
      : 0
    return {
      policyMode: policyEval.policy.mode,
      intent: analysis.intent,
      providerReason: routing?.reason ?? 'no provider available',
      modelReason: modelSelection?.reason ?? 'no model selected',
      estimatedCost,
      estimatedTokens,
      timestamp: new Date().toISOString(),
      stages,
    }
  }
}

function clampNumber(value: number, min: number, max: number): number {
  if (value < min) return min
  if (value > max) return max
  return value
}

/**
 * Singleton ContentIntelligenceEngine wired with the default singletons.
 */
let singleton: ContentIntelligenceEngine | null = null

export function getContentIntelligenceEngine(): ContentIntelligenceEngine {
  if (!singleton) {
    singleton = new ContentIntelligenceEngine()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetContentIntelligenceEngine(): void {
  singleton = null
}
