// =============================================================================
// AICF V3 — GET /api/runtime/audit (Sprint 22: PR 2 — Observability)
// =============================================================================
// Returns audit-log entries recorded by the AuditSubscriber.
//
// Query params:
//   - requestId  : filter by request ID (exact match)
//   - module     : filter by module/stage (exact match)
//   - action     : filter by action (exact match)
//   - limit      : max entries to return (default 50; max 1000)
//
// Response:
//   {
//     entries: AuditEntry[],  // most recent N matching entries (newest last)
//     total:   number         // total matching entries (before limit)
//   }
//
// The AuditProvider is the singleton InMemoryAuditProvider wired by
// observability-singleton.ts. The AuditSubscriber records one entry per
// EDA event published via the global EventBus.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getAuditProvider } from '@/lib/runtime/observability-singleton'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Default + hard cap on the number of entries returned per call. */
const DEFAULT_LIMIT = 50
const MAX_LIMIT = 1000

/**
 * Parses the `limit` query param into a positive integer clamped to
 * [1, MAX_LIMIT]. Falls back to DEFAULT_LIMIT on missing/invalid input.
 */
function parseLimit(raw: string | null): number {
  const parsed = Number.parseInt(raw ?? '', 10)
  if (!Number.isFinite(parsed) || parsed <= 0) return DEFAULT_LIMIT
  return Math.min(parsed, MAX_LIMIT)
}

export async function GET(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/runtime/audit', method: 'GET' })

  try {
    const params = request.nextUrl.searchParams
    const requestId = params.get('requestId') ?? undefined
    // `module` is a reserved name in Next.js tooling — alias to moduleName.
    const moduleName = params.get('module') ?? undefined
    const action = params.get('action') ?? undefined
    const limit = parseLimit(params.get('limit'))

    const auditProvider = getAuditProvider()

    // Query the audit log (in-memory; returns ALL matching entries).
    const matching = await auditProvider.query({ requestId, module: moduleName, action })

    // Apply limit AFTER the query — the InMemoryAuditProvider.query() does
    // not take a limit. We return the most recent `limit` entries (audit
    // entries are stored in insertion order; newest = highest index).
    const total = matching.length
    const start = Math.max(0, total - limit)
    const entries = matching.slice(start)

    reqLogger.info(
      { total, returned: entries.length, requestId, module: moduleName, action, limit },
      'Audit entries retrieved',
    )

    return NextResponse.json({ entries, total })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to retrieve audit entries',
    )
    return NextResponse.json(
      { entries: [], total: 0, error: 'Failed to retrieve audit entries' },
      { status: 500 },
    )
  }
}
