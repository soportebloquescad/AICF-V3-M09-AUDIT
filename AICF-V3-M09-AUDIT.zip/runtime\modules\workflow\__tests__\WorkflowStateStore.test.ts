// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — WorkflowStateStore Tests
// =============================================================================
// Tests for the InMemoryWorkflowStateStore. Verifies CRUD round-trip,
// listPending / listByStatus filtering, checkpoint persistence,
// updateStepExecution, deep-clone isolation on save AND load, and
// full-state export / import serialization.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { InMemoryWorkflowStateStore } from '../state/WorkflowStateStore'
import type {
  WorkflowExecution,
  Checkpoint,
  StepExecution,
} from '@/lib/runtime/contracts/workflow'
import { createPendingExecution } from '@/lib/runtime/contracts/workflow'

/** Build a minimal execution envelope for tests. */
function makeExecution(
  id: string,
  status: WorkflowExecution['status'] = 'pending',
  stepIds: string[] = ['step-1'],
): WorkflowExecution {
  const exec = createPendingExecution(
    'wf-test',
    '1.0.0',
    { topic: 'X' },
    'corr-1',
    false,
    stepIds,
  )
  // Override the generated executionId with a deterministic one.
  exec.executionId = id
  exec.status = status
  return exec
}

describe('InMemoryWorkflowStateStore', () => {
  let store: InMemoryWorkflowStateStore

  beforeEach(() => {
    store = new InMemoryWorkflowStateStore()
  })

  it('saveExecution + loadExecution round-trip', async () => {
    const exec = makeExecution('exec-1')
    await store.saveExecution(exec)
    const loaded = await store.loadExecution('exec-1')
    expect(loaded).not.toBeNull()
    expect(loaded?.executionId).toBe('exec-1')
    expect(loaded?.workflowId).toBe('wf-test')
    expect(loaded?.inputs.topic).toBe('X')
  })

  it('loadExecution returns null for unknown id', async () => {
    const loaded = await store.loadExecution('does-not-exist')
    expect(loaded).toBeNull()
  })

  it('listPending returns pending / running / paused executions', async () => {
    await store.saveExecution(makeExecution('e-pending', 'pending'))
    await store.saveExecution(makeExecution('e-running', 'running'))
    await store.saveExecution(makeExecution('e-paused', 'paused'))
    await store.saveExecution(makeExecution('e-completed', 'completed'))
    await store.saveExecution(makeExecution('e-failed', 'failed'))
    const pending = await store.listPending()
    const ids = pending.map((e) => e.executionId).sort()
    expect(ids).toEqual(['e-paused', 'e-pending', 'e-running'])
  })

  it('listByStatus filters correctly', async () => {
    await store.saveExecution(makeExecution('e-1', 'completed'))
    await store.saveExecution(makeExecution('e-2', 'completed'))
    await store.saveExecution(makeExecution('e-3', 'failed'))
    const completed = await store.listByStatus('completed')
    expect(completed.map((e) => e.executionId).sort()).toEqual(['e-1', 'e-2'])
    const failed = await store.listByStatus('failed')
    expect(failed.map((e) => e.executionId)).toEqual(['e-3'])
  })

  it('deleteExecution removes execution AND checkpoints', async () => {
    const exec = makeExecution('e-1')
    await store.saveExecution(exec)
    const cp: Checkpoint = {
      id: 'cp-1',
      stepId: 'step-1',
      savedAt: Date.now(),
      state: { foo: 'bar' },
    }
    await store.saveCheckpoint('e-1', cp)
    expect((await store.loadCheckpoints('e-1')).length).toBe(1)
    await store.deleteExecution('e-1')
    expect(await store.loadExecution('e-1')).toBeNull()
    expect((await store.loadCheckpoints('e-1')).length).toBe(0)
  })

  it('saveCheckpoint + loadCheckpoints persist in save order', async () => {
    const cp1: Checkpoint = {
      id: 'cp-1',
      stepId: 'step-1',
      savedAt: 1,
      state: { a: 1 },
    }
    const cp2: Checkpoint = {
      id: 'cp-2',
      stepId: 'step-2',
      savedAt: 2,
      state: { b: 2 },
    }
    await store.saveCheckpoint('e-1', cp1)
    await store.saveCheckpoint('e-1', cp2)
    const loaded = await store.loadCheckpoints('e-1')
    expect(loaded.length).toBe(2)
    expect(loaded[0].id).toBe('cp-1')
    expect(loaded[1].id).toBe('cp-2')
    // Different execution: empty.
    expect((await store.loadCheckpoints('e-2')).length).toBe(0)
  })

  it('updateStepExecution updates a single step record', async () => {
    const exec = makeExecution('e-1', 'running', ['step-1'])
    await store.saveExecution(exec)
    const updated: StepExecution = {
      stepId: 'step-1',
      status: 'completed',
      attempts: 1,
      artifacts: ['art-1'],
      output: { content: 'done' },
    }
    await store.updateStepExecution('e-1', 'step-1', updated)
    const loaded = await store.loadExecution('e-1')
    expect(loaded?.steps['step-1'].status).toBe('completed')
    expect(loaded?.steps['step-1'].output?.content).toBe('done')
    expect(loaded?.steps['step-1'].artifacts).toEqual(['art-1'])
  })

  it('deep clone on save: mutating the original does not affect stored state', async () => {
    const exec = makeExecution('e-1', 'running')
    await store.saveExecution(exec)
    // Mutate the original after save.
    exec.inputs.topic = 'MUTATED'
    exec.status = 'failed'
    const loaded = await store.loadExecution('e-1')
    expect(loaded?.inputs.topic).toBe('X')
    expect(loaded?.status).toBe('running')
  })

  it('deep clone on load: mutating the loaded value does not affect stored state', async () => {
    const exec = makeExecution('e-1', 'running')
    await store.saveExecution(exec)
    const loaded1 = await store.loadExecution('e-1')
    if (!loaded1) throw new Error('expected execution')
    loaded1.inputs.topic = 'MUTATED'
    loaded1.status = 'failed'
    const loaded2 = await store.loadExecution('e-1')
    expect(loaded2?.inputs.topic).toBe('X')
    expect(loaded2?.status).toBe('running')
  })

  it('export + import (full state serialization round-trip)', async () => {
    await store.saveExecution(makeExecution('e-1', 'pending'))
    await store.saveExecution(makeExecution('e-2', 'completed'))
    const cp: Checkpoint = {
      id: 'cp-1',
      stepId: 'step-1',
      savedAt: 1,
      state: { foo: 'bar' },
    }
    await store.saveCheckpoint('e-1', cp)

    const exported = store.export()
    expect(typeof exported).toBe('string')

    const newStore = new InMemoryWorkflowStateStore()
    newStore.import(exported)
    const loaded1 = await newStore.loadExecution('e-1')
    const loaded2 = await newStore.loadExecution('e-2')
    expect(loaded1?.status).toBe('pending')
    expect(loaded2?.status).toBe('completed')
    const checkpoints = await newStore.loadCheckpoints('e-1')
    expect(checkpoints.length).toBe(1)
    expect(checkpoints[0].id).toBe('cp-1')
  })
})
