# Presentations Module — Business-layer slide generation

Real Business-layer module (Épica 3 — Educational Factory). Extends
`BusinessModuleBase` and exposes four capabilities:

- `createSlides` — Create a new slide deck from a topic + slide count.
- `generateSlides` — Generate slide content (titles, bullets, notes).
- `exportSlides` — Export a slide deck (returns HTML + markdown).
- `generatePresentation` — Alias of `createSlides`.

## Status

IMPLEMENTED. `executeJob()` produces real slide decks via two paths:

1. **AI mode** (when an `AIAdapter` is injected via the constructor): prompts
   the LLM for a structured JSON deck, parses it into typed slides.
2. **Fallback mode** (no adapter, or AI call fails): a deterministic generator
   produces real, useful content from the requested topic.

Output includes a standalone HTML5 document with embedded CSS, keyboard
navigation (←/→), a slide counter, and print styles — plus markdown source.

## Metadata

| Field | Value |
| --- | --- |
| id | `presentation` |
| version | `1.0.0` |
| mission | `presentation` |
| priority | 35 |
| dependencies | (none) |
| capabilities | `createSlides`, `generateSlides`, `exportSlides`, `generatePresentation` |

## Lifecycle

Inherited from `BusinessModuleBase`.

## Constructor

```typescript
new PresentationModule(aiAdapter?, model?)
```

- `aiAdapter` — optional `AIAdapter` from `@/lib/ai/AIAdapter`. When omitted,
  the module always uses the deterministic fallback.
- `model` — model id passed to the adapter (default `groq-llama-3.3-70b`).
