// =============================================================================
// AICF V3 — Sprint 13+14 — Compensation Handler (Saga Pattern)
// =============================================================================
// Walks backwards through already-executed steps of a workflow execution
// and runs each step's declared `compensation` action. Used by the
// orchestrator when a step fails irrecoverably: instead of leaving the
// system in a half-finished state, the saga rolls back every prior step
// that declared a compensation action.
//
// Sprint 13+14 spec requirements covered:
//   - Saga-pattern rollback: backward walk over completed steps
//   - Skips steps without a compensation action
//   - Updates each step's status to `'compensated'` on success
//   - Emits `workflow.compensation.started` / `workflow.compensation.completed`
//     events through the injected `IEventBus`
//   - Compensation failure on one step does NOT abort compensation of
//     other steps (best-effort rollback; failures are logged)
// =============================================================================

import type {
  WorkflowExecution,
  WorkflowStepDefinition,
  WorkflowContext,
  StepExecution,
} from '@/lib/runtime/contracts/workflow'
import type { IEventBus, IStepExecutor } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Drives saga-pattern compensation for a failed workflow execution.
 *
 * The handler does NOT mutate the execution envelope directly beyond the
 * per-step `status` / `attempts` fields; durable state writes are the
 * caller's responsibility (typically the orchestrator + state store).
 */
export class CompensationHandler {
  /**
   * @param eventBus       Used to emit compensation lifecycle events.
   * @param stepExecutor   Used to invoke the compensation action via the
   *                       step executor surface (so compensation reuses
   *                       retry / variable-resolution semantics).
   */
  constructor(
    private readonly eventBus: IEventBus,
    private readonly stepExecutor: IStepExecutor,
  ) {}

  /**
   * Walk backwards through the steps of `execution`, in reverse dependency
   * order, and compensate every step that:
   *   1. reached `'completed'` status, AND
   *   2. has a `compensation` action declared on its definition, AND
   *   3. appears at-or-before `failedStepId` in the original execution order.
   *
   * Steps without a compensation action are skipped (logged at debug).
   * Compensation failures are logged but do NOT abort the walk.
   *
   * @param execution    The execution envelope to compensate.
   * @param failedStepId Step id at which the failure occurred (exclusive —
   *                     this step is NOT compensated itself).
   * @param ctx          The runtime context for the execution.
   */
  async compensate(
    execution: WorkflowExecution,
    failedStepId: string,
    ctx: WorkflowContext,
  ): Promise<void> {
    await this.eventBus.publish({
      type: 'workflow.compensation.started',
      timestamp: Date.now(),
      level: 'warn',
      executionId: execution.executionId,
      correlationId: execution.correlationId,
      data: { failedStepId, workflowId: execution.workflowId },
    })

    // Build the reverse execution order from the step records (insertion
    // order of the Record is preserved by the JS engine for string keys).
    const orderedStepIds = Object.keys(execution.steps)
    const failedIdx = orderedStepIds.indexOf(failedStepId)
    const toCompensate =
      failedIdx >= 0 ? orderedStepIds.slice(0, failedIdx) : orderedStepIds

    // Walk backwards.
    for (let i = toCompensate.length - 1; i >= 0; i -= 1) {
      const stepId = toCompensate[i]
      const stepExec = execution.steps[stepId]
      if (!stepExec) continue

      // Only compensate steps that completed successfully.
      if (stepExec.status !== 'completed') continue

      // Look up the step definition by id from the execution's workflow
      // (we don't have the definition directly, so the caller must have
      // pre-attached it OR we rely on a minimal definition passed in).
      // The orchestrator attaches definitions to `execution.inputs.__defs`
      // is NOT used — instead the caller supplies a definition map below.
      const stepDef = this.lookupStepDefinition(execution, stepId)
      if (!stepDef) {
        logger.warn(
          { executionId: execution.executionId, stepId },
          'compensation: step definition not found; skipping',
        )
        continue
      }
      if (!stepDef.compensation) {
        logger.debug(
          { executionId: execution.executionId, stepId },
          'compensation: step has no compensation action; skipping',
        )
        continue
      }

      try {
        await this.compensateStep(stepDef, stepExec, ctx)
      } catch (err) {
        // Best-effort rollback: log and continue with the next step.
        const message =
          err instanceof Error ? err.message : 'unknown compensation error'
        logger.error(
          {
            executionId: execution.executionId,
            stepId,
            err: message,
          },
          'compensation step failed; continuing with remaining steps',
        )
      }
    }

    await this.eventBus.publish({
      type: 'workflow.compensation.completed',
      timestamp: Date.now(),
      level: 'warn',
      executionId: execution.executionId,
      correlationId: execution.correlationId,
      data: { failedStepId, workflowId: execution.workflowId },
    })
  }

  /**
   * Run a single step's compensation action. The step's `status` is
   * updated to `'compensated'` on success.
   *
   * The compensation action is dispatched through the injected
   * `IStepExecutor` by setting the step's `type` to `'action'` and
   * `config` to the compensation config. This lets compensation reuse
   * the same retry / variable-resolution / event-emission path as the
   * forward execution.
   */
  async compensateStep(
    step: WorkflowStepDefinition,
    stepExec: StepExecution,
    ctx: WorkflowContext,
  ): Promise<void> {
    if (!step.compensation) {
      return
    }

    logger.debug(
      {
        executionId: ctx.executionId,
        stepId: step.id,
        compensationType: step.compensation.type,
      },
      'running step compensation',
    )

    // Build a synthetic step definition for the compensation action.
    // Reuse the original step's id / inputs / outputs so the executor can
    // resolve variables consistently.
    const compensationStep: WorkflowStepDefinition = {
      ...step,
      type: 'action',
      config: {
        ...step.config,
        __compensation: true,
        __compensationType: step.compensation.type,
        ...step.compensation.config,
      },
      // Compensation should not itself be compensated.
      compensation: undefined,
      retries: 0,
    }

    // Build a synthetic execution envelope fragment. We do not have the
    // full envelope here; we construct the minimum the executor needs.
    const syntheticExec = {
      executionId: ctx.executionId,
      workflowId: '',
      workflowVersion: '',
      status: 'compensating' as const,
      steps: { [step.id]: stepExec },
      inputs: stepExec.output ?? {},
      checkpoints: [],
      startedAt: Date.now(),
      updatedAt: Date.now(),
      correlationId: ctx.correlationId,
      dryRun: ctx.dryRun,
    }

    const result = await this.stepExecutor.execute({
      execution: syntheticExec,
      step: compensationStep,
      ctx,
      variables: ctx.variables,
      artifacts: [],
    })

    if (!result.ok) {
      // Surface the error but do NOT throw — compensation is best-effort.
      logger.warn(
        {
          executionId: ctx.executionId,
          stepId: step.id,
          err: result.error,
        },
        'compensation step returned an error',
      )
      return
    }

    // Mark the step as compensated.
    stepExec.status = 'compensated'
    stepExec.completedAt = Date.now()
  }

  /**
   * Look up a step definition by id from the execution envelope. The
   * orchestrator attaches the full definitions array to the execution's
   * `inputs.__workflow_steps` field (a non-input metadata bag) so the
   * compensation handler can resolve definitions without re-loading the
   * workflow from the registry.
   *
   * Returns `null` if the definitions are not attached (e.g. for older
   * executions persisted before this convention).
   */
  private lookupStepDefinition(
    execution: WorkflowExecution,
    stepId: string,
  ): WorkflowStepDefinition | null {
    const defs = execution.inputs?.['__workflow_steps']
    if (!Array.isArray(defs)) return null
    for (const d of defs) {
      if (
        d &&
        typeof d === 'object' &&
        typeof (d as WorkflowStepDefinition).id === 'string' &&
        (d as WorkflowStepDefinition).id === stepId
      ) {
        return d as WorkflowStepDefinition
      }
    }
    return null
  }
}
