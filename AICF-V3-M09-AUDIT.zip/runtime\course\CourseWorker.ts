// =============================================================================
// AICF V3 — Épica 6 — Course Worker (Orchestrator)
// =============================================================================
// Integrates the Épica 6 production engines (ResearchEngine, KnowledgeBase,
// ContentGenerator, AgentCoordinator, QualityGates, ExportEngine) into the
// course generation pipeline. The engines run BEFORE the Runtime M09
// delegation, producing real content artifacts that are registered and
// exported.
//
// Pipeline flow:
//   1. Research (ResearchEngine) → research data
//   2. Knowledge (KnowledgeBase) → stored facts from research
//   3. Planning (AgentCoordinator) → coordination plan
//   4. Content Generation (ContentGenerator) → course markdown + lessons
//   5. Quality Gates (QualityGates) → validation scores
//   6. Export (ExportEngine) → multi-format exports
//   7. Runtime M09 delegation → existing course/quiz/slides/docs
//   8. ZIP packaging → final artifact
// =============================================================================
import { getRuntimeService } from '@/lib/runtime/runtime-singleton'
import { createJobRequest } from '@/lib/runtime/business/contracts/JobRequest'
import type { JobResponse } from '@/lib/runtime/business/contracts/JobResponse'
import {
  CourseJobStore,
  computeRequestHash,
  type CourseJob,
  type CourseJobRequest,
  STAGE_ORDER,
} from './CourseJobStore'
import { CourseArtifactRegistry, type CourseArtifact } from './CourseArtifactRegistry'
import { ZipExporter } from './ZipExporter'
import { ResearchEngine, type ResearchResult } from './ResearchEngine'
import { KnowledgeBase } from './KnowledgeBase'
import { ContentGenerator, type GeneratedContent } from './ContentGenerator'
import { AgentCoordinator, type CoordinationResult } from './AgentCoordinator'
import { ConsistencyEngine, type ConsistencyResult } from './ConsistencyEngine'
import { AssetGenerator, type GeneratedAsset } from './AssetGenerator'
import { QualityGates, type QualityGateResult } from './QualityGates'
import { ExportEngine as CourseExportEngine, type ExportFormat as CourseExportFormat } from './ExportEngine'
import { PromptOrchestrator } from './PromptOrchestrator'
import { StoryboardGenerator, type Storyboard } from './StoryboardGenerator'
import { ImageGenerator, type ImageArtifact } from './ImageGenerator'
import { InteractivePresentationEngine } from '../engines/InteractivePresentationEngine'
import { getCountryEngine, type LocaleContext } from '../locale/CountryEngine'
import { getThemeEngine } from '../theme/ThemeEngine'
import { logger } from '@/lib/ai/logger'

export interface CourseWorkerResult {
  job: CourseJob
  artifacts: CourseArtifact[]
  zipUrl: string
}

export class CourseWorker {
  private readonly zipExporter = new ZipExporter()

  async run(request: CourseJobRequest, idempotencyKey?: string): Promise<CourseWorkerResult> {
    if (idempotencyKey) {
      const existing = await CourseJobStore.findByIdempotencyKey(idempotencyKey)
      if (existing) {
        logger.info({ jobId: existing.id, idempotencyKey }, 'CourseWorker: idempotent hit')
        const artifacts = await CourseArtifactRegistry.listByJob(existing.id)
        const zipArt = artifacts.find((a) => a.type === 'zip')
        return { job: existing, artifacts, zipUrl: zipArt ? `/api/runtime/assets/${existing.courseId}/${zipArt.artifactId}` : '' }
      }
    }

    let job = await CourseJobStore.create(request, idempotencyKey)
    const projectId = job.courseId
    const jobId = job.id

    logger.info({ jobId, projectId, title: request.title }, 'CourseWorker: starting')

    const service = await getRuntimeService()
    if (!service) {
      job = await CourseJobStore.update(jobId, { status: 'failed', error: 'Runtime not initialized' }) ?? job
      return { job, artifacts: [], zipUrl: '' }
    }

    const metadata = { correlationId: jobId, requestId: jobId, projectId }
    const artifacts: CourseArtifact[] = []
    const errors: string[] = []

    // =========================================================================
    // Épica 6 — Production Engine Integration
    // =========================================================================
    // Instantiate the existing engines. They use the Runtime's AIAdapter
    // (obtained from RuntimeAdapter) when available, and fall back to
    // deterministic content generation when LiteLLM is unreachable.
    // =========================================================================
    const researchEngine = new ResearchEngine({ aiAdapter: null as unknown as import('@/lib/ai/AIAdapter').AIAdapter })
    const knowledgeBase = new KnowledgeBase({ courseId: projectId })
    const promptOrchestrator = new PromptOrchestrator()
    const contentGenerator = new ContentGenerator({ aiAdapter: null as unknown as import('@/lib/ai/AIAdapter').AIAdapter, promptOrchestrator: promptOrchestrator as unknown as InstanceType<typeof PromptOrchestrator> })
    const agentCoordinator = new AgentCoordinator({ aiAdapter: null as unknown as import('@/lib/ai/AIAdapter').AIAdapter })
    const consistencyEngine = new ConsistencyEngine()
    const assetGenerator = new AssetGenerator()
    const qualityGates = new QualityGates()
    const courseExportEngine = new CourseExportEngine()

    // Accumulated content for quality + export stages
    let courseMarkdown = ''
    let totalWordCount = 0
    let researchResult: ResearchResult | null = null
    let coordinationResult: CoordinationResult | null = null
    let qualityResult: QualityGateResult | null = null

    try {
      // =====================================================================
      // Stage 1: RESEARCH — ResearchEngine
      // =====================================================================
      job = await this.transition(jobId, 'research')
      try {
        const depth = request.mode === 'Investigación profunda' ? 'deep' : request.mode === 'Premium' ? 'standard' : 'quick'
        researchResult = await researchEngine.research(request.title, request.locale, depth)
        logger.info({ jobId, factCount: researchResult.keyFacts.length, confidence: researchResult.confidence }, 'CourseWorker: research completed')

        // Store research sources as artifact
        const researchJson = JSON.stringify({
          topic: researchResult.topic,
          summary: researchResult.summary,
          keyFacts: researchResult.keyFacts,
          gaps: researchResult.gaps,
          confidence: researchResult.confidence,
          sources: researchResult.sources.map((s) => ({ title: s.title, content: s.content, confidence: s.confidence })),
        }, null, 2)
        const researchArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'knowledge-sources', format: 'json', name: 'research.json', content: researchJson,
        })
        artifacts.push(researchArt)
      } catch (err) {
        errors.push(`research: ${this.errMsg(err)}`)
        logger.warn({ jobId, error: this.errMsg(err) }, 'CourseWorker: research failed, continuing')
      }

      // =====================================================================
      // Stage 2: KNOWLEDGE BASE — store research facts
      // =====================================================================
      try {
        if (researchResult) {
          for (const fact of researchResult.keyFacts) {
            await knowledgeBase.store({
              courseId: projectId,
              key: `fact-${fact.slice(0, 40)}`,
              value: fact,
              type: 'fact',
              confidence: researchResult.confidence,
              source: researchResult.sources[0] ?? { title: 'Research', content: fact, confidence: 0.8, type: 'memory' as never, retrievedAt: new Date().toISOString(), hash: 'auto', id: 'auto' },
            })
          }
          const kbExport = await knowledgeBase.export()
          const kbArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'knowledge-sources', format: 'json', name: 'knowledge-base.json', content: JSON.stringify(kbExport, null, 2),
          })
          artifacts.push(kbArt)
          logger.info({ jobId, entryCount: Object.keys(kbExport).length }, 'CourseWorker: knowledge base populated')
        }
      } catch (err) {
        errors.push(`knowledge: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 3: PLANNING — AgentCoordinator
      // =====================================================================
      job = await this.transition(jobId, 'curriculum')
      try {
        coordinationResult = await agentCoordinator.coordinate({
          topic: request.title,
          locale: request.locale,
          level: this.mapLevel(request.level),
          audience: request.audience,
          moduleCount: request.modules ?? 5,
          context: researchResult ? { summary: researchResult.summary, keyFacts: researchResult.keyFacts } : {},
        })
        logger.info({ jobId, agentCount: coordinationResult.outputs.length, successCount: coordinationResult.outputs.filter((r) => r.success).length }, 'CourseWorker: coordination completed')
      } catch (err) {
        errors.push(`coordination: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 3b: CONSISTENCY CHECK — ConsistencyEngine
      // =====================================================================
      let consistencyResult: ConsistencyResult | null = null
      try {
        consistencyResult = await consistencyEngine.validate({
          content: courseMarkdown || `# ${request.title}\n\nCourse content for ${request.title}.`,
          terminology: researchResult?.sources[0] ? { topic: request.title } : undefined,
          expectedLanguage: request.locale,
        })
        const consistencyArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'quality-score', format: 'json', name: 'consistency-report.json',
          content: JSON.stringify({
            score: consistencyResult.score,
            issues: consistencyResult.issues,
            recommendations: consistencyResult.recommendations,
          }, null, 2),
        })
        artifacts.push(consistencyArt)
        logger.info({ jobId, consistencyScore: consistencyResult.score, issueCount: consistencyResult.issues.length }, 'CourseWorker: consistency check completed')
      } catch (err) {
        errors.push(`consistency: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 3c: ASSET GENERATION — AssetGenerator
      // =====================================================================
      try {
        const assets = assetGenerator.generateAll({
          title: request.title,
          description: researchResult?.summary ?? `Course about ${request.title}`,
          locale: request.locale,
        })
        for (const asset of assets) {
          const assetArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'course', format: 'markdown', name: `asset-${asset.type}.${asset.format}`,
            content: asset.content,
          })
          artifacts.push(assetArt)
        }
        logger.info({ jobId, assetCount: assets.length }, 'CourseWorker: assets generated')
      } catch (err) {
        errors.push(`assets: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 4: CONTENT GENERATION — ContentGenerator
      // =====================================================================
      job = await this.transition(jobId, 'modules')
      try {
        const courseContent = await contentGenerator.generateCourse({
          topic: request.title,
          level: this.mapLevel(request.level),
          moduleCount: request.modules ?? 5,
          locale: request.locale,
          knowledgeContext: researchResult ? { summary: researchResult.summary, keyFacts: researchResult.keyFacts } : undefined,
        })
        courseMarkdown = courseContent.content
        totalWordCount = courseContent.wordCount

        const courseArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'course', format: 'markdown', name: 'course.md', content: courseContent.content,
        })
        artifacts.push(courseArt)
        logger.info({ jobId, wordCount: courseContent.wordCount }, 'CourseWorker: content generated')

        // Generate lessons
        job = (await CourseJobStore.update(jobId, { stage: 'lessons' })) ?? job
        const lessonCount = Math.min((request.modules ?? 5) * 3, 15)
        for (let i = 0; i < lessonCount; i++) {
          try {
            const lesson = await contentGenerator.generateLesson({
              topic: request.title,
              moduleTitle: `Module ${i + 1}`,
              lessonTitle: `Lesson ${i + 1}`,
              level: this.mapLevel(request.level),
              bloomLevel: 'apply',
              length: 'standard',
              locale: request.locale,
            })
            const lessonArt = await CourseArtifactRegistry.register({
              projectId, jobId, type: 'course', format: 'markdown', name: `lesson-${i + 1}.md`, content: lesson.content,
            })
            artifacts.push(lessonArt)
            courseMarkdown += `\n\n${lesson.content}`
            totalWordCount += lesson.wordCount
          } catch (err) {
            errors.push(`lesson-${i + 1}: ${this.errMsg(err)}`)
          }
        }
      } catch (err) {
        errors.push(`content: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 5: ASSESSMENT — ContentGenerator (if requested)
      // =====================================================================
      if (request.certification.finalExam || request.contentTypes.includes('quizzes')) {
        job = await this.transition(jobId, 'assessment')
        try {
          const assessment = await contentGenerator.generateAssessment({
            topic: request.title,
            questionCount: 10,
            difficulty: this.mapLevel(request.level),
            locale: request.locale,
          })
          const quizArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'quiz', format: 'json', name: 'quiz.json', content: assessment.content,
          })
          artifacts.push(quizArt)
        } catch (err) { errors.push(`assessment: ${this.errMsg(err)}`) }
      }

      // =====================================================================
      // Stage 6: SLIDES — ContentGenerator (if requested)
      // =====================================================================
      if (request.contentTypes.includes('presentation')) {
        job = await this.transition(jobId, 'slides')
        try {
          const slides = await contentGenerator.generateSlides({
            topic: request.title,
            slideCount: 10,
            locale: request.locale,
            audience: request.audience,
          })
          const presArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'presentation', format: 'html', name: 'presentation.html', content: slides.content,
          })
          artifacts.push(presArt)
        } catch (err) { errors.push(`slides: ${this.errMsg(err)}`) }
      }

      // =====================================================================
      // Stage 7: QUALITY GATES — QualityGates
      // =====================================================================
      job = await this.transition(jobId, 'quality')
      try {
        qualityResult = await qualityGates.validate({
          courseMd: courseMarkdown || `# ${request.title}\n\nCourse content for ${request.title}.`,
          wordCount: totalWordCount || courseMarkdown.split(/\s+/).filter(Boolean).length,
          estimatedTokens: totalWordCount * 2,
          budget: request.budget,
        })
        const qualityArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'quality-score', format: 'json', name: 'quality-report.json',
          content: JSON.stringify({
            pedagogical: qualityResult.pedagogical,
            technical: qualityResult.technical,
            overall: qualityResult.score,
            passed: qualityResult.passed,
            issues: qualityResult.issues,
          }, null, 2),
        })
        artifacts.push(qualityArt)
        logger.info({ jobId, overall: qualityResult.score, passed: qualityResult.passed }, 'CourseWorker: quality gates completed')
      } catch (err) {
        errors.push(`quality: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 8: DOCUMENTS — ContentGenerator
      // =====================================================================
      job = await this.transition(jobId, 'documents')
      for (const docType of ['workbook', 'teacher-guide'] as const) {
        try {
          const doc = await contentGenerator.generateDocument({
            topic: request.title,
            type: docType,
            locale: request.locale,
          })
          const docArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: docType as CourseArtifact['type'], format: 'markdown', name: `${docType}.md`, content: doc.content,
          })
          artifacts.push(docArt)
        } catch (err) { errors.push(`${docType}: ${this.errMsg(err)}`) }
      }

      // =====================================================================
      // Stage 8b: STORYBOARD — StoryboardGenerator (Épica 9)
      // =====================================================================
      let storyboard: Storyboard | null = null
      try {
        const countryEngine = getCountryEngine()
        const locale = countryEngine.buildContext(request.country || 'global') ?? countryEngine.buildContext('global')!
        const themeEngine = getThemeEngine()
        const theme = themeEngine.getTheme('profesional')
        const storyboardGen = new StoryboardGenerator()
        storyboard = storyboardGen.generate({
          courseId: projectId,
          title: request.title,
          description: researchResult?.summary ?? `Course on ${request.title}`,
          moduleCount: request.modules ?? 5,
          theme,
          locale,
        })
        const storyboardArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'course', format: 'json', name: 'storyboard.json',
          content: JSON.stringify(storyboard, null, 2),
        })
        artifacts.push(storyboardArt)
        logger.info({ jobId, slideCount: storyboard.slides.length }, 'CourseWorker: storyboard generated')
      } catch (err) {
        errors.push(`storyboard: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 8c: IMAGE GENERATION — ImageGenerator (Épica 9)
      // =====================================================================
      let generatedImages: ImageArtifact[] = []
      try {
        if (storyboard) {
          const countryEngine = getCountryEngine()
          const locale = countryEngine.buildContext(request.country || 'global') ?? countryEngine.buildContext('global')!
          const themeEngine = getThemeEngine()
          const theme = themeEngine.getTheme('profesional')
          const imageGen = new ImageGenerator()
          const imagePrompts = storyboard.slides.map((s) => ({
            prompt: s.visual.imagePrompt,
            type: s.index === 0 ? 'hero' as const : s.visual.diagramPrompt ? 'concept' as const : 'icon' as const,
          }))
          generatedImages = await imageGen.generateBatch({
            prompts: imagePrompts,
            theme,
            locale,
            projectId,
            jobId,
          })
          logger.info({ jobId, imageCount: generatedImages.length }, 'CourseWorker: images generated')
        }
      } catch (err) {
        errors.push(`image-gen: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 8d: INTERACTIVE PRESENTATION — InteractivePresentationEngine (Épica 9)
      // =====================================================================
      try {
        if (storyboard && generatedImages.length > 0) {
          const themeEngine = getThemeEngine()
          const theme = themeEngine.getTheme('profesional')
          const presEngine = new InteractivePresentationEngine()
          const presHtml = presEngine.build({
            storyboard,
            images: generatedImages,
            theme,
          })
          const presArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'presentation', format: 'html', name: 'interactive-presentation.html', content: presHtml,
          })
          artifacts.push(presArt)
          logger.info({ jobId, htmlSize: presHtml.length }, 'CourseWorker: interactive presentation generated')
        }
      } catch (err) {
        errors.push(`interactive-presentation: ${this.errMsg(err)}`)
      }

      // =====================================================================
      // Stage 9: EXPORT — ExportEngine (multi-format)
      // =====================================================================
      job = await this.transition(jobId, 'export')
      try {
        const exportContent = courseMarkdown || `# ${request.title}\n\nCourse content for ${request.title}.`
        const exportMetadata = { title: request.title, locale: request.locale, country: request.country }
        const exportResults = courseExportEngine.exportAll({ content: exportContent, metadata: exportMetadata })
        for (const exp of exportResults) {
          const ext = exp.format === 'markdown' ? 'md' : exp.format === 'scorm12' || exp.format === 'scorm2004' ? 'xml' : exp.format
          const expArt = await CourseArtifactRegistry.register({
            projectId, jobId, type: 'course', format: exp.format === 'markdown' ? 'markdown' : exp.format === 'html' ? 'html' : exp.format === 'json' ? 'json' : 'markdown',
            name: `course.${ext}`, content: exp.content,
          })
          artifacts.push(expArt)
        }
        logger.info({ jobId, exportCount: exportResults.length }, 'CourseWorker: multi-format export completed')
      } catch (err) { errors.push(`export: ${this.errMsg(err)}`) }

      // =====================================================================
      // Stage 10: RUNTIME M09 DELEGATION (existing behavior preserved)
      // =====================================================================
      // The Runtime M09 pipeline still runs for course/quiz/slides/docs
      // generation via the existing executeJob path. This preserves
      // backward compatibility and adds the Épica 6 content on top.
      try {
        const courseResp = await service.executeJob(createJobRequest('createCourse', {
          topic: request.title,
          level: this.mapLevel(request.level),
          modules: request.modules ?? 5,
          language: request.locale,
        }, metadata))
        const courseArts = await this.extractCourseArtifacts(projectId, jobId, courseResp)
        artifacts.push(...courseArts)

        if (request.certification.finalExam || request.contentTypes.includes('quizzes')) {
          const quizResp = await service.executeJob(createJobRequest('createQuiz', {
            topic: request.title, questionCount: 10, difficulty: this.mapLevel(request.level),
          }, metadata))
          const quizArt = await this.extractQuizArtifact(projectId, jobId, quizResp)
          if (quizArt) artifacts.push(quizArt)
        }

        if (request.contentTypes.includes('presentation')) {
          const presResp = await service.executeJob(createJobRequest('createSlides', {
            topic: request.title, slideCount: 10, includeNotes: true,
          }, metadata))
          const presArt = await this.extractPresentationArtifact(projectId, jobId, presResp)
          if (presArt) artifacts.push(presArt)
        }
      } catch (err) {
        errors.push(`runtime: ${this.errMsg(err)}`)
        logger.warn({ jobId, error: this.errMsg(err) }, 'CourseWorker: Runtime M09 delegation failed, continuing with Épica 6 content')
      }

      // =====================================================================
      // Stage 11: MANIFEST + ZIP
      // =====================================================================
      const manifest = {
        projectId,
        version: '1.0.0',
        generatedAt: new Date().toISOString(),
        artifactCount: artifacts.length,
        checksum: artifacts.length > 0 ? artifacts[0].sha256.slice(0, 16) : 'none',
        locale: request.locale,
        country: request.country,
        qualityScore: qualityResult?.score ?? null,
        researchConfidence: researchResult?.confidence ?? null,
        wordCount: totalWordCount,
      }
      const manifestArt = await CourseArtifactRegistry.register({
        projectId, jobId, type: 'manifest', format: 'json', name: 'manifest.json', content: JSON.stringify(manifest, null, 2),
      })
      artifacts.push(manifestArt)

      let zipUrl = ''
      try {
        const zipBuffer = await this.zipExporter.export(projectId, artifacts)
        const zipArt = await CourseArtifactRegistry.register({
          projectId, jobId, type: 'zip', format: 'zip', name: `${projectId}.zip`, content: zipBuffer,
        })
        artifacts.push(zipArt)
        zipUrl = `/api/runtime/assets/${projectId}/${zipArt.artifactId}`
      } catch (err) { errors.push(`zip: ${this.errMsg(err)}`) }

      job = await this.transition(jobId, 'finish')
      job = (await CourseJobStore.update(jobId, { status: 'completed', error: errors.length > 0 ? errors.join('; ') : undefined })) ?? job
      logger.info({ jobId, status: job.status, artifactCount: artifacts.length, wordCount: totalWordCount, qualityScore: qualityResult?.score }, 'CourseWorker: completed')
      return { job, artifacts, zipUrl }
    } catch (err) {
      const msg = this.errMsg(err)
      logger.error({ jobId, error: msg }, 'CourseWorker: fatal error')
      job = (await CourseJobStore.update(jobId, { status: 'failed', error: msg })) ?? job
      return { job, artifacts, zipUrl: '' }
    }
  }

  private async transition(jobId: string, stage: string): Promise<CourseJob> {
    const updated = await CourseJobStore.update(jobId, { status: 'running', stage: stage as CourseJob['stage'] })
    if (!updated) throw new Error(`Job not found: ${jobId}`)
    return updated
  }
  private mapLevel(level: CourseJobRequest['level']): 'beginner' | 'intermediate' | 'advanced' {
    return level === 'Principiante' ? 'beginner' : level === 'Intermedio' ? 'intermediate' : 'advanced'
  }
  private errMsg(err: unknown): string { return err instanceof Error ? err.message : String(err) }

  private async extractCourseArtifacts(projectId: string, jobId: string, resp: JobResponse): Promise<CourseArtifact[]> {
    if (resp.status !== 'completed' || !resp.output) return []
    const course = resp.output.course as Record<string, unknown> | undefined
    if (!course) return []
    const arts: CourseArtifact[] = []
    const md = typeof course.markdown === 'string' ? course.markdown : ''
    const html = typeof course.html === 'string' ? course.html : ''
    if (md) arts.push(await CourseArtifactRegistry.register({ projectId, jobId, type: 'course', format: 'markdown', name: 'course-runtime.md', content: md }))
    if (html) arts.push(await CourseArtifactRegistry.register({ projectId, jobId, type: 'course', format: 'html', name: 'course-runtime.html', content: html }))
    return arts
  }
  private async extractPresentationArtifact(projectId: string, jobId: string, resp: JobResponse): Promise<CourseArtifact | null> {
    if (resp.status !== 'completed' || !resp.output) return null
    const html = typeof resp.output.html === 'string' ? resp.output.html : ''
    if (!html) return null
    return CourseArtifactRegistry.register({ projectId, jobId, type: 'presentation', format: 'html', name: 'presentation-runtime.html', content: html })
  }
  private async extractQuizArtifact(projectId: string, jobId: string, resp: JobResponse): Promise<CourseArtifact | null> {
    if (resp.status !== 'completed' || !resp.output) return null
    const json = JSON.stringify(resp.output.quiz ?? resp.output, null, 2)
    return CourseArtifactRegistry.register({ projectId, jobId, type: 'quiz', format: 'json', name: 'quiz-runtime.json', content: json })
  }
  private async extractDocumentArtifact(projectId: string, jobId: string, docType: string, resp: JobResponse): Promise<CourseArtifact | null> {
    if (resp.status !== 'completed' || !resp.output) return null
    const md = typeof resp.output.markdown === 'string' ? resp.output.markdown : ''
    const html = typeof resp.output.html === 'string' ? resp.output.html : ''
    const content = md || html
    if (!content) return null
    return CourseArtifactRegistry.register({ projectId, jobId, type: docType as CourseArtifact['type'], format: md ? 'markdown' : 'html', name: `${docType}-runtime.${md ? 'md' : 'html'}`, content })
  }
}

export { STAGE_ORDER }
