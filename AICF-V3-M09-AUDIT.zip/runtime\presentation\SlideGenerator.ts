// =============================================================================
// AICF V3 — Sprint 10 — SlideGenerator (SVG images, premium design)
// =============================================================================
// Generates SVG illustrations for slides. NO external image dependencies —
// all images are generated as inline SVG strings. This satisfies the
// "Incluir imágenes generadas" dashboard option.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import type { LocaleContext } from '../locale/CountryEngine'

export type SlideType = 'cover' | 'agenda' | 'content' | 'diagram' | 'quiz' | 'summary' | 'country'

export interface SlideData {
  type: SlideType
  title: string
  subtitle: string
  bullets: string[]
  speakerNotes: string
  countryName?: string
}

export interface GeneratedSlide {
  index: number
  type: SlideType
  title: string
  subtitle: string
  bullets: string[]
  speakerNotes: string
  svgImage: string
  mermaidDiagram: string | null
  countryName: string | null
}

export class SlideGenerator {
  generateSlides(opts: {
    title: string
    description: string
    moduleCount: number
    theme: ThemePreset
    locale: LocaleContext
    includeImages: boolean
  }): GeneratedSlide[] {
    const { title, description, moduleCount, theme, locale, includeImages } = opts
    const slides: GeneratedSlide[] = []
    let idx = 0

    // 1. Cover slide
    slides.push({
      index: idx++,
      type: 'cover',
      title,
      subtitle: description || `A comprehensive course on ${title}`,
      bullets: [],
      speakerNotes: `Welcome to ${title}. This course is adapted for ${locale.country.name}.`,
      svgImage: includeImages ? this.generateCoverSvg(theme, title, locale.country.name) : '',
      mermaidDiagram: null,
      countryName: locale.country.name,
    })

    // 2. Agenda slide
    slides.push({
      index: idx++,
      type: 'agenda',
      title: 'Course Agenda',
      subtitle: `What you will learn in this ${moduleCount}-module course`,
      bullets: Array.from({ length: moduleCount }, (_, i) => `Module ${i + 1}: Key concepts and hands-on practice`),
      speakerNotes: 'Walk through the agenda. Emphasize the hands-on approach.',
      svgImage: includeImages ? this.generateAgendaSvg(theme, moduleCount) : '',
      mermaidDiagram: null,
      countryName: null,
    })

    // 3. Country context slide
    slides.push({
      index: idx++,
      type: 'country',
      title: `Local Context: ${locale.country.name}`,
      subtitle: `Adapted for ${locale.country.name} (${locale.country.language})`,
      bullets: [
        ...locale.realCases.slice(0, 3),
        `Currency: ${locale.currency.code} (${locale.currency.symbol})`,
        `Key companies: ${locale.companies.slice(0, 3).join(', ')}`,
      ],
      speakerNotes: `This course uses real cases from ${locale.country.name} to ground the concepts in local context.`,
      svgImage: includeImages ? this.generateCountrySvg(theme, locale) : '',
      mermaidDiagram: null,
      countryName: locale.country.name,
    })

    // 4. Content slides (one per module)
    for (let m = 0; m < moduleCount; m++) {
      slides.push({
        index: idx++,
        type: 'content',
        title: `Module ${m + 1}`,
        subtitle: 'Core concepts and practical application',
        bullets: locale.examples.slice(0, 3),
        speakerNotes: `Module ${m + 1} covers key concepts with examples from ${locale.country.name}.`,
        svgImage: includeImages ? this.generateContentSvg(theme, m + 1) : '',
        mermaidDiagram: null,
        countryName: null,
      })
    }

    // 5. Diagram slide
    slides.push({
      index: idx++,
      type: 'diagram',
      title: 'Architecture Diagram',
      subtitle: 'System overview and data flow',
      bullets: ['Input → Processing → Output', 'Feedback loop for continuous improvement'],
      speakerNotes: 'Walk through the architecture diagram step by step.',
      svgImage: '',
      mermaidDiagram: this.generateMermaidDiagram(),
      countryName: null,
    })

    // 6. Quiz slide
    slides.push({
      index: idx++,
      type: 'quiz',
      title: 'Knowledge Check',
      subtitle: 'Test your understanding',
      bullets: locale.exercises.slice(0, 3),
      speakerNotes: 'Pause and let participants answer the quiz questions.',
      svgImage: includeImages ? this.generateQuizSvg(theme) : '',
      mermaidDiagram: null,
      countryName: null,
    })

    // 7. Summary slide
    slides.push({
      index: idx++,
      type: 'summary',
      title: 'Summary & Next Steps',
      subtitle: 'Key takeaways and how to apply them',
      bullets: [
        'Review the key concepts covered',
        'Apply the exercises to your own context',
        'Explore the additional resources',
      ],
      speakerNotes: 'Recap the main points and encourage participants to apply what they learned.',
      svgImage: includeImages ? this.generateSummarySvg(theme) : '',
      mermaidDiagram: null,
      countryName: null,
    })

    return slides
  }

  // --- SVG generators (inline, no external dependencies) ---

  private generateCoverSvg(theme: ThemePreset, title: string, countryName: string): string {
    const c = theme.colors
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" width="100%" height="auto">
  <defs>
    <linearGradient id="cover-grad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${c.primary}"/>
      <stop offset="100%" stop-color="${c.accent}"/>
    </linearGradient>
  </defs>
  <rect width="800" height="400" fill="url(#cover-grad)" rx="8"/>
  <circle cx="650" cy="100" r="60" fill="${c.primaryFg}" opacity="0.15"/>
  <circle cx="700" cy="320" r="40" fill="${c.primaryFg}" opacity="0.1"/>
  <rect x="60" y="120" width="500" height="8" fill="${c.primaryFg}" opacity="0.6" rx="4"/>
  <text x="60" y="180" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="36" font-weight="bold">${this.escapeXml(title.slice(0, 40))}</text>
  <text x="60" y="230" fill="${c.primaryFg}" opacity="0.8" font-family="${theme.typography.bodyFont}" font-size="18">Adapted for ${this.escapeXml(countryName)}</text>
  <rect x="60" y="280" width="120" height="36" fill="${c.primaryFg}" opacity="0.9" rx="4"/>
  <text x="120" y="304" fill="${c.primary}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold" text-anchor="middle">AICF V3</text>
</svg>`
  }

  private generateAgendaSvg(theme: ThemePreset, moduleCount: number): string {
    const c = theme.colors
    const items = Array.from({ length: Math.min(moduleCount, 6) }, (_, i) => {
      const y = 60 + i * 50
      return `
  <rect x="40" y="${y}" width="40" height="40" fill="${c.primary}" rx="6"/>
  <text x="60" y="${y + 27}" fill="${c.primaryFg}" font-family="${theme.typography.bodyFont}" font-size="16" font-weight="bold" text-anchor="middle">${i + 1}</text>
  <rect x="100" y="${y + 5}" width="600" height="30" fill="${c.surface}" stroke="${c.border}" rx="4"/>
  <text x="120" y="${y + 25}" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14">Module ${i + 1}: Key concepts</text>`
    }).join('')
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" width="100%" height="auto">
  <rect width="800" height="400" fill="${c.background}" rx="8"/>
  <text x="40" y="35" fill="${c.primary}" font-family="${theme.typography.headingFont}" font-size="20" font-weight="bold">Agenda</text>${items}
</svg>`
  }

  private generateCountrySvg(theme: ThemePreset, locale: LocaleContext): string {
    const c = theme.colors
    const flagColors = this.getFlagColors(locale.country.code)
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" width="100%" height="auto">
  <rect width="800" height="400" fill="${c.background}" rx="8"/>
  <rect x="40" y="40" width="720" height="120" fill="${flagColors[0]}" rx="4"/>
  <rect x="40" y="100" width="720" height="60" fill="${flagColors[1]}" opacity="0.8"/>
  <text x="400" y="110" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="32" font-weight="bold" text-anchor="middle">${this.escapeXml(locale.country.name)}</text>
  <text x="400" y="140" fill="${c.primaryFg}" opacity="0.9" font-family="${theme.typography.bodyFont}" font-size="16" text-anchor="middle">${locale.country.language} • ${locale.currency.code}</text>
  <text x="40" y="200" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold">Key Companies:</text>
  <text x="40" y="225" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">${this.escapeXml(locale.companies.slice(0, 5).join(' • '))}</text>
  <text x="40" y="260" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold">Statistics:</text>
  <text x="40" y="285" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">${this.escapeXml(locale.statistics.map((s) => `${s.metric}: ${s.value}`).join(' • '))}</text>
  <text x="40" y="320" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold">Real Cases:</text>
  <text x="40" y="345" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">${this.escapeXml(locale.realCases.slice(0, 2).join(' • '))}</text>
</svg>`
  }

  private generateContentSvg(theme: ThemePreset, moduleNum: number): string {
    const c = theme.colors
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 300" width="100%" height="auto">
  <rect width="800" height="300" fill="${c.background}" rx="8"/>
  <rect x="40" y="40" width="720" height="4" fill="${c.primary}" rx="2"/>
  <text x="40" y="80" fill="${c.primary}" font-family="${theme.typography.headingFont}" font-size="24" font-weight="bold">Module ${moduleNum}</text>
  <rect x="40" y="100" width="340" height="160" fill="${c.surface}" stroke="${c.border}" rx="8"/>
  <text x="60" y="130" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold">Key Concepts</text>
  <text x="60" y="155" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Fundamentals</text>
  <text x="60" y="175" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Best practices</text>
  <text x="60" y="195" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Common pitfalls</text>
  <rect x="420" y="100" width="340" height="160" fill="${c.surface}" stroke="${c.border}" rx="8"/>
  <text x="440" y="130" fill="${c.accent}" font-family="${theme.typography.bodyFont}" font-size="14" font-weight="bold">Hands-on</text>
  <text x="440" y="155" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Practical exercise</text>
  <text x="440" y="175" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Real-world case</text>
  <text x="440" y="195" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="13">• Discussion</text>
</svg>`
  }

  private generateQuizSvg(theme: ThemePreset): string {
    const c = theme.colors
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 300" width="100%" height="auto">
  <rect width="800" height="300" fill="${c.background}" rx="8"/>
  <circle cx="400" cy="120" r="50" fill="${c.accent}" opacity="0.2"/>
  <text x="400" y="130" fill="${c.accent}" font-family="${theme.typography.headingFont}" font-size="40" font-weight="bold" text-anchor="middle">?</text>
  <text x="400" y="210" fill="${c.primary}" font-family="${theme.typography.headingFont}" font-size="20" font-weight="bold" text-anchor="middle">Knowledge Check</text>
  <text x="400" y="240" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="14" text-anchor="middle">Test your understanding</text>
</svg>`
  }

  private generateSummarySvg(theme: ThemePreset): string {
    const c = theme.colors
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 300" width="100%" height="auto">
  <rect width="800" height="300" fill="${c.background}" rx="8"/>
  <path d="M 200 150 L 350 250 L 600 80" stroke="${c.success}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="200" cy="150" r="12" fill="${c.success}"/>
  <circle cx="350" cy="250" r="12" fill="${c.success}"/>
  <circle cx="600" cy="80" r="12" fill="${c.success}"/>
  <text x="400" y="40" fill="${c.primary}" font-family="${theme.typography.headingFont}" font-size="22" font-weight="bold" text-anchor="middle">Key Takeaways</text>
</svg>`
  }

  private generateMermaidDiagram(): string {
    return `graph LR
    A[Input] --> B[Processing]
    B --> C[Output]
    C --> D[Feedback]
    D --> A
    B --> E[Quality Check]
    E --> C`
  }

  private getFlagColors(code: string): string[] {
    const flags: Record<string, string[]> = {
      pe: ['#D91023', '#FFFFFF'],
      mx: ['#006847', '#CE1126'],
      ar: ['#74ACDF', '#FFFFFF'],
      cl: ['#0039A6', '#D52B1E'],
      co: ['#FCD116', '#003893'],
      br: ['#009C3B', '#FFDF00'],
      es: ['#AA151B', '#F1BF00'],
      us: ['#3C3B6E', '#B22234'],
      global: ['#2563eb', '#0f766e'],
    }
    return flags[code] ?? ['#2563eb', '#0f766e']
  }

  private escapeXml(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;')
  }

  // ===========================================================================
  // Sprint 11A — Premium slide generation
  // ===========================================================================
  // Adds rich fields (learningObjectives, practicalExample, quote, quiz,
  // exercise, caseStudy) and new SlideTypes (quiz-interactive, exercise,
  // case-study). The existing generateSlides() API is preserved.
  // ===========================================================================

  /**
   * Generates premium slides for a module: cover, index, 5-8 content slides
   * with topic-specific SVG images, a quiz with feedback, an exercise, a
   * case study, and a summary.
   *
   * REUSES: MediaGenerator (topic-specific SVGs), LessonEngine (deep content),
   * ExerciseEngine (interactive exercises).
   */
  async generatePremiumSlides(opts: {
    title: string
    description: string
    topic: string
    moduleIndex: number
    moduleCount: number
    theme: ThemePreset
    locale: LocaleContext
    includeImages: boolean
  }): Promise<PremiumGeneratedSlide[]> {
    const { title, description, topic, moduleIndex, moduleCount, theme, locale, includeImages } = opts
    const slides: PremiumGeneratedSlide[] = []
    let idx = 0

    // Dynamic import to avoid circular dependencies at module load time.
    const { MediaGenerator } = await import('../media/MediaGenerator')
    const { LessonEngine } = await import('../lesson/LessonEngine')
    const media = new MediaGenerator()
    const lessonEngine = new LessonEngine()

    // Generate deep lesson content for this module
    const lesson = lessonEngine.generate({
      topic, moduleIndex, lessonIndex: 0, locale,
    })

    // 1. Cover slide
    slides.push({
      index: idx++,
      type: 'cover',
      title,
      subtitle: description || `A comprehensive course on ${title}`,
      bullets: [],
      speakerNotes: `Welcome to ${title}. This course is adapted for ${locale.country.name}. Module ${moduleIndex} covers ${topic}.`,
      svgImage: includeImages ? media.generateHero(title, theme) : '',
      mermaidDiagram: null,
      countryName: locale.country.name,
      learningObjectives: [],
      practicalExample: null,
      quote: null,
      quiz: null,
      exercise: null,
      caseStudy: null,
    })

    // 2. Index slide
    slides.push({
      index: idx++,
      type: 'agenda',
      title: `Module ${moduleIndex} — Index`,
      subtitle: `What you will learn in this module on ${topic}`,
      bullets: lesson.learningObjectives,
      speakerNotes: 'Walk through the module index. Emphasize the learning objectives.',
      svgImage: includeImages ? media.generateConcept(topic, moduleIndex, theme) : '',
      mermaidDiagram: null,
      countryName: null,
      learningObjectives: lesson.learningObjectives,
      practicalExample: null,
      quote: null,
      quiz: null,
      exercise: null,
      caseStudy: null,
    })

    // 3-8. Content slides (5-8 slides per module) — each with topic-specific SVG
    const contentSlideCount = Math.min(8, Math.max(5, lesson.examples.length + 2))
    for (let s = 0; s < contentSlideCount; s++) {
      const example = lesson.examples[s % lesson.examples.length]
      const diagramKind = (s % 4 === 0) ? 'flow' : (s % 4 === 1) ? 'architecture' : (s % 4 === 2) ? 'sequence' : 'comparison'
      slides.push({
        index: idx++,
        type: 'content',
        title: `${topic} — Concept ${s + 1}`,
        subtitle: example.title,
        bullets: this.extractBullets(lesson.content, s),
        speakerNotes: `This slide covers concept ${s + 1} of ${topic}. Key example: ${example.description}`,
        svgImage: includeImages ? media.generateConcept(`${topic} - ${example.title}`, moduleIndex, theme) : '',
        mermaidDiagram: media.generateMermaid(topic, diagramKind as 'flow'),
        countryName: null,
        learningObjectives: [lesson.learningObjectives[s % lesson.learningObjectives.length]],
        practicalExample: example,
        quote: s === 0 ? `"${locale.realCases[0] ?? 'Practice makes perfect'}" — Local Expert` : null,
        quiz: null,
        exercise: null,
        caseStudy: null,
      })
    }

    // Case study slide
    slides.push({
      index: idx++,
      type: 'case-study',
      title: `Case Study: ${topic} in ${locale.country.name}`,
      subtitle: lesson.caseStudy.title,
      bullets: [
        `Scenario: ${lesson.caseStudy.scenario}`,
        `Challenge: ${lesson.caseStudy.challenge}`,
        `Solution: ${lesson.caseStudy.solution}`,
        `Outcome: ${lesson.caseStudy.outcome}`,
      ],
      speakerNotes: `Discuss the case study. Key takeaway: ${lesson.caseStudy.takeaway}`,
      svgImage: includeImages ? media.generateInfographic(locale, theme) : '',
      mermaidDiagram: null,
      countryName: locale.country.name,
      learningObjectives: [],
      practicalExample: null,
      quote: null,
      quiz: null,
      exercise: null,
      caseStudy: lesson.caseStudy,
    })

    // Interactive quiz slide
    slides.push({
      index: idx++,
      type: 'quiz-interactive',
      title: `Quiz: ${topic}`,
      subtitle: 'Test your understanding (interactive — click to reveal answers)',
      bullets: [],
      speakerNotes: 'Pause and let participants answer the quiz questions. Click each question to reveal the answer.',
      svgImage: '',
      mermaidDiagram: null,
      countryName: null,
      learningObjectives: [],
      practicalExample: null,
      quote: null,
      quiz: lesson.quiz,
      exercise: null,
      caseStudy: null,
    })

    // Interactive exercise slide
    slides.push({
      index: idx++,
      type: 'exercise',
      title: `Exercise: ${topic}`,
      subtitle: `${lesson.exercise.title} — ${lesson.exercise.estimatedMinutes} min`,
      bullets: lesson.exercise.instructions,
      speakerNotes: `Guide participants through the exercise. Difficulty: ${lesson.exercise.difficulty}.`,
      svgImage: '',
      mermaidDiagram: null,
      countryName: null,
      learningObjectives: [],
      practicalExample: null,
      quote: null,
      quiz: null,
      exercise: lesson.exercise,
      caseStudy: null,
    })

    // Summary slide
    slides.push({
      index: idx++,
      type: 'summary',
      title: `Module ${moduleIndex} — Summary`,
      subtitle: 'Key takeaways and next steps',
      bullets: [
        ...lesson.learningObjectives.slice(0, 3),
        `Case study takeaway: ${lesson.caseStudy.takeaway}`,
        'Complete the exercise before the next module',
      ],
      speakerNotes: 'Recap the module. Encourage participants to complete the exercise.',
      svgImage: includeImages ? media.generateHero(topic, theme) : '',
      mermaidDiagram: null,
      countryName: null,
      learningObjectives: lesson.learningObjectives,
      practicalExample: null,
      quote: null,
      quiz: null,
      exercise: null,
      caseStudy: null,
    })

    return slides
  }

  private extractBullets(content: string, slideIndex: number): string[] {
    const lines = content.split('\n').filter((l) => l.trim().startsWith('-') || l.trim().startsWith('*'))
    const start = (slideIndex * 2) % Math.max(1, lines.length)
    return lines.slice(start, start + 3).map((l) => l.replace(/^[-*]\s*/, '').trim()).filter((l) => l.length > 0)
  }
}

// --- Sprint 11A premium types -----------------------------------------------

export type PremiumSlideType = SlideType | 'quiz-interactive' | 'exercise' | 'case-study'

export interface PremiumQuizQuestion {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

export interface PremiumExerciseStep {
  number: number
  title: string
  description: string
  code?: string
}

export interface PremiumExercise {
  id: string
  title: string
  description: string
  instructions: string[]
  difficulty: string
  estimatedMinutes: number
  steps: PremiumExerciseStep[]
  exampleCode: string | null
  rubric: Array<{ name: string; weight: number; description: string }>
  hints: string[]
}

export interface PremiumCaseStudy {
  title: string
  scenario: string
  challenge: string
  solution: string
  outcome: string
  takeaway: string
}

export interface PremiumExample {
  title: string
  description: string
  code: string | null
}

export interface PremiumGeneratedSlide {
  index: number
  type: PremiumSlideType
  title: string
  subtitle: string
  bullets: string[]
  speakerNotes: string
  svgImage: string
  mermaidDiagram: string | null
  countryName: string | null
  // Sprint 11A rich fields
  learningObjectives: string[]
  practicalExample: PremiumExample | null
  quote: string | null
  quiz: PremiumQuizQuestion[] | null
  exercise: PremiumExercise | null
  caseStudy: PremiumCaseStudy | null
}
