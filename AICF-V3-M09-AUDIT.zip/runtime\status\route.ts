// =============================================================================
// AICF V3 — GET /api/runtime/status (Sprint 15: Real Health Matrix)
// =============================================================================
// Returns the full Runtime health matrix:
//   - Runtime status (ready/degraded/unhealthy) + uptime
//   - Per-module health (ready, status, startupTime, dependencies, version,
//     lastInitialization, metrics)
//   - Pipeline stages
//   - Providers
//
// Sprint 15: uses RuntimeService.getRuntimeHealth() which calls each module's
// health() method. Modules registered as stubs report ready=false.
// =============================================================================

import { NextResponse } from 'next/server'
import { getRuntimeService, getRuntimeInitError } from '@/lib/runtime/runtime-singleton'
import { DEFAULT_PIPELINE_STAGES } from '@/lib/runtime/pipeline/PipelineRegistry'
import { buildDeepHealth } from '@/lib/runtime/health/DeepHealth'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const PIPELINE_STAGE_NAMES = DEFAULT_PIPELINE_STAGES.map((s) => s.name)

const SUPPORTED_PROVIDERS = [
  'groq',
  'gemini',
  'openrouter',
  'deepseek',
  'openai',
  'anthropic',
]

// Singleton RuntimeService — shared with /api/runtime/execute via runtime-singleton.
async function getStatusService() {
  return await getRuntimeService()
}

export async function GET() {
  const reqLogger = logger.child({ endpoint: '/runtime/status', method: 'GET' })

  try {
    const service = await getStatusService()

    if (!service) {
      const initError = getRuntimeInitError()
      return NextResponse.json({
        status: 'unhealthy',
        version: '3.0.0',
        healthy: false,
        error: initError,
        runtime: {
          status: 'unhealthy',
          startedAt: '',
          uptimeMs: 0,
          totalModules: 0,
          readyModules: 0,
        },
        modules: [],
        pipeline: {
          stages: PIPELINE_STAGE_NAMES,
          stageCount: PIPELINE_STAGE_NAMES.length,
        },
        timestamp: new Date().toISOString(),
      })
    }

    const health = await service.getRuntimeHealth()

    // Sprint 18 Phase A: build DeepHealth for the `health` field
    const deepHealth = await buildDeepHealth(service.getModuleRegistry())

    reqLogger.info(
      { status: health.status, readyModules: health.readyModules, totalModules: health.totalModules, deepRuntime: deepHealth.runtime },
      'Runtime status',
    )

    return NextResponse.json({
      status: health.status,
      version: '3.0.0',
      healthy: health.status === 'ready',
      health: deepHealth,
      runtime: {
        status: health.status,
        startedAt: health.startedAt,
        uptimeMs: health.uptimeMs,
        totalModules: health.totalModules,
        readyModules: health.readyModules,
      },
      modules: health.modules.map((m) => ({
        name: m.name,
        category: m.category,
        ready: m.health.ready,
        health: m.health.status,
        version: m.health.version,
        startupTime: m.health.startupTime,
        dependencies: m.health.dependencies,
        lastInitialization: m.health.lastInitialization,
        lastError: m.health.lastError || null,
        metrics: m.health.metrics || null,
      })),
      pipeline: {
        stages: PIPELINE_STAGE_NAMES,
        stageCount: PIPELINE_STAGE_NAMES.length,
      },
      providers: {
        supported: SUPPORTED_PROVIDERS,
        configured: {
          litellmBaseUrl: Boolean(process.env.LITELLM_BASE_URL),
          litellmApiKey: Boolean(process.env.LITELLM_API_KEY),
        },
      },
      node: {
        version: process.version,
        environment: process.env.NODE_ENV || 'development',
      },
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Runtime status failed',
    )

    // Fallback: return a minimal degraded status so the endpoint never 500s.
    return NextResponse.json({
      status: 'unhealthy',
      version: '3.0.0',
      healthy: false,
      health: {
        runtime: 'unhealthy',
        modules: {
          m08: 'unhealthy', m18: 'unhealthy', m21: 'unhealthy',
          workflow: 'unhealthy', generation: 'unhealthy', observability: 'unhealthy',
          localization: 'unhealthy', assets: 'unhealthy', reports: 'unhealthy',
        },
        litellm: { available: false, latency: 0, models: [] },
        provider: 'litellm',
        model: 'groq-llama-3.3-70b',
        timestamp: new Date().toISOString(),
      },
      error: err instanceof Error ? err.message : String(err),
      runtime: {
        status: 'unhealthy',
        startedAt: '',
        uptimeMs: 0,
        totalModules: 0,
        readyModules: 0,
      },
      modules: [],
      pipeline: {
        stages: PIPELINE_STAGE_NAMES,
        stageCount: PIPELINE_STAGE_NAMES.length,
      },
      timestamp: new Date().toISOString(),
    }, { status: 200 }) // 200 so monitoring tools can parse the error
  }
}
