// =============================================================================
// AICF V3 — Épica 9 — GET /api/runtime/course/[id]/quality
// =============================================================================
// Returns the quality report for a course generation job.
//
// Identifier resolution chain:
//   [id] (URL segment) → jobId
//     → CourseJobStore.get(jobId) → CourseJob (404 if not found)
//     → CourseArtifactRegistry.listByJob(jobId) → quality-score artifact
//
// The [id] segment is treated as a jobId — same convention as /progress,
// /storyboard, /exports. The CourseArtifactRegistry indexes artifacts by
// BOTH projectId AND jobId; we use listByJob(jobId) so the lookup is
// consistent with the URL identifier (no projectId mismatch).
//
// Responses:
//   200 — job found; returns quality report if available, otherwise a
//         placeholder indicating the quality stage has not run yet
//   404 — jobId not found in CourseJobStore
// =============================================================================
import { NextRequest, NextResponse } from 'next/server'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id: jobId } = await params
  const reqLogger = logger.child({
    endpoint: '/api/runtime/course/[id]/quality',
    method: 'GET',
    jobId,
  })

  try {
    const job = await CourseJobStore.get(jobId)

    if (!job) {
      reqLogger.info({ jobId }, 'Quality: job not found')
      return NextResponse.json(
        { error: 'Job not found', jobId },
        { status: 404 },
      )
    }

    // Look up the quality-score artifact by jobId (NOT projectId) so the
    // identifier chain stays consistent: URL → jobId → artifacts.
    const artifacts = await CourseArtifactRegistry.listByJob(jobId)
    const qualityArtifact = artifacts.find((a) => a.type === 'quality-score')

    reqLogger.info(
      {
        jobId,
        artifactCount: artifacts.length,
        hasQualityScore: Boolean(qualityArtifact),
      },
      'Quality retrieved',
    )

    return NextResponse.json({
      jobId: job.id,
      courseId: job.courseId,
      status: job.status,
      stage: job.stage,
      hasQualityReport: Boolean(qualityArtifact),
      qualityReport: qualityArtifact
        ? {
            artifactId: qualityArtifact.artifactId,
            name: qualityArtifact.name,
            format: qualityArtifact.format,
            sizeBytes: qualityArtifact.sizeBytes,
            sha256: qualityArtifact.sha256,
            createdAt: qualityArtifact.createdAt,
            content: JSON.parse(qualityArtifact.content.toString('utf-8')),
          }
        : null,
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Quality: failed',
    )
    return NextResponse.json(
      { error: 'Failed to get quality report' },
      { status: 500 },
    )
  }
}
