// =============================================================================
// AICF V3 — GET + DELETE /api/runtime/workflow/[id] (Sprint 13+14)
// =============================================================================
// GET:    Get execution status by ID.
// DELETE: Cancel + delete an execution.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getWorkflowModuleBundle } from '@/lib/runtime/modules/workflow/bundle'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow/[id]', method: 'GET', executionId: id })

  try {
    const bundle = getWorkflowModuleBundle()
    const execution = await bundle.module.getStatusById(id)

    if (!execution) {
      return NextResponse.json({ error: 'Execution not found' }, { status: 404 })
    }

    reqLogger.info({ status: execution.status }, 'Execution status retrieved')
    return NextResponse.json(execution)
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to get execution',
    )
    return NextResponse.json({ error: 'Failed to get execution' }, { status: 500 })
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow/[id]', method: 'DELETE', executionId: id })

  try {
    const bundle = getWorkflowModuleBundle()

    // Cancel first (if running)
    try {
      await bundle.module.cancel(id)
    } catch {
      // ignore — may already be terminal
    }

    // Delete from state store
    await bundle.stateStore.deleteExecution(id)

    reqLogger.info('Execution cancelled + deleted')
    return NextResponse.json({ ok: true, id })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to delete execution',
    )
    return NextResponse.json({ error: 'Failed to delete execution' }, { status: 500 })
  }
}
