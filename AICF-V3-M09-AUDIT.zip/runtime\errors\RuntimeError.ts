// =============================================================================
// AICF V3 — Runtime Error (Sprint 18: Consistent Error Handling)
// =============================================================================
// Structured error type for all Runtime errors.
// =============================================================================

/**
 * Error codes for the Runtime.
 */
export type RuntimeErrorCode =
  | 'MODULE_NOT_FOUND'
  | 'MODULE_NOT_READY'
  | 'MODULE_INITIALIZATION_FAILED'
  | 'CAPABILITY_NOT_FOUND'
  | 'DEPENDENCY_RESOLUTION_FAILED'
  | 'CIRCULAR_DEPENDENCY'
  | 'PIPELINE_FAILED'
  | 'TIMEOUT'
  | 'NETWORK'
  | 'AUTH'
  | 'MODEL_NOT_FOUND'
  | 'RATE_LIMIT'
  | 'CIRCUIT_OPEN'
  | 'BUDGET_EXCEEDED'
  | 'QUOTA_EXCEEDED'
  | 'UNKNOWN'

/**
 * Structured Runtime error with code, module, message, and details.
 *
 * @example
 * throw new RuntimeError('MODULE_NOT_READY', 'content-intelligence', 'M08 is not initialized')
 */
export class RuntimeError extends Error {
  constructor(
    message: string,
    public readonly code: RuntimeErrorCode,
    public readonly module?: string,
    public readonly statusCode: number = 500,
    public readonly details?: Record<string, unknown>,
  ) {
    super(message)
    this.name = 'RuntimeError'
  }

  /**
   * Returns a JSON-serializable representation.
   */
  toJSON(): Record<string, unknown> {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      module: this.module,
      statusCode: this.statusCode,
      details: this.details,
    }
  }
}
