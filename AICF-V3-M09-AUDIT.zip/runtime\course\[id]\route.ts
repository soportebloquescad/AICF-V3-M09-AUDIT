// =============================================================================
// AICF V3 — Épica 7 — GET /api/runtime/course/[id]
// =============================================================================
// Thin Route Handler: returns the job status from CourseJobStore.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: `/api/runtime/course/${id}`, method: 'GET' })

  try {
    const job = await CourseJobStore.get(id)
    if (!job) {
      return NextResponse.json({ error: 'Job not found', jobId: id }, { status: 404 })
    }

    const artifacts = await CourseArtifactRegistry.listByJob(id)

    reqLogger.info({ jobId: id, status: job.status, stage: job.stage, progress: job.progress }, 'Job status retrieved')

    return NextResponse.json({
      jobId: job.id,
      courseId: job.courseId,
      status: job.status,
      stage: job.stage,
      progress: job.progress,
      startedAt: job.startedAt,
      updatedAt: job.updatedAt,
      completedAt: job.completedAt ?? null,
      error: job.error ?? null,
      logs: job.logs,
      artifactCount: artifacts.length,
      artifacts: artifacts.map((a) => ({
        artifactId: a.artifactId,
        type: a.type,
        format: a.format,
        name: a.name,
        sizeBytes: a.sizeBytes,
      })),
      request: {
        title: job.request.title,
        locale: job.request.locale,
        country: job.request.country,
        audience: job.request.audience,
        level: job.request.level,
        mode: job.request.mode,
        modules: job.request.modules ?? 5,
      },
      downloadUrl: artifacts.some((a) => a.type === 'zip')
        ? `/api/runtime/course/${job.courseId}/download`
        : null,
      contentUrl: `/api/runtime/course/${job.courseId}/content`,
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to get job status',
    )
    return NextResponse.json(
      { error: 'Failed to get job status' },
      { status: 500 },
    )
  }
}
