// =============================================================================
// AICF V3 — Sprint 13+14 — Event Bus Interface
// =============================================================================
// In-process pub/sub for `WorkflowEvent`s. The executor publishes lifecycle
// events; the UI, metrics aggregator, audit log, and compensation tracker
// subscribe.
//
// Sprint 13+14 spec requirements covered:
//   - Typed publish / subscribe by `WorkflowEventType`
//   - `subscribeAll` for cross-cutting consumers (audit, metrics)
//   - `getHistory` for replay / audit queries, optionally scoped by execution
//   - Subscribers return an unsubscribe function (no manual bookkeeping)
//
// NOTE: this is a process-local event bus. For cross-service fan-out, pair it
// with a durable message bus; this contract is the in-process surface only.
// =============================================================================

import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'

/** Handler invoked when a matching event is published. May be async. */
export type EventHandler = (event: WorkflowEvent) => void | Promise<void>

/**
 * In-process event bus contract. Implementations MUST deliver events in
 * publish order to each subscriber; delivery failures in one subscriber
 * MUST NOT block delivery to other subscribers.
 */
export interface IEventBus {
  /** Publish an event to all matching subscribers. */
  publish(event: WorkflowEvent): Promise<void>
  /** Subscribe to a single event type. Returns an unsubscribe function. */
  subscribe(eventType: string, handler: EventHandler): () => void
  /** Subscribe to every event type. Returns an unsubscribe function. */
  subscribeAll(handler: EventHandler): () => void
  /** Return recorded events, optionally scoped by execution id. */
  getHistory(executionId?: string): Promise<WorkflowEvent[]>
  /** Clear all recorded history. Does not unsubscribe handlers. */
  clear(): void
}
