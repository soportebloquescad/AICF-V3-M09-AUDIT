// =============================================================================
// AICF V3 — Épica 9 — GET /api/runtime/course/[id]/exports
// =============================================================================
// Returns the list of export artifacts for a course generation job.
//
// Identifier resolution chain:
//   [id] (URL segment) → jobId
//     → CourseJobStore.get(jobId) → CourseJob (404 if not found)
//     → CourseArtifactRegistry.listByJob(jobId) → all artifacts
//
// The [id] segment is treated as a jobId — same convention as /progress,
// /storyboard, /quality. The CourseArtifactRegistry indexes artifacts by
// BOTH projectId AND jobId; we use listByJob(jobId) so the lookup is
// consistent with the URL identifier (no projectId mismatch).
//
// Responses:
//   200 — job found; returns the list of export artifacts (may be empty if
//         the export stage has not run yet)
//   404 — jobId not found in CourseJobStore
// =============================================================================
import { NextRequest, NextResponse } from 'next/server'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id: jobId } = await params
  const reqLogger = logger.child({
    endpoint: '/api/runtime/course/[id]/exports',
    method: 'GET',
    jobId,
  })

  try {
    const job = await CourseJobStore.get(jobId)

    if (!job) {
      reqLogger.info({ jobId }, 'Exports: job not found')
      return NextResponse.json(
        { error: 'Job not found', jobId },
        { status: 404 },
      )
    }

    // Look up ALL artifacts by jobId (NOT projectId) so the identifier
    // chain stays consistent: URL → jobId → artifacts.
    const artifacts = await CourseArtifactRegistry.listByJob(jobId)
    const zipArtifact = artifacts.find((a) => a.type === 'zip')

    reqLogger.info(
      { jobId, artifactCount: artifacts.length, hasZip: Boolean(zipArtifact) },
      'Exports retrieved',
    )

    return NextResponse.json({
      jobId: job.id,
      courseId: job.courseId,
      status: job.status,
      stage: job.stage,
      artifactCount: artifacts.length,
      hasZip: Boolean(zipArtifact),
      exports: artifacts.map((a) => ({
        artifactId: a.artifactId,
        type: a.type,
        format: a.format,
        name: a.name,
        sizeBytes: a.sizeBytes,
        sha256: a.sha256,
        createdAt: a.createdAt,
      })),
      zip: zipArtifact
        ? {
            artifactId: zipArtifact.artifactId,
            name: zipArtifact.name,
            sizeBytes: zipArtifact.sizeBytes,
            sha256: zipArtifact.sha256,
            createdAt: zipArtifact.createdAt,
          }
        : null,
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Exports: failed',
    )
    return NextResponse.json(
      { error: 'Failed to get exports' },
      { status: 500 },
    )
  }
}
