// =============================================================================
// AICF V3 — Epica 7 — Engine Registry
// =============================================================================
import type { EngineContract, HealthStatus } from './EngineContract'
import { logger } from '@/lib/ai/logger'

export interface RegistryHealth {
  overall: boolean
  engines: Record<string, HealthStatus>
}

class EngineRegistryImpl {
  private readonly engines = new Map<string, EngineContract>()

  register(name: string, engine: EngineContract): void {
    if (this.engines.has(name)) {
      logger.warn({ name }, 'EngineRegistry: overwriting existing engine')
    }
    this.engines.set(name, engine)
    logger.info({ name, total: this.engines.size }, 'EngineRegistry: registered engine')
  }

  unregister(name: string): boolean {
    return this.engines.delete(name)
  }

  get(name: string): EngineContract | null {
    return this.engines.get(name) ?? null
  }

  has(name: string): boolean {
    return this.engines.has(name)
  }

  list(): string[] {
    return Array.from(this.engines.keys()).sort()
  }

  size(): number {
    return this.engines.size
  }

  async health(): Promise<RegistryHealth> {
    const entries = Array.from(this.engines.entries())
    const results = await Promise.all(
      entries.map(async ([name, engine]): Promise<[string, HealthStatus]> => {
        try {
          const status = await engine.health()
          return [name, status]
        } catch (err) {
          return [name, { healthy: false, error: err instanceof Error ? err.message : String(err) }]
        }
      }),
    )
    const engineHealth: Record<string, HealthStatus> = {}
    for (const [name, status] of results) {
      engineHealth[name] = status
    }
    const overall = results.every(([, s]) => s.healthy)
    return { overall, engines: engineHealth }
  }

  async initializeAll(): Promise<void> {
    for (const [name, engine] of this.engines) {
      try {
        await engine.initialize()
      } catch (err) {
        logger.error({ name, error: err instanceof Error ? err.message : String(err) }, 'EngineRegistry: initialize failed')
      }
    }
  }

  async shutdownAll(): Promise<void> {
    for (const [name, engine] of this.engines) {
      try {
        await engine.shutdown()
      } catch (err) {
        logger.error({ name, error: err instanceof Error ? err.message : String(err) }, 'EngineRegistry: shutdown failed')
      }
    }
  }

  clear(): void {
    this.engines.clear()
  }
}

export const engineRegistry = new EngineRegistryImpl()
export type EngineRegistry = EngineRegistryImpl
export type { EngineContract, HealthStatus } from './EngineContract'
