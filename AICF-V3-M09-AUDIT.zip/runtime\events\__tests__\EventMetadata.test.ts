// =============================================================================
// AICF V3 — EventMetadata + Envelope Tests (Sprint 21)
// =============================================================================
// Verifies:
//   - createEventMetadata() generates a UUID eventId
//   - createEventMetadata() fills all required fields
//   - createEventMetadata() includes optional durationMs when provided
//   - createEnvelope() wraps metadata + payload with version '1.0'
//   - runtimeVersion is the current AICF V3 version ('3.0.0')
//   - emittedAt is a parseable ISO timestamp
//   - each eventId is unique across multiple calls
// =============================================================================

import { describe, it, expect } from 'bun:test'
import {
  createEventMetadata,
  createEnvelope,
  RUNTIME_VERSION,
  type EventMetadata,
  type RuntimeEventEnvelope,
} from '../EventMetadata'

describe('createEventMetadata', () => {
  it('generates a UUID eventId', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
    })
    // UUIDv4 string format: 8-4-4-4-12 hex digits
    expect(md.eventId).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
  })

  it('generates a unique eventId on every call', () => {
    const ids = new Set<string>()
    for (let i = 0; i < 100; i++) {
      const md = createEventMetadata({
        correlationId: 'cor-1',
        requestId: 'req-1',
        operation: 'chat',
        pipelineStage: 'Policy',
        stageOrder: 4,
      })
      ids.add(md.eventId)
    }
    expect(ids.size).toBe(100)
  })

  it('fills all required fields', () => {
    const md: EventMetadata = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
    })

    expect(md.correlationId).toBe('cor-1')
    expect(md.requestId).toBe('req-1')
    expect(md.operation).toBe('chat')
    expect(md.pipelineStage).toBe('Policy')
    expect(md.stageOrder).toBe(4)
    expect(md.runtimeVersion).toBe(RUNTIME_VERSION)
    expect(md.runtimeVersion).toBe('3.0.0')
    expect(typeof md.emittedAt).toBe('string')
    expect(md.emittedAt.length).toBeGreaterThan(0)
  })

  it('emittedAt is a parseable ISO timestamp', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
    })
    const parsed = new Date(md.emittedAt)
    expect(parsed.toString()).not.toBe('Invalid Date')
    // ISO format check
    expect(md.emittedAt).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)
  })

  it('includes durationMs when provided', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
      durationMs: 42,
    })
    expect(md.durationMs).toBe(42)
  })

  it('omits durationMs (undefined) when not provided', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
    })
    expect(md.durationMs).toBeUndefined()
  })
})

describe('createEnvelope', () => {
  it('wraps metadata + payload with version 1.0', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Policy',
      stageOrder: 4,
    })
    const payload = { allowed: true, reason: 'ok' }
    const envelope: RuntimeEventEnvelope<typeof payload> = createEnvelope(md, payload)

    expect(envelope.version).toBe('1.0')
    expect(envelope.metadata).toBe(md)
    expect(envelope.payload).toBe(payload)
  })

  it('preserves the payload reference for unknown payloads', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Routing',
      stageOrder: 6,
    })
    const payload = { provider: 'litellm', model: 'gpt-4o' } as unknown
    const envelope = createEnvelope(md, payload)

    expect(envelope.payload).toBe(payload)
  })

  it('version is always the literal "1.0"', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Routing',
      stageOrder: 6,
    })
    for (let i = 0; i < 5; i++) {
      const envelope = createEnvelope(md, { i })
      expect(envelope.version).toBe('1.0')
    }
  })

  it('carries the stageOrder through to the envelope metadata', () => {
    const md = createEventMetadata({
      correlationId: 'cor-1',
      requestId: 'req-1',
      operation: 'chat',
      pipelineStage: 'Execution',
      stageOrder: 9,
    })
    const envelope = createEnvelope(md, { success: true })
    expect(envelope.metadata.stageOrder).toBe(9)
  })
})
