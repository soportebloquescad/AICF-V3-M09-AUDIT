// =============================================================================
// AICF V3 — Sprint 4 — ArtifactStorage (Filesystem Persistence)
// =============================================================================
// Persists RegisteredArtifacts to the filesystem under
// `storage/artifacts/{courseId}/{artifactId}.json`. Each file is a JSON
// envelope containing the artifact metadata plus its content (text as
// UTF-8 string, binary as base64).
//
// This is the persistent backing store for the in-memory ArtifactRegistry.
// A future sprint can wire the registry to use this storage as its
// persistence layer (save-on-write + load-on-miss).
// =============================================================================

import { promises as fs } from 'node:fs'
import path from 'node:path'
import type { RegisteredArtifact } from './ArtifactRegistry'
import { logger } from '@/lib/ai/logger'

/**
 * On-disk envelope for a single artifact.
 */
interface ArtifactEnvelope {
  artifact: Omit<RegisteredArtifact, 'content'>
  /** Text content as UTF-8 string (set when content is a string). */
  textContent: string | null
  /** Binary content as base64 (set when content is a Buffer). */
  base64Content: string | null
}

/**
 * Filesystem-backed artifact storage.
 */
export class ArtifactStorage {
  private readonly rootDir: string

  constructor(rootDir: string = 'storage/artifacts') {
    this.rootDir = path.resolve(process.cwd(), rootDir)
  }

  /**
   * Save a single artifact to disk. Returns the path written.
   */
  async save(artifact: RegisteredArtifact): Promise<string> {
    const dir = path.join(this.rootDir, artifact.courseId)
    await fs.mkdir(dir, { recursive: true })
    const filePath = path.join(dir, `${artifact.id}.json`)

    const envelope: ArtifactEnvelope = {
      artifact: {
        id: artifact.id,
        courseId: artifact.courseId,
        type: artifact.type,
        name: artifact.name,
        mimeType: artifact.mimeType,
        sizeBytes: artifact.sizeBytes,
        producedBy: artifact.producedBy,
        registeredAt: artifact.registeredAt,
      },
      textContent: typeof artifact.content === 'string' ? artifact.content : null,
      base64Content: artifact.content instanceof Buffer
        ? artifact.content.toString('base64')
        : null,
    }

    await fs.writeFile(filePath, JSON.stringify(envelope, null, 2), 'utf-8')
    logger.debug(
      { artifactId: artifact.id, courseId: artifact.courseId, path: filePath },
      'ArtifactStorage: saved',
    )
    return filePath
  }

  /**
   * Load a single artifact by id. Returns null if not found.
   */
  async load(courseId: string, artifactId: string): Promise<RegisteredArtifact | null> {
    const filePath = path.join(this.rootDir, courseId, `${artifactId}.json`)
    try {
      const raw = await fs.readFile(filePath, 'utf-8')
      return this.deserialize(raw)
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return null
      throw err
    }
  }

  /**
   * Load all artifacts for a course. Returns [] if the course directory
   * does not exist or contains no artifacts.
   */
  async loadByCourse(courseId: string): Promise<RegisteredArtifact[]> {
    const dir = path.join(this.rootDir, courseId)
    try {
      const files = await fs.readdir(dir)
      const out: RegisteredArtifact[] = []
      for (const file of files) {
        if (!file.endsWith('.json')) continue
        const raw = await fs.readFile(path.join(dir, file), 'utf-8')
        const artifact = this.deserialize(raw)
        if (artifact) out.push(artifact)
      }
      return out
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return []
      throw err
    }
  }

  /**
   * Delete a single artifact. Returns true if deleted, false if not found.
   */
  async delete(courseId: string, artifactId: string): Promise<boolean> {
    const filePath = path.join(this.rootDir, courseId, `${artifactId}.json`)
    try {
      await fs.unlink(filePath)
      return true
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return false
      throw err
    }
  }

  /**
   * List artifact ids for a course. Returns [] if the course directory
   * does not exist.
   */
  async listByCourse(courseId: string): Promise<string[]> {
    const dir = path.join(this.rootDir, courseId)
    try {
      const files = await fs.readdir(dir)
      return files
        .filter((f) => f.endsWith('.json'))
        .map((f) => f.replace(/\.json$/, ''))
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return []
      throw err
    }
  }

  /**
   * List all (courseId, artifactId) pairs across all courses.
   */
  async list(): Promise<Array<{ courseId: string; artifactId: string }>> {
    try {
      const courseDirs = await fs.readdir(this.rootDir)
      const out: Array<{ courseId: string; artifactId: string }> = []
      for (const courseId of courseDirs) {
        const stat = await fs.stat(path.join(this.rootDir, courseId))
        if (!stat.isDirectory()) continue
        const ids = await this.listByCourse(courseId)
        for (const artifactId of ids) {
          out.push({ courseId, artifactId })
        }
      }
      return out
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return []
      throw err
    }
  }

  /**
   * Save multiple artifacts in parallel.
   */
  async saveAll(artifacts: RegisteredArtifact[]): Promise<string[]> {
    const paths = await Promise.all(artifacts.map((a) => this.save(a)))
    return paths
  }

  private deserialize(raw: string): RegisteredArtifact | null {
    try {
      const envelope = JSON.parse(raw) as ArtifactEnvelope
      const content: string | Buffer = envelope.base64Content !== null
        ? Buffer.from(envelope.base64Content, 'base64')
        : envelope.textContent ?? ''
      return {
        ...envelope.artifact,
        content,
      }
    } catch (err) {
      logger.warn(
        { error: err instanceof Error ? err.message : String(err) },
        'ArtifactStorage: failed to deserialize envelope',
      )
      return null
    }
  }
}

/**
 * Singleton ArtifactStorage rooted at `storage/artifacts`.
 */
let singleton: ArtifactStorage | null = null

export function getArtifactStorage(): ArtifactStorage {
  if (!singleton) {
    singleton = new ArtifactStorage()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetArtifactStorage(): void {
  singleton = null
}
