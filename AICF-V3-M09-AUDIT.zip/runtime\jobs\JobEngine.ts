// =============================================================================
// AICF V3 — Sprint 3 RC45 — Job Engine
// =============================================================================
// In-memory job queue for course generation. Each job runs the CoursePipeline
// asynchronously and tracks per-stage progress.
//
// REUSES: CoursePipeline (existing), AIFactory (existing), ExportManager (existing)
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { getCoursePipeline } from '../pipeline/CoursePipeline'
import type { CoursePipelineResult } from '../pipeline/CoursePipeline'
import type { GenerateCourseInput } from '../course/AIFactory'
import type { CourseResult } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

/** Job status. */
export type JobStatus = 'queued' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled'

/** Stage status. */
export type StageStatus = 'pending' | 'running' | 'completed' | 'failed'

/** Per-stage progress. */
export interface StageProgress {
  status: StageStatus
  progress: number // 0-100
}

/** A course generation job. */
export interface CourseJob {
  id: string
  status: JobStatus
  progress: number // 0-100
  input: GenerateCourseInput
  stages: {
    research: StageProgress
    architecture: StageProgress
    modules: StageProgress
    lessons: StageProgress
    assessment: StageProgress
    slides: StageProgress
    guides: StageProgress
    qa: StageProgress
    audit: StageProgress
    export: StageProgress
  }
  createdAt: string
  updatedAt: string
  completedAt: string | null
  result: CourseResult | null
  error: string | null
  qualityScore: number | null
  courseId: string | null
}

/** The 10 pipeline stages in order. */
export const JOB_STAGES = [
  'research', 'architecture', 'modules', 'lessons', 'assessment',
  'slides', 'guides', 'qa', 'audit', 'export',
] as const

export type JobStage = typeof JOB_STAGES[number]

/** Factory: creates a fresh job with all stages pending. */
function createJob(id: string, input: GenerateCourseInput): CourseJob {
  const now = new Date().toISOString()
  const emptyStage: StageProgress = { status: 'pending', progress: 0 }
  return {
    id,
    status: 'queued',
    progress: 0,
    input,
    stages: {
      research: { ...emptyStage },
      architecture: { ...emptyStage },
      modules: { ...emptyStage },
      lessons: { ...emptyStage },
      assessment: { ...emptyStage },
      slides: { ...emptyStage },
      guides: { ...emptyStage },
      qa: { ...emptyStage },
      audit: { ...emptyStage },
      export: { ...emptyStage },
    },
    createdAt: now,
    updatedAt: now,
    completedAt: null,
    result: null,
    error: null,
    qualityScore: null,
    courseId: null,
  }
}

/**
 * The Job Engine — manages course generation jobs in memory.
 *
 * Each job runs the CoursePipeline asynchronously. The engine tracks
 * per-stage progress by mapping the 7 business stages from the pipeline
 * to the 10 job stages.
 */
export class JobEngine {
  private readonly jobs = new Map<string, CourseJob>()
  private readonly log = logger.child({ component: 'JobEngine' })

  /**
   * Creates and starts a new job.
   * @returns The job ID.
   */
  create(input: GenerateCourseInput): string {
    const id = `job-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
    const job = createJob(id, input)
    this.jobs.set(id, job)
    this.log.info({ jobId: id, topic: input.topic }, 'JobEngine: job created')
    // Start asynchronously
    this.run(id)
    return id
  }

  /**
   * Returns a job by ID, or null.
   */
  get(id: string): CourseJob | null {
    return this.jobs.get(id) ?? null
  }

  /**
   * Lists all jobs (newest first).
   */
  list(): CourseJob[] {
    return Array.from(this.jobs.values()).reverse()
  }

  /**
   * Cancels a job (if running).
   */
  cancel(id: string): boolean {
    const job = this.jobs.get(id)
    if (!job) return false
    if (job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled') return false
    job.status = 'cancelled'
    job.updatedAt = new Date().toISOString()
    job.completedAt = job.updatedAt
    this.log.info({ jobId: id }, 'JobEngine: job cancelled')
    return true
  }

  /**
   * Runs a job asynchronously. Updates stages as the pipeline progresses.
   */
  private async run(id: string): Promise<void> {
    const job = this.jobs.get(id)
    if (!job) return

    job.status = 'running'
    job.updatedAt = new Date().toISOString()
    this.log.info({ jobId: id }, 'JobEngine: job started')

    try {
      // Mark all stages as running sequentially as the pipeline progresses.
      // The CoursePipeline runs synchronously (17 stages internally), so we
      // simulate per-stage progress by updating stages before/after the run.
      for (const stage of JOB_STAGES) {
        if (job.status === 'cancelled' as JobStatus) return
        ;(job.stages[stage] as StageProgress).status = 'running'
        ;(job.stages[stage] as StageProgress).progress = 50
        job.progress = Math.round((JOB_STAGES.indexOf(stage) / JOB_STAGES.length) * 100)
        job.updatedAt = new Date().toISOString()
      }

      // Run the actual pipeline
      const pipeline = getCoursePipeline()
      const result: CoursePipelineResult = await pipeline.run(job.input)

      // Mark stages complete based on pipeline result
      if (result.success) {
        for (const stage of JOB_STAGES) {
          ;(job.stages[stage] as StageProgress).status = 'completed'
          ;(job.stages[stage] as StageProgress).progress = 100
        }
        job.status = 'completed'
        job.progress = 100
        job.result = result.courseResult
        job.courseId = result.courseId
        job.qualityScore = result.courseResult.qualityReport?.overallScore ?? 0
        job.completedAt = new Date().toISOString()
        this.log.info({ jobId: id, courseId: result.courseId, qualityScore: job.qualityScore }, 'JobEngine: job completed')
      } else {
        job.status = 'failed'
        job.error = result.error ?? 'Unknown error'
        job.completedAt = new Date().toISOString()
        this.log.error({ jobId: id, error: job.error }, 'JobEngine: job failed')
      }
      job.updatedAt = new Date().toISOString()
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      job.status = 'failed'
      job.error = msg
      job.completedAt = new Date().toISOString()
      job.updatedAt = job.completedAt
      this.log.error({ jobId: id, error: msg }, 'JobEngine: job threw')
    }
  }
}

// --- Global singleton ---
const GLOBAL_JOB_ENGINE_KEY = '__AICF_JOB_ENGINE__'

export function getGlobalJobEngine(): JobEngine {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_JOB_ENGINE_KEY]) {
    g[GLOBAL_JOB_ENGINE_KEY] = new JobEngine()
  }
  return g[GLOBAL_JOB_ENGINE_KEY] as JobEngine
}
