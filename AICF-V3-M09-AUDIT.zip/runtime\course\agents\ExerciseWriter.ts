// =============================================================================
// AICF V3 — Exercise Writer Agent
// =============================================================================
// Writes practice exercises for each lesson. Reads `context.lessons`
// (produced by LessonWriter) to decide which lessons to cover. Each
// lesson receives 2-3 exercises spanning multiple types: short-answer,
// application, reflection, and (where relevant) code-based tasks.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, normalizeLevel, readContext } from './agentUtils'

export interface ExerciseWriterDeps {
  aiAdapter: AIAdapter | null
}

type ExerciseType = 'short-answer' | 'application' | 'reflection' | 'multiple-choice'

interface Exercise {
  type: ExerciseType
  question: string
  answer?: string
}

interface LessonExercises {
  lessonTitle: string
  exercises: Exercise[]
}

interface ExercisesPayload {
  exercises: LessonExercises[]
}

interface LessonShape {
  title: string
  content?: string
}

const EXERCISE_TYPES: ExerciseType[] = ['short-answer', 'application', 'reflection']

export class ExerciseWriter implements Agent {
  public readonly name = 'exercise-writer'

  constructor(private readonly deps: ExerciseWriterDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const lessons = collectLessons(input)
      const ai = this.deps.aiAdapter
      const result: LessonExercises[] = []

      for (const lesson of lessons) {
        const aiResult = await callAI(ai, buildPrompt(input, lesson), {
          systemPrompt:
            'You are an instructional exercise designer. Respond with valid JSON only.',
          temperature: 0.5,
          maxTokens: 900,
        })
        let exercises: Exercise[]
        if (aiResult.ok && aiResult.content) {
          const parsed = extractJSON<{ exercises?: unknown[] }>(aiResult.content)
          exercises = coerceExercises(parsed)
          if (exercises.length === 0) {
            exercises = fallbackExercises(input, lesson)
          }
        } else {
          exercises = fallbackExercises(input, lesson)
        }
        result.push({ lessonTitle: lesson.title, exercises })
      }

      return {
        agentName: this.name,
        result: { exercises: result },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function collectLessons(input: AgentInput): LessonShape[] {
  const lessons = readContext<LessonShape[]>(input.context, 'lessons')
  if (Array.isArray(lessons) && lessons.length > 0) {
    return lessons.filter((l) => l && typeof l.title === 'string').slice(0, 24)
  }
  // Fall back to a small set derived from the topic.
  const count = Math.max(3, Math.min(5, (input.moduleCount || 3)))
  const out: LessonShape[] = []
  for (let i = 0; i < count; i++) {
    out.push({ title: `Lesson ${i + 1}: ${input.topic} - Part ${i + 1}` })
  }
  return out
}

function buildPrompt(input: AgentInput, lesson: LessonShape): string {
  return [
    `Write practice exercises for the lesson titled "${lesson.title}".`,
    `Course topic: "${input.topic}". Audience: ${input.audience}. Level: ${input.level}.`,
    `Lesson content excerpt: ${(lesson.content ?? '').slice(0, 400)}`,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "exercises": [`,
    `    {`,
    `      "type": "short-answer" | "application" | "reflection" | "multiple-choice",`,
    `      "question": string,`,
    `      "answer": string   // optional for reflection`,
    `    }`,
    `  ]   // 2-3 exercises`,
    `}`,
  ].join('\n')
}

function coerceExercises(parsed: { exercises?: unknown[] } | null): Exercise[] {
  if (!parsed || !Array.isArray(parsed.exercises)) return []
  const out: Exercise[] = []
  for (const raw of parsed.exercises) {
    if (!raw || typeof raw !== 'object') continue
    const r = raw as Record<string, unknown>
    const type = r.type
    const question = r.question
    const answer = r.answer
    if (
      typeof type === 'string' &&
      EXERCISE_TYPES.includes(type as ExerciseType) &&
      typeof question === 'string' &&
      question.length > 0
    ) {
      out.push({
        type: type as ExerciseType,
        question,
        answer: typeof answer === 'string' && answer.length > 0 ? answer : undefined,
      })
    }
  }
  return out.slice(0, 4)
}

function fallbackExercises(input: AgentInput, lesson: LessonShape): Exercise[] {
  const topic = input.topic
  const level = normalizeLevel(input.level)
  return [
    {
      type: 'short-answer',
      question: `In your own words, define the central concept of "${lesson.title}" within ${topic}.`,
      answer: `A concise definition that names the concept, its purpose, and how it relates to the broader field of ${topic}, appropriate for a ${level} learner.`,
    },
    {
      type: 'application',
      question: `Describe a realistic scenario where you would apply the ideas from "${lesson.title}". Walk through the steps you would take.`,
      answer: `Identify the relevant inputs, select the appropriate technique, apply it step by step, and verify the result against expected outcomes.`,
    },
    {
      type: 'reflection',
      question: `What was the most surprising or counterintuitive idea in this lesson, and why?`,
    },
  ]
}
