// =============================================================================
// AICF V3 — Lesson Writer Agent
// =============================================================================
// Writes substantive lesson content for each lesson in the curriculum.
// Reads `context.curriculum` (produced by CurriculumArchitect) to decide
// which lessons to write; if absent, generates a minimal set from the
// topic. Each lesson includes overview, objectives, key concepts,
// detailed explanation, worked examples, common pitfalls, and summary.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, normalizeLevel, readContext } from './agentUtils'

export interface LessonWriterDeps {
  aiAdapter: AIAdapter | null
}

interface LessonItem {
  title: string
  content: string
}

interface LessonsPayload {
  lessons: LessonItem[]
}

interface CurriculumShape {
  modules?: Array<{
    title: string
    lessons?: Array<{ title: string }>
  }>
}

export class LessonWriter implements Agent {
  public readonly name = 'lesson-writer'

  constructor(private readonly deps: LessonWriterDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const targets = collectLessonTargets(input)
      const ai = this.deps.aiAdapter
      const lessons: LessonItem[] = []

      // Generate content lesson by lesson. We call the AI once per lesson
      // to keep prompts focused and responses parseable.
      for (const target of targets) {
        const aiResult = await callAI(ai, buildLessonPrompt(input, target), {
          systemPrompt:
            'You are an expert instructional writer. Respond with valid JSON only.',
          temperature: 0.5,
          maxTokens: 1500,
        })
        if (aiResult.ok && aiResult.content) {
          const parsed = extractJSON<{ content?: string }>(aiResult.content)
          if (parsed && typeof parsed.content === 'string' && parsed.content.length > 80) {
            lessons.push({ title: target.lessonTitle, content: parsed.content })
            continue
          }
        }
        lessons.push({
          title: target.lessonTitle,
          content: fallbackLessonContent(input, target),
        })
      }

      return {
        agentName: this.name,
        result: { lessons },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

interface LessonTarget {
  moduleTitle: string
  lessonTitle: string
  index: number
}

function collectLessonTargets(input: AgentInput): LessonTarget[] {
  const curriculum = readContext<CurriculumShape>(input.context, 'curriculum')
  const targets: LessonTarget[] = []
  if (curriculum?.modules) {
    let idx = 0
    for (const mod of curriculum.modules) {
      for (const lesson of mod.lessons ?? []) {
        targets.push({
          moduleTitle: mod.title ?? input.topic,
          lessonTitle: lesson.title ?? `Lesson ${idx + 1}`,
          index: idx,
        })
        idx += 1
      }
    }
  }
  if (targets.length === 0) {
    // No curriculum available: synthesize a small set from the topic.
    const count = Math.max(3, Math.min(6, (input.moduleCount || 3) * 2))
    for (let i = 0; i < count; i++) {
      targets.push({
        moduleTitle: input.topic,
        lessonTitle: `Lesson ${i + 1}: ${lessonLabel(i, input.topic)}`,
        index: i,
      })
    }
  }
  // Cap the number of lessons to keep generation tractable.
  return targets.slice(0, 24)
}

function lessonLabel(i: number, topic: string): string {
  const labels = [
    `Introduction to ${topic}`,
    `Core Concepts of ${topic}`,
    `Applied Practice in ${topic}`,
    `Advanced Topics in ${topic}`,
    `Integration and Synthesis`,
    `Capstone Review`,
  ]
  return labels[i % labels.length]
}

function buildLessonPrompt(input: AgentInput, target: LessonTarget): string {
  return [
    `Write the full content for a lesson titled "${target.lessonTitle}".`,
    `It belongs to "${target.moduleTitle}" in the course on "${input.topic}".`,
    `Audience: ${input.audience}. Level: ${input.level}. Locale: ${input.locale}.`,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "content": string   // Markdown, 400-800 words, with sections: Overview,`,
    `                     // Learning Objectives, Key Concepts, Detailed Explanation,`,
    `                     // Worked Examples, Common Pitfalls, Practice, Summary`,
    `}`,
  ].join('\n')
}

function fallbackLessonContent(input: AgentInput, target: LessonTarget): string {
  const topic = input.topic
  const level = normalizeLevel(input.level)
  const title = target.lessonTitle
  const moduleTitle = target.moduleTitle
  return [
    `# ${title}`,
    ``,
    `## Overview`,
    `This lesson is part of ${moduleTitle} in the ${topic} course. It is designed for ${level} learners and focuses on building a clear, applied understanding of the concepts below.`,
    ``,
    `## Learning Objectives`,
    `By the end of this lesson, you will be able to:`,
    `- Describe the key ideas of ${title}.`,
    `- Explain how ${title} relates to the broader study of ${topic}.`,
    `- Apply the core techniques in realistic scenarios.`,
    `- Recognize common pitfalls and how to avoid them.`,
    ``,
    `## Key Concepts`,
    `The lesson centers on ${title}. At a conceptual level, this involves understanding the foundational definitions, the relationships between key terms, and the procedures that translate theory into practice.`,
    ``,
    `Approach each concept by first establishing a clear definition, then examining a concrete example, and finally considering edge cases. This three-step pattern reinforces both retention and transfer to novel situations.`,
    ``,
    `## Detailed Explanation`,
    `${title} builds on prior material in ${moduleTitle}. The central idea is that small, well-understood components combine to form more complex capabilities. Mastery at the ${level} level requires fluency with both the individual components and their interactions.`,
    ``,
    `When you encounter a new situation, ask: which components are involved, how do they interact, and what constraints apply? This habit of structured analysis is the hallmark of a competent practitioner of ${topic}.`,
    ``,
    `## Worked Examples`,
    `1. **Basic example.** A straightforward application showing the core mechanism in isolation.`,
    `2. **Applied example.** A realistic scenario that combines multiple concepts from this lesson.`,
    `3. **Edge case.** A situation that reveals the limits of the basic approach and motivates more advanced techniques.`,
    ``,
    `## Common Pitfalls`,
    `- Treating related concepts as interchangeable when they have distinct meanings.`,
    `- Applying a technique outside its intended scope without checking assumptions.`,
    `- Skipping validation steps that catch mistakes early.`,
    ``,
    `## Practice`,
    `Pause and try to restate the key ideas in your own words. Then attempt the exercises that accompany this lesson. If you get stuck, revisit the Worked Examples above before reading the solution.`,
    ``,
    `## Summary`,
    `This lesson introduced ${title} as a foundational element of ${topic}. You should now be able to recognize, explain, and apply the key concepts. The next lesson will extend these ideas further.`,
  ].join('\n')
}
