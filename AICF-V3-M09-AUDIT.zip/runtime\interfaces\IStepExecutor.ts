// =============================================================================
// AICF V3 — Sprint 13+14 — Step Executor Interface
// =============================================================================
// Per-step execution contract. The workflow engine delegates each DAG node to
// an IStepExecutor that knows how to run a specific `WorkflowStepType`
// (chat / generate / validate / transform / conditional / action).
//
// Sprint 13+14 spec requirements covered:
//   - Uniform per-step input/output envelope (artifacts, tokens, cost)
//   - Provider / model attribution on every step result for audit
//   - `canHandle(stepType)` for executor dispatch by step type
// =============================================================================

import type {
  WorkflowExecution,
  WorkflowStepDefinition,
  WorkflowContext,
  WorkflowArtifact,
  TokenUsage,
} from '@/lib/runtime/contracts/workflow'

/** Inputs handed to an IStepExecutor for a single step run. */
export interface StepExecutionContext {
  /** The mutable execution envelope (executor may read / update step state). */
  execution: WorkflowExecution
  /** The static step definition being executed. */
  step: WorkflowStepDefinition
  /** The per-execution runtime context. */
  ctx: WorkflowContext
  /** Resolved variable bindings visible to this step. */
  variables: Record<string, unknown>
  /** Artifacts produced by upstream steps (read-only view). */
  artifacts: WorkflowArtifact[]
}

/** Result of executing a single step. */
export interface StepExecutionResult {
  /** Whether the step completed without error. */
  ok: boolean
  /** Produced output variables (logical name -> value). */
  output: Record<string, unknown>
  /** Artifacts produced by this step. */
  artifacts: WorkflowArtifact[]
  /** Error message when `ok === false`. */
  error?: string
  /** Wall-clock duration in milliseconds. */
  durationMs: number
  /** Token usage reported by the underlying provider, if applicable. */
  tokensUsed?: TokenUsage
  /** Cost incurred by this step (platform currency units), if applicable. */
  cost?: number
  /** Provider name that handled the step, if applicable. */
  provider?: string
  /** Model name that handled the step, if applicable. */
  model?: string
}

/**
 * Executes a single workflow step. Implementations are dispatched by
 * `canHandle(stepType)`; the engine selects the first registered executor
 * that claims the step type.
 */
export interface IStepExecutor {
  /** Execute the step described by `context`. */
  execute(context: StepExecutionContext): Promise<StepExecutionResult>
  /** Whether this executor can handle the given step type. */
  canHandle(stepType: string): boolean
}
