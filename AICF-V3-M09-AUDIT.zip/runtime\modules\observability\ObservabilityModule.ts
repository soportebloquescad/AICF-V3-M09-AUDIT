// =============================================================================
// AICF V3 — Observability Module (Sprint 15: Full Lifecycle)
// =============================================================================
// Implements the RuntimeModule interface with full lifecycle:
//   - initialize(): idempotent, marks ready
//   - health(): returns ModuleHealth with metrics
//   - dispose(): releases resources
//   - shutdown(): graceful shutdown
//   - getMetrics(): returns per-module metrics
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { OBSERVABILITY_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { ObservabilityMetricsCollector } from './metrics/MetricsCollector'
import type { TraceCollector } from './trace/TraceCollector'
import type { LoggerProvider } from './logger/LoggerProvider'
import { logger } from '@/lib/ai/logger'

/**
 * Plugin metadata for the Observability module (M11).
 * Sprint 17: declares capabilities, contracts, events, priority, mission.
 */
export const OBSERVABILITY_MODULE_METADATA: PluginMetadata = {
  id: 'observability',
  name: 'Observability',
  description: 'Metrics collection, distributed tracing, and logger management',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M11',
  priority: 5,
  dependencies: [],
  capabilities: [...OBSERVABILITY_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'metric.recorded',
    'trace.span.started',
    'trace.span.ended',
  ],
}

/**
 * Runtime module that exposes the observability subsystem. Owns a
 * metrics collector, a trace collector, and a logger provider, and
 * delegates health/status queries to them.
 */
export class ObservabilityModule implements RuntimeModule {
  public readonly name = 'observability'
  public readonly version = '1.0.0'

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(
    private readonly metrics: ObservabilityMetricsCollector,
    private readonly trace: TraceCollector,
    private readonly loggerProvider: LoggerProvider,
  ) {}

  public async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
    logger.info({ initLatencyMs: this.initLatencyMs }, 'ObservabilityModule: initialized')
  }

  public isReady(): boolean {
    return this.initialized && !this.disposed
  }

  public getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        metricsCount: this.metrics.getMetricCount(),
        traceCount: this.trace.getTraceCount(),
        startupTime: this.startupTime,
        lastInitialization: this.lastInitialization,
      },
    }
  }

  public async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  public getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  public async dispose(): Promise<void> {
    this.disposed = true
    logger.info('ObservabilityModule: disposed')
  }

  public async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('ObservabilityModule: shut down')
  }

  /**
   * Gets the plugin metadata (Sprint 17).
   */
  public getMetadata(): PluginMetadata {
    return OBSERVABILITY_MODULE_METADATA
  }

  public getMetricsCollector(): ObservabilityMetricsCollector {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
    return this.metrics
  }

  public getTrace(): TraceCollector {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
    return this.trace
  }

  public getLoggerProvider(): LoggerProvider {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
    return this.loggerProvider
  }

  public getHealthSnapshot(): Record<string, unknown> {
    return {
      timestamp: Date.now(),
      module: this.name,
      version: this.version,
      ready: this.isReady(),
      metrics: this.metrics.snapshot(),
      traces: this.trace.getAllTraces(),
      traceCount: this.trace.getTraceCount(),
      spanCount: this.trace.getSpanCount(),
      logs: this.loggerProvider.getLogHistory(),
    }
  }
}
