// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — CompensationHandler Tests
// =============================================================================
// Tests for the CompensationHandler (Saga Pattern). Verifies backward walk
// through executed steps, skipping steps without a compensation action,
// the `'compensated'` status transition, the lifecycle events emitted, and
// best-effort error isolation between compensation steps.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { CompensationHandler } from '../engine/CompensationHandler'
import { InMemoryEventBus } from '../events/EventBus'
import type {
  WorkflowExecution,
  WorkflowStepDefinition,
  WorkflowContext,
  StepExecution,
} from '@/lib/runtime/contracts/workflow'
import type {
  IStepExecutor,
  StepExecutionContext,
  StepExecutionResult,
  IEventBus,
} from '@/lib/runtime/interfaces'

/** Mock IStepExecutor that records calls and returns a configurable result. */
class MockStepExecutor implements IStepExecutor {
  calls: StepExecutionContext[] = []
  // Per-step-id response: 'ok' | 'fail' | undefined (default 'ok').
  responses: Record<string, 'ok' | 'fail'> = {}

  async execute(context: StepExecutionContext): Promise<StepExecutionResult> {
    this.calls.push(context)
    const stepId = context.step.id
    if (this.responses[stepId] === 'fail') {
      return {
        ok: false,
        output: {},
        artifacts: [],
        durationMs: 1,
        error: `compensation failed for ${stepId}`,
      }
    }
    return { ok: true, output: {}, artifacts: [], durationMs: 1 }
  }

  canHandle(_stepType: string): boolean {
    return true
  }
}

/** Build a step definition. */
function step(
  id: string,
  opts: { compensate?: boolean; provider?: string } = {},
): WorkflowStepDefinition {
  const base: WorkflowStepDefinition = {
    id,
    name: id,
    type: 'action',
    provider: opts.provider ?? 'chat',
    config: {},
    inputs: {},
    outputs: {},
    dependsOn: [],
    retries: 0,
  }
  if (opts.compensate) {
    base.compensation = { type: 'rollback', config: { ref: id } }
  }
  return base
}

/** Build an execution envelope with completed steps. */
function makeExecution(
  stepDefs: WorkflowStepDefinition[],
  completedStepIds: string[],
  failedStepId: string,
): WorkflowExecution {
  const steps: Record<string, StepExecution> = {}
  for (const def of stepDefs) {
    const isFailed = def.id === failedStepId
    steps[def.id] = {
      stepId: def.id,
      status: isFailed ? 'failed' : 'completed',
      attempts: 1,
      artifacts: [],
      output: { ref: def.id },
    }
  }
  const completed = completedStepIds
  return {
    executionId: 'exec-1',
    workflowId: 'wf-test',
    workflowVersion: '1.0.0',
    status: 'compensating',
    steps,
    inputs: { topic: 'X', __workflow_steps: stepDefs },
    checkpoints: [],
    startedAt: Date.now(),
    updatedAt: Date.now(),
    correlationId: 'corr-1',
    dryRun: false,
  }
}

/** Build a minimal WorkflowContext for compensation. */
function makeCtx(): WorkflowContext {
  return {
    correlationId: 'corr-1',
    executionId: 'exec-1',
    locale: 'en',
    cost: 0,
    tokens: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
    startedAt: Date.now(),
    variables: {},
    dryRun: false,
  }
}

describe('CompensationHandler', () => {
  let eventBus: IEventBus
  let executor: MockStepExecutor
  let handler: CompensationHandler

  beforeEach(() => {
    eventBus = new InMemoryEventBus()
    executor = new MockStepExecutor()
    handler = new CompensationHandler(eventBus, executor)
  })

  it('compensate walks backwards through executed steps', async () => {
    const stepDefs = [
      step('a', { compensate: true }),
      step('b', { compensate: true }),
      step('c', { compensate: true }),
    ]
    const execution = makeExecution(stepDefs, ['a', 'b'], 'c')
    await handler.compensate(execution, 'c', makeCtx())
    // 'c' is the failed step (exclusive); only 'a' and 'b' are compensated.
    // Walk backwards: b, then a.
    expect(executor.calls.length).toBe(2)
    expect(executor.calls[0].step.id).toBe('b')
    expect(executor.calls[1].step.id).toBe('a')
  })

  it('steps without a compensation action are skipped', async () => {
    const stepDefs = [
      step('a', { compensate: true }),
      step('b', { compensate: false }),
      step('c', { compensate: true }),
    ]
    const execution = makeExecution(stepDefs, ['a', 'b'], 'c')
    await handler.compensate(execution, 'c', makeCtx())
    // Only 'a' and 'c' have compensation; 'c' is the failed step (excluded),
    // so only 'a' is compensated.
    expect(executor.calls.length).toBe(1)
    expect(executor.calls[0].step.id).toBe('a')
  })

  it("steps get status 'compensated' after successful compensation", async () => {
    const stepDefs = [
      step('a', { compensate: true }),
      step('b', { compensate: true }),
    ]
    const execution = makeExecution(stepDefs, ['a'], 'b')
    await handler.compensate(execution, 'b', makeCtx())
    expect(execution.steps['a'].status).toBe('compensated')
    expect(execution.steps['a'].completedAt).toBeDefined()
  })

  it("emits 'workflow.compensation.started' and '.completed' events", async () => {
    const stepDefs = [step('a', { compensate: true })]
    const execution = makeExecution(stepDefs, ['a'], 'b-fail')
    // Add a 'b-fail' step record so the failedStepId is found.
    execution.steps['b-fail'] = {
      stepId: 'b-fail',
      status: 'failed',
      attempts: 1,
      artifacts: [],
      output: {},
    }
    const events: string[] = []
    eventBus.subscribeAll((e) => { events.push(e.type) })
    await handler.compensate(execution, 'b-fail', makeCtx())
    expect(events).toContain('workflow.compensation.started')
    expect(events).toContain('workflow.compensation.completed')
    // 'started' must come before 'completed'.
    expect(events.indexOf('workflow.compensation.started')).toBeLessThan(
      events.indexOf('workflow.compensation.completed'),
    )
  })

  it('compensation error in one step does NOT stop compensation of others', async () => {
    const stepDefs = [
      step('a', { compensate: true }),
      step('b', { compensate: true }),
      step('c', { compensate: true }),
    ]
    const execution = makeExecution(stepDefs, ['a', 'b'], 'c')
    // 'b' (compensated first) fails; 'a' should still be attempted.
    executor.responses['b'] = 'fail'
    await handler.compensate(execution, 'c', makeCtx())
    // Both 'b' and 'a' should have been called (backwards: b, then a).
    expect(executor.calls.length).toBe(2)
    expect(executor.calls[0].step.id).toBe('b')
    expect(executor.calls[1].step.id).toBe('a')
    // 'b' did not transition to 'compensated' (the call failed); 'a' did.
    expect(execution.steps['b'].status).toBe('completed')
    expect(execution.steps['a'].status).toBe('compensated')
    // The 'workflow.compensation.completed' event is still emitted.
    const history = await eventBus.getHistory()
    expect(
      history.some((e) => e.type === 'workflow.compensation.completed'),
    ).toBe(true)
  })
})
