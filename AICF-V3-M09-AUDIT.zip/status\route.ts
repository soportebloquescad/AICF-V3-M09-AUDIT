// =============================================================================
// AICF V3 — Status API Endpoint
// Mission 23: Platform Environment Integration & Production Readiness
// =============================================================================
// Returns the health status of all platform services.
// =============================================================================

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  const status = {
    database: 'unknown' as string,
    litellm: 'unknown' as string,
    n8n: 'unknown' as string,
    openwebui: 'unknown' as string,
  }

  // Check PostgreSQL
  try {
    await db.$queryRaw`SELECT 1`
    status.database = 'connected'
  } catch {
    status.database = 'disconnected'
  }

  // Check LiteLLM
  try {
    const litellmUrl = process.env.LITELLM_BASE_URL || 'http://localhost:4000'
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${litellmUrl}/health`, {
      signal: controller.signal,
    })
    clearTimeout(timeout)
    status.litellm = res.ok ? 'healthy' : 'unhealthy'
  } catch {
    status.litellm = 'unhealthy'
  }

  // Check n8n
  try {
    const n8nUrl = process.env.N8N_BASE_URL || 'http://localhost:5678'
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${n8nUrl}/healthz`, {
      signal: controller.signal,
    })
    clearTimeout(timeout)
    status.n8n = res.ok ? 'available' : 'unavailable'
  } catch {
    status.n8n = 'unavailable'
  }

  // Check Open WebUI
  try {
    const owuiUrl = process.env.OPENWEBUI_BASE_URL || 'http://localhost:8080'
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(`${owuiUrl}/health`, {
      signal: controller.signal,
    })
    clearTimeout(timeout)
    status.openwebui = res.ok ? 'available' : 'unavailable'
  } catch {
    status.openwebui = 'unavailable'
  }

  // Fetch recent executions (if database is connected)
  let executions: Array<{ id: string; state: string; provider: string | null; startedAt: string | null }> = []
  if (status.database === 'connected') {
    try {
      const records = await db.execution.findMany({
        take: 20,
        orderBy: { createdAt: 'desc' },
        select: { id: true, state: true, provider: true, startedAt: true },
      })
      executions = records.map((e) => ({
        id: e.id,
        state: e.state,
        provider: e.provider,
        startedAt: e.startedAt?.toISOString() || null,
      }))
    } catch {
      // Table might not exist yet
    }
  }

  // Fetch recent generations
  let generations: Array<{ id: string; model: string; provider: string; totalTokens: number; cost: number; cached: boolean }> = []
  if (status.database === 'connected') {
    try {
      const records = await db.generationRecord.findMany({
        take: 20,
        orderBy: { createdAt: 'desc' },
        select: { id: true, model: true, provider: true, totalTokens: true, cost: true, cached: true },
      })
      generations = records.map((g) => ({
        id: g.id,
        model: g.model,
        provider: g.provider,
        totalTokens: g.totalTokens,
        cost: g.cost,
        cached: g.cached,
      }))
    } catch {
      // Table might not exist yet
    }
  }

  return NextResponse.json({ status, executions, generations })
}
