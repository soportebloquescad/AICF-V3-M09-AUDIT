// =============================================================================
// AICF V3 — Sprint 2 — Runtime Manifest
// =============================================================================
// Describes the manifest of runtime modules and their initialization order.
// =============================================================================

export interface ManifestModuleEntry {
  id: string
  enabled: boolean
  priority: number
  dependencies: string[]
}

export interface RuntimeManifest {
  modules: ManifestModuleEntry[]
}

export const runtimeManifest: RuntimeManifest = {
  modules: [
    { id: 'observability', enabled: true, priority: 5, dependencies: [] },
    { id: 'localization', enabled: true, priority: 5, dependencies: [] },
    { id: 'infrastructure', enabled: true, priority: 10, dependencies: [] },
    { id: 'workflow', enabled: true, priority: 12, dependencies: [] },
    { id: 'content-intelligence', enabled: true, priority: 15, dependencies: [] },
    { id: 'assets', enabled: true, priority: 15, dependencies: [] },
    { id: 'generation', enabled: true, priority: 20, dependencies: ['workflow'] },
    { id: 'real-generation', enabled: true, priority: 25, dependencies: ['content-intelligence', 'infrastructure'] },
    { id: 'reports', enabled: true, priority: 25, dependencies: ['localization', 'assets'] },
  ],
}

export function resolveManifest(manifest: RuntimeManifest): ManifestModuleEntry[] {
  return [...manifest.modules].sort((a, b) => a.priority - b.priority)
}
