// =============================================================================
// AICF V3 — Module Factory (Sprint 16: ServiceContainer DI + M08/M18/M21)
// =============================================================================
// The SINGLE place where Runtime modules are instantiated.
// Sprint 16: uses ServiceContainer for dependency injection.
// No `new ModuleName()` is allowed outside this factory.
//
// To add a new module:
//   1. Create the module class under src/lib/runtime/modules/<name>/
//   2. Add a case to ModuleFactory.create() below
//   3. Register in runtime.manifest.ts
// =============================================================================

import type { RuntimeModule } from '../contracts/RuntimeModule'
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { ServiceContainer } from '../container/ServiceContainer'
import { logger } from '@/lib/ai/logger'

// --- Module imports (the ONLY place these are imported for instantiation) ---
import { WorkflowModule } from '../modules/workflow/WorkflowModule'
import { createWorkflowModule } from '../modules/workflow/factory'
import { GenerationModule } from '../modules/generation/GenerationModule'
import { createGenerationModule } from '../modules/generation'
import { ObservabilityModule } from '../modules/observability/ObservabilityModule'
import { createObservabilityModule } from '../modules/observability'
import {
  ContentIntelligenceRuntimeModule,
  createContentIntelligenceModule,
  type M08Facade,
} from '../modules/m08/ContentIntelligenceRuntimeModule'
import {
  InfrastructureRuntimeModule,
  createInfrastructureModule,
  type M18Facade,
} from '../modules/m18/InfrastructureRuntimeModule'
import {
  RealGenerationRuntimeModule,
  createRealGenerationModule,
  type M21Facade,
} from '../modules/m21/RealGenerationRuntimeModule'
import { LocalizationModule } from '../modules/localization/LocalizationModule'
import { AssetsModule } from '../modules/assets/AssetsModule'
import { ReportsModule } from '../modules/reports/ReportsModule'

/**
 * Dependencies that can be injected into modules via the factory.
 * Each module picks what it needs from this bag.
 */
export interface ModuleDeps {
  /** AI adapter (RuntimeAdapter or LiteLLMAdapter). Required by workflow + generation. */
  aiAdapter?: AIAdapter

  /** Optional event bus (for module lifecycle events). */
  eventBus?: unknown

  /** Optional logger. */
  logger?: unknown

  /** Optional external health checks. */
  externalHealthChecks?: Record<string, () => Promise<{ healthy: boolean; latencyMs?: number; details?: Record<string, unknown>; error?: string }>>

  /** Sprint 16: ServiceContainer for DI. If provided, modules resolve deps from it. */
  container?: ServiceContainer

  /** Sprint 16: M08 facade (for content-intelligence module). */
  m08Facade?: M08Facade

  /** Sprint 16: M18 facade (for infrastructure module). */
  m18Facade?: M18Facade

  /** Sprint 16: M21 facade (for real-generation module). */
  m21Facade?: M21Facade
}

/**
 * Factory that creates Runtime modules by ID.
 * This is the ONLY place where `new ModuleName(...)` is allowed.
 *
 * Sprint 16: supports ServiceContainer-based DI. If deps.container is provided,
 * the factory resolves dependencies from it. Otherwise, it uses deps directly.
 *
 * @example
 * const mod = ModuleFactory.create('workflow', { aiAdapter })
 * await mod.initialize()
 */
export class ModuleFactory {
  /**
   * Creates a module instance by ID. Throws for unknown module IDs.
   */
  static create(moduleId: string, deps?: ModuleDeps): RuntimeModule {
    logger.debug({ moduleId, hasDeps: Boolean(deps) }, 'ModuleFactory: creating module')

    switch (moduleId) {
      case 'workflow': {
        const aiAdapter = deps?.aiAdapter || deps?.container?.get<AIAdapter>('aiAdapter')
        if (!aiAdapter) {
          throw new Error("ModuleFactory: 'workflow' requires deps.aiAdapter or container.get('aiAdapter')")
        }
        const bundle = createWorkflowModule({
          aiAdapter,
          externalHealthChecks: deps?.externalHealthChecks,
        })
        return bundle.module
      }

      case 'generation': {
        const aiAdapter = deps?.aiAdapter || deps?.container?.get<AIAdapter>('aiAdapter')
        if (!aiAdapter) {
          throw new Error("ModuleFactory: 'generation' requires deps.aiAdapter or container.get('aiAdapter')")
        }
        const genBundle = createGenerationModule({ aiAdapter })
        return genBundle.module
      }

      case 'observability': {
        const obsBundle = createObservabilityModule({})
        return obsBundle.module
      }

      case 'content-intelligence': {
        const facade = deps?.m08Facade || deps?.container?.get<M08Facade>('m08Facade')
        if (!facade) {
          throw new Error("ModuleFactory: 'content-intelligence' requires deps.m08Facade or container.get('m08Facade')")
        }
        return createContentIntelligenceModule(facade)
      }

      case 'infrastructure': {
        const facade = deps?.m18Facade || deps?.container?.get<M18Facade>('m18Facade')
        if (!facade) {
          throw new Error("ModuleFactory: 'infrastructure' requires deps.m18Facade or container.get('m18Facade')")
        }
        return createInfrastructureModule(facade)
      }

      case 'real-generation': {
        const facade = deps?.m21Facade || deps?.container?.get<M21Facade>('m21Facade')
        if (!facade) {
          throw new Error("ModuleFactory: 'real-generation' requires deps.m21Facade or container.get('m21Facade')")
        }
        return createRealGenerationModule(facade)
      }

      case 'localization': {
        // Self-contained module — no external deps required.
        return new LocalizationModule()
      }

      case 'assets': {
        // Self-contained module — no external deps required.
        return new AssetsModule()
      }

      case 'reports': {
        // Self-contained module — declared dependencies (localization,
        // assets) are resolved by the manifest/bootstrap, not by the
        // factory. The ReportsModule works standalone for tests.
        return new ReportsModule()
      }

      default:
        throw new Error(`ModuleFactory: unknown module '${moduleId}'`)
    }
  }

  /**
   * Returns the list of module IDs this factory knows how to create.
   */
  static list(): string[] {
    return [
      'workflow',
      'generation',
      'observability',
      'content-intelligence',
      'infrastructure',
      'real-generation',
      'localization',
      'assets',
      'reports',
    ]
  }

  /**
   * Returns true if the factory can create the given module ID.
   */
  static canCreate(moduleId: string): boolean {
    return this.list().includes(moduleId)
  }
}
