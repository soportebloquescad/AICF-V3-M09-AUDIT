// =============================================================================
// AICF V3 — Sprint 2 (Production Runtime) — RuntimeResponseCache
// =============================================================================
// In-memory LRU cache for Runtime responses. The Cache pipeline stage uses
// this to short-circuit idempotent chat requests (same model + messages +
// params). Bounded to MAX_ENTRIES to prevent unbounded memory growth.
//
// Cache key = stable hash of (operation, model, messages, parameters).
// Cache value = a snapshot of the RuntimeResponse (without the requestId /
// correlationId / durationMs — those are regenerated per response).
//
// This is the SINGLE cache implementation for the Runtime pipeline. It is
// intentionally in-memory + LRU: production deployments that need a shared
// cache can swap this out for a Redis-backed implementation behind the same
// RuntimeCache interface (additive — no pipeline changes required).
// =============================================================================

import type { RuntimeResponse } from '../contracts/RuntimeResponse'
import type { ChatMessage } from '@/lib/ai/AIAdapter'
import { logger } from '@/lib/ai/logger'

/** Maximum number of cached responses retained (LRU eviction). */
const MAX_ENTRIES = 256

/**
 * Cache entry: the cached response snapshot.
 */
interface CacheEntry {
  response: CachedResponse
}

/**
 * A response snapshot suitable for caching. Excludes request-specific fields
 * (requestId, correlationId, durationMs) which are regenerated per response.
 */
interface CachedResponse {
  ok: boolean
  content?: string
  model?: string
  provider?: string
  usage?: unknown
  models?: unknown
  error?: string
  errorCode?: string
}

/**
 * Computes a stable cache key from a chat request's identity fields.
 * Two requests with the same operation + model + messages + parameters
 * produce the same key.
 */
export function computeCacheKey(opts: {
  operation: string
  model?: string | null
  messages?: readonly ChatMessage[] | null
  parameters?: Record<string, unknown> | null
}): string {
  const msgHash = opts.messages
    ? opts.messages
        .map((m) => `${m.role}:${m.content}`)
        .join('||')
    : ''
  const paramsHash = opts.parameters
    ? JSON.stringify(opts.parameters)
    : ''
  return `${opts.operation}|${opts.model ?? ''}|${msgHash}|${paramsHash}`
}

/**
 * In-memory LRU cache for Runtime responses.
 *
 * Implements the RuntimeCache contract used by the Cache pipeline stage.
 */
export class RuntimeResponseCache {
  private readonly entries = new Map<string, CacheEntry>()
  private hits = 0
  private misses = 0

  /** Returns the cached response for the key, or null if not cached. */
  get(key: string): RuntimeResponse | null {
    const entry = this.entries.get(key)
    if (!entry) {
      this.misses++
      return null
    }
    // LRU: re-insert at the end (most-recently-used).
    this.entries.delete(key)
    this.entries.set(key, entry)
    this.hits++
    // Hydrate a fresh RuntimeResponse from the snapshot. The requestId /
    // correlationId / durationMs are regenerated so callers can correlate
    // the served-from-cache response with the current request.
    return this.hydrate(entry.response)
  }

  /** Stores a response snapshot under the given key. */
  set(key: string, response: RuntimeResponse): void {
    // Evict oldest when at capacity.
    if (this.entries.size >= MAX_ENTRIES && !this.entries.has(key)) {
      const oldestKey = this.entries.keys().next().value
      if (oldestKey) this.entries.delete(oldestKey)
    }
    this.entries.set(key, { response: this.snapshot(response) })
  }

  /** Returns the number of cached entries. */
  size(): number {
    return this.entries.size
  }

  /** Returns cache hit/miss statistics. */
  stats(): { hits: number; misses: number; size: number; hitRate: number } {
    const total = this.hits + this.misses
    return {
      hits: this.hits,
      misses: this.misses,
      size: this.entries.size,
      hitRate: total === 0 ? 0 : this.hits / total,
    }
  }

  /** Clears the cache (for tests). */
  clear(): void {
    this.entries.clear()
    this.hits = 0
    this.misses = 0
  }

  // --- Helpers -------------------------------------------------------------

  private snapshot(response: RuntimeResponse): CachedResponse {
    return {
      ok: response.ok,
      content: response.content,
      model: response.model,
      provider: response.provider,
      usage: response.usage,
      models: response.models,
      error: response.error,
      errorCode: response.errorCode,
    }
  }

  private hydrate(cached: CachedResponse): RuntimeResponse {
    return {
      ok: cached.ok,
      requestId: `cache-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      correlationId: '',
      durationMs: 0,
      cached: true,
      content: cached.content,
      model: cached.model,
      provider: cached.provider,
      usage: cached.usage as RuntimeResponse['usage'],
      models: cached.models as RuntimeResponse['models'],
      error: cached.error,
      errorCode: cached.errorCode,
    }
  }
}

// --- Singleton accessor ----------------------------------------------------

let singleton: RuntimeResponseCache | null = null

export function getRuntimeResponseCache(): RuntimeResponseCache {
  if (!singleton) {
    singleton = new RuntimeResponseCache()
    logger.info('RuntimeResponseCache: singleton initialized (in-memory LRU, max=256)')
  }
  return singleton
}

export function resetRuntimeResponseCache(): void {
  singleton = null
}
