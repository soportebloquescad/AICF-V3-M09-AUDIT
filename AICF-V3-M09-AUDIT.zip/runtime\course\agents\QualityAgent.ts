// =============================================================================
// AICF V3 — Quality Agent
// =============================================================================
// Validates the assembled course package. Reads every prior agent's
// output from `input.context` and evaluates completeness, alignment,
// and content depth. Returns an overall score (0.0-1.0), a list of
// concrete issues, and actionable recommendations.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, readContext } from './agentUtils'

export interface QualityAgentDeps {
  aiAdapter: AIAdapter | null
}

interface QualityPayload {
  quality: {
    overall: number
    issues: string[]
    recommendations: string[]
  }
}

interface CurriculumShape {
  modules?: Array<{ title: string; lessons?: Array<{ title: string }> }>
}

interface LessonShape {
  title: string
  content?: string
}

interface AssessmentShape {
  question: string
  options?: unknown[]
}

const EXPECTED_KEYS = [
  'research',
  'design',
  'curriculum',
  'lessons',
  'exercises',
  'assessments',
  'slides',
  'documents',
] as const

export class QualityAgent implements Agent {
  public readonly name = 'quality-agent'

  constructor(private readonly deps: QualityAgentDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const ctx = input.context
      const ai = this.deps.aiAdapter
      const aiResult = await callAI(ai, buildPrompt(ctx), {
        systemPrompt:
          'You are a course quality reviewer. Respond with valid JSON only.',
        temperature: 0.2,
        maxTokens: 900,
      })

      let quality: QualityPayload['quality']
      if (aiResult.ok && aiResult.content) {
        const parsed = extractJSON<Partial<QualityPayload['quality']>>(aiResult.content)
        if (parsed && typeof parsed.overall === 'number' && Array.isArray(parsed.issues)) {
          quality = {
            overall: clampScore(parsed.overall),
            issues: parsed.issues.filter((i): i is string => typeof i === 'string'),
            recommendations: Array.isArray(parsed.recommendations)
              ? parsed.recommendations.filter((r): r is string => typeof r === 'string')
              : [],
          }
        } else {
          quality = evaluateLocally(ctx)
        }
      } else {
        quality = evaluateLocally(ctx)
      }

      return {
        agentName: this.name,
        result: { quality },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function buildPrompt(ctx: Record<string, unknown>): string {
  const present = EXPECTED_KEYS.filter((k) => ctx[k] !== undefined && ctx[k] !== null)
  const absent = EXPECTED_KEYS.filter((k) => ctx[k] === undefined || ctx[k] === null)
  return [
    `Review the quality of an assembled course package.`,
    `Present outputs: ${present.join(', ') || '(none)'}.`,
    `Absent outputs: ${absent.join(', ') || '(none)'}.`,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "overall": number,            // 0.0 to 1.0`,
    `  "issues": string[],           // concrete problems found`,
    `  "recommendations": string[]   // actionable next steps`,
    `}`,
  ].join('\n')
}

function clampScore(value: number): number {
  if (Number.isNaN(value)) return 0
  return Math.max(0, Math.min(1, value))
}

function evaluateLocally(ctx: Record<string, unknown>): QualityPayload['quality'] {
  const issues: string[] = []
  const recommendations: string[] = []
  let score = 1.0

  // 1. Completeness: every expected agent output should be present.
  const missing = EXPECTED_KEYS.filter((k) => ctx[k] === undefined || ctx[k] === null)
  if (missing.length > 0) {
    issues.push(`Missing outputs from: ${missing.join(', ')}.`)
    score -= missing.length * 0.08
  }

  // 2. Curriculum-lesson alignment.
  const curriculum = readContext<CurriculumShape>(ctx, 'curriculum')
  const lessons = readContext<LessonShape[]>(ctx, 'lessons')
  if (curriculum?.modules && Array.isArray(lessons)) {
    const expected = new Set<string>()
    for (const m of curriculum.modules) {
      for (const l of m.lessons ?? []) {
        if (l.title) expected.add(l.title)
      }
    }
    const actual = new Set(lessons.map((l) => l.title))
    if (expected.size > 0) {
      const unmatched = [...actual].filter((t) => !expected.has(t))
      if (unmatched.length > 0) {
        issues.push(`${unmatched.length} lesson(s) do not match curriculum titles.`)
        score -= 0.05
      }
    }
  }

  // 3. Content depth.
  if (Array.isArray(lessons)) {
    const thin = lessons.filter((l) => !l.content || l.content.length < 100)
    if (thin.length > 0) {
      issues.push(`${thin.length} lesson(s) have thin content (fewer than 100 characters).`)
      score -= 0.05
    }
  }

  // 4. Assessment coverage.
  const assessments = readContext<AssessmentShape[]>(ctx, 'assessments')
  if (Array.isArray(assessments)) {
    const incomplete = assessments.filter(
      (a) => !a.question || !Array.isArray(a.options) || a.options.length < 2,
    )
    if (incomplete.length > 0) {
      issues.push(`${incomplete.length} assessment item(s) are missing a question or options.`)
      score -= 0.04
    }
    if (assessments.length < 5) {
      issues.push(`Only ${assessments.length} assessment item(s); at least 5 recommended.`)
      score -= 0.03
    }
  }

  // 5. Slide coverage.
  const slides = readContext<unknown[]>(ctx, 'slides')
  if (Array.isArray(slides) && slides.length === 0) {
    issues.push('No slides generated.')
    score -= 0.04
  }

  // 6. Recommendations.
  if (issues.length === 0) {
    recommendations.push('All quality checks passed. The course is ready for publication.')
  } else {
    recommendations.push('Address the listed issues before publishing the course.')
    recommendations.push('Re-run the affected agents to regenerate deficient outputs.')
    if (missing.length > 0) {
      recommendations.push(`Run the missing agents: ${missing.join(', ')}.`)
    }
  }

  return {
    overall: clampScore(score),
    issues,
    recommendations,
  }
}
