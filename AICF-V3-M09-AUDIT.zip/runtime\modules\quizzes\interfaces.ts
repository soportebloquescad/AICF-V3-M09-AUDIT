// =============================================================================
// AICF V3 — Quizzes Module Contract (Sprint: Foundation Modules)
// =============================================================================
// Typed contract for the Quiz Generation module.
//
// Responsibilities:
//   - Generate multiple-choice quizzes from a topic string
//   - Each question carries an id, prompt, options, the correct index, and
//     an optional explanation
//   - Configurable question count and difficulty via `QuizOptions`
//
// This file contains INTERFACES ONLY — no implementation classes.
// Strict TypeScript: no `any`.
// =============================================================================

import type { RuntimeModule } from '@/lib/runtime/contracts/RuntimeModule'

/**
 * Difficulty buckets supported by the Quiz module.
 */
export type QuizDifficulty = 'easy' | 'medium' | 'hard'

/**
 * Options accepted by `QuizzesModule.generateQuiz`.
 */
export interface QuizOptions {
  /** Number of questions to generate. */
  questionCount?: number

  /** Target difficulty bucket. */
  difficulty?: QuizDifficulty
}

/**
 * A single multiple-choice quiz question.
 */
export interface QuizQuestion {
  /** Stable question identifier (unique within a quiz). */
  id: string

  /** The question prompt. */
  question: string

  /** Answer options (length >= 2). */
  options: string[]

  /** Index into `options` of the correct answer. */
  correctIndex: number

  /** Optional rationale / explanation shown after answering. */
  explanation?: string
}

/**
 * Structured result returned by `QuizzesModule.generateQuiz`.
 */
export interface QuizResult {
  /** Whether generation completed without errors. */
  ok: boolean

  /** Generated questions in order. */
  questions: QuizQuestion[]
}

/**
 * Public surface of the Quizzes module.
 */
export interface QuizzesModule extends RuntimeModule {
  /**
   * Generate a quiz for the given topic.
   *
   * @param topic  Topic the quiz should cover.
   * @param opts   Optional generation knobs (questionCount, difficulty).
   */
  generateQuiz(topic: string, opts?: QuizOptions): Promise<QuizResult>
}
