// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Generation Orchestrator
// =============================================================================
// Dispatches incoming generation requests to the registered generator that
// claims the requested `contentType`. Maintains a `Map<string, IGenerator>`
// keyed by `generatorType` (course / presentation / quiz / document) and
// exposes registration, lookup, and pass-through `generate` / `dryRun`
// operations.
//
// Each generator gets its own `GenerationPipeline` (constructed lazily) so
// the pipeline's stage logging, validation, and `generation.completed` event
// emission apply uniformly across all generators.
//
// Sprint 13+14 spec requirements covered:
//   - Pluggable generator registry (`registerGenerator`)
//   - Content-type dispatch (`generate` / `dryRun`)
//   - Optional event bus shared by every per-generator pipeline
//   - `listGenerators()` introspection for status / discovery surfaces
// =============================================================================

import type {
  GeneratorInput,
  GeneratorOutput,
  IEventBus,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  DryRunResult,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'
import { GenerationPipeline } from './GenerationPipeline'

/**
 * Orchestrator that dispatches generation requests by content type. Holds a
 * registry of generators keyed by `generatorType`; each generator is wrapped
 * in a `GenerationPipeline` on first use.
 */
export class GenerationOrchestrator {
  private readonly generators: Map<string, IGenerator>
  private readonly pipelines: Map<string, GenerationPipeline>
  private readonly eventBus: IEventBus | null

  constructor(
    generators: Map<string, IGenerator> = new Map(),
    eventBus?: IEventBus,
  ) {
    this.generators = new Map(generators)
    this.pipelines = new Map()
    this.eventBus = eventBus ?? null
  }

  /**
   * Register a generator. Replaces any existing generator with the same
   * `generatorType`. The per-generator pipeline is constructed lazily on
   * the next `generate` / `dryRun` call so a re-registration invalidates
   * the cached pipeline.
   */
  public registerGenerator(generator: IGenerator): void {
    this.generators.set(generator.generatorType, generator)
    this.pipelines.delete(generator.generatorType)
    logger.debug(
      {
        generator: generator.name,
        generatorType: generator.generatorType,
      },
      'GenerationOrchestrator: registered generator',
    )
  }

  /**
   * Return the list of registered generator types (suitable for status /
   * discovery surfaces).
   */
  public listGenerators(): string[] {
    return Array.from(this.generators.keys())
  }

  /**
   * Look up the generator by `input.contentType` and delegate to its
   * pipeline. Returns a failed `GeneratorOutput` (with `ok: false`) when no
   * generator is registered for the requested content type.
   */
  public async generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const pipeline = this.getPipeline(input.contentType)
    if (pipeline === null) {
      const error = `no generator registered for content type "${input.contentType}"`
      logger.warn(
        { contentType: input.contentType, executionId: ctx.executionId },
        'GenerationOrchestrator: no generator for content type',
      )
      return { ok: false, content: '', artifacts: [], error }
    }
    return pipeline.run(input, ctx)
  }

  /**
   * Look up the generator by `input.contentType` and delegate to its
   * pipeline's `dryRun`. Returns a `DryRunResult` with `canExecute: false`
   * when no generator is registered for the requested content type.
   */
  public async dryRun(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<DryRunResult> {
    const pipeline = this.getPipeline(input.contentType)
    if (pipeline === null) {
      logger.warn(
        { contentType: input.contentType, executionId: ctx.executionId },
        'GenerationOrchestrator: dryRun — no generator for content type',
      )
      return {
        canExecute: false,
        estimatedTokens: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
        estimatedCost: 0,
        estimatedDurationMs: 0,
        stepsPlanned: [],
        providerSelection: {},
        warnings: [
          `no generator registered for content type "${input.contentType}"`,
        ],
      }
    }
    return pipeline.dryRun(input, ctx)
  }

  /**
   * Resolve the pipeline for the given content type, constructing it on
   * first use. Returns `null` when no generator is registered for the type.
   */
  private getPipeline(contentType: string): GenerationPipeline | null {
    const cached = this.pipelines.get(contentType)
    if (cached) return cached
    const generator = this.generators.get(contentType)
    if (!generator) return null
    const pipeline = new GenerationPipeline(
      generator,
      this.eventBus ?? undefined,
    )
    this.pipelines.set(contentType, pipeline)
    return pipeline
  }
}
