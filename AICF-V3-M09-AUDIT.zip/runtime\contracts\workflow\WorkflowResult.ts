// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Result Contract
// =============================================================================
// Defines the *terminal* result envelope returned to callers once a workflow
// execution reaches a final state, plus the dry-run preview envelope and the
// supporting metrics / token-usage shapes.
//
// Sprint 13+14 spec requirements covered:
//   - Final result with terminal status (`completed` | `failed` | `cancelled`)
//   - Artifact references (full artifact bodies live in `WorkflowArtifact`)
//   - Cost / token / latency / retry / success-rate metrics
//   - Dry-run preview (`DryRunResult`) enabling caller-side validation before
//     committing to a real execution
//
// Note: `WorkflowResult` is intentionally distinct from `WorkflowExecution`:
//   - `WorkflowExecution`  = mutable, persisted, full lifecycle state.
//   - `WorkflowResult`     = immutable, returned to the caller, terminal.
// =============================================================================

/**
 * Token-usage breakdown reported by the underlying provider / model.
 * Also reused by `WorkflowContext` as a running tally.
 */
export interface TokenUsage {
  /** Tokens consumed by the prompt. */
  promptTokens: number
  /** Tokens produced by the model. */
  completionTokens: number
  /** Sum of prompt + completion. */
  totalTokens: number
}

/**
 * Aggregated execution metrics. Populated by the executor from
 * `WorkflowExecution` + `WorkflowContext` at terminal state.
 */
export interface WorkflowMetrics {
  /** Total wall-clock execution time in milliseconds. */
  executionTimeMs: number
  /** Aggregated token usage across all steps. */
  tokenUsage: TokenUsage
  /** Per-provider cumulative latency in milliseconds (provider → ms). */
  providerLatency: Record<string, number>
  /** Total cost incurred (platform currency units). */
  cost: number
  /** Total retry attempts across all steps. */
  retries: number
  /** Number of steps that ended in `'failed'` status. */
  failures: number
  /** Fraction of steps that completed successfully (0–1). */
  successRate: number
  /** Number of steps that reached a terminal state. */
  stepsExecuted: number
  /** Total number of steps in the workflow definition. */
  stepsTotal: number
}

/**
 * Reference to an artifact produced during execution. The full artifact
 * body (content, lineage, hash) lives in `WorkflowArtifact`; the result
 * envelope carries only references so it stays small.
 */
export interface WorkflowArtifactRef {
  /** Artifact id (matches `WorkflowArtifact.id`). */
  id: string
  /** Producing step id. */
  stepId: string
  /** Artifact name. */
  name: string
  /** Artifact type. */
  type: string
  /** Artifact size in bytes. */
  sizeBytes: number
}

/**
 * Terminal result envelope returned to callers.
 */
export interface WorkflowResult {
  /** Execution id (matches `WorkflowExecution.executionId`). */
  executionId: string
  /** Workflow id (matches `WorkflowMetadata.id`). */
  workflowId: string
  /** Terminal status. */
  status: 'completed' | 'failed' | 'cancelled'
  /** Final outputs (only populated on `completed`). */
  outputs: Record<string, unknown>
  /** References to artifacts produced during the run. */
  artifacts: WorkflowArtifactRef[]
  /** Aggregated execution metrics. */
  metrics: WorkflowMetrics
  /** Total wall-clock duration in milliseconds. */
  durationMs: number
  /** Terminal error message (set on `failed`). */
  error?: string
  /** Cross-service correlation id. */
  correlationId: string
}

/**
 * Dry-run preview envelope. Returned by the planner when
 * `WorkflowPolicies.dryRun === true` (or when the caller explicitly requests
 * a dry run). Contains no side-effects.
 */
export interface DryRunResult {
  /** Whether the workflow is executable as declared. */
  canExecute: boolean
  /** Estimated token usage if executed. */
  estimatedTokens: TokenUsage
  /** Estimated total cost if executed. */
  estimatedCost: number
  /** Estimated total duration in milliseconds. */
  estimatedDurationMs: number
  /** Ordered list of step ids the planner intends to execute. */
  stepsPlanned: string[]
  /** Per-step provider selection (stepId → provider name). */
  providerSelection: Record<string, string>
  /** Non-fatal warnings (e.g. ambiguous routing, deprecated provider). */
  warnings: string[]
}

/**
 * Factory: builds a `WorkflowResult` for a completed execution.
 */
export function createCompletedResult(params: {
  executionId: string
  workflowId: string
  outputs: Record<string, unknown>
  artifacts: WorkflowArtifactRef[]
  metrics: WorkflowMetrics
  durationMs: number
  correlationId: string
}): WorkflowResult {
  return {
    executionId: params.executionId,
    workflowId: params.workflowId,
    status: 'completed',
    outputs: params.outputs,
    artifacts: params.artifacts,
    metrics: params.metrics,
    durationMs: params.durationMs,
    correlationId: params.correlationId,
  }
}

/**
 * Factory: builds a `WorkflowResult` for a failed execution.
 */
export function createFailedResult(params: {
  executionId: string
  workflowId: string
  error: string
  metrics: WorkflowMetrics
  durationMs: number
  correlationId: string
  partialOutputs?: Record<string, unknown>
  artifacts?: WorkflowArtifactRef[]
}): WorkflowResult {
  return {
    executionId: params.executionId,
    workflowId: params.workflowId,
    status: 'failed',
    outputs: params.partialOutputs ?? {},
    artifacts: params.artifacts ?? [],
    metrics: params.metrics,
    durationMs: params.durationMs,
    error: params.error,
    correlationId: params.correlationId,
  }
}

/**
 * Factory: builds a `WorkflowResult` for a cancelled execution.
 */
export function createCancelledResult(params: {
  executionId: string
  workflowId: string
  metrics: WorkflowMetrics
  durationMs: number
  correlationId: string
  partialOutputs?: Record<string, unknown>
  artifacts?: WorkflowArtifactRef[]
}): WorkflowResult {
  return {
    executionId: params.executionId,
    workflowId: params.workflowId,
    status: 'cancelled',
    outputs: params.partialOutputs ?? {},
    artifacts: params.artifacts ?? [],
    metrics: params.metrics,
    durationMs: params.durationMs,
    correlationId: params.correlationId,
  }
}
