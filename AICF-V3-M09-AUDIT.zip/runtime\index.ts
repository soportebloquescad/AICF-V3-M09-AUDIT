// =============================================================================
// AICF V3 — Runtime Public API (Épica 1 — Stabilization)
// =============================================================================
// Cleaned barrel: only re-exports modules that are consumed by production
// code. Dead directories (real/, adapters/, resilience/, cqrs/, cost/,
// cache/, config/, lifecycle/, plugins/, resolver/, workers/, context/,
// middleware/ except buildContext, server/, RuntimeManager.ts) have been
// deleted — see docs/adrs/ADR-E1-003-dead-code-removal.md.
//
// Consumers should import directly from the specific file path when possible
// (e.g. `import { RuntimeError } from '@/lib/runtime/errors/RuntimeError'`)
// rather than going through this barrel — that keeps the dependency graph
// explicit.
// =============================================================================

// --- Contracts (FROZEN) ----------------------------------------------------
export type { RuntimeRequest, RuntimeOperation } from './contracts/RuntimeRequest'
export type { RuntimeResponse } from './contracts/RuntimeResponse'
export type { RuntimeContext, RuntimeMetrics } from './contracts/RuntimeContext'
export type {
  RuntimeModule,
  RuntimeStatus,
  RuntimeModuleCategory,
  ModuleHealth,
  RuntimeModuleLifecycle,
} from './contracts/RuntimeModule'
export {
  createDefaultModuleMetrics,
  createUninitializedHealth,
} from './contracts/RuntimeModule'
export type {
  ContentIntelligenceModule,
  RealGenerationModule,
  InfrastructureModule,
  WorkflowModule,
  LocalizationModule,
  AssetsModule,
  ReportsModule,
  PolicyDecision,
  ProviderRoute,
  GenerationResult,
  InfrastructureHealth,
  WorkflowResult as ModuleWorkflowResult,
  AssetResult,
  ReportResult,
} from './contracts/ModuleInterfaces'
export { createRuntimeRequest } from './contracts/RuntimeRequest'
export { createRuntimeResponse, createRuntimeErrorResponse } from './contracts/RuntimeResponse'
export { createRuntimeContext } from './contracts/RuntimeContext'
export type { PluginMetadata } from './contracts/PluginMetadata'
export { createVersionedContract, RUNTIME_VERSION, validateContractCompatibility } from './contracts/VersionedContract'

// --- Pipeline (FROZEN) -----------------------------------------------------
export { type PipelineStage, type PipelineStageFn, createPipelineStage } from './pipeline/PipelineStage'
export { Pipeline } from './pipeline/Pipeline'
export { PipelineRegistry, buildDefaultPipeline, type PipelineConfig } from './pipeline/PipelineRegistry'
export { StageRegistry } from './pipeline/StageRegistry'

// --- Stages ----------------------------------------------------------------
export { createPolicyStage } from './stages/PolicyStage'
export { createRoutingStage } from './stages/RoutingStage'
export { createPromptBuilderStage } from './stages/PromptBuilderStage'
export { createExecutionStage, type ExecutionStageConfig, type FallbackGenerateFn } from './stages/ExecutionStage'
export { createPostProcessingStage } from './stages/PostProcessingStage'

// --- Registry --------------------------------------------------------------
export { ModuleRegistry } from './registry/ModuleRegistry'
export {
  CapabilityRegistry,
  type CapabilityQuery,
  type CapabilityResult,
  type ModuleHealthLevel,
} from './registry/CapabilityRegistry'

// --- Services (FROZEN) -----------------------------------------------------
export { RuntimeService, type RuntimeServiceConfig, getGlobalEventBus, _resetGlobalBootstrap } from './services/RuntimeService'

// --- Middleware (only buildContext is used in prod) ------------------------
export { buildContext } from './middleware/RuntimeContextMiddleware'

// --- Bootstrap + Manifest + Factory + EventBus -----------------------------
export { RuntimeBootstrap, type BootstrapResult } from './bootstrap/RuntimeBootstrap'
export { runtimeManifest, resolveManifest, type ManifestModuleEntry } from './runtime.manifest'
export { ModuleFactory, type ModuleDeps } from './factories/ModuleFactory'
export { RuntimeEventBus, type RuntimeEvent, type RuntimeEventType, createRuntimeEvent } from './events/RuntimeEventBus'

// --- EDA Runtime Observability (Sprint 21) ---------------------------------
export {
  createEventMetadata,
  createEnvelope,
  type EventMetadata,
  type RuntimeEventEnvelope,
} from './events/EventMetadata'
export {
  RuntimeEventRegistry,
  runtimeEventRegistry,
  type EventRegistration,
} from './events/EventRegistry'
export { type RuntimeEventBusTelemetry } from './events/RuntimeEventBus'

// --- Subscribers (Sprint 21) -----------------------------------------------
export {
  type EventSubscriber,
  AuditSubscriber,
  MetricsSubscriber,
  DashboardSubscriber,
} from './subscribers'

// --- MetricsRegistry (consumed via observability-singleton, re-exported
//     here for type-only imports) -------------------------------------------
export {
  MetricsRegistry,
  createEmptyModuleMetrics,
  type ModuleMetrics,
} from './metrics/MetricsRegistry'

// --- Audit (consumed via observability-singleton) --------------------------
export { type AuditProvider, type AuditEntry, InMemoryAuditProvider } from './audit/AuditProvider'

// --- Errors (RuntimeError consumed directly from errors/RuntimeError) ------
export { RuntimeError, type RuntimeErrorCode } from './errors/RuntimeError'

// --- Health (DeepHealth buildDeepHealth consumed directly from health/DeepHealth) ---
export { type DeepHealth, type ModuleHealthStatus, type LiteLLMHealth, buildDeepHealth } from './health/DeepHealth'
export {
  HealthRegistry,
  type HealthStatus,
  type HealthStatusReport,
  type DependencyHealth,
} from './health/HealthRegistry'

// --- Course Factory (legacy, still used by /api/course/*) ------------------
export { type CourseRequest as CourseFactoryRequest, type Module, type Lesson, type Exercise } from '@/lib/course/CourseRequest'
export { type CourseResult as CourseFactoryResult } from '@/lib/course/CourseResult'
export { CourseService, type CourseServiceConfig } from '@/lib/course/CourseService'
export { CourseWorker as CourseFactoryWorker, type CourseWorkerConfig } from '@/lib/course/CourseWorker'

// --- Workflow Generator (legacy) -------------------------------------------
export { type WorkflowRequest as WFGenRequest, type WorkflowSettings } from '@/lib/workflow/WorkflowRequest'
export { type WorkflowResult as WFGenResult, type WorkflowStep } from '@/lib/workflow/WorkflowResult'
export { WorkflowGenerator } from '@/lib/workflow/WorkflowGenerator'
export { WorkflowDoctor, type ValidationIssue, type ValidationResult } from '@/lib/workflow/WorkflowDoctor'

// --- Export (legacy) -------------------------------------------------------
export { ExportMarkdown } from '@/lib/export/ExportMarkdown'
export { ExportDOCX } from '@/lib/export/ExportDOCX'
export { ExportPDF } from '@/lib/export/ExportPDF'
export { ExportPPTX, type PPTXSlide } from '@/lib/export/ExportPPTX'

// --- Queue (legacy) --------------------------------------------------------
export { WorkflowQueue, type QueueJob, type QueueProcessor } from '@/lib/queue/WorkflowQueue'
export { QueueWorker, type QueueWorkerConfig } from '@/lib/queue/QueueWorker'

// =============================================================================
// Épica 1 — REMOVED re-exports (modules deleted, see ADR-E1-003):
//   - ContentIntelligenceAdapter, GenerationAdapter, InfrastructureAdapter (adapters/)
//   - DependencyResolver, DependencyGraph (resolver/)
//   - LifecycleManager, ModuleState (lifecycle/)
//   - CorrelationContextManager, CorrelationContext (context/)
//   - PluginManager (plugins/)
//   - CommandBus, QueryBus (cqrs/)
//   - InMemoryCacheProvider, CacheProvider (cache/)
//   - CostTracker, CostEntry (cost/)
//   - HealthManager (health/HealthManager.ts — only re-exported, never consumed)
//   - ConfigManager, RuntimeConfig (config/)
//   - LoggingMiddleware, ErrorHandlerMiddleware, AuditMiddleware (middleware/)
//   - ensureCorrelationId, ensureRequestId (middleware/CorrelationId)
//   - MetricsCollector, InMemoryMetricsCollector (middleware/Metrics)
//   - WorkflowRegistry, WorkflowRuntime (workers/)
//   - CourseWorker (runtime/workers/ — the OTHER CourseWorker, never imported)
//   - ResearchWorker, ResearchRequest, ResearchResult (workers/)
// =============================================================================
