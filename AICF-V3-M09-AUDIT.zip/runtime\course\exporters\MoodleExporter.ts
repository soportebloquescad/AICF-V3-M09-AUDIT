// =============================================================================
// AICF V3 — Moodle Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a Moodle backup XML structure. The output
// is a `<moodle_backup>` document that describes a single course with one
// section and one or more `page` (or `label`) activities. The resulting XML
// can be wrapped into a `.mbz` Moodle backup archive (together with the
// rendered HTML / moodle_backup.xml file) and restored into a Moodle site.
//
// The structure follows the Moodle backup format (moodle_backup.xml):
//   <moodle_backup>
//     <information> ... </information>
//     <contents>
//       <section ...>
//         <activities>
//           <activity ...> ... </activity>
//         </activities>
//       </section>
//     </contents>
//   </moodle_backup>
//
// The exporter NEVER generates or modifies content — it only wraps the
// supplied Markdown into the Moodle backup vocabulary. Metadata is projected
// into the course header and activity attributes.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { escapeHtml } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by MoodleExporter.export(). */
export type MoodleExportMetadata = Record<string, unknown>

/** Schema describing one Moodle activity in the backup. */
export interface MoodleActivity {
  /** Stable Moodle module id (e.g. "1"). */
  id: string
  /** Moodle module type (page, label, url, resource, etc.). */
  module: string
  /** Human-readable activity title. */
  title: string
  /** Absolute directory path inside the backup for this activity. */
  directory: string
}

/** Default Moodle version string for the backup header. */
const DEFAULT_MOODLE_VERSION = '2023100900'

/** Default Moodle backup format version. */
const DEFAULT_BACKUP_VERSION = '2023100900'

/**
 * MoodleExporter — transforms content to a Moodle backup XML structure.
 */
export class MoodleExporter {
  /**
   * Transform `content` (Markdown) into a `<moodle_backup>` XML document.
   *
   * @param content  Markdown source text. Heading sections become activities.
   * @param metadata Optional metadata: { title, description, course_id,
   *                 category, language, moodle_version, ... }.
   * @returns A `<moodle_backup>` XML document string.
   */
  export(content: string, metadata?: MoodleExportMetadata): string {
    const meta = metadata ?? {}
    const title = asString(meta.title, asString(meta.topic, 'Moodle Course'))
    const description = asString(meta.description, '')
    const courseId = asString(meta.course_id, asString(meta.id, '1'))
    const shortName = asString(meta.shortname, slugify(title))
    const category = asString(meta.category, 'misc')
    const language = asString(meta.language, 'en').toLowerCase()
    const moodleVersion = asString(meta.moodle_version, DEFAULT_MOODLE_VERSION)
    const backupVersion = asString(meta.backup_version, DEFAULT_BACKUP_VERSION)
    const author = asString(meta.author, '')
    const activities = this.resolveActivities(content ?? '', title)
    const sections = this.buildSections(activities)
    const contents = this.buildContents(courseId, sections, activities)

    const lines: string[] = []
    lines.push('<?xml version="1.0" encoding="UTF-8"?>')
    lines.push('<moodle_backup>')
    lines.push('  <information>')
    lines.push('    <name>' + escapeXmlText(title) + '</name>')
    lines.push('    <moodle_version>' + escapeXmlText(moodleVersion) + '</moodle_version>')
    lines.push('    <moodle_release>Moodle ' + escapeXmlText(moodleVersion.slice(0, 4)) + '</moodle_release>')
    lines.push('    <backup_version>' + escapeXmlText(backupVersion) + '</backup_version>')
    lines.push('    <backup_release>4.x</backup_release>')
    lines.push('    <backup_date>' + new Date().toISOString() + '</backup_date>')
    lines.push('    <mnet_remoteusers_required>0</mnet_remoteusers_required>')
    lines.push('    <include_files>1</include_files>')
    lines.push('    <include_file_references_to_external_content>0</include_file_references_to_external_content>')
    lines.push('    <original_wwwroot>https://moodle.example.edu</original_wwwroot>')
    lines.push('    <original_site_identifier_hash>' + hashString('aicf-' + courseId) + '</original_site_identifier_hash>')
    lines.push('    <original_course_id>' + escapeXmlText(courseId) + '</original_course_id>')
    lines.push('    <original_course_fullname>' + escapeXmlText(title) + '</original_course_fullname>')
    lines.push('    <original_course_shortname>' + escapeXmlText(shortName) + '</original_course_shortname>')
    lines.push('    <original_course_startdate>' + Math.floor(Date.now() / 1000) + '</original_course_startdate>')
    lines.push('    <original_course_contextid>' + escapeXmlText(courseId) + '</original_course_contextid>')
    lines.push('    <original_system_contextid>1</original_system_contextid>')
    lines.push('    <details>')
    lines.push('      <type>course</type>')
    lines.push('      <users>0</users>')
    lines.push('      <anonymise>0</anonymise>')
    lines.push('      <role_assignments>0</role_assignments>')
    lines.push('      <activities>1</activities>')
    lines.push('      <blocks>0</blocks>')
    lines.push('      <files>1</files>')
    lines.push('      <gradebook_history>0</gradebook_history>')
    lines.push('      <comments>0</comments>')
    lines.push('      <badges>0</badges>')
    lines.push('      <calendarevents>0</calendarevents>')
    lines.push('      <userscompletion>0</userscompletion>')
    lines.push('      <logs>0</logs>')
    lines.push('      <questionsets>0</questionsets>')
    lines.push('      <competencies>0</competencies>')
    lines.push('      <contentbankcontent>0</contentbankcontent>')
    lines.push('    </details>')
    lines.push('    <course_settings>')
    lines.push('      <courseid>' + escapeXmlText(courseId) + '</courseid>')
    lines.push('      <fullname>' + escapeXmlText(title) + '</fullname>')
    lines.push('      <shortname>' + escapeXmlText(shortName) + '</shortname>')
    lines.push('      <summary>' + escapeXmlText(description) + '</summary>')
    lines.push('      <category>' + escapeXmlText(category) + '</category>')
    lines.push('      <lang>' + escapeXmlText(language) + '</lang>')
    if (author) {
      lines.push('      <teacher>' + escapeXmlText(author) + '</teacher>')
    }
    lines.push('    </course_settings>')
    lines.push(contents)
    lines.push('  </information>')
    lines.push('</moodle_backup>')
    lines.push('')
    return lines.join('\n')
  }

  // -------------------------------------------------------------------------
  // Section + contents builders
  // -------------------------------------------------------------------------

  private buildSections(activities: MoodleActivity[]): string {
    const sectionId = '1'
    const sectionNumber = '0'
    const lines: string[] = []
    lines.push('      <sections>')
    lines.push('        <section>')
    lines.push('          <sectionid>' + sectionId + '</sectionid>')
    lines.push('          <sectionnumber>' + sectionNumber + '</sectionnumber>')
    lines.push('          <title>General</title>')
    lines.push('          <summary></summary>')
    lines.push('          <activities>' + activities.length + '</activities>')
    lines.push('        </section>')
    lines.push('      </sections>')
    return lines.join('\n')
  }

  private buildContents(
    courseId: string,
    sections: string,
    activities: MoodleActivity[],
  ): string {
    const lines: string[] = []
    lines.push('    <contents>')
    lines.push('      <section sectionid="1" sectionnumber="0" sectiontitle="General" sectionsummary="">')
    lines.push('        <activities>')
    for (let i = 0; i < activities.length; i++) {
      const a = activities[i]
      lines.push('          <activity moduleid="' + escapeXmlAttr(a.id) + '" sectionid="1" modulename="' + escapeXmlAttr(a.module) + '" title="' + escapeXmlAttr(a.title) + '" directory="' + escapeXmlAttr(a.directory) + '">')
      lines.push('            <directory>' + escapeXmlText(a.directory) + '</directory>')
      lines.push('          </activity>')
    }
    lines.push('        </activities>')
    lines.push('      </section>')
    lines.push('      <course courseid="' + escapeXmlAttr(courseId) + '" directory="course">')
    lines.push('        <directory>course</directory>')
    lines.push('      </course>')
    lines.push('    </contents>')
    // Acknowledge `sections` (it mirrors <contents><section>...</section></contents>
    // — kept for callers that read the structural summary separately).
    void sections
    return lines.join('\n')
  }

  // -------------------------------------------------------------------------
  // Activity resolution from Markdown
  // -------------------------------------------------------------------------

  private resolveActivities(content: string, fallbackTitle: string): MoodleActivity[] {
    const activities: MoodleActivity[] = []
    const lines = content.replace(/\r\n/g, '\n').split('\n')
    let current: { title: string; body: string[] } | null = null

    const flush = (): void => {
      if (!current) return
      if (current.title.trim().length === 0) {
        current = null
        return
      }
      // If the activity body is empty, make it a "label"; otherwise "page".
      const hasBody = current.body.some((l) => l.trim().length > 0)
      const moduleName = hasBody ? 'page' : 'label'
      const idx = activities.length + 1
      activities.push({
        id: String(idx),
        module: moduleName,
        title: current.title,
        directory: `activities/${moduleName}_${idx}`,
      })
      current = null
    }

    for (const line of lines) {
      const heading = line.match(/^(#{1,3})\s+(.*)$/)
      if (heading) {
        flush()
        current = { title: heading[2].trim(), body: [] }
        continue
      }
      if (!current) {
        // Content before the first heading becomes a lead-in activity
        if (line.trim().length === 0) continue
        current = { title: fallbackTitle, body: [] }
      }
      current.body.push(line)
    }
    flush()

    // Guarantee at least one activity so the backup is never empty
    if (activities.length === 0) {
      activities.push({
        id: '1',
        module: 'label',
        title: fallbackTitle,
        directory: 'activities/label_1',
      })
    }
    return activities
  }
}

// -------------------------------------------------------------------------
// Small input-narrowing + XML-escaping helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function slugify(input: string): string {
  const lower = input.toLowerCase()
  const slug = lower.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
  return slug.length > 0 ? slug.slice(0, 100) : 'moodle-course'
}

function hashString(input: string): string {
  // Simple, deterministic 32-char hex "hash" — NOT cryptographically secure,
  // but stable across runs for the same input, which is all Moodle requires
  // for the original_site_identifier_hash field.
  let h1 = 0x811c9dc5
  let h2 = 0x1000193
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i)
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0
    h2 = Math.imul(h2 ^ c, 0x85ebca6b) >>> 0
  }
  const part1 = h1.toString(16).padStart(8, '0')
  const part2 = h2.toString(16).padStart(8, '0')
  return (part1 + part2).repeat(2).slice(0, 32)
}

/** Escape text content for safe inclusion between XML tags. */
function escapeXmlText(input: string): string {
  return escapeHtml(input)
}

/** Escape an attribute value for safe inclusion inside XML quotes. */
function escapeXmlAttr(input: string): string {
  return escapeHtml(input)
}
