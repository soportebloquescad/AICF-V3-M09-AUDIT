// =============================================================================
// AICF V3 — Épica 6 — Agent Coordinator
// =============================================================================
import type { AIAdapter } from '@/lib/ai/AIAdapter'

export interface AgentInput {
  topic: string
  locale: string
  level: string
  audience: string
  moduleCount: number
  context: Record<string, unknown>
}

export interface AgentOutput {
  agentName: string
  result: Record<string, unknown>
  durationMs: number
  success: boolean
  error?: string
}

export interface Agent {
  name: string
  execute(input: AgentInput): Promise<AgentOutput>
}

export interface CoordinationResult {
  outputs: AgentOutput[]
  finalResult: Record<string, unknown>
}

export class AgentCoordinator {
  private readonly agents: Agent[] = []

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  registerAgent(agent: Agent): void {
    this.agents.push(agent)
  }

  listAgents(): string[] {
    return this.agents.map((a) => a.name)
  }

  async coordinate(input: AgentInput): Promise<CoordinationResult> {
    const outputs: AgentOutput[] = []
    const context: Record<string, unknown> = { ...input.context }

    for (const agent of this.agents) {
      const start = Date.now()
      try {
        const agentInput: AgentInput = { ...input, context: { ...context } }
        const output = await agent.execute(agentInput)
        outputs.push(output)
        context[output.agentName] = output.result
        if (output.result) {
          for (const [k, v] of Object.entries(output.result)) {
            context[k] = v
          }
        }
      } catch (err) {
        outputs.push({
          agentName: agent.name,
          result: {},
          durationMs: Date.now() - start,
          success: false,
          error: err instanceof Error ? err.message : String(err),
        })
      }
    }

    return { outputs, finalResult: context }
  }
}
