// =============================================================================
// AICF V3 — Sprint 10 — Theme Engine
// =============================================================================
import { getThemeByName, listAllThemes, type ThemePreset } from './ThemeCatalog'

export class ThemeEngine {
  listThemes(): ThemePreset[] { return listAllThemes() }
  getTheme(name: string): ThemePreset { return getThemeByName(name) }

  renderCssVars(theme: ThemePreset): string {
    const c = theme.colors
    return `
:root {
  --color-primary: ${c.primary}; --color-primary-fg: ${c.primaryFg};
  --color-background: ${c.background}; --color-surface: ${c.surface};
  --color-border: ${c.border}; --color-text: ${c.text}; --color-text-muted: ${c.textMuted};
  --color-accent: ${c.accent}; --color-success: ${c.success}; --color-warning: ${c.warning}; --color-danger: ${c.danger};
  --font-heading: ${theme.typography.headingFont}; --font-body: ${theme.typography.bodyFont};
  --font-base-size: ${theme.typography.baseSize}; --font-line-height: ${theme.typography.lineHeight};
  --radius: ${theme.radius}; --theme-name: ${theme.name}; --theme-mode: ${theme.mode};
}
`.trim()
  }

  renderBaseCss(theme: ThemePreset): string {
    return `
${this.renderCssVars(theme)}
* { box-sizing: border-box; }
body, .aicf-root { margin: 0; background: var(--color-background); color: var(--color-text);
  font-family: var(--font-body); font-size: var(--font-base-size); line-height: var(--font-line-height); }
h1,h2,h3,h4,h5,h6 { font-family: var(--font-heading); color: var(--color-text); margin: 0 0 0.5em; }
a { color: var(--color-accent); text-decoration: none; }
.card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1.5rem; margin-bottom: 1rem; }
`.trim()
  }
}

let singleton: ThemeEngine | null = null
export function getThemeEngine(): ThemeEngine {
  if (!singleton) singleton = new ThemeEngine()
  return singleton
}
export function resetThemeEngine(): void { singleton = null }
