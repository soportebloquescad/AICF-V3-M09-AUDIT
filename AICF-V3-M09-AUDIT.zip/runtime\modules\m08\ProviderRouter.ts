// =============================================================================
// AICF V3 — M08 Content Intelligence — ProviderRouter
// =============================================================================
// The ProviderRouter holds metadata about every registered AI provider
// (groq, gemini, openrouter, litellm, ...) and selects the most appropriate
// one for a given policy mode.
//
// Selection rules:
//   - Filter to providers where `available === true`.
//   - For 'economy' mode: prefer providers flagged `economy === true`,
//     then sort by priority (lower number = higher priority).
//   - For 'premium' / 'deep-research' mode: prefer providers flagged
//     `premium === true`, then sort by priority.
//   - For all other modes: sort by priority.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * Static metadata about a single provider. Does not include secrets —
 * the actual API key is loaded from environment by the AIAdapter at
 * execution time, not by the router.
 */
export interface ProviderMetadata {
  /** Provider name (unique within the router). */
  name: string
  /** Human-readable label. */
  label: string
  /**
   * Priority — lower number = higher priority. Used to break ties when
   * multiple providers satisfy the selection criteria.
   */
  priority: number
  /** Whether the provider is currently available. */
  available: boolean
  /** Capabilities supported by this provider (e.g. 'chat', 'streaming'). */
  capabilities: string[]
  /** Estimated cost per 1k tokens (input + output blended), in USD. */
  costPer1kTokens: number
  /** Whether this provider offers premium / frontier models. */
  premium: boolean
  /** Whether this provider is optimized for low-cost economy workloads. */
  economy: boolean
}

/**
 * Result returned by `ProviderRouter.select()`.
 */
export interface RoutingResult {
  /** The selected provider. */
  provider: ProviderMetadata
  /** Human-readable reason for the selection. */
  reason: string
  /** Estimated cost per 1k tokens for the selected provider. */
  estimatedCostPer1k: number
}

/**
 * The 4 default providers. Registered in `registerDefaults()`.
 *
 * Priorities:
 *   - litellm: 5  (economy, generic gateway)
 *   - groq:    10 (economy, fast inference)
 *   - gemini:  20 (premium, Google frontier)
 *   - openrouter: 30 (premium, multi-model gateway)
 */
const DEFAULT_PROVIDERS: ProviderMetadata[] = [
  {
    name: 'groq',
    label: 'Groq (LPU inference)',
    priority: 10,
    available: true,
    capabilities: ['chat', 'streaming', 'json'],
    costPer1kTokens: 0.0002,
    premium: false,
    economy: true,
  },
  {
    name: 'gemini',
    label: 'Google Gemini',
    priority: 20,
    available: true,
    capabilities: ['chat', 'streaming', 'json', 'vision', 'long-context'],
    costPer1kTokens: 0.0015,
    premium: true,
    economy: false,
  },
  {
    name: 'openrouter',
    label: 'OpenRouter (multi-model)',
    priority: 30,
    available: true,
    capabilities: ['chat', 'streaming', 'json', 'vision'],
    costPer1kTokens: 0.002,
    premium: true,
    economy: false,
  },
  {
    name: 'litellm',
    label: 'LiteLLM (gateway)',
    priority: 5,
    available: true,
    capabilities: ['chat', 'streaming', 'json'],
    costPer1kTokens: 0.0008,
    premium: false,
    economy: true,
  },
]

/**
 * The ProviderRouter. Holds a registry of provider metadata and selects
 * the most appropriate provider for a given policy mode.
 */
export class ProviderRouter {
  private readonly providers = new Map<string, ProviderMetadata>()

  constructor(registerDefaults = true) {
    if (registerDefaults) {
      this.registerDefaults()
    }
  }

  /**
   * Register the 4 default providers (groq, gemini, openrouter, litellm).
   */
  registerDefaults(): void {
    for (const p of DEFAULT_PROVIDERS) {
      this.providers.set(p.name, p)
    }
    logger.debug(
      { count: this.providers.size, names: this.list().map((p) => p.name) },
      'ProviderRouter: default providers registered',
    )
  }

  /**
   * Register a custom provider. Overwrites any existing provider with the same name.
   */
  register(provider: ProviderMetadata): void {
    this.providers.set(provider.name, provider)
    logger.info({ provider: provider.name }, 'ProviderRouter: provider registered')
  }

  /**
   * Unregister a provider by name.
   */
  unregister(name: string): boolean {
    return this.providers.delete(name)
  }

  /**
   * Get a provider by name. Returns null if not registered.
   */
  get(name: string): ProviderMetadata | null {
    return this.providers.get(name) ?? null
  }

  /**
   * Returns true if a provider with the given name is registered.
   */
  has(name: string): boolean {
    return this.providers.has(name)
  }

  /**
   * List all registered providers (available + unavailable).
   */
  list(): ProviderMetadata[] {
    return Array.from(this.providers.values())
  }

  /**
   * List only available providers.
   */
  listAvailable(): ProviderMetadata[] {
    return this.list().filter((p) => p.available)
  }

  /**
   * Returns true if at least one provider is available.
   */
  hasAvailable(): boolean {
    for (const p of this.providers.values()) {
      if (p.available) return true
    }
    return false
  }

  /**
   * Select the best provider for the given policy mode.
   *
   * Selection algorithm:
   *   1. Filter to available providers.
   *   2. For 'economy' mode: prefer economy providers.
   *   3. For 'premium' / 'deep-research' mode: prefer premium providers.
   *   4. Sort by priority (lower = preferred).
   *   5. Return the first one (or null if none available).
   */
  select(mode: string): RoutingResult | null {
    const available = this.listAvailable()
    if (available.length === 0) {
      logger.warn({ mode }, 'ProviderRouter: no available providers')
      return null
    }

    let preferred: ProviderMetadata[]
    let reason: string

    if (mode === 'economy') {
      const economy = available.filter((p) => p.economy)
      preferred = economy.length > 0 ? economy : available
      reason = economy.length > 0
        ? `economy mode — selected economy provider`
        : `economy mode — no economy provider available, falling back to lowest priority`
    } else if (mode === 'premium' || mode === 'deep-research') {
      const premium = available.filter((p) => p.premium)
      preferred = premium.length > 0 ? premium : available
      reason = premium.length > 0
        ? `${mode} mode — selected premium provider`
        : `${mode} mode — no premium provider available, falling back to lowest priority`
    } else {
      preferred = available
      reason = `${mode} mode — selected by priority`
    }

    preferred.sort((a, b) => a.priority - b.priority)
    const selected = preferred[0]!
    logger.debug(
      { mode, selected: selected.name, reason },
      'ProviderRouter: provider selected',
    )
    return {
      provider: selected,
      reason,
      estimatedCostPer1k: selected.costPer1kTokens,
    }
  }
}

/**
 * Singleton ProviderRouter with default providers pre-registered.
 */
let singleton: ProviderRouter | null = null

export function getProviderRouter(): ProviderRouter {
  if (!singleton) {
    singleton = new ProviderRouter(true)
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetProviderRouter(): void {
  singleton = null
}
