// =============================================================================
// AICF V3 — Epica 7 — Cost Engine
// =============================================================================
import { logger } from '@/lib/ai/logger'
import type { Provider } from './CourseContracts'

export interface CostRecord {
  id: string
  correlationId: string
  courseId: string
  stage: string
  provider: Provider
  model: string
  promptTokens: number
  completionTokens: number
  totalTokens: number
  cost: number
  recordedAt: string
}

export interface PricingTier {
  inputPerMillion: number
  outputPerMillion: number
}

export type CostProvider = Provider | 'default'

const PRICING: Record<CostProvider, PricingTier> = {
  groq: { inputPerMillion: 0.05, outputPerMillion: 0.10 },
  gemini: { inputPerMillion: 0.50, outputPerMillion: 1.50 },
  claude: { inputPerMillion: 3.00, outputPerMillion: 15.00 },
  openai: { inputPerMillion: 5.00, outputPerMillion: 15.00 },
  openrouter: { inputPerMillion: 2.00, outputPerMillion: 6.00 },
  litellm: { inputPerMillion: 1.00, outputPerMillion: 3.00 },
  'runtime-adapter': { inputPerMillion: 1.00, outputPerMillion: 3.00 },
  default: { inputPerMillion: 1.00, outputPerMillion: 3.00 },
}

export function estimateCost(
  provider: Provider,
  model: string,
  promptTokens: number,
  completionTokens: number,
): number {
  const tier = PRICING[provider as CostProvider] ?? PRICING.default
  const inputCost = (promptTokens / 1_000_000) * tier.inputPerMillion
  const outputCost = (completionTokens / 1_000_000) * tier.outputPerMillion
  const cost = inputCost + outputCost
  logger.debug({ provider, model, promptTokens, completionTokens, cost }, 'CostEngine: estimated')
  return Math.round(cost * 1_000_000) / 1_000_000
}

class CostEngineImpl {
  private readonly records = new Map<string, CostRecord>()

  record(input: {
    correlationId: string
    courseId: string
    stage: string
    provider: Provider
    model: string
    promptTokens: number
    completionTokens: number
  }): CostRecord {
    const totalTokens = input.promptTokens + input.completionTokens
    const cost = estimateCost(input.provider, input.model, input.promptTokens, input.completionTokens)
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const record: CostRecord = {
      id: `cost-${ts}-${rand}`,
      correlationId: input.correlationId,
      courseId: input.courseId,
      stage: input.stage,
      provider: input.provider,
      model: input.model,
      promptTokens: input.promptTokens,
      completionTokens: input.completionTokens,
      totalTokens,
      cost,
      recordedAt: new Date().toISOString(),
    }
    this.records.set(record.id, record)
    logger.info({ costId: record.id, stage: input.stage, cost }, 'CostEngine: recorded')
    return record
  }

  getByCorrelationId(correlationId: string): CostRecord[] {
    return Array.from(this.records.values()).filter((r) => r.correlationId === correlationId)
  }

  getByCourseId(courseId: string): CostRecord[] {
    return Array.from(this.records.values()).filter((r) => r.courseId === courseId)
  }

  getByStage(stage: string): CostRecord[] {
    return Array.from(this.records.values()).filter((r) => r.stage === stage)
  }

  getTotal(correlationId?: string): { cost: number; tokens: number; records: number } {
    const filtered = correlationId ? this.getByCorrelationId(correlationId) : Array.from(this.records.values())
    const cost = filtered.reduce((sum, r) => sum + r.cost, 0)
    const tokens = filtered.reduce((sum, r) => sum + r.totalTokens, 0)
    return { cost: Math.round(cost * 1_000_000) / 1_000_000, tokens, records: filtered.length }
  }

  list(): CostRecord[] {
    return Array.from(this.records.values()).sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }

  clear(): void {
    this.records.clear()
  }

  size(): number {
    return this.records.size
  }

  getPricing(provider: CostProvider): PricingTier {
    return PRICING[provider] ?? PRICING.default
  }

  listPricing(): Record<CostProvider, PricingTier> {
    return { ...PRICING }
  }
}

export const costEngine = new CostEngineImpl()
