// =============================================================================
// AICF V3 — Épica 6 — Course Job Store
// =============================================================================
import { createHash } from 'node:crypto'
import { logger } from '@/lib/ai/logger'

export type CourseJobStage = 'research' | 'curriculum' | 'modules' | 'lessons' | 'assessment' | 'slides' | 'quality' | 'documents' | 'export' | 'finish'

export const STAGE_ORDER: CourseJobStage[] = ['research', 'curriculum', 'modules', 'lessons', 'assessment', 'slides', 'quality', 'documents', 'export', 'finish']

export type CourseJobStatus = 'pending' | 'queued' | 'running' | 'retrying' | 'paused' | 'completed' | 'failed' | 'cancelled'

const VALID_TRANSITIONS: Record<CourseJobStatus, CourseJobStatus[]> = {
  pending: ['queued', 'running', 'cancelled'],
  queued: ['running', 'cancelled'],
  running: ['paused', 'completed', 'failed', 'retrying', 'cancelled'],
  retrying: ['running', 'failed', 'cancelled'],
  paused: ['running', 'cancelled'],
  completed: [],
  failed: ['pending', 'cancelled'],
  cancelled: [],
}

export function isValidTransition(from: CourseJobStatus, to: CourseJobStatus): boolean {
  return VALID_TRANSITIONS[from]?.includes(to) ?? false
}

export interface CourseJobArtifact {
  artifactId: string
  type: string
  format: string
  name: string
  sizeBytes: number
  sha256: string
}

export interface CourseJobCheckpoint {
  stage: CourseJobStage
  data: Record<string, unknown>
}

export interface CourseJobRequest {
  title: string
  locale: string
  country: string
  audience: string
  level: 'Principiante' | 'Intermedio' | 'Avanzado' | 'Experto'
  objective: string
  certification: { finalExam: boolean; rubrics: boolean; certificate: boolean; badges: boolean; finalProject: boolean }
  contentTypes: Array<'pdf' | 'presentation' | 'videos' | 'scripts' | 'quizzes' | 'labs' | 'cases' | 'templates' | 'resources' | 'prompts'>
  premiumLevel: 'Standard' | 'Premium' | 'Enterprise'
  model: 'Auto' | 'Groq' | 'Gemini' | 'Claude' | 'OpenAI' | 'OpenRouter'
  budget: number
  mode: 'Rápido' | 'Balanceado' | 'Premium' | 'Investigación profunda'
  modules?: number
}

export interface CourseJob {
  id: string
  courseId: string
  idempotencyKey?: string
  status: CourseJobStatus
  stage: CourseJobStage
  progress: number
  startedAt: string
  updatedAt: string
  completedAt?: string
  error?: string
  checkpoint: CourseJobCheckpoint
  artifacts: CourseJobArtifact[]
  logs: string[]
  request: CourseJobRequest
}

export function computeRequestHash(request: CourseJobRequest): string {
  const canonical = JSON.stringify({ title: request.title, locale: request.locale, country: request.country, audience: request.audience, level: request.level, modules: request.modules ?? 5 })
  return createHash('sha256').update(canonical).digest('hex')
}

class CourseJobStoreImpl {
  private readonly jobs = new Map<string, CourseJob>()

  async create(request: CourseJobRequest, idempotencyKey?: string): Promise<CourseJob> {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const id = `job-${ts}-${rand}`
    const courseId = `course-${ts}-${rand}`
    const now = new Date().toISOString()
    const job: CourseJob = { id, courseId, idempotencyKey, status: 'pending', stage: 'research', progress: 0, startedAt: now, updatedAt: now, checkpoint: { stage: 'research', data: {} }, artifacts: [], logs: [`[${now}] Job created for "${request.title}"`], request }
    this.jobs.set(id, job)
    logger.info({ jobId: id, courseId, title: request.title }, 'CourseJobStore: job created')
    return job
  }

  async findByIdempotencyKey(key: string): Promise<CourseJob | null> {
    for (const job of this.jobs.values()) { if (job.idempotencyKey === key) return job }
    return null
  }

  async get(id: string): Promise<CourseJob | null> { return this.jobs.get(id) ?? null }

  async list(): Promise<CourseJob[]> { return Array.from(this.jobs.values()).sort((a, b) => b.startedAt.localeCompare(a.startedAt)) }

  async update(id: string, patch: Partial<Omit<CourseJob, 'id' | 'courseId' | 'request'>>): Promise<CourseJob | null> {
    const job = this.jobs.get(id)
    if (!job) return null
    const prevStage = job.stage
    const updated: CourseJob = { ...job, ...patch, id: job.id, courseId: job.courseId, request: job.request, updatedAt: new Date().toISOString() }
    if (patch.stage && patch.stage !== prevStage) {
      const stageIdx = STAGE_ORDER.indexOf(patch.stage as CourseJobStage)
      if (stageIdx >= 0) updated.progress = Math.round(((stageIdx + 1) / STAGE_ORDER.length) * 100)
      updated.logs = [...job.logs, `[${new Date().toISOString()}] stage: ${prevStage} → ${patch.stage}`]
    }
    if (patch.status === 'completed') { updated.completedAt = new Date().toISOString(); updated.progress = 100; updated.logs = [...updated.logs, `[${updated.completedAt}] job completed`] }
    if (patch.status === 'cancelled') { updated.logs = [...updated.logs, `[${new Date().toISOString()}] job cancelled`] }
    if (patch.status === 'failed' && patch.error) { updated.logs = [...updated.logs, `[${new Date().toISOString()}] ERROR: ${patch.error}`] }
    this.jobs.set(id, updated)
    return updated
  }

  async addArtifact(id: string, artifact: CourseJobArtifact): Promise<CourseJob | null> {
    const job = this.jobs.get(id)
    if (!job) return null
    const updated = { ...job, artifacts: [...job.artifacts, artifact], logs: [...job.logs, `[${new Date().toISOString()}] artifact: ${artifact.name} (${artifact.sizeBytes}B)`], updatedAt: new Date().toISOString() }
    this.jobs.set(id, updated)
    return updated
  }

  async addLog(id: string, line: string): Promise<CourseJob | null> {
    const job = this.jobs.get(id)
    if (!job) return null
    const updated = { ...job, logs: [...job.logs, `[${new Date().toISOString()}] ${line}`], updatedAt: new Date().toISOString() }
    this.jobs.set(id, updated)
    return updated
  }

  async cancel(id: string): Promise<CourseJob | null> { return this.update(id, { status: 'cancelled' }) }
  async pause(id: string): Promise<CourseJob | null> { return this.update(id, { status: 'paused' }) }
  async resume(id: string): Promise<CourseJob | null> { const job = await this.get(id); if (!job) return null; return this.update(id, { status: 'running', stage: job.checkpoint.stage }) }
  async delete(id: string): Promise<boolean> { return this.jobs.delete(id) }
  async clear(): Promise<void> { this.jobs.clear() }
  async size(): Promise<number> { return this.jobs.size }
}

export const CourseJobStore = new CourseJobStoreImpl()
