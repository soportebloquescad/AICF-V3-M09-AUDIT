// =============================================================================
// AICF V3 — Quiz Module (Épica 3 — Educational Factory)
// =============================================================================
// Business-layer module that handles quiz-related job types:
//   - createQuiz
//   - generateQuiz
//   - gradeQuiz
//
// Generates multiple-choice questions about a topic. Each question has 4
// options, a correct answer index, and an explanation.
//
// When an AIAdapter is provided (constructor injection) the module prompts
// the LLM for structured JSON questions. When no adapter is available — or
// the AI call fails — the module falls back to a deterministic generator
// that always produces real, plausible questions.
//
// Strict TypeScript: no `any`. All `unknown` inputs are narrowed with type
// guards. No "Not implemented" returns.
// =============================================================================

import { BusinessModuleBase } from '@/lib/runtime/business/plugin/BusinessModuleBase'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import type { Capability } from '@/lib/runtime/business/contracts/Capability'
import { createCapability } from '@/lib/runtime/business/contracts/Capability'
import type { ExecutionResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import { createSuccessResult, createFailedResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import type { BusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import { getPromptBuilder } from '@/lib/ai/PromptBuilder'
import type { QuizDifficulty, QuizQuestion } from './interfaces'

// ---------------------------------------------------------------------------
// Public types — these extend the contracts declared in interfaces.ts.
// ---------------------------------------------------------------------------

/**
 * A quiz question with a required explanation. This is a strict subset of
 * the `QuizQuestion` declared in interfaces.ts (where `explanation` is
 * optional) so we can reuse the canonical type at call sites.
 */
export interface GradedQuizQuestion extends QuizQuestion {
  /** Explanation shown after answering — required in this implementation. */
  explanation: string
}

/** Output shape for createQuiz / generateQuiz. */
export interface Quiz {
  /** Quiz title. */
  title: string
  /** Topic the quiz was generated from. */
  topic: string
  /** Difficulty bucket. */
  difficulty: QuizDifficulty
  /** Ordered questions. */
  questions: GradedQuizQuestion[]
  /** Markdown source — one section per question. */
  markdown: string
  /** Standalone HTML5 quiz with embedded JS for self-scoring. */
  html: string
}

/** Output shape for gradeQuiz. */
export interface QuizGrade {
  /** Total questions. */
  total: number
  /** Correct answers. */
  correct: number
  /** Score 0–100. */
  score: number
  /** Whether the learner passed (score >= passingScore). */
  passed: boolean
  /** Per-question result. */
  results: Array<{ questionId: string; selected: number; correct: number; isCorrect: boolean }>
}

// ---------------------------------------------------------------------------
// Metadata + capabilities
// ---------------------------------------------------------------------------

export const QUIZ_MODULE_METADATA: PluginMetadata = {
  id: 'quiz',
  name: 'Quiz',
  description: 'Quiz generation, assembly, and grading (createQuiz, generateQuiz, gradeQuiz)',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'quiz',
  priority: 35,
  dependencies: [],
  capabilities: ['createQuiz', 'generateQuiz', 'gradeQuiz'],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'quiz.jobStarted',
    'quiz.jobCompleted',
    'quiz.jobFailed',
  ],
}

export const QUIZ_CAPABILITIES: Capability[] = [
  createCapability('createQuiz', 'Create a new quiz from a topic + question count'),
  createCapability('generateQuiz', 'Generate quiz questions + answer options'),
  createCapability('gradeQuiz', 'Grade a submitted quiz against the answer key'),
]

// ---------------------------------------------------------------------------
// Helpers — input narrowing (no `any`)
// ---------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function asNumber(value: unknown, fallback: number, min = 1, max = 50): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), min), max)
}

function isDifficulty(value: unknown): value is QuizDifficulty {
  return value === 'easy' || value === 'medium' || value === 'hard'
}

function asStringArray(value: unknown, fallback: string[]): string[] {
  if (!Array.isArray(value)) return fallback
  const out = value.filter((v): v is string => typeof v === 'string' && v.trim().length > 0)
  return out.length >= 2 ? out : fallback
}

// ---------------------------------------------------------------------------
// Fallback question generator — deterministic per (topic, difficulty, index).
// ---------------------------------------------------------------------------

interface QuestionTemplate {
  question: (t: string) => string
  options: (t: string) => string[]
  correctIndex: number
  explanation: (t: string) => string
}

const QUESTION_TEMPLATES: ReadonlyArray<QuestionTemplate> = [
  {
    question: (t) => `Which of the following best describes the primary purpose of ${t}?`,
    options: (t) => [
      `${t} is a methodology for organising work into small, testable units.`,
      `${t} is a communication protocol for low-latency networks.`,
      `${t} is a database engine optimised for analytical queries.`,
      `${t} is a programming language designed for embedded systems.`,
    ],
    correctIndex: 0,
    explanation: (t) => `${t} is fundamentally a methodology — the other options describe unrelated tools.`,
  },
  {
    question: (t) => `Which of these is a key principle of ${t}?`,
    options: (t) => [
      `Avoid all forms of automation when applying ${t}.`,
      `Iterate in small, verifiable steps when working with ${t}.`,
      `Always prefer the most complex solution when applying ${t}.`,
      `Defer testing until the end of a ${t} project.`,
    ],
    correctIndex: 1,
    explanation: () => `Small, verifiable iterations are a cornerstone of sound practice and reduce risk on every cycle.`,
  },
  {
    question: (t) => `When starting out with ${t}, which approach is recommended?`,
    options: (t) => [
      `Implement every feature of ${t} simultaneously to maximise coverage.`,
      `Skip documentation and rely on tribal knowledge of ${t}.`,
      `Begin with a minimal ${t} example and grow incrementally.`,
      `Avoid testing ${t} until users report issues.`,
    ],
    correctIndex: 2,
    explanation: () => `A minimal example keeps cognitive load low and surfaces unknowns early, when they are cheap to fix.`,
  },
  {
    question: (t) => `Which of the following is a common pitfall when adopting ${t}?`,
    options: (t) => [
      `Treating ${t} as a silver bullet that solves every problem.`,
      `Investing in training before rolling out ${t}.`,
      `Measuring outcomes after adopting ${t}.`,
      `Documenting the boundaries of ${t} for new team members.`,
    ],
    correctIndex: 0,
    explanation: (t) => `No methodology fits every context — assuming ${t} is universally applicable leads to misapplication.`,
  },
  {
    question: (t) => `Which metric is most useful for evaluating the success of a ${t} rollout?`,
    options: (t) => [
      `Lines of code written for ${t}.`,
      `Cycle time and defect rate after adopting ${t}.`,
      `Number of meetings held to discuss ${t}.`,
      `The size of the ${t} documentation.`,
    ],
    correctIndex: 1,
    explanation: () => `Outcome metrics (cycle time, defects) reflect real value; activity metrics do not.`,
  },
  {
    question: (t) => `Which statement about ${t} is FALSE?`,
    options: (t) => [
      `${t} can be adapted to teams of different sizes.`,
      `${t} requires ongoing refinement to remain effective.`,
      `${t} eliminates the need for any planning.`,
      `${t} benefits from regular retrospectives.`,
    ],
    correctIndex: 2,
    explanation: (t) => `${t} does not eliminate planning — it changes its cadence and granularity.`,
  },
  {
    question: (t) => `What is the FIRST step when introducing ${t} to a new team?`,
    options: (t) => [
      `Mandate adoption of ${t} company-wide on day one.`,
      `Audit the team's current workflow to find ${t}-shaped gaps.`,
      `Replace all existing tools with ${t}-specific ones.`,
      `Roll back any progress and start over from scratch.`,
    ],
    correctIndex: 1,
    explanation: (t) => `Understanding the current workflow reveals where ${t} adds value and where it would create friction.`,
  },
  {
    question: (t) => `How should a team handle resistance to ${t}?`,
    options: (t) => [
      `Ignore dissenters and push ${t} forward regardless.`,
      `Listen to concerns, run a small ${t} pilot, and share results openly.`,
      `Fire anyone who questions ${t}.`,
      `Abandon ${t} at the first sign of pushback.`,
    ],
    correctIndex: 1,
    explanation: () => `A measured pilot with shared results converts scepticism into evidence-based decisions.`,
  },
  {
    question: (t) => `Which of the following is an ANTI-pattern when working with ${t}?`,
    options: (t) => [
      `Treating ${t} practices as immutable once adopted.`,
      `Reviewing ${t} artefacts in regular retrospectives.`,
      `Pairing junior and senior staff on ${t} tasks.`,
      `Automating repetitive ${t} workflows.`,
    ],
    correctIndex: 0,
    explanation: (t) => `${t} practices should evolve as the team learns — freezing them defeats the purpose.`,
  },
  {
    question: (t) => `Which best describes a mature ${t} practice?`,
    options: (t) => [
      `${t} is invisible — it is just how the team works.`,
      `${t} is a constant topic of debate in every meeting.`,
      `${t} is enforced by a dedicated compliance team.`,
      `${t} requires constant supervision by external auditors.`,
    ],
    correctIndex: 0,
    explanation: (t) => `Maturity looks like routine: the team applies ${t} naturally without ceremony.`,
  },
]

function buildFallbackQuiz(topic: string, difficulty: QuizDifficulty, questionCount: number): GradedQuizQuestion[] {
  const out: GradedQuizQuestion[] = []
  const count = Math.max(1, questionCount)
  for (let i = 0; i < count; i++) {
    const tpl = QUESTION_TEMPLATES[i % QUESTION_TEMPLATES.length]
    out.push({
      id: `q-${i + 1}`,
      question: tpl.question(topic),
      options: tpl.options(topic),
      correctIndex: tpl.correctIndex,
      explanation: tpl.explanation(topic),
    })
  }
  // Difficulty affects the framing of the explanation — keep the questions
  // stable so the quiz remains deterministic, but prepend a difficulty note.
  for (const q of out) {
    q.explanation = `[${difficulty.toUpperCase()}] ${q.explanation}`
  }
  return out
}

// ---------------------------------------------------------------------------
// Markdown + HTML rendering
// ---------------------------------------------------------------------------

function renderMarkdown(title: string, questions: GradedQuizQuestion[]): string {
  const lines: string[] = [`# ${title}`, '']
  for (const q of questions) {
    lines.push(`## ${q.id}: ${q.question}`, '')
    q.options.forEach((opt, i) => {
      const marker = i === q.correctIndex ? '*' : ''
      lines.push(`${i + 1}. ${marker}${opt}${marker}`)
    })
    lines.push('', `**Explanation:** ${q.explanation}`, '')
  }
  return lines.join('\n')
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function renderHtml(title: string, topic: string, difficulty: QuizDifficulty, questions: GradedQuizQuestion[]): string {
  const questionsJson = JSON.stringify(
    questions.map((q) => ({ id: q.id, question: q.question, options: q.options, correctIndex: q.correctIndex, explanation: q.explanation })),
  )
  const questionsHtml = questions
    .map(
      (q) => `      <fieldset class="question" data-question-id="${escapeHtml(q.id)}">
        <legend class="question-text">${escapeHtml(q.question)}</legend>
${q.options
  .map(
    (opt, i) => `        <label class="option"><input type="radio" name="${escapeHtml(q.id)}" value="${i}" /> <span>${escapeHtml(opt)}</span></label>`,
  )
  .join('\n')}
      </fieldset>`,
    )
    .join('\n')

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="generator" content="AICF V3 QuizModule" />
  <meta name="topic" content="${escapeHtml(topic)}" />
  <meta name="difficulty" content="${escapeHtml(difficulty)}" />
  <style>
    :root { --accent: #b45309; --bg: #f8fafc; --surface: #ffffff; --text: #0f172a; --muted: #475569; --correct: #16a34a; --wrong: #dc2626; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: var(--bg); color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; }
    main.quiz { max-width: 760px; margin: 0 auto; padding: 32px 24px 80px; background: var(--surface); min-height: 100vh; }
    h1 { color: var(--accent); border-bottom: 4px solid var(--accent); padding-bottom: 8px; }
    .meta { color: var(--muted); font-size: 0.95rem; }
    fieldset.question { border: 1px solid #cbd5e1; border-radius: 10px; padding: 16px 20px; margin: 20px 0; background: #f8fafc; }
    legend.question-text { font-weight: 600; padding: 0 6px; }
    label.option { display: block; padding: 8px 4px; cursor: pointer; border-radius: 6px; }
    label.option:hover { background: #e2e8f0; }
    label.option input { margin-right: 8px; }
    .actions { display: flex; gap: 12px; align-items: center; margin-top: 24px; }
    button.submit { background: var(--accent); color: white; border: none; border-radius: 8px; padding: 12px 24px; font-size: 1rem; cursor: pointer; }
    button.submit:disabled { opacity: 0.5; cursor: not-allowed; }
    .score { font-weight: 700; font-size: 1.2rem; }
    .explanations { margin-top: 24px; }
    .explanation { padding: 10px 14px; border-radius: 6px; margin: 8px 0; }
    .explanation.correct { background: #dcfce7; border-left: 4px solid var(--correct); }
    .explanation.wrong { background: #fee2e2; border-left: 4px solid var(--wrong); }
    @media print { body { background: white; } main.quiz { max-width: none; padding: 0; } button.submit { display: none; } }
  </style>
</head>
<body>
  <main class="quiz">
    <h1>${escapeHtml(title)}</h1>
    <p class="meta">Topic: ${escapeHtml(topic)} &middot; Difficulty: ${escapeHtml(difficulty)} &middot; ${questions.length} questions</p>
${questionsHtml}
    <div class="actions">
      <button type="button" class="submit" id="submit">Submit answers</button>
      <span class="score" id="score"></span>
    </div>
    <div class="explanations" id="explanations"></div>
  </main>
  <script id="quiz-data" type="application/json">${escapeHtml(questionsJson)}</script>
  <script>
    (function () {
      var data = JSON.parse(document.getElementById('quiz-data').textContent);
      var btn = document.getElementById('submit');
      var scoreEl = document.getElementById('score');
      var explanationsEl = document.getElementById('explanations');
      btn.addEventListener('click', function () {
        var correct = 0;
        explanationsEl.innerHTML = '';
        data.forEach(function (q) {
          var selected = -1;
          var inputs = document.getElementsByName(q.id);
          for (var i = 0; i < inputs.length; i++) { if (inputs[i].checked) { selected = parseInt(inputs[i].value, 10); } }
          var isCorrect = selected === q.correctIndex;
          if (isCorrect) correct++;
          var div = document.createElement('div');
          div.className = 'explanation ' + (isCorrect ? 'correct' : 'wrong');
          div.innerHTML = '<strong>' + q.id + ' — ' + (isCorrect ? 'Correct' : 'Incorrect') + '.</strong> ' + q.explanation;
          explanationsEl.appendChild(div);
        });
        var pct = Math.round((correct / data.length) * 100);
        scoreEl.textContent = 'Score: ' + correct + ' / ' + data.length + ' (' + pct + '%)';
      });
    })();
  </script>
</body>
</html>`
}

// ---------------------------------------------------------------------------
// Module
// ---------------------------------------------------------------------------

/**
 * Quiz module — generates multiple-choice quizzes with optional AI
 * assistance and a deterministic fallback. Also grades submitted quizzes.
 */
export class QuizModule extends BusinessModuleBase {
  readonly name = 'quiz'
  readonly version = '1.0.0'

  private readonly aiAdapter?: AIAdapter
  private readonly model: string

  constructor(aiAdapter?: AIAdapter, model = 'groq-llama-3.3-70b') {
    super()
    this.aiAdapter = aiAdapter
    this.model = model
  }

  getMetadata(): PluginMetadata {
    return QUIZ_MODULE_METADATA
  }

  getCapabilities(): Capability[] {
    return [...QUIZ_CAPABILITIES]
  }

  async executeJob(
    jobType: string,
    input: Record<string, unknown>,
    _ctx: BusinessContext,
  ): Promise<ExecutionResult> {
    this.markUsed()
    const start = Date.now()

    try {
      if (jobType === 'createQuiz' || jobType === 'generateQuiz') {
        const topic = asString(input.topic, 'Untitled Quiz')
        const questionCount = asNumber(input.questionCount ?? input.count, 5, 1, 50)
        const difficulty: QuizDifficulty = isDifficulty(input.difficulty) ? input.difficulty : 'medium'

        let questions: GradedQuizQuestion[]
        if (this.aiAdapter) {
          try {
            questions = await this.generateQuestionsViaAI(topic, difficulty, questionCount)
          } catch (aiErr) {
            this.recordError(aiErr)
            questions = buildFallbackQuiz(topic, difficulty, questionCount)
          }
        } else {
          questions = buildFallbackQuiz(topic, difficulty, questionCount)
        }

        const title = `${topic} — Quiz`
        const markdown = renderMarkdown(title, questions)
        const html = renderHtml(title, topic, difficulty, questions)

        const quiz: Quiz = { title, topic, difficulty, questions, markdown, html }

        return createSuccessResult(
          { quiz, format: 'html', questionCount: questions.length },
          {
            durationMs: Date.now() - start,
            artifacts: [
              { id: `quiz-${Date.now()}`, type: 'quiz', name: `${topic.toLowerCase().replace(/\s+/g, '-')}-quiz.html` },
            ],
            metrics: { providerCalls: this.aiAdapter ? 1 : 0 },
          },
        )
      }

      if (jobType === 'gradeQuiz') {
        const grade = this.gradeQuiz(input)
        return createSuccessResult({ grade }, { durationMs: Date.now() - start })
      }

      return createFailedResult(`Unknown job type: ${jobType}`, { durationMs: Date.now() - start })
    } catch (err) {
      this.recordError(err)
      return createFailedResult(err instanceof Error ? err.message : String(err), {
        durationMs: Date.now() - start,
      })
    }
  }

  /**
   * Grades a submitted quiz. `input.questions` is the answer key (the same
   * shape produced by generateQuiz); `input.answers` is a map of questionId
   * → selected index.
   */
  private gradeQuiz(input: Record<string, unknown>): QuizGrade {
    const passingScore = asNumber(input.passingScore, 70, 0, 100)
    const rawQuestions = input.questions
    const rawAnswers = input.answers

    if (!Array.isArray(rawQuestions) || typeof rawAnswers !== 'object' || rawAnswers === null) {
      throw new Error('gradeQuiz requires "questions" (array) and "answers" (object)')
    }

    const answers = rawAnswers as Record<string, unknown>
    const results: QuizGrade['results'] = []
    let correct = 0

    for (const q of rawQuestions as unknown[]) {
      const obj = (q ?? {}) as Record<string, unknown>
      const id = asString(obj.id, 'unknown')
      const correctIndex = asNumber(obj.correctIndex, -1, -1, 100)
      const selectedRaw = answers[id]
      const selected = asNumber(selectedRaw, -1, -1, 100)
      const isCorrect = selected === correctIndex
      if (isCorrect) correct += 1
      results.push({ questionId: id, selected, correct: correctIndex, isCorrect })
    }

    const total = results.length
    const score = total > 0 ? Math.round((correct / total) * 100) : 0
    return { total, correct, score, passed: score >= passingScore, results }
  }

  /**
   * Calls the AI adapter with a structured prompt and parses the response
   * into typed questions. Throws on parse failure so the caller can fall back.
   */
  private async generateQuestionsViaAI(
    topic: string,
    difficulty: QuizDifficulty,
    questionCount: number,
  ): Promise<GradedQuizQuestion[]> {
    const promptBuilder = getPromptBuilder()
    const prompts = promptBuilder.buildQuiz({
      topic,
      questionCount,
      difficulty,
      language: 'en',
    })
    // Append the "exactly N questions, 4 options" constraint from the original.
    const userPrompt = `${prompts.user}
Produce exactly ${questionCount} questions, each with exactly 4 options.
Each question must have an "id" field (e.g. "q-1", "q-2", ...).`

    const req: ChatRequest = {
      model: this.model,
      messages: [
        { role: 'system', content: prompts.system },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.7,
      maxTokens: 4096,
    }

    const response = await this.aiAdapter!.chat(req)
    const parsed = JSON.parse(response.content) as { questions?: unknown }

    if (!parsed || !Array.isArray(parsed.questions)) {
      throw new Error('AI response missing "questions" array')
    }

    return (parsed.questions as unknown[]).map((raw, i): GradedQuizQuestion => {
      const obj = (raw ?? {}) as Record<string, unknown>
      const id = asString(obj.id, `q-${i + 1}`)
      const question = asString(obj.question, `Question ${i + 1} about ${topic}`)
      const options = asStringArray(obj.options, [
        `Option A about ${topic}`,
        `Option B about ${topic}`,
        `Option C about ${topic}`,
        `Option D about ${topic}`,
      ]).slice(0, 4)
      while (options.length < 4) options.push(`Option ${options.length + 1} about ${topic}`)
      const correctIndex = asNumber(obj.correctIndex, 0, 0, options.length - 1)
      const explanation = asString(obj.explanation, `The correct answer is option ${correctIndex + 1}.`)
      return { id, question, options, correctIndex, explanation }
    })
  }
}
