// =============================================================================
// AICF V3 — Metrics Registry (Sprint 17: Runtime Foundation Consolidation)
// =============================================================================
// Centralized per-module call metrics: call count, error count, average /
// p95 / p99 latency, total duration, last-used timestamps. Replaces ad-hoc
// per-module metrics with a single registry that all module calls flow
// through.
//
// NOTE: This `ModuleMetrics` is intentionally different from the legacy
// `ModuleMetrics` in `contracts/RuntimeModule.ts` (which tracks init
// latency + operation count). The legacy interface stays untouched for
// backward compatibility; this new interface tracks call-level metrics.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * Per-module call metrics (Sprint 17).
 */
export interface ModuleMetrics {
  /** Number of calls recorded. */
  callCount: number
  /** Number of calls that errored. */
  errorCount: number
  /** Average latency in milliseconds. */
  avgLatencyMs: number
  /** 95th-percentile latency in milliseconds. */
  p95LatencyMs: number
  /** 99th-percentile latency in milliseconds. */
  p99LatencyMs: number
  /** ISO timestamp of the last call (or null if never called). */
  lastUsed: string | null
  /** Last error message (or null if no errors). */
  lastError: string | null
  /** Total cumulative duration in milliseconds. */
  totalDurationMs: number
}

/**
 * Internal record: the live metrics counter + the latency samples (for
 * percentile calculation). Latency samples are capped to bound memory.
 */
interface ModuleRecord {
  callCount: number
  errorCount: number
  totalDurationMs: number
  lastUsed: string | null
  lastError: string | null
  latencies: number[]
}

/** Maximum number of latency samples retained per module for percentile calc. */
const MAX_LATENCY_SAMPLES = 1000

/**
 * Creates a zeroed-out ModuleMetrics (for unknown modules).
 */
export function createEmptyModuleMetrics(): ModuleMetrics {
  return {
    callCount: 0,
    errorCount: 0,
    avgLatencyMs: 0,
    p95LatencyMs: 0,
    p99LatencyMs: 0,
    lastUsed: null,
    lastError: null,
    totalDurationMs: 0,
  }
}

/**
 * Computes a percentile from a sorted sample array.
 * `p` is in [0, 1]. Returns 0 if the array is empty.
 */
function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0
  if (sorted.length === 1) return sorted[0]
  // Nearest-rank method (inclusive).
  const rank = Math.ceil(p * sorted.length)
  const idx = Math.max(0, Math.min(sorted.length - 1, rank - 1))
  return sorted[idx]
}

/**
 * MetricsRegistry — records per-module call metrics and computes aggregates.
 *
 * @example
 * const registry = new MetricsRegistry()
 * registry.recordCall('workflow', 42)
 * registry.recordCall('workflow', 88, 'timeout')
 * const m = registry.getMetrics('workflow')
 * // m.callCount === 2, m.errorCount === 1, m.avgLatencyMs === 65, ...
 */
export class MetricsRegistry {
  private readonly records = new Map<string, ModuleRecord>()

  /**
   * Records a single call. Updates callCount, errorCount (if `error` is set),
   * totalDurationMs, lastUsed, lastError, and the latency sample buffer.
   */
  recordCall(moduleId: string, durationMs: number, error?: string): void {
    let record = this.records.get(moduleId)
    if (!record) {
      record = {
        callCount: 0,
        errorCount: 0,
        totalDurationMs: 0,
        lastUsed: null,
        lastError: null,
        latencies: [],
      }
      this.records.set(moduleId, record)
    }

    record.callCount += 1
    record.totalDurationMs += durationMs
    record.lastUsed = new Date().toISOString()

    if (error) {
      record.errorCount += 1
      record.lastError = error
    }

    record.latencies.push(durationMs)
    if (record.latencies.length > MAX_LATENCY_SAMPLES) {
      // Drop the oldest sample (FIFO) to bound memory.
      record.latencies.shift()
    }
  }

  /**
   * Returns the current metrics for a module. Returns empty metrics if the
   * module has never been recorded.
   */
  getMetrics(moduleId: string): ModuleMetrics {
    const record = this.records.get(moduleId)
    if (!record) return createEmptyModuleMetrics()

    const sorted = [...record.latencies].sort((a, b) => a - b)
    const avg = record.callCount > 0 ? record.totalDurationMs / record.callCount : 0

    return {
      callCount: record.callCount,
      errorCount: record.errorCount,
      avgLatencyMs: avg,
      p95LatencyMs: percentile(sorted, 0.95),
      p99LatencyMs: percentile(sorted, 0.99),
      lastUsed: record.lastUsed,
      lastError: record.lastError,
      totalDurationMs: record.totalDurationMs,
    }
  }

  /**
   * Returns metrics for all modules (moduleId → ModuleMetrics).
   */
  getAllMetrics(): Record<string, ModuleMetrics> {
    const result: Record<string, ModuleMetrics> = {}
    for (const moduleId of this.records.keys()) {
      result[moduleId] = this.getMetrics(moduleId)
    }
    return result
  }

  /**
   * Resets a single module's metrics.
   */
  reset(moduleId: string): void {
    this.records.delete(moduleId)
    logger.debug({ moduleId }, 'MetricsRegistry: reset metrics for module')
  }

  /**
   * Resets all modules' metrics.
   */
  resetAll(): void {
    this.records.clear()
    logger.debug('MetricsRegistry: reset all metrics')
  }

  /**
   * Returns all module IDs that have recorded metrics.
   */
  getModuleIds(): string[] {
    return Array.from(this.records.keys())
  }
}
