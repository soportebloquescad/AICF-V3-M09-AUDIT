// =============================================================================
// AICF V3 — Quizzes Module (barrel)
// =============================================================================
// Re-exports the public typed contracts of the Quizzes module plus the
// concrete QuizModule (Épica 3 — Educational Factory).
// =============================================================================

export type {
  QuizzesModule,
  QuizOptions,
  QuizDifficulty,
  QuizQuestion,
  QuizResult,
} from './interfaces'

export {
  QuizModule,
  QUIZ_MODULE_METADATA,
  QUIZ_CAPABILITIES,
} from './QuizModule'

export type { GradedQuizQuestion, Quiz, QuizGrade } from './QuizModule'
