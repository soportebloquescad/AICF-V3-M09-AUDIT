// =============================================================================
// AICF V3 — Business Module Registry (Épica 2 — AI Factory Core, B5)
// =============================================================================
// Registry for Business-layer modules (subclasses of BusinessModuleBase).
// This is SEPARATE from the Runtime-layer ModuleRegistry — the Business
// layer is a new tier and its modules live here so existing Runtime code
// is untouched (frozen).
//
// Operations:
//   - register(module)              → add a module by its `name` (id).
//   - unregister(moduleId)          → remove a module + drop its capability index.
//   - get(moduleId)                 → fetch a module by id (or null).
//   - list()                        → all registered modules (insertion order).
//   - findByCapability(capability)  → every module that exposes `capability`.
//   - listCapabilities()            → every capability name across all modules.
//
// The registry is in-memory + per-instance (no global singleton). The
// RuntimeService.executeJob() will use the per-RuntimeService instance that
// B10 wires up.
//
// No `any`.
// =============================================================================

import { BusinessModuleBase } from '../plugin/BusinessModuleBase'
import { logger } from '@/lib/ai/logger'

/**
 * In-memory registry for Business-layer modules.
 *
 * @example
 * const registry = new BusinessModuleRegistry()
 * registry.register(new CourseModule())
 * registry.register(new PresentationModule())
 *
 * const testModule = registry.get('course')            // → CourseModule | null
 * const mods = registry.findByCapability('createCourse')  // → [CourseModule]
 * const caps = registry.listCapabilities()         // → ['createCourse', ...]
 */
export class BusinessModuleRegistry {
  /** Insertion-ordered map of module id → module instance. */
  private readonly modules = new Map<string, BusinessModuleBase>()

  /**
   * Registers a module. Keyed by `module.name`. Overwrites a previous
   * registration for the same id (logged at debug).
   */
  register(module: BusinessModuleBase): void {
    const id = module.name
    if (this.modules.has(id)) {
      logger.debug(
        { moduleId: id, existing: true },
        'BusinessModuleRegistry: overwriting existing module registration',
      )
    }
    this.modules.set(id, module)
    logger.debug(
      { moduleId: id, capabilities: module.getCapabilities().map((c) => c.name) },
      'BusinessModuleRegistry: module registered',
    )
  }

  /**
   * Unregisters a module by id. No-op if the id is unknown.
   */
  unregister(moduleId: string): void {
    const removed = this.modules.delete(moduleId)
    if (removed) {
      logger.debug({ moduleId }, 'BusinessModuleRegistry: module unregistered')
    }
  }

  /**
   * Returns the module with the given id (or null).
   */
  get(moduleId: string): BusinessModuleBase | null {
    return this.modules.get(moduleId) ?? null
  }

  /**
   * Returns every registered module in insertion order.
   */
  list(): BusinessModuleBase[] {
    return Array.from(this.modules.values())
  }

  /**
   * Returns every module that exposes the given capability name.
   * Returns an empty array if no module matches.
   */
  findByCapability(capability: string): BusinessModuleBase[] {
    const out: BusinessModuleBase[] = []
    for (const mod of this.modules.values()) {
      const caps = mod.getCapabilities()
      if (caps.some((c) => c.name === capability)) {
        out.push(mod)
      }
    }
    return out
  }

  /**
   * Returns every capability name across all registered modules (de-duplicated
   * + insertion-ordered). Useful for capability discovery endpoints.
   */
  listCapabilities(): string[] {
    const seen = new Set<string>()
    const out: string[] = []
    for (const mod of this.modules.values()) {
      for (const cap of mod.getCapabilities()) {
        if (!seen.has(cap.name)) {
          seen.add(cap.name)
          out.push(cap.name)
        }
      }
    }
    return out
  }

  /**
   * Returns the list of registered module ids (insertion order). Useful for
   * diagnostics + tests.
   */
  listIds(): string[] {
    return Array.from(this.modules.keys())
  }

  /**
   * Clears every registration. Mainly for tests.
   */
  clear(): void {
    this.modules.clear()
  }
}
