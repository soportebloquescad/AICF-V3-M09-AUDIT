// =============================================================================
// AICF V3 — SCORM Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a SCORM `imsmanifest.xml` file. The output
// is a valid SCORM 1.2 or SCORM 2004 (4th Edition) package manifest that an
// LMS (Moodle, Blackboard, Canvas, SCORM Cloud) can import as a learning
// object.
//
// The manifest declares:
//   - The proper IMS CP + ADL namespaces for the chosen version
//   - A single <organization> with one <item> pointing at the SCO resource
//   - A <resource> of type "web content" that references the SCO launcher
//     ("index.html") and declares the adlcp:scormtype attribute
//   - The mandatory <metadata> block with the ADL CP root schema
//
// The exporter NEVER generates or modifies content — it only wraps the
// supplied Markdown into the SCORM manifest vocabulary. Downstream packaging
// (zipping the manifest + the rendered HTML) is the responsibility of the
// caller; this exporter produces the XML text only.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { escapeHtml } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by SCORMExporter.export(). */
export type ScormExportMetadata = Record<string, unknown>

/** Supported SCORM versions. */
export type ScormVersion = '1.2' | '2004'

/** Schema describing one SCORM item (a learning activity). */
export interface ScormItem {
  /** Stable item identifier (must be a valid XML ID). */
  identifier: string
  /** Human-readable title. */
  title: string
  /** Identifier of the referenced <resource>. */
  resourceIdentifier: string
  /** Mastery score required to pass (0-100), if applicable. */
  masteryScore?: number
  /** Estimated time the learner should spend on this item (e.g. "PT30M"). */
  timeLimitAction?: 'exit,message' | 'exit,no message' | 'continue,message' | 'continue,no message'
}

/** Default SCORM versions when the caller omits the version argument. */
const DEFAULT_VERSION: ScormVersion = '1.2'

/**
 * SCORMExporter — transforms content to a SCORM imsmanifest.xml.
 */
export class SCORMExporter {
  /**
   * Transform `content` into a SCORM `imsmanifest.xml` document.
   *
   * @param content  Source content (Markdown). Embedded into the manifest as
   *                 a base SCO resource reference so the LMS can launch it.
   * @param metadata Optional metadata: { title, identifier, language, author,
   *                 description, version, scormVersion, items, ... }.
   * @param version  SCORM version override ('1.2' or '2004').
   * @returns A valid `imsmanifest.xml` document string.
   */
  export(
    content: string,
    metadata?: ScormExportMetadata,
    version?: ScormVersion,
  ): string {
    const meta = metadata ?? {}
    const ver: ScormVersion = version ?? asVersion(meta.scormVersion) ?? DEFAULT_VERSION
    const title = asString(meta.title, asString(meta.topic, 'SCORM Learning Object'))
    const courseIdentifier = asXmlId(meta.identifier, 'aicf-course')
    const language = asString(meta.language, 'en').toLowerCase()
    const description = asString(meta.description, '')
    const author = asString(meta.author, '')
    const versionStr = asString(meta.version, '1.0.0')
    const contentSize = (content ?? '').length
    const items = this.resolveItems(meta.items, title, courseIdentifier)
    const resources = this.buildResources(items, contentSize)
    const schema = ver === '2004' ? SCORM_2004_SCHEMA : SCORM_1_2_SCHEMA

    const lines: string[] = []
    lines.push('<?xml version="1.0" encoding="UTF-8"?>')
    lines.push(this.buildManifestRoot(courseIdentifier, ver))
    lines.push('  <metadata>')
    lines.push('    <schema>' + schema.schema + '</schema>')
    lines.push('    <schemaversion>' + schema.schemaversion + '</schemaversion>')
    lines.push('    <adlcp:location>imsmetadata.xml</adlcp:location>')
    lines.push('  </metadata>')
    lines.push(this.buildOrganizations(items, language, description, ver))
    lines.push(resources)
    lines.push('</manifest>')
    lines.push('')
    return lines.join('\n')
  }

  // -------------------------------------------------------------------------
  // Manifest root + namespaces
  // -------------------------------------------------------------------------

  private buildManifestRoot(identifier: string, version: ScormVersion): string {
    if (version === '2004') {
      return [
        '<manifest identifier="' + escapeXmlAttr(identifier) + '" version="1.0"',
        '          xmlns="http://www.imsglobal.org/xsd/imscp_v1p1"',
        '          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_v1p3"',
        '          xmlns:adlseq="http://www.adlnet.org/xsd/adlseq_v1p3"',
        '          xmlns:imsss="http://www.imsglobal.org/xsd/imsss"',
        '          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
        '          xsi:schemaLocation="http://www.imsglobal.org/xsd/imscp_v1p1 imscp_v1p1.xsd',
        '                              http://www.adlnet.org/xsd/adlcp_v1p3 adlcp_v1p3.xsd',
        '                              http://www.adlnet.org/xsd/adlseq_v1p3 adlseq_v1p3.xsd',
        '                              http://www.imsglobal.org/xsd/imsss imsss_v1p0.xsd">',
      ].join('\n')
    }
    return [
      '<manifest identifier="' + escapeXmlAttr(identifier) + '" version="1.0"',
      '          xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2"',
      '          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2"',
      '          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
      '          xsi:schemaLocation="http://www.imsproject.org/xsd/imscp_rootv1p1p2 imscp_rootv1p1p2.xsd',
      '                              http://www.adlnet.org/xsd/adlcp_rootv1p2 adlcp_rootv1p2.xsd">',
    ].join('\n')
  }

  // -------------------------------------------------------------------------
  // Organizations
  // -------------------------------------------------------------------------

  private buildOrganizations(
    items: ScormItem[],
    language: string,
    description: string,
    version: ScormVersion,
  ): string {
    const orgId = 'ORG-1'
    const defaultItem = items[0]?.identifier ?? ''
    const lines: string[] = []
    lines.push('  <organizations default="' + escapeXmlAttr(orgId) + '">')
    lines.push('    <organization identifier="' + escapeXmlAttr(orgId) + '" structure="hierarchical">')
    lines.push('      <title>' + escapeXmlText(items[0]?.title ?? 'SCORM Course') + '</title>')
    for (const item of items) {
      lines.push('      <item identifier="' + escapeXmlAttr(item.identifier) + '" identifierref="' + escapeXmlAttr(item.resourceIdentifier) + '" isvisible="true">')
      lines.push('        <title>' + escapeXmlText(item.title) + '</title>')
      if (version === '1.2' && item.masteryScore !== undefined) {
        lines.push('        <adlcp:masteryscore>' + String(item.masteryScore) + '</adlcp:masteryscore>')
      }
      if (version === '1.2' && item.timeLimitAction) {
        lines.push('        <adlcp:timelimitaction>' + escapeXmlText(item.timeLimitAction) + '</adlcp:timelimitaction>')
      }
      if (version === '2004' && item.masteryScore !== undefined) {
        lines.push('        <imsss:sequencing>')
        lines.push('          <imsss:objectives>')
        lines.push('            <imsss:objective objectiveID="PRIMARYOBJ" satisfiedByMeasure="true">')
        lines.push('              <imsss:minNormalizedMeasure>' + (item.masteryScore / 100).toFixed(2) + '</imsss:minNormalizedMeasure>')
        lines.push('            </imsss:objective>')
        lines.push('          </imsss:objectives>')
        lines.push('        </imsss:sequencing>')
      }
      lines.push('      </item>')
    }
    if (description) {
      // ADL allows an adlcp:description on the organization in SCORM 2004.
      // For 1.2 we emit it as a comment-like <adlcp:location> hint, omitted.
      if (version === '2004') {
        lines.push('      <adlcp:location>course-description.html</adlcp:location>')
      }
    }
    void language
    lines.push('    </organization>')
    lines.push('  </organizations>')
    return lines.join('\n')
  }

  // -------------------------------------------------------------------------
  // Resources
  // -------------------------------------------------------------------------

  private buildResources(items: ScormItem[], contentSize: number): string {
    const lines: string[] = []
    lines.push('  <resources>')
    for (const item of items) {
      lines.push('    <resource identifier="' + escapeXmlAttr(item.resourceIdentifier) + '" type="webcontent" adlcp:scormtype="sca" href="index.html">')
      lines.push('      <file href="index.html" />')
      lines.push('      <file href="content.md" />')
      lines.push('      <metadata>')
      lines.push('        <schema>ADL SCORM</schema>')
      lines.push('        <schemaversion>1.2</schemaversion>')
      lines.push('      </metadata>')
      lines.push('      <dependency identifierref="COMMON_ASSETS" />')
      lines.push('    </resource>')
    }
    // Common assets resource (shared CSS, scripts)
    lines.push('    <resource identifier="COMMON_ASSETS" type="webcontent" adlcp:scormtype="asset">')
    lines.push('      <file href="assets/style.css" />')
    lines.push('      <file href="assets/scorm-api.js" />')
    lines.push('    </resource>')
    lines.push('  </resources>')
    // Reference contentSize to acknowledge the supplied content payload
    void contentSize
    return lines.join('\n')
  }

  // -------------------------------------------------------------------------
  // Item resolution
  // -------------------------------------------------------------------------

  private resolveItems(raw: unknown, title: string, courseIdentifier: string): ScormItem[] {
    const fallback: ScormItem[] = [
      {
        identifier: 'ITEM-1',
        title,
        resourceIdentifier: 'RES-1',
        masteryScore: 80,
        timeLimitAction: 'continue,no message',
      },
    ]
    if (!Array.isArray(raw) || raw.length === 0) return fallback
    const items: ScormItem[] = []
    for (let i = 0; i < raw.length; i++) {
      const entry = raw[i] as Record<string, unknown> | null
      if (!entry || typeof entry !== 'object') continue
      const itemTitle = asString(entry.title, `Lesson ${i + 1}`)
      items.push({
        identifier: asXmlId(entry.identifier, `ITEM-${i + 1}`),
        title: itemTitle,
        resourceIdentifier: asXmlId(entry.resourceIdentifier, `RES-${i + 1}`),
        masteryScore: asMasteryScore(entry.masteryScore, 80),
        timeLimitAction: asTimeLimitAction(entry.timeLimitAction),
      })
    }
    void courseIdentifier
    return items.length > 0 ? items : fallback
  }
}

// -------------------------------------------------------------------------
// Version + schema descriptors
// -------------------------------------------------------------------------

interface ScormSchemaDescriptor {
  schema: string
  schemaversion: string
}

const SCORM_1_2_SCHEMA: ScormSchemaDescriptor = {
  schema: 'ADL SCORM',
  schemaversion: '1.2',
}

const SCORM_2004_SCHEMA: ScormSchemaDescriptor = {
  schema: 'ADL SCORM',
  schemaversion: '2004 4th Edition',
}

// -------------------------------------------------------------------------
// Small input-narrowing + XML-escaping helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function asVersion(value: unknown): ScormVersion | undefined {
  return value === '1.2' || value === '2004' ? value : undefined
}

function asXmlId(value: unknown, fallback: string): string {
  const raw = asString(value, fallback)
  // XML IDs must match NCName production: letter/underscore followed by
  // letters/digits/underscores/hyphens/dots. Sanitise aggressively.
  const sanitised = raw.replace(/[^A-Za-z0-9_.-]/g, '-')
  const head = /^[A-Za-z_]/.test(sanitised) ? sanitised : '_' + sanitised
  return head.length > 0 ? head : fallback
}

function asMasteryScore(value: unknown, fallback: number): number | undefined {
  if (value === undefined || value === null) return fallback
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(100, Math.max(0, Math.round(n)))
}

function asTimeLimitAction(value: unknown): ScormItem['timeLimitAction'] | undefined {
  if (value === 'exit,message' || value === 'exit,no message' ||
      value === 'continue,message' || value === 'continue,no message') {
    return value
  }
  return undefined
}

/** Escape text content for safe inclusion between XML tags. */
function escapeXmlText(input: string): string {
  return escapeHtml(input)
}

/** Escape an attribute value for safe inclusion inside XML quotes. */
function escapeXmlAttr(input: string): string {
  return escapeHtml(input)
}
