// =============================================================================
// AICF V3 — POST /api/runtime/workflow/[id]/cancel (Sprint 13+14)
// =============================================================================
// Cancels a running or paused execution.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { getWorkflowModuleBundle } from '@/lib/runtime/modules/workflow/bundle'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow/[id]/cancel', method: 'POST', executionId: id })

  try {
    const bundle = getWorkflowModuleBundle()
    await bundle.module.cancel(id)

    reqLogger.info('Execution cancelled')
    return NextResponse.json({ ok: true, id, status: 'cancelled' })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to cancel execution',
    )
    return NextResponse.json({ error: 'Failed to cancel execution' }, { status: 500 })
  }
}
