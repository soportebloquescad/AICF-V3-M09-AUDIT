// =============================================================================
// AICF V3 — Health Registry (Sprint 17: Runtime Foundation Consolidation)
// =============================================================================
// Centralized registry for module health status. Replaces ad-hoc health
// tracking inside ModuleRegistry.getHealth() with a dedicated, queryable
// registry. Supports manual status updates (set) and active probing
// (checkAll — calls module.health() on every registered module).
//
// The registry is process-local and in-memory. It does not persist status
// across restarts. For multi-process deployments, pair it with a shared
// health store (Redis, etcd) — out of scope for Sprint 17.
// =============================================================================

import type { ModuleMetrics } from '../contracts/RuntimeModule'
import type { ModuleRegistry } from '../registry/ModuleRegistry'
import { logger } from '@/lib/ai/logger'

/**
 * Coarse health status for a single module.
 * - 'unknown': no status has been recorded yet
 * - 'initializing': bootstrap is currently initializing the module
 * - 'healthy': module is fully operational
 * - 'degraded': module is operational but with reduced capacity
 * - 'failed': module initialization failed or a health check returned unhealthy
 * - 'disabled': module is disabled in the manifest and was never initialized
 */
export type HealthStatus =
  | 'unknown'
  | 'initializing'
  | 'healthy'
  | 'degraded'
  | 'failed'
  | 'disabled'

/**
 * Health status of a single dependency (moduleId + its current status).
 */
export interface DependencyHealth {
  moduleId: string
  status: HealthStatus
}

/**
 * Full health report for a single module.
 */
export interface HealthStatusReport {
  moduleId: string
  status: HealthStatus
  /** ISO timestamp of the last health check or manual set(). */
  lastCheck: string | null
  /** Last error message (if status is 'failed' or 'degraded'). */
  lastError?: string
  /** Milliseconds since the module first reported 'healthy'. 0 if never healthy. */
  uptime: number
  /** Health of this module's declared dependencies. */
  dependencies: DependencyHealth[]
  /** Module metrics snapshot (from the module's getMetrics() if available). */
  metrics: ModuleMetrics
}

/**
 * Creates an empty metrics object (zeroed) for modules that don't expose
 * metrics. Mirrors the shape of `ModuleMetrics` from the contracts.
 */
function emptyMetrics(): ModuleMetrics {
  return {
    initLatencyMs: 0,
    errorCount: 0,
    lastUsed: null,
    lastError: null,
    operationCount: 0,
  }
}

/**
 * HealthRegistry — tracks per-module health, supports manual updates and
 * active probing. Constructor-injected with a ModuleRegistry so checkAll()
 * can iterate registered modules.
 *
 * @example
 * const health = new HealthRegistry(moduleRegistry)
 * health.set('workflow', 'healthy')
 * const reports = await health.checkAll()
 * const failed = health.getUnhealthy()
 */
export class HealthRegistry {
  private readonly reports = new Map<string, HealthStatusReport>()
  private readonly healthySince = new Map<string, number>()

  constructor(private readonly moduleRegistry: ModuleRegistry) {}

  /**
   * Returns the current status report for a module, or an 'unknown' report
   * if no status has been recorded.
   */
  getStatus(moduleId: string): HealthStatusReport {
    return (
      this.reports.get(moduleId) || {
        moduleId,
        status: 'unknown',
        lastCheck: null,
        uptime: 0,
        dependencies: [],
        metrics: emptyMetrics(),
      }
    )
  }

  /**
   * Returns all status reports (one per tracked module).
   */
  getAllStatuses(): HealthStatusReport[] {
    return Array.from(this.reports.values())
  }

  /**
   * Returns modules whose status is 'failed'. (Spec wording: 'unhealthy' or
   * 'failed' — the only failing status in the type is 'failed'.)
   */
  getUnhealthy(): HealthStatusReport[] {
    return this.getAllStatuses().filter((r) => r.status === 'failed')
  }

  /**
   * Returns modules whose status is 'degraded'.
   */
  getDegraded(): HealthStatusReport[] {
    return this.getAllStatuses().filter((r) => r.status === 'degraded')
  }

  /**
   * Returns modules whose status is 'healthy'.
   */
  getHealthy(): HealthStatusReport[] {
    return this.getAllStatuses().filter((r) => r.status === 'healthy')
  }

  /**
   * Returns modules whose status is 'initializing'.
   */
  getInitializing(): HealthStatusReport[] {
    return this.getAllStatuses().filter((r) => r.status === 'initializing')
  }

  /**
   * Returns modules whose status is 'unknown' (never reported).
   */
  getUnknown(): HealthStatusReport[] {
    return this.getAllStatuses().filter((r) => r.status === 'unknown')
  }

  /**
   * Probes every registered module via its optional health() method.
   * Updates the internal status for each. Returns the full report list.
   * Modules that don't implement health() are reported as 'unknown'.
   */
  async checkAll(): Promise<HealthStatusReport[]> {
    const entries = this.moduleRegistry.getEntries()
    for (const entry of entries) {
      const moduleId = entry.metadata?.id || entry.module.name
      const moduleInstance = entry.module
      try {
        if (typeof moduleInstance.health === 'function') {
          const health = await moduleInstance.health()
          let status: HealthStatus
          if (health.status === 'healthy') status = 'healthy'
          else if (health.status === 'degraded') status = 'degraded'
          else status = 'failed'
          this.set(moduleId, status, health.lastError)
        } else {
          // No health() — fall back to isReady()
          this.set(moduleId, moduleInstance.isReady() ? 'healthy' : 'unknown')
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err)
        logger.warn(
          { moduleId, error: message },
          'HealthRegistry: health check threw (marking failed)',
        )
        this.set(moduleId, 'failed', message)
      }
    }
    return this.getAllStatuses()
  }

  /**
   * Manually sets the status of a module. Updates lastCheck timestamp.
   * Tracks healthy-since time for uptime calculation.
   */
  set(moduleId: string, status: HealthStatus, error?: string): void {
    const now = Date.now()
    if (status === 'healthy' && !this.healthySince.has(moduleId)) {
      this.healthySince.set(moduleId, now)
    }
    if (status !== 'healthy') {
      this.healthySince.delete(moduleId)
    }

    const since = this.healthySince.get(moduleId)
    const uptime = since ? now - since : 0

    // Resolve dependency healths (best-effort: based on current reports).
    const entry = this.moduleRegistry.getEntry(moduleId)
    const deps: DependencyHealth[] = (entry?.metadata?.dependencies || []).map(
      (depId) => ({
        moduleId: depId,
        status: this.reports.get(depId)?.status || 'unknown',
      }),
    )

    // Pull metrics from the module if available (best-effort).
    let metrics: ModuleMetrics = emptyMetrics()
    try {
      if (typeof entry?.module.getMetrics === 'function') {
        metrics = entry.module.getMetrics()
      }
    } catch {
      // fall back to empty
    }

    this.reports.set(moduleId, {
      moduleId,
      status,
      lastCheck: new Date().toISOString(),
      lastError: error,
      uptime,
      dependencies: deps,
      metrics,
    })
  }
}
