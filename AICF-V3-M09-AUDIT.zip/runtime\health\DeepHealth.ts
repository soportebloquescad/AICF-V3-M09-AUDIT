// =============================================================================
// AICF V3 — Deep Health (Sprint 18 Phase A: Runtime Production Readiness)
// =============================================================================
// Structured deep health report for the Runtime. Aggregates module health,
// LiteLLM connectivity, and provider/model info into a single response.
// =============================================================================

import type { ModuleRegistry } from '../registry/ModuleRegistry'
import type { ModuleHealth } from '../contracts/RuntimeModule'
import { logger } from '@/lib/ai/logger'

/**
 * Per-module health status (simplified for DeepHealth).
 */
export type ModuleHealthStatus = 'healthy' | 'unhealthy'

/**
 * LiteLLM connectivity health.
 */
export interface LiteLLMHealth {
  available: boolean
  latency: number
  models: string[]
}

/**
 * Full deep health report returned by /api/runtime/status.
 */
export interface DeepHealth {
  runtime: 'healthy' | 'degraded' | 'unhealthy'
  modules: {
    m08: ModuleHealthStatus
    m18: ModuleHealthStatus
    m21: ModuleHealthStatus
    workflow: ModuleHealthStatus
    generation: ModuleHealthStatus
    observability: ModuleHealthStatus
    localization: ModuleHealthStatus
    assets: ModuleHealthStatus
    reports: ModuleHealthStatus
  }
  litellm: LiteLLMHealth
  provider: string
  model: string
  timestamp: string
}

/**
 * Maps a ModuleHealth.status to the simplified ModuleHealthStatus.
 */
function toSimpleStatus(health: ModuleHealth | undefined | null): ModuleHealthStatus {
  if (!health) return 'unhealthy'
  if (health.status === 'healthy') return 'healthy'
  if (health.status === 'degraded') return 'healthy' // degraded is still operational
  return 'unhealthy'
}

/**
 * Probes LiteLLM health by calling its /health endpoint.
 * Returns quickly if LITELLM_BASE_URL is not configured.
 */
async function probeLiteLLM(): Promise<LiteLLMHealth> {
  const baseUrl = process.env.LITELLM_BASE_URL || 'http://localhost:4000'
  const apiKey = process.env.LITELLM_API_KEY || ''
  const startMs = Date.now()

  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 5000)

    const res = await fetch(`${baseUrl}/health`, {
      method: 'GET',
      headers: {
        ...(apiKey && { Authorization: `Bearer ${apiKey}` }),
      },
      signal: controller.signal,
    })

    clearTimeout(timer)

    if (!res.ok) {
      return { available: false, latency: Date.now() - startMs, models: [] }
    }

    // Try to get models list
    let models: string[] = []
    try {
      const modelsRes = await fetch(`${baseUrl}/v1/models`, {
        method: 'GET',
        headers: {
          ...(apiKey && { Authorization: `Bearer ${apiKey}` }),
        },
      })
      if (modelsRes.ok) {
        const data = await modelsRes.json() as { data?: Array<{ id?: string }> }
        if (Array.isArray(data.data)) {
          models = data.data.map((m) => m.id || 'unknown').slice(0, 20)
        }
      }
    } catch {
      // Models list is best-effort
    }

    return { available: true, latency: Date.now() - startMs, models }
  } catch {
    return { available: false, latency: Date.now() - startMs, models: [] }
  }
}

/**
 * Builds a DeepHealth report from the ModuleRegistry + LiteLLM probe.
 *
 * @param registry - The ModuleRegistry to query for module health
 * @param provider - The active provider (default: 'litellm')
 * @param model - The default model (default: 'groq-llama-3.3-70b')
 */
export async function buildDeepHealth(
  registry: ModuleRegistry,
  provider = 'litellm',
  model = 'groq-llama-3.3-70b',
): Promise<DeepHealth> {
  // Get health from all registered modules
  const moduleHealths = await registry.getHealth()

  // Index by category for easy lookup
  const healthByCategory = new Map<string, ModuleHealth>()
  for (const entry of moduleHealths) {
    healthByCategory.set(entry.category, entry.health)
  }

  // Map to simple status per module
  const m08Status = toSimpleStatus(healthByCategory.get('content-intelligence'))
  const m18Status = toSimpleStatus(healthByCategory.get('infrastructure'))
  const m21Status = toSimpleStatus(healthByCategory.get('real-generation'))
  const workflowStatus = toSimpleStatus(healthByCategory.get('workflow'))
  const generationStatus = toSimpleStatus(healthByCategory.get('generation'))
  const observabilityStatus = toSimpleStatus(healthByCategory.get('observability'))
  const localizationStatus = toSimpleStatus(healthByCategory.get('localization'))
  const assetsStatus = toSimpleStatus(healthByCategory.get('assets'))
  const reportsStatus = toSimpleStatus(healthByCategory.get('reports'))

  // Probe LiteLLM
  const litellm = await probeLiteLLM()

  // Determine overall runtime health
  const allModules = [m08Status, m18Status, m21Status, workflowStatus, generationStatus, observabilityStatus, localizationStatus, assetsStatus, reportsStatus]
  const healthyCount = allModules.filter((s) => s === 'healthy').length
  const totalModules = allModules.length

  let runtime: 'healthy' | 'degraded' | 'unhealthy' = 'healthy'
  if (healthyCount === 0) {
    runtime = 'unhealthy'
  } else if (healthyCount < totalModules || !litellm.available) {
    runtime = 'degraded'
  }

  const deepHealth: DeepHealth = {
    runtime,
    modules: {
      m08: m08Status,
      m18: m18Status,
      m21: m21Status,
      workflow: workflowStatus,
      generation: generationStatus,
      observability: observabilityStatus,
      localization: localizationStatus,
      assets: assetsStatus,
      reports: reportsStatus,
    },
    litellm,
    provider,
    model,
    timestamp: new Date().toISOString(),
  }

  logger.debug(
    { runtime, healthyCount, totalModules, litellmAvailable: litellm.available },
    'DeepHealth: built',
  )

  return deepHealth
}
