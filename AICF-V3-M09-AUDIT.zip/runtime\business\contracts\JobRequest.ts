// =============================================================================
// AICF V3 — Business Job Request Contract (Épica 2 — AI Factory Core)
// =============================================================================
// The payload that enters the Business layer (the AI Factory). This is the
// analog of RuntimeRequest at the business layer: instead of `operation`
// ('chat' | 'workflow' | 'models' | 'status') we carry a `jobType` that names
// the business capability to invoke ('createCourse', 'createSlides', etc.).
//
// Design notes:
//   - `input` is a structured `Record<string, unknown>` — typed DTOs in
//     `business/shared/dtos.ts` narrow this per jobType. The Business layer
//     validates `input` with `business/shared/validators.ts` before invoking
//     the module's executeJob().
//   - `metadata` carries trace context (correlationId, requestId, userId,
//     workspaceId, projectId) so a JobRequest can be linked back to the
//     RuntimeRequest that triggered it.
//   - `timeout` and `retries` are optional policy knobs. When omitted, the
//     BusinessModuleRegistry uses defaults.
//   - No `any` — `unknown` is used everywhere.
// =============================================================================

/**
 * The set of job types the AI Factory can execute. New job types are added
 * here; module stubs declare which subset they handle.
 */
export type JobType =
  | 'createCourse'
  | 'createSlides'
  | 'createQuiz'
  | 'research'
  | 'generateDocument'
  | 'exportPDF'
  | 'exportDOCX'
  | 'exportPPTX'
  | 'exportMarkdown'
  | 'custom'

/**
 * A request entering the Business layer.
 */
export interface JobRequest {
  /** Unique job identifier (generated if not provided by the caller). */
  jobId: string

  /** The business capability to invoke. */
  jobType: JobType

  /** Structured input for the job (validated per jobType). */
  input: Record<string, unknown>

  /** Optional trace + tenancy metadata. */
  metadata?: {
    /** Correlation ID for distributed tracing across Runtime + Business. */
    correlationId?: string
    /** Request ID that originated this job (the RuntimeRequest.requestId). */
    requestId?: string
    /** Acting user ID. */
    userId?: string
    /** Workspace scope. */
    workspaceId?: string
    /** Project scope. */
    projectId?: string
    /** Locale tag (e.g. 'en', 'es', 'pt-BR'). */
    locale?: string
    /** Lower number = higher priority (mirrors PluginMetadata.priority). */
    priority?: number
  }

  /** Timeout in milliseconds (optional; registry may apply a default). */
  timeout?: number

  /** Number of retries the registry should attempt on failure. */
  retries?: number
}

/**
 * Factory: creates a JobRequest with an auto-generated jobId.
 *
 * @example
 * const req = createJobRequest('createCourse', { topic: 'Intro to Rust' })
 * // → { jobId: 'job-...', jobType: 'createCourse', input: { topic: '...' } }
 */
export function createJobRequest(
  jobType: JobType,
  input: Record<string, unknown>,
  metadata?: JobRequest['metadata'],
): JobRequest {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return {
    jobId: `job-${ts}-${rand}`,
    jobType,
    input,
    metadata,
  }
}
