// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Security Policy
// =============================================================================
// Denies steps whose config contains forbidden patterns:
//   - Secret references (`${env:...}`, `${vault:...}`, `${docker-secrets:...}`)
//     in fields that are likely to be logged or persisted in plaintext
//     (e.g. `step.config.log`, `step.config.message`, `step.config.label`).
//   - Shell command execution (`step.config.shell`, `step.config.command`,
//     `step.config.exec`) — the runtime does not allow steps to spawn shells.
//
// Sprint 13+14 spec requirements covered:
//   - name: 'security-policy'
//   - Returns denied with a violations list when forbidden patterns are found
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import type { IPolicy, PolicyDecision } from '@/lib/runtime/modules/workflow/policies/PolicyMiddleware'

/** Pattern matching secret references like `${env:KEY}`. */
const SECRET_PATTERN = /\$\{(env|vault|docker-secrets):[^}]+\}/

/** Fields whose values may end up in logs / UI / audit and therefore must
 *  not contain secret references. */
const LOGGED_FIELDS: ReadonlyArray<string> = [
  'log',
  'message',
  'label',
  'title',
  'description',
  'summary',
  'prompt', // prompts may be persisted for reproducibility — secrets must
            // be resolved by the resolver before being interpolated.
]

/** Fields that would spawn a shell / subprocess — forbidden. */
const SHELL_FIELDS: ReadonlyArray<string> = [
  'shell',
  'command',
  'exec',
  'cmd',
  'script',
  'bin',
]

/**
 * Enforces basic security guard rails. Implements `IPolicy`.
 */
export class SecurityPolicy implements IPolicy {
  readonly name = 'security-policy'

  async check(
    _ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const violations: string[] = []

    // 1. Shell-execution fields are forbidden.
    for (const f of SHELL_FIELDS) {
      if (step.config[f] !== undefined) {
        violations.push(
          `step.config.${f} is forbidden: shell execution is not allowed`,
        )
      }
    }

    // 2. Secret references in logged fields are forbidden.
    for (const f of LOGGED_FIELDS) {
      const v = step.config[f]
      if (typeof v === 'string' && SECRET_PATTERN.test(v)) {
        violations.push(
          `step.config.${f} contains a secret reference; resolve before logging`,
        )
      }
    }

    // 3. Recursively scan config values for raw secret references in
    //    arrays / nested objects — these would leak if the config were
    //    serialized for audit.
    const leaked = findSecretLeaks(step.config)
    for (const path of leaked) {
      violations.push(`secret reference leaked at step.config.${path}`)
    }

    return violations.length === 0
      ? { allowed: true, violations: [] }
      : {
          allowed: false,
          violations,
          reason: 'forbidden patterns detected in step config',
        }
  }
}

/**
 * Walk a config value looking for string leaves that contain secret
 * references. Returns the dotted path to each leaked value.
 */
function findSecretLeaks(value: unknown, prefix = ''): string[] {
  const out: string[] = []
  if (typeof value === 'string') {
    if (SECRET_PATTERN.test(value)) {
      out.push(prefix || '(root)')
    }
    return out
  }
  if (Array.isArray(value)) {
    value.forEach((item, idx) => {
      out.push(...findSecretLeaks(item, `${prefix}[${idx}]`))
    })
    return out
  }
  if (value !== null && typeof value === 'object') {
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      const path = prefix ? `${prefix}.${k}` : k
      out.push(...findSecretLeaks(v, path))
    }
  }
  return out
}
