// =============================================================================
// AICF V3 — Sprint 10 — Country Engine (locale motor)
// =============================================================================
import { getCountryByCode, listAllCountries, type CountryEntry } from './CountryCatalog'
import type { CourseConfiguration } from '../configuration/CourseConfiguration'
import { logger } from '@/lib/ai/logger'

export interface LocaleContext {
  country: CountryEntry
  locale: string
  currency: CountryEntry['currency']
  companies: readonly string[]
  legislation: readonly CountryEntry['legislation'][number][]
  terminology: Readonly<Record<string, string>>
  realCases: readonly string[]
  examples: readonly string[]
  exercises: readonly string[]
  datasets: readonly CountryEntry['datasets'][number][]
  statistics: readonly CountryEntry['statistics'][number][]
  references: readonly CountryEntry['references'][number][]
}

export class CountryEngine {
  private readonly log = logger.child({ component: 'CountryEngine' })

  listCountries(): CountryEntry[] { return listAllCountries() }
  getCountry(code: string): CountryEntry | null { return getCountryByCode(code) }

  buildContext(countryCode: string): LocaleContext | null {
    const country = this.getCountry(countryCode) ?? this.getCountry('global')
    if (!country) { this.log.warn({ countryCode }, 'CountryEngine: not found'); return null }
    return {
      country, locale: country.language, currency: country.currency,
      companies: country.companies, legislation: country.legislation,
      terminology: country.terminology, realCases: country.realCases,
      examples: country.examples, exercises: country.exercises,
      datasets: country.datasets, statistics: country.statistics,
      references: country.references,
    }
  }

  buildContexts(countryCodes: string[]): LocaleContext[] {
    const ctxs: LocaleContext[] = []
    for (const code of countryCodes) {
      const ctx = this.buildContext(code)
      if (ctx) ctxs.push(ctx)
    }
    if (ctxs.length === 0) {
      const global = this.buildContext('global')
      if (global) ctxs.push(global)
    }
    return ctxs
  }

  count(): number { return listAllCountries().length }
}

let singleton: CountryEngine | null = null
export function getCountryEngine(): CountryEngine {
  if (!singleton) singleton = new CountryEngine()
  return singleton
}
export function resetCountryEngine(): void { singleton = null }
