// =============================================================================
// AICF V3 — Generation Module (Sprint 15: Full Lifecycle)
// =============================================================================
// Implements the RuntimeModule interface with full lifecycle:
//   - initialize(): idempotent, marks ready
//   - health(): returns ModuleHealth with metrics
//   - dispose(): releases resources
//   - shutdown(): graceful shutdown
//   - getMetrics(): returns per-module metrics
// =============================================================================

import type { RuntimeModule, RuntimeStatus, ModuleHealth, ModuleMetrics } from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { GENERATION_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { GeneratorInput, GeneratorOutput } from '@/lib/runtime/interfaces'
import type { DryRunResult, WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'
import { GenerationOrchestrator } from './engine/GenerationOrchestrator'

/**
 * Plugin metadata for the Generation module (M21).
 * Sprint 17: declares capabilities, contracts, events, priority, mission.
 */
export const GENERATION_MODULE_METADATA: PluginMetadata = {
  id: 'generation',
  name: 'Content Generation',
  description: 'Multi-content-type generation: courses, presentations, quizzes, documents',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M21',
  priority: 20,
  dependencies: ['workflow'],
  capabilities: [...GENERATION_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'generation.started',
    'generation.completed',
    'generation.failed',
  ],
}

/**
 * Runtime module that exposes the generation subsystem. Owns a
 * `GenerationOrchestrator` and delegates `generate` / `dryRun` calls to it.
 */
export class GenerationModule implements RuntimeModule {
  public readonly name = 'generation'
  public readonly version = '1.0.0'

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(private readonly orchestrator: GenerationOrchestrator) {}

  public async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    logger.debug(
      { module: this.name, generators: this.orchestrator.listGenerators() },
      'GenerationModule: initialize',
    )
    this.initialized = true
    this.initLatencyMs = Date.now() - start
  }

  public isReady(): boolean {
    return this.initialized && !this.disposed
  }

  public getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        generators: this.orchestrator.listGenerators(),
        startupTime: this.startupTime,
        lastInitialization: this.lastInitialization,
      },
    }
  }

  public async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: ['workflow'],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  public getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  public async dispose(): Promise<void> {
    this.disposed = true
    logger.info('GenerationModule: disposed')
  }

  public async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('GenerationModule: shut down')
  }

  /**
   * Gets the plugin metadata (Sprint 17).
   */
  public getMetadata(): PluginMetadata {
    return GENERATION_MODULE_METADATA
  }

  private markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  private recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }

  public getOrchestrator(): GenerationOrchestrator {
    return this.orchestrator
  }

  public async generate(input: GeneratorInput, ctx: WorkflowContext): Promise<GeneratorOutput> {
    this.markUsed()
    try {
      return await this.orchestrator.generate(input, ctx)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  public async dryRun(input: GeneratorInput, ctx: WorkflowContext): Promise<DryRunResult> {
    this.markUsed()
    try {
      return await this.orchestrator.dryRun(input, ctx)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }
}
