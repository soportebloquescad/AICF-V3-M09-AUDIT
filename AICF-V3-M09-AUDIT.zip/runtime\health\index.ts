// =============================================================================
// AICF V3 — Runtime Health Barrel (Épica 1 — Stabilization)
// =============================================================================
// HealthManager removed (dead code — never consumed in prod).
// HealthRegistry + DeepHealth remain (both consumed).
// =============================================================================
export {
  HealthRegistry,
  type HealthStatus,
  type HealthStatusReport,
  type DependencyHealth,
} from './HealthRegistry'
export { type DeepHealth, type ModuleHealthStatus, type LiteLLMHealth, buildDeepHealth } from './DeepHealth'
