// =============================================================================
// AICF V3 — Localization Module (Sprint 19: Reference Plugin Implementation)
// =============================================================================
// Reference implementation of a Runtime plugin module. Follows the EXACT
// pattern established by ContentIntelligenceRuntimeModule (M08):
//   - Full lifecycle: initialize, isReady, getStatus, health, getMetrics,
//     dispose, shutdown
//   - HotReloadable: load, unload, reload
//   - Plugin metadata via LOCALIZATION_METADATA + getMetadata()
//   - Internal telemetry: initialized, disposed, startupTime,
//     lastInitialization, lastError, initLatencyMs, operationCount,
//     errorCount, lastUsed
//   - markUsed() / recordError() helpers
//
// Capabilities: translate, detectLanguage, getSupportedLocales, formatDate,
//               formatNumber
// Mission: localization
//
// Runtime Agnostic: only imports from @/lib/ai/logger (never from
// AIService/AIAdapter/LiteLLMAdapter). All translation logic is in-process
// using the standard Intl API plus a small dictionary for common phrases.
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { LOCALIZATION_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * The list of locales this module supports.
 * Exposed as a constant so tests and downstream consumers can reference it.
 */
export const SUPPORTED_LOCALES: readonly string[] = [
  'en', 'es', 'fr', 'de', 'pt', 'ja', 'zh',
] as const

/**
 * A minimal phrase dictionary used by `translate()`.
 *
 * The reference implementation is intentionally lightweight: it performs
 * literal dictionary lookups for a small set of common phrases. Anything
 * not in the dictionary falls back to a bracketed marker string so callers
 * can detect that the text was not actually translated.
 */
const PHRASE_DICTIONARY: Readonly<Record<string, Readonly<Record<string, string>>>> = {
  'hello': {
    es: 'hola',
    fr: 'bonjour',
    de: 'hallo',
    pt: 'olá',
    ja: 'こんにちは',
    zh: '你好',
  },
  'goodbye': {
    es: 'adiós',
    fr: 'au revoir',
    de: 'auf wiedersehen',
    pt: 'adeus',
    ja: 'さようなら',
    zh: '再见',
  },
  'thank you': {
    es: 'gracias',
    fr: 'merci',
    de: 'danke',
    pt: 'obrigado',
    ja: 'ありがとう',
    zh: '谢谢',
  },
  'yes': {
    es: 'sí',
    fr: 'oui',
    de: 'ja',
    pt: 'sim',
    ja: 'はい',
    zh: '是',
  },
  'no': {
    es: 'no',
    fr: 'non',
    de: 'nein',
    pt: 'não',
    ja: 'いいえ',
    zh: '不',
  },
}

/**
 * Plugin metadata for the Localization module.
 */
export const LOCALIZATION_METADATA: PluginMetadata = {
  id: 'localization',
  name: 'Localization',
  description: 'i18n, traducciones y formato regional',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'localization',
  priority: 5,
  dependencies: [],
  capabilities: [...LOCALIZATION_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['translation.completed', 'locale.changed'],
}

/**
 * Normalizes a locale string to a 2-letter ISO 639-1 code.
 * Examples: 'en-US' → 'en', 'es-ES' → 'es', 'PT-BR' → 'pt'.
 */
function normalizeLocale(locale: string): string {
  if (!locale) return 'en'
  const lower = locale.toLowerCase()
  const base = lower.split(/[-_]/)[0]
  return base || 'en'
}

/**
 * Detects the dominant script of a piece of text and returns the matching
 * ISO 639-1 language code. Detection is intentionally heuristic (character
 * ranges) and defaults to 'en' when no other script matches.
 */
function detectLanguageFromText(text: string): string {
  if (!text) return 'en'
  // CJK Unified Ideographs + Hiragana + Katakana
  if (/[\u3040-\u309f\u30a0-\u30ff]/.test(text)) return 'ja'
  if (/[\u4e00-\u9fff]/.test(text)) return 'zh'
  // Cyrillic
  if (/[\u0400-\u04ff]/.test(text)) return 'ru'
  // Greek
  if (/[\u0370-\u03ff]/.test(text)) return 'el'
  // Arabic
  if (/[\u0600-\u06ff]/.test(text)) return 'ar'
  // Hebrew
  if (/[\u0590-\u05ff]/.test(text)) return 'he'
  // Devanagari
  if (/[\u0900-\u097f]/.test(text)) return 'hi'
  // Korean Hangul
  if (/[\uac00-\ud7af]/.test(text)) return 'ko'
  // Accent-laden Latin (Spanish/Portuguese/French/German hints)
  if (/[ñáéíóúü¿¡]/i.test(text)) return 'es'
  if (/[àâçèéêëîïôûùüÿœ]/i.test(text)) return 'fr'
  if (/[äöüß]/i.test(text)) return 'de'
  if (/[ãáâàéêíóôõúç]/i.test(text)) return 'pt'
  return 'en'
}

/**
 * Localization Runtime Module.
 *
 * Self-contained: takes no constructor arguments, holds no external
 * dependencies beyond the central logger. Capabilities operate purely on
 * in-memory state and the platform's Intl API.
 */
export class LocalizationModule implements RuntimeModule, HotReloadable {
  readonly name = LOCALIZATION_METADATA.name
  readonly version = LOCALIZATION_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  /**
   * No-argument constructor — the module is fully self-contained.
   */
  constructor() {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.disposed = false
    this.initLatencyMs = Date.now() - start
    logger.info(
      { initLatencyMs: this.initLatencyMs, locales: SUPPORTED_LOCALES.length },
      'LocalizationModule: initialized',
    )
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'runtime/modules/localization',
        capabilities: LOCALIZATION_CAPABILITIES,
        supportedLocales: [...SUPPORTED_LOCALES],
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    logger.info('LocalizationModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('LocalizationModule: shut down')
  }

  // --- HotReloadable ---

  async load(): Promise<void> {
    await this.initialize()
  }

  async unload(): Promise<void> {
    await this.dispose()
  }

  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    this.lastError = null
    await this.initialize()
  }

  /**
   * Returns the plugin metadata.
   */
  getMetadata(): PluginMetadata {
    return LOCALIZATION_METADATA
  }

  // --- Internal helpers ---

  private markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  private recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }

  // --- Localization capabilities ---

  /**
   * Translates `text` to `targetLang`.
   *
   * Uses an in-process dictionary for a small set of common phrases. Anything
   * not in the dictionary (or whose target language is unsupported) returns
   * the text wrapped in `[translate:${text}]` so callers can detect that no
   * real translation was performed.
   *
   * `sourceLang` is accepted for API compatibility but not required — the
   * dictionary is keyed on the lowercased source phrase itself.
   */
  async translate(
    text: string,
    targetLang: string,
    sourceLang?: string,
  ): Promise<string> {
    this.markUsed()
    try {
      const target = normalizeLocale(targetLang)
      // No-op when target equals source (or when target is English).
      if (sourceLang && normalizeLocale(sourceLang) === target) return text
      if (target === 'en') return text

      const key = text.trim().toLowerCase()
      const entry = PHRASE_DICTIONARY[key]
      if (entry) {
        const translation = entry[target]
        if (translation) {
          logger.debug(
            { text, target, sourceLang, translation },
            'LocalizationModule: translation.completed',
          )
          return translation
        }
      }
      // Fallback marker — callers can detect that nothing was translated.
      return `[translate:${text}]`
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Detects the dominant language of `text` and returns a 2-letter code.
   * Falls back to 'en' when detection is inconclusive.
   */
  async detectLanguage(text: string): Promise<string> {
    this.markUsed()
    try {
      return detectLanguageFromText(text)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Returns the list of supported locales.
   */
  getSupportedLocales(): string[] {
    this.markUsed()
    return [...SUPPORTED_LOCALES]
  }

  /**
   * Formats a Date (or ISO date string) for the given locale using the
   * platform's Intl.DateTimeFormat API.
   */
  formatDate(date: Date | string, locale: string): string {
    this.markUsed()
    try {
      const parsed = typeof date === 'string' ? new Date(date) : date
      const normalized = normalizeLocale(locale)
      return new Intl.DateTimeFormat(normalized, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(parsed)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Formats a number for the given locale using the platform's
   * Intl.NumberFormat API.
   */
  formatNumber(number: number, locale: string): string {
    this.markUsed()
    try {
      const normalized = normalizeLocale(locale)
      return new Intl.NumberFormat(normalized).format(number)
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }
}

/**
 * Factory: creates a LocalizationModule with no external dependencies.
 */
export function createLocalizationModule(): LocalizationModule {
  return new LocalizationModule()
}
