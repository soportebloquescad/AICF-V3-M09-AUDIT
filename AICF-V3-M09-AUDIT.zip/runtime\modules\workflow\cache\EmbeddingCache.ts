// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Embedding Cache
// =============================================================================
// Caches embedding vectors keyed by a SHA-256 hash of (text + model).
// Avoids re-computing embeddings for the same text across workflow runs.
//
// Sprint 13+14 spec requirements covered:
//   - `get(text, model)` / `set(text, model, embedding)`
//   - `computeHash(text, model)` — deterministic SHA-256
//   - `clear()` for forced invalidation
// =============================================================================

import { createHash } from 'crypto'
import { logger } from '@/lib/ai/logger'

/**
 * In-memory embedding cache. Keys are SHA-256 hashes computed by
 * `computeHash(text, model)`; values are the embedding vectors (arrays of
 * numbers). The cache never expires entries — embeddings are deterministic
 * for a given (text, model) pair, so the only invalidation path is
 * `clear()`.
 */
export class EmbeddingCache {
  /** Map<hash, number[]>. */
  private readonly entries = new Map<string, number[]>()

  /**
   * Look up an embedding by (text, model). Returns null on miss.
   */
  async get(text: string, model: string): Promise<number[] | null> {
    const hash = this.computeHash(text, model)
    return this.entries.get(hash) ?? null
  }

  /**
   * Store an embedding for (text, model). Overwrites any prior entry.
   * The vector is shallow-copied so the caller's reference cannot mutate
   * the cached value.
   */
  async set(text: string, model: string, embedding: number[]): Promise<void> {
    const hash = this.computeHash(text, model)
    this.entries.set(hash, [...embedding])
  }

  /**
   * Compute a deterministic SHA-256 hash over (text, model). The hash is
   * the cache key — two calls with the same (text, model) produce the same
   * hash, enabling deduplication.
   */
  computeHash(text: string, model: string): string {
    return createHash('sha256')
      .update(`${model}\u0000${text}`)
      .digest('hex')
  }

  /** Clear all cached embeddings. */
  clear(): void {
    this.entries.clear()
    logger.debug('EmbeddingCache: cleared')
  }

  /** Number of cached embeddings. */
  get size(): number {
    return this.entries.size
  }
}
