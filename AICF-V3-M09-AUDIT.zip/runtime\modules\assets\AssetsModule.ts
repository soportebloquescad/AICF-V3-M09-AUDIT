// =============================================================================
// AICF V3 — Assets Module (Sprint 19: Reference Plugin Implementation)
// =============================================================================
// Reference implementation of a Runtime plugin module. Follows the EXACT
// pattern established by ContentIntelligenceRuntimeModule (M08):
//   - Full lifecycle: initialize, isReady, getStatus, health, getMetrics,
//     dispose, shutdown
//   - HotReloadable: load, unload, reload
//   - Plugin metadata via ASSETS_METADATA + getMetadata()
//   - Internal telemetry: initialized, disposed, startupTime,
//     lastInitialization, lastError, initLatencyMs, operationCount,
//     errorCount, lastUsed
//   - markUsed() / recordError() helpers
//
// Capabilities: storeAsset, getAsset, deleteAsset, listAssets, getAssetUrl
// Mission: assets
//
// Storage: an in-memory Map<string, AssetRecord>. Not persistent — when the
// module is disposed or the process exits, all assets are lost. Suitable as
// a reference; production deployments should swap the store for a durable
// backend (S3, Postgres, etc.) without changing the public surface.
//
// Runtime Agnostic: only imports from @/lib/ai/logger.
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { ASSETS_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * A stored asset record. `content` is base64-encoded so the same payload
 * can be embedded directly in a data URL via `getAssetUrl()`.
 */
export interface AssetRecord {
  /** Unique asset ID (UUID-ish). */
  id: string
  /** Original file name (e.g., 'logo.png'). */
  name: string
  /** MIME type (e.g., 'image/png'). */
  mimeType: string
  /** Base64-encoded content. */
  content: string
  /** Size of the decoded content in bytes. */
  size: number
  /** Arbitrary caller-supplied metadata. */
  metadata: Record<string, unknown>
  /** ISO timestamp when the asset was created. */
  createdAt: string
}

/**
 * Input shape accepted by `storeAsset()`.
 */
export interface StoreAssetInput {
  /** Base64-encoded content. */
  content: string
  /** MIME type (e.g., 'image/png'). */
  mimeType: string
  /** Original file name. */
  name: string
  /** Optional arbitrary metadata. */
  metadata?: Record<string, unknown>
}

/**
 * Optional filter passed to `listAssets()`.
 */
export interface AssetFilter {
  /** Filter by exact MIME type. */
  mimeType?: string
  /** Filter by exact name. */
  name?: string
}

/**
 * Generates a reasonably-unique asset ID without pulling in the `crypto`
 * module's UUID helper (keeps the module runtime-agnostic and deterministic
 * for tests). Combines a counter, a timestamp, and a random suffix.
 */
function generateAssetId(): string {
  const ts = Date.now().toString(36)
  const rnd = Math.random().toString(36).slice(2, 10)
  return `asset_${ts}_${rnd}`
}

/**
 * Decodes a base64 string into its byte length.
 * Falls back to the raw string length when the input is not valid base64
 * (we don't reject the asset — we just report an approximate size).
 */
function approxByteLength(base64: string): number {
  try {
    if (typeof atob === 'function') {
      return atob(base64).length
    }
  } catch {
    // fall through to estimate
  }
  // Estimate: 4 base64 chars encode 3 bytes, minus padding.
  const padding = base64.endsWith('==') ? 2 : base64.endsWith('=') ? 1 : 0
  return Math.max(0, Math.floor((base64.length * 3) / 4) - padding)
}

/**
 * Plugin metadata for the Assets module.
 */
export const ASSETS_METADATA: PluginMetadata = {
  id: 'assets',
  name: 'Assets',
  description: 'Gestión de imágenes, documentos y archivos estáticos',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'assets',
  priority: 15,
  dependencies: [],
  capabilities: [...ASSETS_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['asset.stored', 'asset.deleted', 'asset.accessed'],
}

/**
 * Assets Runtime Module.
 *
 * Self-contained: takes no constructor arguments. All state lives in an
 * internal Map<string, AssetRecord>.
 */
export class AssetsModule implements RuntimeModule, HotReloadable {
  readonly name = ASSETS_METADATA.name
  readonly version = ASSETS_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  private readonly assets = new Map<string, AssetRecord>()

  /**
   * No-argument constructor — the module is fully self-contained.
   */
  constructor() {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.disposed = false
    this.initLatencyMs = Date.now() - start
    logger.info(
      { initLatencyMs: this.initLatencyMs },
      'AssetsModule: initialized',
    )
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'runtime/modules/assets',
        capabilities: ASSETS_CAPABILITIES,
        assetCount: this.assets.size,
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    this.assets.clear()
    logger.info('AssetsModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    this.assets.clear()
    logger.info('AssetsModule: shut down')
  }

  // --- HotReloadable ---

  async load(): Promise<void> {
    await this.initialize()
  }

  async unload(): Promise<void> {
    await this.dispose()
  }

  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    this.lastError = null
    await this.initialize()
  }

  /**
   * Returns the plugin metadata.
   */
  getMetadata(): PluginMetadata {
    return ASSETS_METADATA
  }

  // --- Internal helpers ---

  private markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  private recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }

  // --- Assets capabilities ---

  /**
   * Stores an asset and returns its generated ID.
   */
  async storeAsset(data: StoreAssetInput): Promise<{ id: string }> {
    this.markUsed()
    try {
      const id = generateAssetId()
      const record: AssetRecord = {
        id,
        name: data.name,
        mimeType: data.mimeType,
        content: data.content,
        size: approxByteLength(data.content),
        metadata: data.metadata ? { ...data.metadata } : {},
        createdAt: new Date().toISOString(),
      }
      this.assets.set(id, record)
      logger.debug({ id, name: data.name, mimeType: data.mimeType }, 'AssetsModule: asset.stored')
      return { id }
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Retrieves an asset by ID. Returns null when not found.
   */
  async getAsset(id: string): Promise<AssetRecord | null> {
    this.markUsed()
    try {
      const record = this.assets.get(id)
      if (!record) return null
      logger.debug({ id }, 'AssetsModule: asset.accessed')
      // Return a defensive copy so callers can't mutate internal state.
      return { ...record, metadata: { ...record.metadata } }
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Deletes an asset by ID. Returns true if an asset was deleted, false
   * if no asset existed with that ID.
   */
  async deleteAsset(id: string): Promise<boolean> {
    this.markUsed()
    try {
      const existed = this.assets.delete(id)
      if (existed) {
        logger.debug({ id }, 'AssetsModule: asset.deleted')
      }
      return existed
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Lists all assets, optionally filtered by MIME type or name.
   */
  async listAssets(filter?: AssetFilter): Promise<AssetRecord[]> {
    this.markUsed()
    try {
      const all = Array.from(this.assets.values())
      const filtered = all.filter((record) => {
        if (filter?.mimeType && record.mimeType !== filter.mimeType) return false
        if (filter?.name && record.name !== filter.name) return false
        return true
      })
      // Return defensive copies.
      return filtered.map((r) => ({ ...r, metadata: { ...r.metadata } }))
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }

  /**
   * Returns a `data:` URL for the asset, or null when not found.
   */
  async getAssetUrl(id: string): Promise<string | null> {
    this.markUsed()
    try {
      const record = this.assets.get(id)
      if (!record) return null
      logger.debug({ id }, 'AssetsModule: asset.accessed (url)')
      return `data:${record.mimeType};base64,${record.content}`
    } catch (err) {
      this.recordError(err)
      throw err
    }
  }
}

/**
 * Factory: creates an AssetsModule with no external dependencies.
 */
export function createAssetsModule(): AssetsModule {
  return new AssetsModule()
}
