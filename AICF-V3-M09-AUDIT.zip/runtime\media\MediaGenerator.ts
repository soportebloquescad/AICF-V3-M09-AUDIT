// =============================================================================
// AICF V3 — Sprint 11A — MediaGenerator
// =============================================================================
// Generates SVG images + Mermaid diagrams that are SPECIFIC to each slide's
// topic. NO generic placeholders — every SVG is built from the slide's title,
// module number, and locale context so two slides with different topics get
// different illustrations.
//
// Public API:
//   - generateHero(topic, theme)        → cover hero SVG
//   - generateConcept(topic, theme)     → concept diagram SVG
//   - generateIcon(topic, theme)        → topic-specific icon SVG
//   - generateMermaid(topic, kind)      → Mermaid diagram source
//   - generateInfographic(stats, theme) → statistics infographic SVG
//
// REUSES: ThemePreset colors (no hardcoded palette), LocaleContext stats.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

export type DiagramKind = 'flow' | 'sequence' | 'architecture' | 'comparison'

export interface MediaGeneratorOpts {
  topic: string
  moduleIndex: number
  theme: ThemePreset
  locale: LocaleContext
}

export class MediaGenerator {
  private readonly log = logger.child({ component: 'MediaGenerator' })

  /**
   * Hero image for the cover slide. Topic-specific: encodes the topic title
   * and a stylized landscape based on the topic's first letter and module
   * count. NO two topics produce the same hero.
   */
  generateHero(topic: string, theme: ThemePreset): string {
    const c = theme.colors
    const seed = this.hash(topic)
    const accentShape = this.shapeFromSeed(seed)
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" width="100%" height="auto" role="img" aria-label="Hero illustration for ${this.escape(topic)}">
  <defs>
    <linearGradient id="hero-grad-${seed}" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${c.primary}"/>
      <stop offset="50%" stop-color="${c.accent}"/>
      <stop offset="100%" stop-color="${c.primary}"/>
    </linearGradient>
    <pattern id="hero-dots-${seed}" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
      <circle cx="10" cy="10" r="1.5" fill="${c.primaryFg}" opacity="0.15"/>
    </pattern>
  </defs>
  <rect width="800" height="400" fill="url(#hero-grad-${seed})" rx="8"/>
  <rect width="800" height="400" fill="url(#hero-dots-${seed})" rx="8"/>
  ${accentShape(seed, c.primaryFg)}
  <rect x="60" y="280" width="${Math.min(500, topic.length * 12 + 40)}" height="6" fill="${c.primaryFg}" opacity="0.7" rx="3"/>
  <text x="60" y="200" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="38" font-weight="bold">${this.escape(topic.slice(0, 38))}</text>
  <text x="60" y="240" fill="${c.primaryFg}" opacity="0.8" font-family="${theme.typography.bodyFont}" font-size="16">AICF V3 Premium Course</text>
</svg>`
  }

  /**
   * Concept diagram for a content slide. Renders a topic-specific flow:
   * Input → [Topic-specific transformation] → Output, with the topic name
   * embedded in the central node. Different topics → different labels.
   */
  generateConcept(topic: string, moduleIndex: number, theme: ThemePreset): string {
    const c = theme.colors
    const label = this.shortLabel(topic)
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 300" width="100%" height="auto" role="img" aria-label="Concept diagram for ${this.escape(topic)}">
  <rect width="800" height="300" fill="${c.background}" rx="8"/>
  <rect x="40" y="120" width="160" height="60" fill="${c.surface}" stroke="${c.border}" stroke-width="2" rx="8"/>
  <text x="120" y="155" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" text-anchor="middle" font-weight="bold">Input</text>
  <path d="M 200 150 L 280 150" stroke="${c.accent}" stroke-width="3" marker-end="url(#arrow-${moduleIndex})" fill="none"/>
  <defs><marker id="arrow-${moduleIndex}" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="0"><path d="M0,0 L0,6 L9,3 z" fill="${c.accent}"/></marker></defs>
  <rect x="280" y="100" width="240" height="100" fill="${c.primary}" rx="8"/>
  <text x="400" y="140" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="16" text-anchor="middle" font-weight="bold">Module ${moduleIndex}</text>
  <text x="400" y="165" fill="${c.primaryFg}" opacity="0.9" font-family="${theme.typography.bodyFont}" font-size="13" text-anchor="middle">${this.escape(label)}</text>
  <path d="M 520 150 L 600 150" stroke="${c.accent}" stroke-width="3" marker-end="url(#arrow-${moduleIndex})" fill="none"/>
  <rect x="600" y="120" width="160" height="60" fill="${c.surface}" stroke="${c.border}" stroke-width="2" rx="8"/>
  <text x="680" y="155" fill="${c.text}" font-family="${theme.typography.bodyFont}" font-size="14" text-anchor="middle" font-weight="bold">Output</text>
  <text x="400" y="270" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="11" text-anchor="middle">Topic: ${this.escape(label)}</text>
</svg>`
  }

  /**
   * Topic-specific icon. The icon's shape is derived from the topic's hash
   * so two different topics get visually distinct icons.
   */
  generateIcon(topic: string, theme: ThemePreset): string {
    const c = theme.colors
    const seed = this.hash(topic)
    const shape = seed % 4
    const label = this.shortLabel(topic).slice(0, 8)
    let shapeSvg: string
    switch (shape) {
      case 0:
        shapeSvg = `<rect x="20" y="20" width="60" height="60" fill="${c.primary}" rx="8"/><text x="50" y="58" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="20" font-weight="bold" text-anchor="middle">${label.charAt(0).toUpperCase()}</text>`
        break
      case 1:
        shapeSvg = `<circle cx="50" cy="50" r="32" fill="${c.accent}"/><text x="50" y="58" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="20" font-weight="bold" text-anchor="middle">${label.charAt(0).toUpperCase()}</text>`
        break
      case 2:
        shapeSvg = `<polygon points="50,18 82,82 18,82" fill="${c.primary}"/><text x="50" y="70" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="16" font-weight="bold" text-anchor="middle">${label.charAt(0).toUpperCase()}</text>`
        break
      default:
        shapeSvg = `<polygon points="50,18 82,38 82,62 50,82 18,62 18,38" fill="${c.accent}"/><text x="50" y="58" fill="${c.primaryFg}" font-family="${theme.typography.headingFont}" font-size="18" font-weight="bold" text-anchor="middle">${label.charAt(0).toUpperCase()}</text>`
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="48" height="48" role="img" aria-label="Icon for ${this.escape(topic)}">${shapeSvg}</svg>`
  }

  /**
   * Mermaid diagram source. The diagram encodes the topic name in its nodes
   * so it is semantically related to the slide.
   */
  generateMermaid(topic: string, kind: DiagramKind): string {
    const label = this.shortLabel(topic)
    switch (kind) {
      case 'sequence':
        return `sequenceDiagram
    participant L as Learner
    participant S as System
    participant ${this.mermaidId(label)} as ${this.escape(label)}
    L->>S: Request ${this.escape(label)}
    S->>${this.mermaidId(label)}: Process
    ${this.mermaidId(label)}-->>S: Result
    S-->>L: Response`
      case 'architecture':
        return `graph TB
    subgraph "${this.escape(label)} Architecture"
    A[Frontend] --> B[API Gateway]
    B --> C[${this.escape(label)} Service]
    C --> D[(Database)]
    C --> E[Cache]
    end`
      case 'comparison':
        return `graph LR
    subgraph Before
    A1[Manual ${this.escape(label)}]
    A2[Slow]
    A3[Error-prone]
    end
    subgraph After
    B1[Automated ${this.escape(label)}]
    B2[Fast]
    B3[Reliable]
    end
    A1 --> B1`
      case 'flow':
      default:
        return `graph LR
    A[Start ${this.escape(label)}] --> B[Analyze]
    B --> C{Decision}
    C -->|Yes| D[Implement ${this.escape(label)}]
    C -->|No| E[Review]
    D --> F[Deploy]
    E --> B
    F --> G[Monitor]`
    }
  }

  /**
   * Statistics infographic. Uses the locale's real statistics so the
   * infographic is grounded in local data (not generic).
   */
  generateInfographic(locale: LocaleContext, theme: ThemePreset): string {
    const c = theme.colors
    const stats = locale.statistics.slice(0, 4)
    if (stats.length === 0) {
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 200" width="100%" height="auto"><rect width="800" height="200" fill="${c.surface}" rx="8"/><text x="400" y="100" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="14" text-anchor="middle">No statistics available for ${this.escape(locale.country.name)}</text></svg>`
    }
    const barWidth = 160
    const gap = 20
    const startX = 40
    const items = stats.map((s, i) => {
      const x = startX + i * (barWidth + gap)
      const height = 80 + (i % 3) * 30
      const y = 160 - height
      return `<rect x="${x}" y="${y}" width="${barWidth}" height="${height}" fill="${i % 2 === 0 ? c.primary : c.accent}" rx="4"/>
      <text x="${x + barWidth / 2}" y="${y - 8}" fill="${c.text}" font-family="${theme.typography.headingFont}" font-size="18" font-weight="bold" text-anchor="middle">${this.escape(s.value)}</text>
      <text x="${x + barWidth / 2}" y="180" fill="${c.textMuted}" font-family="${theme.typography.bodyFont}" font-size="11" text-anchor="middle">${this.escape(s.metric)}</text>`
    }).join('')
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 200" width="100%" height="auto" role="img" aria-label="Statistics for ${this.escape(locale.country.name)}">
  <rect width="800" height="200" fill="${c.background}" rx="8"/>
  <text x="400" y="30" fill="${c.primary}" font-family="${theme.typography.headingFont}" font-size="16" font-weight="bold" text-anchor="middle">${this.escape(locale.country.name)} — Key Statistics</text>
  ${items}
</svg>`
  }

  // --- Helpers -------------------------------------------------------------

  private hash(text: string): number {
    let h = 0
    for (let i = 0; i < text.length; i++) {
      h = ((h << 5) - h + text.charCodeAt(i)) | 0
    }
    return Math.abs(h)
  }

  private shortLabel(topic: string): string {
    return topic.length > 30 ? topic.slice(0, 27) + '...' : topic
  }

  private mermaidId(label: string): string {
    return label.replace(/[^a-zA-Z0-9]/g, '').slice(0, 12) || 'Topic'
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }

  private shapeFromSeed(seed: number): (s: number, color: string) => string {
    const variant = seed % 3
    switch (variant) {
      case 0:
        return (_s, color) => `
  <circle cx="650" cy="100" r="60" fill="${color}" opacity="0.15"/>
  <circle cx="720" cy="80" r="30" fill="${color}" opacity="0.1"/>
  <rect x="600" y="280" width="120" height="60" fill="${color}" opacity="0.12" rx="8"/>`
      case 1:
        return (_s, color) => `
  <polygon points="600,80 700,80 650,180" fill="${color}" opacity="0.15"/>
  <polygon points="650,200 720,200 685,280" fill="${color}" opacity="0.1"/>`
      default:
        return (_s, color) => `
  <rect x="600" y="80" width="100" height="100" fill="${color}" opacity="0.12" rx="12" transform="rotate(15 650 130)"/>
  <circle cx="720" cy="280" r="40" fill="${color}" opacity="0.1"/>`
    }
  }
}

let singleton: MediaGenerator | null = null
export function getMediaGenerator(): MediaGenerator {
  if (!singleton) singleton = new MediaGenerator()
  return singleton
}
export function resetMediaGenerator(): void { singleton = null }
