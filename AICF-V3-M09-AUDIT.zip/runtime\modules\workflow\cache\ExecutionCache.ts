// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Execution Cache
// =============================================================================
// Generic TTL-based key/value cache implementing `ICacheProvider`, plus a
// deterministic cache-key derivation helper for workflow executions.
//
// Sprint 13+14 spec requirements covered:
//   - Typed `get<T>` / `set<T>` with optional TTL
//   - `has` / `delete` / `clear`
//   - `cleanup()` removes expired entries and returns the count removed
//   - `getKey(definition, inputs)` — deterministic SHA-256 cache key from
//     workflow id + version + sorted inputs
//   - Configurable auto-cleanup interval (default 60s)
// =============================================================================

import type { ICacheProvider } from '@/lib/runtime/interfaces'
import type { WorkflowDefinition } from '@/lib/runtime/contracts/workflow'
import { createHash } from 'crypto'
import { logger } from '@/lib/ai/logger'

/** Internal cache entry. */
interface CacheEntry {
  value: unknown
  /** Epoch ms at which the entry expires (Infinity = no TTL). */
  expiresAt: number
}

/** Options for constructing an `ExecutionCache`. */
export interface ExecutionCacheOptions {
  /** Auto-cleanup interval in ms. Default 60_000. Set to 0 to disable. */
  cleanupIntervalMs?: number
  /** Default TTL applied when `set` is called without a TTL. */
  defaultTtlMs?: number
}

/**
 * In-memory `ICacheProvider` with TTL support and an auto-cleanup timer.
 *
 * One instance can hold values of any shape; the generic parameter is on
 * each method (not the class) per the `ICacheProvider` contract.
 */
export class ExecutionCache implements ICacheProvider {
  /** Map<key, CacheEntry>. */
  private readonly entries = new Map<string, CacheEntry>()
  /** Handle for the auto-cleanup timer (null when disabled). */
  private readonly timer: NodeJS.Timeout | null
  /** Default TTL applied when `set` is called without an explicit TTL. */
  private readonly defaultTtlMs: number

  constructor(opts: ExecutionCacheOptions = {}) {
    this.defaultTtlMs = opts.defaultTtlMs ?? 0
    const interval = opts.cleanupIntervalMs ?? 60_000
    if (interval > 0) {
      // `unref` so the timer does not keep the process alive on its own.
      this.timer = setInterval(() => {
        const removed = this.cleanup()
        if (removed > 0) {
          logger.debug(
            { removed, remaining: this.entries.size },
            'ExecutionCache: auto-cleanup',
          )
        }
      }, interval)
      // Safety: Node typings expect Timer.unref, but on Timeout it exists too.
      if (typeof this.timer.unref === 'function') {
        this.timer.unref()
      }
    } else {
      this.timer = null
    }
  }

  // ----- ICacheProvider ----------------------------------------------------

  /** Get a cached value, or null if absent / expired. */
  async get<T>(key: string): Promise<T | null> {
    const entry = this.entries.get(key)
    if (!entry) return null
    if (entry.expiresAt !== Infinity && entry.expiresAt <= Date.now()) {
      // Lazy eviction on read.
      this.entries.delete(key)
      return null
    }
    return entry.value as T
  }

  /** Set a cached value with an optional TTL in milliseconds. */
  async set<T>(key: string, value: T, ttlMs?: number): Promise<void> {
    const ttl = ttlMs ?? this.defaultTtlMs
    this.entries.set(key, {
      value,
      expiresAt: ttl > 0 ? Date.now() + ttl : Infinity,
    })
  }

  /** Delete a cached value by key. No-op if absent. */
  async delete(key: string): Promise<void> {
    this.entries.delete(key)
  }

  /** Clear all cached values. */
  async clear(): Promise<void> {
    this.entries.clear()
  }

  /** Whether a key is present AND not expired. */
  async has(key: string): Promise<boolean> {
    const entry = this.entries.get(key)
    if (!entry) return false
    if (entry.expiresAt !== Infinity && entry.expiresAt <= Date.now()) {
      this.entries.delete(key)
      return false
    }
    return true
  }

  // ----- Extended (Batch D) ------------------------------------------------

  /**
   * Remove all expired entries. Returns the count of entries removed.
   * Entries with `expiresAt === Infinity` are never removed by this method.
   */
  cleanup(): number {
    const now = Date.now()
    let removed = 0
    for (const [key, entry] of this.entries) {
      if (entry.expiresAt !== Infinity && entry.expiresAt <= now) {
        this.entries.delete(key)
        removed += 1
      }
    }
    return removed
  }

  /**
   * Derive a deterministic cache key from a workflow definition + inputs.
   * The key is `wf:<id>:<version>:<inputsHash>` where `inputsHash` is the
   * SHA-256 of the canonical JSON of the inputs (sorted keys at every
   * level, so `{ a: 1, b: 2 }` and `{ b: 2, a: 1 }` produce the same hash).
   *
   * Two executions of the same workflow version with the same inputs
   * therefore share a cache key — enabling idempotent caching of the
   * resulting `WorkflowResult`.
   */
  getKey(
    definition: WorkflowDefinition,
    inputs: Record<string, unknown>,
  ): string {
    const id = definition.metadata.id
    const version = definition.version
    const canonical = canonicalJson(inputs)
    const inputsHash = createHash('sha256').update(canonical).digest('hex')
    return `wf:${id}:${version}:${inputsHash}`
  }

  /** Number of entries currently held (including expired, until cleanup). */
  get size(): number {
    return this.entries.size
  }

  /** Stop the auto-cleanup timer. Safe to call multiple times. */
  dispose(): void {
    if (this.timer) {
      clearInterval(this.timer)
    }
  }
}

// ----- Helpers --------------------------------------------------------------

/**
 * Produce a canonical JSON string for a value: object keys sorted at every
 * level, arrays preserved in order. Handles plain JSON-serializable data
 * (strings, numbers, booleans, null, arrays, plain objects).
 */
function canonicalJson(value: unknown): string {
  if (value === null) return 'null'
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'null'
  if (typeof value === 'boolean') return String(value)
  if (Array.isArray(value)) {
    const items = value.map((v) => canonicalJson(v)).join(',')
    return `[${items}]`
  }
  if (typeof value === 'object') {
    const obj = value as Record<string, unknown>
    const keys = Object.keys(obj).sort()
    const pairs = keys
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`)
      .join(',')
    return `{${pairs}}`
  }
  // Functions, symbols, undefined: fall back to a stable placeholder.
  return 'null'
}
