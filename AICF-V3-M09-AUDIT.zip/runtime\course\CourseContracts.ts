// =============================================================================
// AICF V3 — Epica 8 — Course Contracts (Typed Domain Model)
// =============================================================================
// All Epica 7+8 engines exchange data through these typed contracts.
// Each contract carries provenance metadata (id, version, timestamps,
// generatorVersion, provider, model, runtimeVersion) so that any artifact
// can be traced back to the engine + provider that produced it.
// =============================================================================

export type ResearchDepth = 'quick' | 'standard' | 'deep'

export type CourseLevel = 'beginner' | 'intermediate' | 'advanced' | 'expert'

export type CourseMode = 'fast' | 'balanced' | 'premium' | 'deep-research'

export type Provider =
  | 'groq'
  | 'gemini'
  | 'claude'
  | 'openai'
  | 'openrouter'
  | 'litellm'
  | 'runtime-adapter'

export type ContentType =
  | 'course'
  | 'presentation'
  | 'quiz'
  | 'document'
  | 'exercises'
  | 'assessment'
  | 'case-study'
  | 'checklist'
  | 'template'
  | 'guide'

export interface CertificationOptions {
  finalExam: boolean
  rubrics: boolean
  certificate: boolean
  badges: boolean
  finalProject: boolean
}

/**
 * Provenance metadata shared by every contract. Engines MUST populate
 * these fields so downstream stages know which generator + provider
 * produced each artifact.
 */
export interface Provenance {
  id: string
  version: string
  createdAt: string
  updatedAt: string
  generatorVersion: string
  provider: Provider
  model: string
  runtimeVersion: string
}

// -----------------------------------------------------------------------------
// Course Request
// -----------------------------------------------------------------------------
export interface CourseRequest extends Provenance {
  topic: string
  title: string
  description: string
  audience: string
  level: CourseLevel
  locale: string
  country: string
  moduleCount: number
  researchDepth: ResearchDepth
  contentTypes: ContentType[]
  certification: CertificationOptions
  budget: number
  mode: CourseMode
  correlationId: string
}

// -----------------------------------------------------------------------------
// Knowledge
// -----------------------------------------------------------------------------
export interface KnowledgeSource {
  id: string
  title: string
  url?: string
  content: string
  confidence: number
  provider: Provider
  retrievedAt: string
  hash: string
  type: 'web' | 'document' | 'memory' | 'rag' | 'knowledge-base'
}

export interface KnowledgePack extends Provenance {
  topic: string
  summary: string
  sources: KnowledgeSource[]
  keyFacts: string[]
  gaps: string[]
  confidence: number
  depth: ResearchDepth
  courseRequestId: string
}

// -----------------------------------------------------------------------------
// Curriculum & Module Planning
// -----------------------------------------------------------------------------
export interface Curriculum extends Provenance {
  topic: string
  title: string
  description: string
  level: CourseLevel
  audience: string
  locale: string
  learningOutcomes: string[]
  prerequisites: string[]
  moduleCount: number
  totalDurationHours: number
  knowledgePackId: string
  courseRequestId: string
}

export interface ModulePlan extends Provenance {
  curriculumId: string
  moduleIndex: number
  title: string
  summary: string
  learningOutcomes: string[]
  lessonCount: number
  durationHours: number
  bloomLevels: string[]
}

export interface LessonPlan extends Provenance {
  moduleId: string
  moduleTitle: string
  lessonIndex: number
  title: string
  summary: string
  learningObjectives: string[]
  bloomLevel: string
  length: 'short' | 'standard' | 'long'
  durationMinutes: number
  keyConcepts: string[]
}

// -----------------------------------------------------------------------------
// Lesson & Exercises
// -----------------------------------------------------------------------------
export interface Lesson extends Provenance {
  lessonPlanId: string
  moduleId: string
  moduleTitle: string
  lessonIndex: number
  title: string
  content: string
  wordCount: number
  learningObjectives: string[]
  keyTakeaways: string[]
  durationMinutes: number
  bloomLevel: string
}

export interface Exercise extends Provenance {
  lessonId: string
  lessonTitle: string
  type: 'quiz' | 'coding' | 'writing' | 'discussion' | 'practice'
  difficulty: 'easy' | 'medium' | 'hard'
  question: string
  context: string
  expectedAnswer: string
  hints: string[]
  rubricCriteria: string[]
}

// -----------------------------------------------------------------------------
// Quiz & Assessment
// -----------------------------------------------------------------------------
export interface QuizQuestion {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation: string
  difficulty: 'easy' | 'medium' | 'hard'
  bloomLevel: string
}

export interface Quiz extends Provenance {
  moduleId: string
  moduleTitle: string
  title: string
  description: string
  questions: QuizQuestion[]
  passingScore: number
  maxAttempts: number
  durationMinutes: number
}

export interface Assessment extends Provenance {
  moduleId: string
  moduleTitle: string
  title: string
  description: string
  type: 'formative' | 'summative' | 'diagnostic' | 'final'
  questions: QuizQuestion[]
  rubric: AssessmentRubric
  passingScore: number
  weight: number
  durationMinutes: number
}

export interface AssessmentRubric {
  criteria: Array<{ name: string; weight: number; description: string }>
  totalPoints: number
  passingThreshold: number
}

// -----------------------------------------------------------------------------
// Case Study & Checklist
// -----------------------------------------------------------------------------
export interface CaseStudy extends Provenance {
  moduleId: string
  moduleTitle: string
  title: string
  scenario: string
  background: string
  challenge: string
  questions: string[]
  learningObjectives: string[]
  suggestedApproach: string
  durationMinutes: number
}

export interface Checklist extends Provenance {
  lessonId: string
  lessonTitle: string
  title: string
  items: Array<{ id: string; label: string; completed: boolean; required: boolean }>
  category: 'preparation' | 'execution' | 'review' | 'delivery'
}

// -----------------------------------------------------------------------------
// Template & Presentation & Guide
// -----------------------------------------------------------------------------
export interface Template extends Provenance {
  lessonId: string
  lessonTitle: string
  name: string
  description: string
  format: 'markdown' | 'html' | 'json' | 'text'
  body: string
  placeholders: Array<{ name: string; description: string; required: boolean }>
  useCase: string
}

export interface Slide {
  id: string
  index: number
  title: string
  bullets: string[]
  notes: string
  layout: 'title' | 'content' | 'section' | 'two-column' | 'image'
  /** EPIC 10 — Premium fields (optional, backward-compatible) */
  /** Specific content/explanation for this slide (beyond bullets) */
  content?: string
  /** Concrete example illustrating the slide's concept */
  example?: string
  /** Visual asset descriptor (SVG/Mermaid/diagram reference) */
  visual?: {
    type: 'image' | 'diagram' | 'chart' | 'code' | 'mermaid' | 'none'
    description: string
    prompt?: string
    code?: string
    svg?: string
    mermaid?: string
  }
  /** Instructor-facing notes (distinct from student-facing notes) */
  instructorNotes?: string
  /** Traceability: which lesson this slide belongs to */
  lessonId?: string
  /** Traceability: which module this slide belongs to */
  moduleId?: string
}

export interface Presentation extends Provenance {
  title: string
  description: string
  slides: Slide[]
  slideCount: number
  theme: string
  audience: string
  /** EPIC 10 — Traceability: course this presentation belongs to */
  courseId?: string
}

export interface Guide extends Provenance {
  type: 'teacher' | 'student' | 'facilitator' | 'administrator'
  title: string
  description: string
  sections: Array<{ id: string; title: string; content: string }>
  totalWords: number
  audience: string
}

// -----------------------------------------------------------------------------
// Stage Result & Course Result
// -----------------------------------------------------------------------------
export interface StageResult {
  stage: string
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped'
  startedAt: string
  completedAt?: string
  durationMs: number
  engineName: string
  provider: Provider
  model: string
  output: unknown
  error?: string
  checkpoint: Record<string, unknown>
  tokenUsage?: { promptTokens: number; completionTokens: number; totalTokens: number }
  cost?: number
}

export interface CourseResult extends Provenance {
  courseRequestId: string
  topic: string
  title: string
  description: string
  status: 'pending' | 'generating' | 'completed' | 'failed' | 'partial'
  curriculum: Curriculum | null
  modules: ModulePlan[]
  lessons: Lesson[]
  exercises: Exercise[]
  quizzes: Quiz[]
  assessments: Assessment[]
  caseStudies: CaseStudy[]
  checklists: Checklist[]
  templates: Template[]
  presentation: Presentation | null
  guides: Guide[]
  qualityReport: QualityReport | null
  stages: StageResult[]
  zipBuffer: Buffer | null
  zipUrl: string
  totalWordCount: number
  totalDurationMs: number
  totalCost: number
  error?: string
}

// -----------------------------------------------------------------------------
// Quality Report
// -----------------------------------------------------------------------------
export interface QualityReport extends Provenance {
  courseResultId: string
  overallScore: number
  passed: boolean
  validators: QualityValidatorResult[]
  issues: string[]
  recommendations: string[]
  /** Reasons explaining the overall score (Sprint 4 RC31). */
  reasons: string[]
  /** Non-fatal warnings (things that don't fail the threshold but need attention). */
  warnings: string[]
}

export interface QualityValidatorResult {
  name: string
  passed: boolean
  score: number
  issues: string[]
  details: Record<string, unknown>
}
