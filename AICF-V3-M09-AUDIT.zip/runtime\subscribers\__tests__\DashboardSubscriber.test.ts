// =============================================================================
// AICF V3 — DashboardSubscriber Tests (Sprint 22: PR 2 — Observability subscribers)
// =============================================================================
// Verifies:
//   - Ring buffer (fixed-size): onEvent() is O(1) push, no allocation growth
//   - getRecentEvents(limit?) returns the most recent N events in
//     chronological order (oldest first)
//   - getEventCount() returns the total events received (monotonic, may
//     exceed capacity — overwritten events are still counted)
//   - When the buffer is full, the OLDEST entry is overwritten (FIFO)
//   - Default capacity is 1000
//   - createDashboardSubscriber(maxEvents?) factory returns a DashboardSubscriber
//   - onEvent() never throws (best-effort)
//   - isReady() returns false before initialize(), true after
//
// No `any`. Uses `testModule` not `module` per project conventions.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { DashboardSubscriber, createDashboardSubscriber } from '../DashboardSubscriber'
import {
  createEventMetadata,
  createEnvelope,
  type RuntimeEventEnvelope,
} from '../../events/EventMetadata'

/**
 * Helper: builds an envelope with a payload that uniquely identifies it.
 * `i` is used to make each envelope distinguishable from the others.
 */
function makeEnvelope(
  i: number,
  overrides: Partial<{ pipelineStage: string; requestId: string }> = {},
): RuntimeEventEnvelope<Record<string, unknown>> {
  const meta = createEventMetadata({
    correlationId: `cor-${i}`,
    requestId: overrides.requestId ?? `req-${i}`,
    operation: 'chat',
    pipelineStage: overrides.pipelineStage ?? 'Policy',
    stageOrder: i,
  })
  return createEnvelope(meta, { index: i })
}

describe('DashboardSubscriber (Sprint 22: PR 2)', () => {
  // -------------------------------------------------------------------------
  // isReady()
  // -------------------------------------------------------------------------
  describe('isReady()', () => {
    it('returns false before initialize()', () => {
      const sub = new DashboardSubscriber()
      expect(sub.isReady()).toBe(false)
    })

    it('returns true after initialize()', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })
  })

  // -------------------------------------------------------------------------
  // Ring buffer — getEventCount() + getRecentEvents()
  // -------------------------------------------------------------------------
  describe('ring buffer basics', () => {
    it('getEventCount() is 0 on a fresh subscriber', () => {
      const sub = new DashboardSubscriber()
      expect(sub.getEventCount()).toBe(0)
    })

    it('getRecentEvents() returns [] on a fresh subscriber', () => {
      const sub = new DashboardSubscriber()
      expect(sub.getRecentEvents()).toEqual([])
    })

    it('onEvent() increments the total counter', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      expect(sub.getEventCount()).toBe(1)
      await sub.onEvent(makeEnvelope(2))
      expect(sub.getEventCount()).toBe(2)
    })

    it('getRecentEvents() returns events in chronological order (oldest first)', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()

      await sub.onEvent(makeEnvelope(1))
      await sub.onEvent(makeEnvelope(2))
      await sub.onEvent(makeEnvelope(3))

      const events = sub.getRecentEvents()
      expect(events.length).toBe(3)
      // Oldest first → 1, 2, 3.
      const indices = events.map((e) => (e.payload as { index: number }).index)
      expect(indices).toEqual([1, 2, 3])
    })

    it('getRecentEvents(limit) returns the most recent N events', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()

      for (let i = 1; i <= 10; i++) {
        await sub.onEvent(makeEnvelope(i))
      }

      const recent = sub.getRecentEvents(3)
      expect(recent.length).toBe(3)
      // Most recent 3 events: indices 8, 9, 10 (oldest of those first).
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      expect(indices).toEqual([8, 9, 10])
    })

    it('getRecentEvents(0) returns an empty array', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      expect(sub.getRecentEvents(0)).toEqual([])
    })

    it('getRecentEvents(negative) returns an empty array', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      // Negative limit is clamped to 0.
      expect(sub.getRecentEvents(-5)).toEqual([])
    })

    it('getRecentEvents(limit) larger than stored returns all stored events', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      await sub.onEvent(makeEnvelope(2))

      const recent = sub.getRecentEvents(1000)
      expect(recent.length).toBe(2)
    })

    it('getRecentEvents() returns a fresh array — mutating the result does not affect internal state', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))

      const recent = sub.getRecentEvents()
      recent.length = 0 // mutate the returned array.

      // Internal state unchanged.
      expect(sub.getRecentEvents().length).toBe(1)
    })
  })

  // -------------------------------------------------------------------------
  // Ring buffer — overwrite behavior (capacity exceeded)
  // -------------------------------------------------------------------------
  describe('ring buffer overwrite', () => {
    it('overwrites the OLDEST entry when the buffer is full', async () => {
      const sub = new DashboardSubscriber(3)
      await sub.initialize()

      await sub.onEvent(makeEnvelope(1))
      await sub.onEvent(makeEnvelope(2))
      await sub.onEvent(makeEnvelope(3))
      // Buffer is now [1, 2, 3] (cursor points at slot 0 = entry 1).
      await sub.onEvent(makeEnvelope(4))
      // Buffer is now [4, 2, 3] (entry 1 was overwritten; cursor at slot 1).

      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(3)
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      // Chronological order (oldest first): 2, 3, 4.
      expect(indices).toEqual([2, 3, 4])
    })

    it('keeps only the last `capacity` events after many pushes', async () => {
      const sub = new DashboardSubscriber(5)
      await sub.initialize()

      for (let i = 1; i <= 12; i++) {
        await sub.onEvent(makeEnvelope(i))
      }

      // Total events received = 12; buffer holds only the last 5.
      expect(sub.getEventCount()).toBe(12)
      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(5)
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      // Last 5 events: 8, 9, 10, 11, 12 (oldest first).
      expect(indices).toEqual([8, 9, 10, 11, 12])
    })

    it('getEventCount() exceeds capacity (overwritten events still counted)', async () => {
      const sub = new DashboardSubscriber(3)
      await sub.initialize()

      for (let i = 1; i <= 10; i++) {
        await sub.onEvent(makeEnvelope(i))
      }

      expect(sub.getEventCount()).toBe(10)
      expect(sub.getRecentEvents().length).toBe(3)
    })

    it('wraps multiple times around the buffer correctly', async () => {
      const sub = new DashboardSubscriber(4)
      await sub.initialize()

      for (let i = 1; i <= 9; i++) {
        await sub.onEvent(makeEnvelope(i))
      }
      // After 9 pushes into a 4-slot buffer, the last 4 events are 6, 7, 8, 9.
      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(4)
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      expect(indices).toEqual([6, 7, 8, 9])
    })

    it('getRecentEvents(limit) returns the most recent N after wraparound', async () => {
      const sub = new DashboardSubscriber(3)
      await sub.initialize()

      for (let i = 1; i <= 7; i++) {
        await sub.onEvent(makeEnvelope(i))
      }
      // Buffer holds [7, 6, 5] internally (cursor at slot 1, but ring order
      // means oldest is 5 → 6 → 7).
      const recent = sub.getRecentEvents(2)
      expect(recent.length).toBe(2)
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      expect(indices).toEqual([6, 7])
    })
  })

  // -------------------------------------------------------------------------
  // Default capacity (1000)
  // -------------------------------------------------------------------------
  describe('default capacity (1000)', () => {
    it('default constructor sets capacity to 1000', async () => {
      const sub = new DashboardSubscriber()
      await sub.initialize()

      // Push 1001 events — the buffer should hold only the last 1000.
      for (let i = 1; i <= 1001; i++) {
        await sub.onEvent(makeEnvelope(i))
      }

      expect(sub.getEventCount()).toBe(1001)
      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(1000)
      const first = recent[0].payload as { index: number }
      const last = recent[recent.length - 1].payload as { index: number }
      expect(first.index).toBe(2) // oldest surviving entry
      expect(last.index).toBe(1001) // newest entry
    })

    it('createDashboardSubscriber() with no args defaults to 1000', async () => {
      const sub = createDashboardSubscriber()
      await sub.initialize()

      for (let i = 1; i <= 1002; i++) {
        await sub.onEvent(makeEnvelope(i))
      }

      expect(sub.getEventCount()).toBe(1002)
      expect(sub.getRecentEvents().length).toBe(1000)
    })
  })

  // -------------------------------------------------------------------------
  // Capacity validation (defensive)
  // -------------------------------------------------------------------------
  describe('capacity validation', () => {
    it('clamps non-positive capacity to the default (1000)', async () => {
      const sub = new DashboardSubscriber(0)
      await sub.initialize()

      // Capacity should be 1000, not 0 — pushing 1 event should succeed.
      await sub.onEvent(makeEnvelope(1))
      expect(sub.getRecentEvents().length).toBe(1)
    })

    it('clamps negative capacity to the default (1000)', async () => {
      const sub = new DashboardSubscriber(-10)
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      expect(sub.getRecentEvents().length).toBe(1)
    })

    it('clamps non-integer capacity to the default (1000)', async () => {
      const sub = new DashboardSubscriber(3.5)
      await sub.initialize()
      await sub.onEvent(makeEnvelope(1))
      // Capacity was not a valid integer — should default to 1000.
      expect(sub.getRecentEvents().length).toBe(1)
    })

    it('capacity = 1 holds only the most recent event', async () => {
      const sub = new DashboardSubscriber(1)
      await sub.initialize()

      await sub.onEvent(makeEnvelope(1))
      await sub.onEvent(makeEnvelope(2))
      await sub.onEvent(makeEnvelope(3))

      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(1)
      const only = recent[0].payload as { index: number }
      expect(only.index).toBe(3)
      expect(sub.getEventCount()).toBe(3)
    })
  })

  // -------------------------------------------------------------------------
  // onEvent() — best-effort (never throws)
  // -------------------------------------------------------------------------
  describe('onEvent() best-effort contract', () => {
    it('does not throw — onEvent resolves cleanly', async () => {
      const sub = new DashboardSubscriber(5)
      await sub.initialize()
      await expect(sub.onEvent(makeEnvelope(1))).resolves.toBeUndefined()
    })
  })

  // -------------------------------------------------------------------------
  // createDashboardSubscriber() factory
  // -------------------------------------------------------------------------
  describe('createDashboardSubscriber() factory', () => {
    it('returns a DashboardSubscriber instance', () => {
      const sub = createDashboardSubscriber(10)
      expect(sub).toBeInstanceOf(DashboardSubscriber)
    })

    it('accepts a capacity argument', async () => {
      const sub = createDashboardSubscriber(2)
      await sub.initialize()

      await sub.onEvent(makeEnvelope(1))
      await sub.onEvent(makeEnvelope(2))
      await sub.onEvent(makeEnvelope(3)) // overwrites entry 1.

      const recent = sub.getRecentEvents()
      expect(recent.length).toBe(2)
      const indices = recent.map((e) => (e.payload as { index: number }).index)
      expect(indices).toEqual([2, 3])
    })

    it('factory result name is "dashboard-subscriber"', () => {
      const sub = createDashboardSubscriber()
      expect(sub.name).toBe('dashboard-subscriber')
    })
  })
})
