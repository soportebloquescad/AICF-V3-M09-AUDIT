// =============================================================================
// AICF V3 — Sprint 2.2 — GET /api/runtime/healthz (LIVENESS)
// =============================================================================
// Liveness probe: returns 200 OK if the process is alive.
// NEVER depends on external services (LiteLLM, PostgreSQL, n8n, OpenWebUI).
// Does NOT call getRuntimeHealth() — that's readiness, not liveness.
// Returns x-correlation-id header.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { createCorrelationId, extractCorrelationIdFromHeaders, CORRELATION_ID_HEADER } from '@/lib/runtime/middleware/CorrelationId'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  const correlationId = extractCorrelationIdFromHeaders(request.headers) ?? createCorrelationId()
  const reqLogger = logger.child({ endpoint: '/runtime/healthz', correlationId })
  const timestamp = new Date().toISOString()

  reqLogger.debug('healthz: liveness check (process alive)')

  return NextResponse.json(
    { status: 'ok' as const, timestamp, correlationId },
    { status: 200, headers: { [CORRELATION_ID_HEADER]: correlationId } },
  )
}
