// =============================================================================
// AICF V3 — Sprint 10 + 11B — CourseConfiguration Contract (8 domains, multi-country)
// =============================================================================
// Sprint 11B additions (all OPTIONAL — backward compatible):
//   - includeExercises, includeLabs, includeCertificate, includeDownloadable
//   - suggestedPrice, estimatedHours, targetAudience, recommendedAge
// These extend the contract without breaking existing configurations.
// =============================================================================
import type { ThemeName } from '../theme/ThemeCatalog'

export interface CourseMetadataDomain {
  title: string; subtitle: string; description: string
  category: string; subcategory: string; tags: string[]
}

export interface CommerceDomain {
  price: number; currency: string; coupon: string; certificate: boolean
  license: string; access: string
  // Sprint 11B (optional)
  suggestedPrice?: number
}

export type TargetAudience = 'children' | 'teenagers' | 'adults' | 'professionals'

export interface AudienceDomain {
  target: string; level: 'beginner' | 'intermediate' | 'advanced' | 'expert'
  ageRange: string; priorKnowledge: string[]; objectives: string[]
  // Sprint 11B (optional)
  targetAudience?: TargetAudience
  recommendedAge?: string
}

export interface LocalizationDomain {
  primaryLanguage: string; secondaryLanguages: string[]
  subtitles: string[]; autoTranslate: boolean
}

export interface AcademicDomain {
  moduleCount: number; lessonsPerModule: number; estimatedDurationHours: number
  contentTypes: string[]; depth: 'quick' | 'standard' | 'deep'; difficulty: number
  // Sprint 11B (optional)
  estimatedHours?: number
}

export interface GeographicDomain {
  countries: string[]
  region: string; localCurrency: string
  culturalAdaptation: boolean; legislation: boolean; localExamples: boolean; realCases: boolean
}

export interface VisualDomain {
  theme: ThemeName; colorMode: 'light' | 'dark' | 'auto'
  branding: string; logoUrl: string; slideStyle: string
}

export interface ExportsDomain {
  documents: string[]; presentations: string[]; lms: string[]
  resources: string[]; marketing: string[]
}

export interface CourseConfiguration {
  id: string
  title: string; subtitle: string; description: string
  category: string; subcategory: string; tags: string[]
  commerce: CommerceDomain
  audience: AudienceDomain
  localization: LocalizationDomain
  academic: AcademicDomain
  geographic: GeographicDomain
  visual: VisualDomain
  exports: ExportsDomain
  // Sprint 10 options
  generateByCountry: boolean
  exportAllFormats: boolean
  includeGeneratedImages: boolean
  automaticDesign: boolean
  // Sprint 11B options (all optional — backward compatible)
  includeExercises?: boolean
  includeLabs?: boolean
  includeCertificate?: boolean
  includeDownloadable?: boolean
  isActive: boolean; version: number
  createdAt: string; updatedAt: string
}

export function createDefaultConfiguration(partial?: Partial<CourseConfiguration>): CourseConfiguration {
  const now = new Date().toISOString()
  return {
    id: partial?.id ?? '',
    title: partial?.title ?? 'Untitled Course',
    subtitle: partial?.subtitle ?? '',
    description: partial?.description ?? '',
    category: partial?.category ?? 'general',
    subcategory: partial?.subcategory ?? '',
    tags: partial?.tags ?? [],
    commerce: partial?.commerce ?? { price: 0, currency: 'USD', coupon: '', certificate: true, license: 'standard', access: 'free' },
    audience: partial?.audience ?? { target: 'general learners', level: 'intermediate', ageRange: '18-65', priorKnowledge: [], objectives: [] },
    localization: partial?.localization ?? { primaryLanguage: 'es', secondaryLanguages: [], subtitles: [], autoTranslate: false },
    academic: partial?.academic ?? { moduleCount: 3, lessonsPerModule: 3, estimatedDurationHours: 9, contentTypes: ['course', 'slides', 'quiz', 'exercises'], depth: 'standard', difficulty: 5 },
    geographic: partial?.geographic ?? { countries: ['global'], region: 'Global', localCurrency: 'USD', culturalAdaptation: true, legislation: true, localExamples: true, realCases: true },
    visual: partial?.visual ?? { theme: 'profesional', colorMode: 'light', branding: '', logoUrl: '', slideStyle: 'standard' },
    exports: partial?.exports ?? { documents: ['html', 'pdf', 'markdown', 'json'], presentations: ['slides-html', 'pptx'], lms: ['scorm', 'xapi'], resources: ['zip'], marketing: ['landing', 'certificate'] },
    generateByCountry: partial?.generateByCountry ?? false,
    exportAllFormats: partial?.exportAllFormats ?? false,
    includeGeneratedImages: partial?.includeGeneratedImages ?? true,
    automaticDesign: partial?.automaticDesign ?? true,
    // Sprint 11B defaults
    includeExercises: partial?.includeExercises ?? true,
    includeLabs: partial?.includeLabs ?? false,
    includeCertificate: partial?.includeCertificate ?? true,
    includeDownloadable: partial?.includeDownloadable ?? true,
    isActive: partial?.isActive ?? true,
    version: partial?.version ?? 1,
    createdAt: partial?.createdAt ?? now,
    updatedAt: partial?.updatedAt ?? now,
  }
}
