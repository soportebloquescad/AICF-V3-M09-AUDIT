// =============================================================================
// AICF V3 — Runtime Adapter (Production Runtime — fully functional)
// =============================================================================
// Implements the AIAdapter interface by delegating to RuntimeService.
//
// Architecture:
//   AIService → RuntimeAdapter → RuntimeService → Pipeline
//     → Validate → Policy → Routing → PromptBuilder → Execution
//     → PostProcessing → Audit → Cache → Metrics → Response
//
// The RuntimeAdapter does NOT call LiteLLM directly. It delegates to
// RuntimeService, which runs the pipeline. The pipeline's Execution stage
// uses a fallback function (wired in runtime-singleton.ts) that calls
// LiteLLMAdapter.chat() — this is the ONLY path to LiteLLM from the Runtime.
//
// Fallback rule (Sprint 4): the RuntimeAdapter falls back to LiteLLMAdapter
// ONLY when the Runtime itself is unavailable (RuntimeUnavailableError during
// init, or RuntimeService.execute() throws). Functional errors (pipeline
// stage failures, validation errors) are surfaced to the caller as
// AIAdapterError — NOT silently fallback'd. This prevents masking Runtime
// issues.
//
// Swapping from LiteLLMAdapter to RuntimeAdapter in AIService requires
// changing exactly one line:
//   new LiteLLMAdapter()  →  new RuntimeAdapter()
// =============================================================================

import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from './AIAdapter'
import { AIAdapterError } from './AIAdapter'
import { LiteLLMAdapter } from './LiteLLMAdapter'
import { logger } from './logger'
import { RuntimeService } from '@/lib/runtime/services/RuntimeService'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { ModuleRegistry } from '@/lib/runtime/registry/ModuleRegistry'
import { buildDefaultPipeline } from '@/lib/runtime/pipeline/PipelineRegistry'
import { Pipeline } from '@/lib/runtime/pipeline/Pipeline'
import type { RuntimeModule } from '@/lib/runtime/contracts/RuntimeModule'
import type { ContentIntelligenceModule, RealGenerationModule, InfrastructureModule } from '@/lib/runtime/contracts/ModuleInterfaces'
import { RuntimeUnavailableError } from '@/lib/runtime/errors/RuntimeUnavailableError'

/**
 * Configuration for the RuntimeAdapter.
 */
export interface RuntimeAdapterConfig {
  /** Content Intelligence module (M08 adapter). */
  ciModule?: ContentIntelligenceModule | null

  /** Real Generation module (M21 adapter). */
  genModule?: RealGenerationModule | null

  /** Infrastructure module (M18 adapter). */
  infraModule?: InfrastructureModule | null

  /** Fallback adapter (used when no modules are ready). */
  fallback?: AIAdapter

  /** Custom RuntimeService (overrides all other config). */
  runtimeService?: RuntimeService
}

/**
 * Adapter that routes AI calls through the Runtime pipeline.
 *
 * When the pipeline's Execution stage has M21/M18 wired (via adapters),
 * it calls: M21 → M18 → LiteLLM → Provider.
 *
 * Until then, it falls back to LiteLLMAdapter.
 *
 * Swapping from LiteLLMAdapter to RuntimeAdapter in AIService requires
 * changing exactly one line:
 *   new LiteLLMAdapter()  →  new RuntimeAdapter()
 */
export class RuntimeAdapter implements AIAdapter {
  private readonly runtimeService: RuntimeService
  private readonly fallback: AIAdapter
  private initialized = false

  constructor(config?: RuntimeAdapterConfig) {
    const fallback = config?.fallback || new LiteLLMAdapter()

    if (config?.runtimeService) {
      // Use a pre-built RuntimeService
      this.runtimeService = config.runtimeService
    } else {
      // Build a RuntimeService with the provided modules
      const moduleRegistry = new ModuleRegistry()

      // Register real modules if provided
      if (config?.ciModule) {
        moduleRegistry.register('content-intelligence', config.ciModule as unknown as RuntimeModule)
      }
      if (config?.genModule) {
        moduleRegistry.register('real-generation', config.genModule as unknown as RuntimeModule)
      }
      if (config?.infraModule) {
        moduleRegistry.register('infrastructure', config.infraModule as unknown as RuntimeModule)
      }

      // Build pipeline with real stages
      const stages = buildDefaultPipeline({
        ciModule: config?.ciModule || null,
        genModule: config?.genModule || null,
        infraModule: config?.infraModule || null,
        fallback: async (req: ChatRequest) => fallback.chat(req),
      })
      const pipeline = new Pipeline(stages)

      this.runtimeService = new RuntimeService({ pipeline, moduleRegistry })
    }

    this.fallback = fallback
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    // Sprint 4: Fallback rule — only fall back to LiteLLMAdapter when the
    // Runtime itself is unavailable (RuntimeUnavailableError). Functional
    // errors (pipeline stage failures, validation errors, module not
    // registered) are surfaced to the caller as AIAdapterError, NOT
    // silently fallback'd. This prevents masking Runtime issues.
    try {
      await this.ensureInitialized()
    } catch (err) {
      // Runtime initialization failed — Runtime is unavailable → fallback.
      // Any error during init means the Runtime infrastructure is down,
      // so we fall back to LiteLLMAdapter directly.
      logger.warn(
        { error: err instanceof Error ? err.message : String(err) },
        'RuntimeAdapter: Runtime unavailable during init, using fallback',
      )
      return this.fallback.chat(request)
    }

    const runtimeRequest = createRuntimeRequest({
      operation: 'chat',
      model: request.model,
      messages: request.messages,
      parameters: {
        temperature: request.temperature,
        maxTokens: request.maxTokens,
        topP: request.topP,
        stop: request.stop,
        stream: request.stream,
      },
    })

    logger.info(
      { requestId: runtimeRequest.requestId, model: request.model },
      'RuntimeAdapter: executing chat via Runtime pipeline',
    )

    let response
    try {
      response = await this.runtimeService.execute(runtimeRequest)
    } catch (err) {
      // RuntimeService.execute() threw — Runtime is unavailable → fallback
      logger.warn(
        { requestId: runtimeRequest.requestId, error: err instanceof Error ? err.message : String(err) },
        'RuntimeAdapter: Runtime execute threw, using fallback',
      )
      return this.fallback.chat(request)
    }

    if (response.ok && response.content) {
      return {
        content: response.content,
        model: response.model || request.model,
        provider: response.provider || 'runtime',
        usage: response.usage || null,
        durationMs: response.durationMs,
      }
    }

    // Sprint 4: Functional error (response.ok === false) — do NOT fallback.
    // Surface the error to the caller so Runtime issues are visible.
    logger.warn(
      { requestId: runtimeRequest.requestId, error: response.error, ok: response.ok },
      'RuntimeAdapter: pipeline returned functional error (NOT falling back)',
    )

    throw new AIAdapterError(
      response.error || 'Runtime pipeline did not produce content',
      'UNKNOWN',
      500,
    )
  }

  async models(): Promise<AIModel[]> {
    await this.ensureInitialized()

    const runtimeRequest = createRuntimeRequest({ operation: 'models' })

    logger.info(
      { requestId: runtimeRequest.requestId },
      'RuntimeAdapter: listing models via Runtime pipeline',
    )

    const response = await this.runtimeService.execute(runtimeRequest)

    if (response.ok && response.models && response.models.length > 0) {
      return response.models
    }

    // Fallback
    logger.debug('RuntimeAdapter: pipeline did not produce models, using fallback')
    return this.fallback.models()
  }

  async health(): Promise<AIHealth> {
    try {
      await this.ensureInitialized()

      const moduleStatuses = this.runtimeService.getModuleStatus()
      const fallbackHealth = await this.fallback.health()

      return {
        healthy: fallbackHealth.healthy,
        provider: 'runtime',
        latencyMs: fallbackHealth.latencyMs,
        details: {
          modules: moduleStatuses,
          fallback: fallbackHealth,
          pipelineStages: this.runtimeService.getPipelineStages(),
        },
      }
    } catch (err) {
      return {
        healthy: false,
        provider: 'runtime',
        details: { error: err instanceof Error ? err.message : String(err) },
      }
    }
  }

  private async ensureInitialized(): Promise<void> {
    if (!this.initialized) {
      await this.runtimeService.initialize()
      this.initialized = true
      logger.info('RuntimeAdapter initialized with RuntimeService')
    }
  }
}
