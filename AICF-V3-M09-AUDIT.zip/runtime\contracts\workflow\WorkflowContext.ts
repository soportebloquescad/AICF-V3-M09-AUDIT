// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Context Contract
// =============================================================================
// Defines the *runtime* context that flows through every step of a single
// workflow execution. Distinct from the higher-level `RuntimeContext` (which
// governs the request/response pipeline), the `WorkflowContext` is the
// per-execution, per-step shared state:
//
//   - Identity / scoping (correlation, execution, user, workspace, project)
//   - Localization (locale, defaulting to `'en'`)
//   - Resolved model / provider (set by the routing stage)
//   - Running cost + token tallies (updated immutably by each step)
//   - Resolved variable bindings (`variables`) for the workflow
//   - Dry-run flag (propagated from `WorkflowPolicies.dryRun`)
//   - Timing (`startedAt`, `endedAt`, `durationMs`)
//
// Sprint 13+14 spec requirements covered:
//   - Observability: every step can read+update cost/tokens immutably
//   - Localization: locale flows to providers and prompts
//   - Idempotency / replay: correlationId + executionId identify a run
//   - Dry-run propagation: `dryRun` flag carries through the whole context
// =============================================================================

import type { TokenUsage } from './WorkflowResult'

/** Options accepted by `createWorkflowContext`. */
export interface CreateWorkflowContextOptions {
  /** Cross-service correlation id. */
  correlationId: string
  /** Execution id this context belongs to. */
  executionId: string
  /** Optional owning user id. */
  userId?: string
  /** Optional owning workspace id. */
  workspaceId?: string
  /** Optional owning project id. */
  projectId?: string
  /** BCP-47 locale tag (defaults to `'en'`). */
  locale?: string
  /** Resolved model name (set by routing). */
  model?: string
  /** Resolved provider name (set by routing). */
  provider?: string
  /** Pre-resolved variable bindings (default `{}`). */
  variables?: Record<string, unknown>
  /** Whether this is a dry-run (default `false`). */
  dryRun?: boolean
  /** Optional free-form metadata bag. */
  metadata?: Record<string, unknown>
}

/**
 * Per-execution runtime context. Flows through every step; updated
 * immutably via `updateContextCost` (and equivalent helpers).
 */
export interface WorkflowContext {
  /** Cross-service correlation id for distributed tracing. */
  correlationId: string
  /** Execution id this context belongs to. */
  executionId: string
  /** Owning user id, if known. */
  userId?: string
  /** Owning workspace id, if known. */
  workspaceId?: string
  /** Owning project id, if known. */
  projectId?: string
  /** BCP-47 locale tag (default `'en'`). */
  locale: string
  /** Resolved model name (set by routing stage). */
  model?: string
  /** Resolved provider name (set by routing stage). */
  provider?: string
  /** Running cost tally (platform currency units). */
  cost: number
  /** Running token tally (prompt / completion / total). */
  tokens: TokenUsage
  /** Epoch ms when the context (and thus the execution) started. */
  startedAt: number
  /** Epoch ms when the execution ended (set on terminal state). */
  endedAt?: number
  /** Total wall-clock duration in milliseconds (set on terminal state). */
  durationMs?: number
  /** Resolved variable bindings for the workflow (name → value). */
  variables: Record<string, unknown>
  /** Whether this is a dry-run execution (no side-effects). */
  dryRun: boolean
  /** Optional free-form metadata bag. */
  metadata?: Record<string, unknown>
}

/**
 * Factory: creates a fresh `WorkflowContext` with sensible defaults.
 * - `locale` defaults to `'en'`.
 * - `dryRun` defaults to `false`.
 * - `cost` defaults to `0`.
 * - `tokens` defaults to `{ promptTokens: 0, completionTokens: 0, totalTokens: 0 }`.
 * - `startedAt` defaults to `Date.now()`.
 * - `variables` defaults to `{}`.
 */
export function createWorkflowContext(
  opts: CreateWorkflowContextOptions,
): WorkflowContext {
  const ctx: WorkflowContext = {
    correlationId: opts.correlationId,
    executionId: opts.executionId,
    locale: opts.locale ?? 'en',
    cost: 0,
    tokens: { promptTokens: 0, completionTokens: 0, totalTokens: 0 },
    startedAt: Date.now(),
    variables: opts.variables ?? {},
    dryRun: opts.dryRun ?? false,
  }
  if (opts.userId !== undefined) ctx.userId = opts.userId
  if (opts.workspaceId !== undefined) ctx.workspaceId = opts.workspaceId
  if (opts.projectId !== undefined) ctx.projectId = opts.projectId
  if (opts.model !== undefined) ctx.model = opts.model
  if (opts.provider !== undefined) ctx.provider = opts.provider
  if (opts.metadata !== undefined) ctx.metadata = opts.metadata
  return ctx
}

/**
 * Immutably update a context's running cost + token tallies.
 *
 * Returns a NEW `WorkflowContext` — the input `ctx` is not mutated — so
 * callers can keep an audit trail of every context revision.
 *
 * @param ctx          The context to update.
 * @param deltaCost    Cost delta to add (platform currency units).
 * @param deltaTokens  Token-usage delta to add.
 */
export function updateContextCost(
  ctx: WorkflowContext,
  deltaCost: number,
  deltaTokens: TokenUsage,
): WorkflowContext {
  return {
    ...ctx,
    cost: ctx.cost + deltaCost,
    tokens: {
      promptTokens: ctx.tokens.promptTokens + deltaTokens.promptTokens,
      completionTokens:
        ctx.tokens.completionTokens + deltaTokens.completionTokens,
      totalTokens: ctx.tokens.totalTokens + deltaTokens.totalTokens,
    },
  }
}
