// =============================================================================
// AICF V3 — M08 Content Intelligence — Barrel
// =============================================================================
// Re-exports all M08 types and classes so consumers can write:
//   import { ContentIntelligenceEngine, DecisionPlan } from '@/lib/runtime/modules/m08'
// =============================================================================

// --- DecisionPlan -----------------------------------------------------------
export type {
  DecisionPriority,
  CachePolicy,
  RetryPolicy,
  FallbackStrategy,
  DecisionAudit,
  DecisionPlan,
} from './DecisionPlan'
export {
  DEFAULT_CACHE_POLICY,
  DEFAULT_RETRY_POLICY,
  DEFAULT_FALLBACK_STRATEGY,
  createDecisionPlan,
} from './DecisionPlan'

// --- PolicyEngine -----------------------------------------------------------
export type {
  PolicyMode,
  PolicyDefinition,
  PolicyEvaluationResult,
} from './PolicyEngine'
export {
  PolicyEngine,
  getPolicyEngine,
  resetPolicyEngine,
} from './PolicyEngine'

// --- ProviderRouter ---------------------------------------------------------
export type {
  ProviderMetadata,
  RoutingResult,
} from './ProviderRouter'
export {
  ProviderRouter,
  getProviderRouter,
  resetProviderRouter,
} from './ProviderRouter'

// --- ModelSelector ----------------------------------------------------------
export type {
  ModelTask,
  ModelMetadata,
  ModelSelectionResult,
} from './ModelSelector'
export {
  ModelSelector,
  getModelSelector,
  resetModelSelector,
} from './ModelSelector'

// --- ContentIntelligenceEngine ----------------------------------------------
export type {
  RequestIntent,
  RequestAnalysis,
} from './ContentIntelligenceEngine'
export {
  ContentIntelligenceEngine,
  getContentIntelligenceEngine,
  resetContentIntelligenceEngine,
} from './ContentIntelligenceEngine'

// --- Runtime plugin wrapper (pre-existing) ----------------------------------
export {
  ContentIntelligenceRuntimeModule,
  CONTENT_INTELLIGENCE_METADATA,
  createContentIntelligenceModule,
  type M08Facade,
} from './ContentIntelligenceRuntimeModule'
