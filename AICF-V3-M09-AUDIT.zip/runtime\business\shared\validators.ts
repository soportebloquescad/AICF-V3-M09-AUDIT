// =============================================================================
// AICF V3 — Shared Validators (Épica 2 — AI Factory Core, B8)
// =============================================================================
// Lightweight runtime validators for the shared DTOs (B7). Each validator
// takes `unknown` and returns `{ valid: boolean; errors: string[] }`.
//
// These are deliberately minimal — they check shape, not deep semantics.
// They exist so the Business layer can reject malformed input before
// handing it to a module's executeJob() method.
//
// No `any` — `unknown` is the input type for every validator.
// =============================================================================

/**
 * Result shape returned by every validator.
 */
export interface ValidationResult {
  valid: boolean
  errors: string[]
}

/**
 * Narrows `value` to a non-null object (returns the record or null).
 */
function asRecord(value: unknown): Record<string, unknown> | null {
  if (typeof value !== 'object' || value === null) return null
  return value as Record<string, unknown>
}

/**
 * Validates a TopicInput: requires `topic` to be a non-empty string.
 * `description` is optional but, when present, must be a string.
 */
export function validateTopicInput(input: unknown): ValidationResult {
  const errors: string[] = []
  const rec = asRecord(input)
  if (rec === null) {
    return { valid: false, errors: ['TopicInput must be an object'] }
  }
  const topic = rec.topic
  if (typeof topic !== 'string' || topic.trim().length === 0) {
    errors.push('TopicInput.topic must be a non-empty string')
  }
  if (rec.description !== undefined && typeof rec.description !== 'string') {
    errors.push('TopicInput.description must be a string when present')
  }
  return { valid: errors.length === 0, errors }
}

/**
 * Validates a LevelInput: requires `level` to be one of the three allowed
 * literals.
 */
export function validateLevelInput(input: unknown): ValidationResult {
  const errors: string[] = []
  const rec = asRecord(input)
  if (rec === null) {
    return { valid: false, errors: ['LevelInput must be an object'] }
  }
  const level = rec.level
  if (
    typeof level !== 'string' ||
    (level !== 'beginner' && level !== 'intermediate' && level !== 'advanced')
  ) {
    errors.push("LevelInput.level must be one of 'beginner' | 'intermediate' | 'advanced'")
  }
  return { valid: errors.length === 0, errors }
}

/**
 * Validates a ModuleCountInput: requires `modules` to be a positive integer
 * (1..=100). 100 is an arbitrary upper bound to catch malformed requests;
 * the Business layer may tighten this per job type.
 */
export function validateModuleCountInput(input: unknown): ValidationResult {
  const errors: string[] = []
  const rec = asRecord(input)
  if (rec === null) {
    return { valid: false, errors: ['ModuleCountInput must be an object'] }
  }
  const modules = rec.modules
  if (typeof modules !== 'number' || !Number.isInteger(modules) || modules < 1 || modules > 100) {
    errors.push('ModuleCountInput.modules must be an integer between 1 and 100')
  }
  return { valid: errors.length === 0, errors }
}

/**
 * Validates a FormatInput: requires `format` to be one of the four allowed
 * literals.
 */
export function validateFormatInput(input: unknown): ValidationResult {
  const errors: string[] = []
  const rec = asRecord(input)
  if (rec === null) {
    return { valid: false, errors: ['FormatInput must be an object'] }
  }
  const format = rec.format
  if (
    typeof format !== 'string' ||
    (format !== 'markdown' && format !== 'docx' && format !== 'pdf' && format !== 'pptx')
  ) {
    errors.push("FormatInput.format must be one of 'markdown' | 'docx' | 'pdf' | 'pptx'")
  }
  return { valid: errors.length === 0, errors }
}
