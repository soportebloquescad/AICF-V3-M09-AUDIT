// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Policy Middleware
// =============================================================================
// Runs BEFORE step execution. Aggregates the decisions of an ordered list
// of `IPolicy` implementations; if ANY policy denies, the step is skipped
// (or otherwise handled by the caller).
//
// Sprint 13+14 spec requirements covered:
//   - `IPolicy` interface: `name` + `check(ctx, step): Promise<PolicyDecision>`
//   - `PolicyMiddleware.check(ctx, step)` runs every policy and aggregates
//   - Aggregation rule: deny wins. Any `allowed === false` makes the
//     aggregate decision `allowed === false`. Violations are concatenated.
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Aggregated decision returned by a policy check. */
export interface PolicyDecision {
  /** Whether the step is allowed to run. */
  allowed: boolean
  /** List of policy violation messages (empty when allowed). */
  violations: string[]
  /** Optional human-readable reason for the decision. */
  reason?: string
}

/**
 * A policy implementation. Policies are run in registration order; each
 * receives the same `(ctx, step)` and returns an independent decision.
 */
export interface IPolicy {
  /** Policy name (e.g. 'execution-policy', 'approval-policy'). */
  name: string
  /** Check whether the step is allowed to run. */
  check(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision>
}

/** Convenience: an "allow" decision with no violations. */
const ALLOW: PolicyDecision = { allowed: true, violations: [] }

/**
 * Compose an ordered list of `IPolicy` implementations into a single
 * `check(ctx, step)` call. The middleware does NOT short-circuit on the
 * first denial — every policy runs so that all violations are reported.
 *
 * Aggregation:
 *   - `allowed` is `true` iff every policy returns `allowed === true`.
 *   - `violations` is the concatenation of every policy's violations.
 *   - `reason` is the first denied policy's reason (or undefined when allowed).
 */
export class PolicyMiddleware {
  /**
   * @param policies Ordered list of policy implementations.
   */
  constructor(private readonly policies: IPolicy[]) {}

  /**
   * Run every policy against `(ctx, step)` and return the aggregated
   * decision. A single policy throwing is treated as a denial with the
   * error message as the violation — the remaining policies still run.
   */
  async check(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const violations: string[] = []
    let firstReason: string | undefined
    let allowed = true

    for (const policy of this.policies) {
      try {
        const decision = await policy.check(ctx, step)
        if (!decision.allowed) {
          allowed = false
          if (firstReason === undefined && decision.reason) {
            firstReason = decision.reason
          }
          for (const v of decision.violations) {
            violations.push(`[${policy.name}] ${v}`)
          }
        }
      } catch (err) {
        // A throwing policy is treated as a hard denial.
        allowed = false
        const msg = err instanceof Error ? err.message : 'policy threw'
        violations.push(`[${policy.name}] policy threw: ${msg}`)
        if (firstReason === undefined) firstReason = msg
      }
    }

    if (!allowed) {
      logger.warn(
        {
          executionId: ctx.executionId,
          stepId: step.id,
          policyCount: this.policies.length,
          violationCount: violations.length,
        },
        'PolicyMiddleware: step denied',
      )
    }

    return allowed
      ? ALLOW
      : {
          allowed: false,
          violations,
          ...(firstReason !== undefined ? { reason: firstReason } : {}),
        }
  }

  /** Names of the registered policies (for diagnostics). */
  policyNames(): string[] {
    return this.policies.map((p) => p.name)
  }
}
