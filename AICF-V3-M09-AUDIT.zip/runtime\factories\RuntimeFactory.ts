// =============================================================================
// AICF V3 — Sprint 2 — Runtime Factory
// =============================================================================
// Factory that creates a fully wired RuntimeService with default pipeline.
// =============================================================================

import { RuntimeService } from '../services/RuntimeService'
import { Pipeline } from '../pipeline/Pipeline'
import { PipelineRegistry, buildDefaultPipeline, type PipelineConfig } from '../pipeline/PipelineRegistry'
import { ModuleRegistry } from '../registry/ModuleRegistry'
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { RuntimeEventBus } from '../events/RuntimeEventBus'

export interface RuntimeFactoryConfig {
  aiAdapter?: AIAdapter
  eventBus?: RuntimeEventBus
  useBootstrap?: boolean
  pipelineConfig?: PipelineConfig
}

export function createRuntime(config?: RuntimeFactoryConfig): RuntimeService {
  const moduleRegistry = new ModuleRegistry()
  const pipelineRegistry = new PipelineRegistry()

  const pipelineConfig: PipelineConfig = config?.pipelineConfig ?? {
    fallback: async () => ({
      content: '',
      model: '',
      provider: 'litellm',
      usage: null,
      durationMs: 0,
    }),
    eventBus: config?.eventBus,
  }

  const stages = buildDefaultPipeline(pipelineConfig)
  const pipeline = new Pipeline(stages)

  return new RuntimeService({
    pipeline,
    moduleRegistry,
    eventBus: config?.eventBus,
    useBootstrap: config?.useBootstrap ?? false,
  })
}
