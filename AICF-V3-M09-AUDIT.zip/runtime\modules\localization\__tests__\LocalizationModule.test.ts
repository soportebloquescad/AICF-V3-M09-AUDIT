// =============================================================================
// AICF V3 — Sprint 19 — Localization Module Reference Tests
// =============================================================================
// Verifies that the LocalizationModule follows the reference pattern:
//   - Full lifecycle (initialize / isReady / dispose / reload)
//   - Health and metadata accessors
//   - Capabilities (translate, detectLanguage, getSupportedLocales,
//     formatDate, formatNumber) return the expected shapes
//
// Tests are self-contained — no external services or fixtures required.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import {
  LocalizationModule,
  LOCALIZATION_METADATA,
  SUPPORTED_LOCALES,
  createLocalizationModule,
} from '../LocalizationModule'

describe('LocalizationModule', () => {
  let testModule: LocalizationModule

  beforeEach(() => {
    testModule = createLocalizationModule()
  })

  describe('lifecycle', () => {
    it('initialize() → isReady() === true', async () => {
      expect(testModule.isReady()).toBe(false)
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      await testModule.initialize()
      const firstStartup = (await testModule.health()).startupTime
      await testModule.initialize()
      const secondStartup = (await testModule.health()).startupTime
      expect(secondStartup).toBe(firstStartup)
    })

    it('dispose() → isReady() === false', async () => {
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
      await testModule.dispose()
      expect(testModule.isReady()).toBe(false)
    })

    it('reload() works', async () => {
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
      await testModule.reload()
      expect(testModule.isReady()).toBe(true)
    })

    it('load() and unload() mirror initialize() and dispose()', async () => {
      await testModule.load()
      expect(testModule.isReady()).toBe(true)
      await testModule.unload()
      expect(testModule.isReady()).toBe(false)
    })
  })

  describe('health and metadata', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('health() returns healthy when initialized', async () => {
      const h = await testModule.health()
      expect(h.ready).toBe(true)
      expect(h.status).toBe('healthy')
      expect(h.version).toBe(LOCALIZATION_METADATA.version)
      expect(h.dependencies).toEqual([])
    })

    it('getMetadata() returns the declared plugin metadata', () => {
      const meta = testModule.getMetadata()
      expect(meta).toEqual(LOCALIZATION_METADATA)
      expect(meta.id).toBe('localization')
      expect(meta.priority).toBe(5)
      expect(meta.dependencies).toEqual([])
      expect(meta.capabilities).toContain('translate')
      expect(meta.capabilities).toContain('detectLanguage')
      expect(meta.capabilities).toContain('formatDate')
      expect(meta.capabilities).toContain('formatNumber')
      expect(meta.events).toEqual(['translation.completed', 'locale.changed'])
    })

    it('getStatus() returns the expected status shape', () => {
      const s = testModule.getStatus()
      expect(s.name).toBe(LOCALIZATION_METADATA.name)
      expect(s.ready).toBe(true)
      expect(s.version).toBe(LOCALIZATION_METADATA.version)
      expect(s.details).toBeDefined()
      expect(s.details?.implemented).toBe(true)
    })

    it('getMetrics() returns metric counters', async () => {
      // Trigger an operation so operationCount > 0
      await testModule.translate('hello', 'es')
      const m = testModule.getMetrics()
      expect(m.operationCount).toBeGreaterThan(0)
      expect(m.errorCount).toBe(0)
      expect(m.lastError).toBeNull()
      expect(m.lastUsed).not.toBeNull()
    })
  })

  describe('translate', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns a real translation for dictionary phrases', async () => {
      const result = await testModule.translate('hello', 'es')
      expect(result).toBe('hola')
    })

    it('returns a real translation for Japanese', async () => {
      const result = await testModule.translate('thank you', 'ja')
      expect(result).toBe('ありがとう')
    })

    it('returns the original text when target is English', async () => {
      const result = await testModule.translate('hello', 'en')
      expect(result).toBe('hello')
    })

    it('returns the original text when source equals target', async () => {
      const result = await testModule.translate('hello', 'es', 'es')
      expect(result).toBe('hello')
    })

    it('returns the fallback marker when the phrase is unknown', async () => {
      const result = await testModule.translate('this phrase is not in the dictionary', 'es')
      expect(result).toBe('[translate:this phrase is not in the dictionary]')
    })

    it('normalizes locale variants (es-AR → es)', async () => {
      const result = await testModule.translate('hello', 'es-AR')
      expect(result).toBe('hola')
    })
  })

  describe('detectLanguage', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('detects Japanese text', async () => {
      const result = await testModule.detectLanguage('これは日本語のテキストです')
      expect(result).toBe('ja')
    })

    it('detects Chinese text', async () => {
      const result = await testModule.detectLanguage('这是一段中文文本')
      expect(result).toBe('zh')
    })

    it('detects Cyrillic text as Russian', async () => {
      const result = await testModule.detectLanguage('Привет, мир')
      expect(result).toBe('ru')
    })

    it('defaults to en for plain ASCII text', async () => {
      const result = await testModule.detectLanguage('hello world')
      expect(result).toBe('en')
    })

    it('returns en for empty input', async () => {
      const result = await testModule.detectLanguage('')
      expect(result).toBe('en')
    })
  })

  describe('getSupportedLocales', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns the 7 supported locales', () => {
      const locales = testModule.getSupportedLocales()
      expect(locales).toEqual([...SUPPORTED_LOCALES])
      expect(locales).toHaveLength(7)
      expect(locales).toContain('en')
      expect(locales).toContain('es')
      expect(locales).toContain('fr')
      expect(locales).toContain('de')
      expect(locales).toContain('pt')
      expect(locales).toContain('ja')
      expect(locales).toContain('zh')
    })

    it('returns a fresh array each call (defensive copy)', () => {
      const a = testModule.getSupportedLocales()
      const b = testModule.getSupportedLocales()
      expect(a).toEqual(b)
      expect(a).not.toBe(b)
    })
  })

  describe('formatDate', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('formats a Date for the en locale', () => {
      const result = testModule.formatDate(new Date('2024-03-15T12:00:00Z'), 'en')
      expect(typeof result).toBe('string')
      expect(result.length).toBeGreaterThan(0)
      expect(result).toContain('2024')
    })

    it('formats an ISO string for the de locale', () => {
      const result = testModule.formatDate('2024-03-15T12:00:00Z', 'de')
      expect(typeof result).toBe('string')
      expect(result).toContain('2024')
    })

    it('normalizes locale variants', () => {
      const a = testModule.formatDate(new Date('2024-03-15T12:00:00Z'), 'en-US')
      const b = testModule.formatDate(new Date('2024-03-15T12:00:00Z'), 'en')
      expect(a).toBe(b)
    })
  })

  describe('formatNumber', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('formats an integer for the en locale', () => {
      const result = testModule.formatNumber(1234567, 'en')
      expect(typeof result).toBe('string')
      expect(result).toContain('1')
      expect(result).toContain('234')
    })

    it('formats a decimal for the de locale', () => {
      const result = testModule.formatNumber(1234.5, 'de')
      expect(typeof result).toBe('string')
      // German locale uses comma as decimal separator
      expect(result).toContain(',')
    })

    it('normalizes locale variants', () => {
      const a = testModule.formatNumber(1000, 'en-US')
      const b = testModule.formatNumber(1000, 'en')
      expect(a).toBe(b)
    })
  })
})
