// =============================================================================
// AICF V3 — Sprint 11B — CertificateEngine
// =============================================================================
// Single responsibility: generate course completion certificates.
//
// Generates:
//   - HTML certificate (self-contained, printable to PDF via browser)
//   - Print-ready CSS (page size, no margins)
//
// The certificate includes:
//   - Student name
//   - Course title
//   - Completion date
//   - Instructor signature
//   - Institution seal
//
// REUSES: ThemePreset (colors, typography), logger.
// No dependencies on BFF or Runtime M09.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import { logger } from '@/lib/ai/logger'

export interface CertificateData {
  studentName: string
  courseTitle: string
  completionDate: string
  instructorName: string
  institutionName: string
  score?: number
  certificateId: string
}

export interface CertificateResult {
  html: string
  data: CertificateData
}

export class CertificateEngine {
  private readonly log = logger.child({ component: 'CertificateEngine' })

  generate(opts: {
    studentName: string
    courseTitle: string
    instructorName?: string
    institutionName?: string
    score?: number
    theme: ThemePreset
  }): CertificateResult {
    const {
      studentName,
      courseTitle,
      instructorName = 'AICF V3 Instructor',
      institutionName = 'AICF V3 Academy',
      score,
      theme,
    } = opts

    const completionDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric',
    })
    const certificateId = `cert-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`

    const data: CertificateData = {
      studentName,
      courseTitle,
      completionDate,
      instructorName,
      institutionName,
      score,
      certificateId,
    }

    const html = this.buildHtml(data, theme)
    this.log.info({ certificateId, studentName, courseTitle }, 'CertificateEngine: generated')
    return { html, data }
  }

  private buildHtml(data: CertificateData, theme: ThemePreset): string {
    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderCssVars(theme)
    const c = theme.colors

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Certificate of Completion — ${this.escape(data.courseTitle)}</title>
  <style>
    ${themeCss}
    @page { size: landscape; margin: 0; }
    body { margin: 0; padding: 0; font-family: var(--font-body); background: var(--color-surface); }
    .cert-page { width: 100%; max-width: 1000px; margin: 0 auto; padding: 2rem; }
    .cert {
      background: var(--color-background);
      border: 8px double var(--color-primary);
      padding: 3rem;
      text-align: center;
      position: relative;
      border-radius: var(--radius);
      box-shadow: 0 4px 24px rgba(0,0,0,0.1);
    }
    .cert::before {
      content: '🏆';
      font-size: 4rem;
      position: absolute;
      top: 1rem;
      left: 50%;
      transform: translateX(-50%);
    }
    .cert h1 {
      color: var(--color-primary);
      font-size: 2.2rem;
      margin-top: 3rem;
      font-family: var(--font-heading);
    }
    .cert .subtitle {
      color: var(--color-text-muted);
      font-size: 1.1rem;
      margin: 0.5rem 0 2rem;
    }
    .cert .student-name {
      font-size: 2rem;
      font-weight: bold;
      color: var(--color-text);
      border-bottom: 2px solid var(--color-primary);
      display: inline-block;
      padding: 0 2rem 0.5rem;
      margin: 1rem 0;
      font-family: var(--font-heading);
    }
    .cert .course-title {
      font-size: 1.4rem;
      color: var(--color-text-muted);
      margin: 1rem 0;
    }
    .cert .score {
      font-size: 1.2rem;
      color: var(--color-success);
      font-weight: bold;
      margin: 1rem 0;
    }
    .cert .meta {
      display: flex;
      justify-content: space-around;
      margin-top: 3rem;
      padding-top: 2rem;
      border-top: 1px solid var(--color-border);
    }
    .cert .signature-block { text-align: center; }
    .cert .signature-line {
      border-top: 1px solid var(--color-text);
      width: 200px;
      margin: 3rem auto 0.5rem;
      padding-top: 0.5rem;
    }
    .cert .signature-name { font-weight: bold; color: var(--color-text); font-size: 0.95rem; }
    .cert .signature-role { color: var(--color-text-muted); font-size: 0.85rem; }
    .cert .seal {
      position: absolute;
      bottom: 2rem;
      right: 2rem;
      width: 100px;
      height: 100px;
      border: 3px solid var(--color-primary);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.7rem;
      color: var(--color-primary);
      font-weight: bold;
      text-align: center;
      line-height: 1.3;
      transform: rotate(-10deg);
    }
    .cert .cert-id {
      position: absolute;
      bottom: 1rem;
      left: 2rem;
      font-size: 0.7rem;
      color: var(--color-text-muted);
      font-family: monospace;
    }
    @media print { body { background: white; } .cert { box-shadow: none; } }
  </style>
</head>
<body>
  <div class="cert-page">
    <div class="cert">
      <h1>Certificate of Completion</h1>
      <p class="subtitle">This certifies that</p>
      <div class="student-name">${this.escape(data.studentName)}</div>
      <p class="subtitle">has successfully completed</p>
      <div class="course-title">${this.escape(data.courseTitle)}</div>
      ${data.score !== undefined ? `<div class="score">with a score of ${data.score}/100</div>` : ''}
      <div class="meta">
        <div class="signature-block">
          <div class="signature-line"></div>
          <div class="signature-name">${this.escape(data.instructorName)}</div>
          <div class="signature-role">Instructor</div>
        </div>
        <div class="signature-block">
          <div class="signature-line"></div>
          <div class="signature-name">${this.escape(data.completionDate)}</div>
          <div class="signature-role">Date of Completion</div>
        </div>
      </div>
      <div class="seal">${this.escape(data.institutionName)}<br>Official Seal</div>
      <div class="cert-id">ID: ${this.escape(data.certificateId)}</div>
    </div>
  </div>
</body>
</html>`
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }
}

let singleton: CertificateEngine | null = null
export function getCertificateEngine(): CertificateEngine {
  if (!singleton) singleton = new CertificateEngine()
  return singleton
}
export function resetCertificateEngine(): void { singleton = null }
