// =============================================================================
// AICF V3 — Instructional Designer Agent
// =============================================================================
// Designs the pedagogical framework for the course: Bloom levels,
// pedagogy approach, and an assessment strategy. Downstream agents
// (CurriculumArchitect, LessonWriter, AssessmentWriter) consume this
// design to align their outputs.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import {
  BLOOM_LEVELS_ORDER,
  callAI,
  elapsedMs,
  errorToString,
  extractJSON,
  normalizeLevel,
  pickBloomLevels,
  readContext,
} from './agentUtils'

export interface InstructionalDesignerDeps {
  aiAdapter: AIAdapter | null
}

interface DesignPayload {
  bloomLevels: string[]
  pedagogy: {
    approach: string
    methods: string[]
    differentiation: string
  }
  assessmentStrategy: {
    formative: string[]
    summative: string[]
    masteryThreshold: number
  }
}

/**
 * Loose shape used when parsing AI output. Every field is optional and
 * nested objects are also partial so we can safely probe each property.
 */
interface ParsedDesign {
  bloomLevels?: unknown
  pedagogy?: {
    approach?: unknown
    methods?: unknown
    differentiation?: unknown
  }
  assessmentStrategy?: {
    formative?: unknown
    summative?: unknown
    masteryThreshold?: unknown
  }
}

const APPROACHES = [
  'constructivist',
  'cognitive apprenticeship',
  'experiential learning',
  'mastery learning',
] as const

const METHODS = [
  'scaffolding',
  'active recall',
  'spaced repetition',
  'worked examples',
  'project-based learning',
  'peer instruction',
  'reflective journaling',
  'case-based reasoning',
] as const

const FORMATIVE = [
  'lesson quizzes',
  'in-lesson exercises',
  'reflection prompts',
  'peer review',
  'knowledge checks',
] as const

const SUMMATIVE = ['final assessment', 'capstone project', 'portfolio review', 'comprehensive exam'] as const

export class InstructionalDesigner implements Agent {
  public readonly name = 'instructional-designer'

  constructor(private readonly deps: InstructionalDesignerDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const research = readContext<{ topic?: string; keyFacts?: string[] }>(input.context, 'research')
      const ai = this.deps.aiAdapter
      const aiResult = await callAI(ai, buildPrompt(input, research), {
        systemPrompt:
          'You are a senior instructional designer. Respond with valid JSON only, no prose.',
        temperature: 0.4,
        maxTokens: 1000,
      })

      let design: DesignPayload
      if (aiResult.ok && aiResult.content) {
        const parsed = extractJSON<ParsedDesign>(aiResult.content)
        if (parsed && Array.isArray(parsed.bloomLevels) && parsed.bloomLevels.length > 0) {
          design = coerceDesign(parsed, input)
        } else {
          design = fallbackDesign(input)
        }
      } else {
        design = fallbackDesign(input)
      }

      return {
        agentName: this.name,
        result: { design },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function buildPrompt(
  input: AgentInput,
  research: { topic?: string; keyFacts?: string[] } | null,
): string {
  const facts = research?.keyFacts?.slice(0, 4).map((f) => `- ${f}`).join('\n') ?? '(no research available)'
  return [
    `Design the pedagogy for a course on "${input.topic}" aimed at ${input.audience} at the ${input.level} level.`,
    `Locale: ${input.locale}.`,
    `Research context:`,
    facts,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "bloomLevels": string[],   // 3 Bloom levels from: ${BLOOM_LEVELS_ORDER.join(', ')}`,
    `  "pedagogy": {`,
    `    "approach": string,`,
    `    "methods": string[],`,
    `    "differentiation": string`,
    `  },`,
    `  "assessmentStrategy": {`,
    `    "formative": string[],`,
    `    "summative": string[],`,
    `    "masteryThreshold": number`,
    `  }`,
    `}`,
  ].join('\n')
}

function coerceDesign(parsed: ParsedDesign, input: AgentInput): DesignPayload {
  const level = normalizeLevel(input.level)
  const validLevels = new Set<string>(BLOOM_LEVELS_ORDER)
  const rawBloom = Array.isArray(parsed.bloomLevels)
    ? parsed.bloomLevels.filter((l): l is string => typeof l === 'string' && validLevels.has(l))
    : []
  const finalBloom = rawBloom.length > 0 ? rawBloom.slice(0, 3) : pickBloomLevels(level)

  const pedagogy = parsed.pedagogy ?? {}
  const approach =
    typeof pedagogy.approach === 'string' && pedagogy.approach.length > 0
      ? pedagogy.approach
      : APPROACHES[0]
  const methods =
    Array.isArray(pedagogy.methods) && pedagogy.methods.length > 0
      ? pedagogy.methods.filter((m): m is string => typeof m === 'string')
      : METHODS.slice(0, 4)
  const differentiation =
    typeof pedagogy.differentiation === 'string' && pedagogy.differentiation.length > 0
      ? pedagogy.differentiation
      : `Tailored for ${input.audience} at the ${level} level.`

  const strategy = parsed.assessmentStrategy ?? {}
  const formative =
    Array.isArray(strategy.formative) && strategy.formative.length > 0
      ? strategy.formative.filter((m): m is string => typeof m === 'string')
      : FORMATIVE.slice(0, 3)
  const summative =
    Array.isArray(strategy.summative) && strategy.summative.length > 0
      ? strategy.summative.filter((m): m is string => typeof m === 'string')
      : SUMMATIVE.slice(0, 2)
  const masteryThreshold =
    typeof strategy.masteryThreshold === 'number' &&
    strategy.masteryThreshold > 0 &&
    strategy.masteryThreshold <= 1
      ? strategy.masteryThreshold
      : 0.75

  return {
    bloomLevels: finalBloom,
    pedagogy: { approach, methods, differentiation },
    assessmentStrategy: { formative, summative, masteryThreshold },
  }
}

function fallbackDesign(input: AgentInput): DesignPayload {
  const level = normalizeLevel(input.level)
  const bloomLevels = pickBloomLevels(level)
  return {
    bloomLevels,
    pedagogy: {
      approach: APPROACHES[0],
      methods: METHODS.slice(0, 4),
      differentiation: `Tailored for ${input.audience} at the ${level} level.`,
    },
    assessmentStrategy: {
      formative: FORMATIVE.slice(0, 3),
      summative: SUMMATIVE.slice(0, 2),
      masteryThreshold: 0.75,
    },
  }
}
