// =============================================================================
// AICF V3 — Sprint 13+14 — Content Generator Interface
// =============================================================================
// A generator produces a finished artifact (course / presentation / quiz /
// document) from a high-level `GeneratorInput`. Generators sit one layer
// above raw providers: they orchestrate multi-step provider calls and emit
// typed `WorkflowArtifact`s ready for the artifact store.
//
// Sprint 13+14 spec requirements covered:
//   - Strongly-typed `GeneratorType` covering the four product surfaces
//   - Uniform `GeneratorInput` with sensible optionals (level, modules,
//     audience, language, format, metadata)
//   - `GeneratorOutput` carries content + structured modules + outline +
//     artifacts + token/cost/provider/model attribution
//   - `canHandle(contentType)` for registry dispatch
// =============================================================================

import type {
  WorkflowContext,
  WorkflowArtifact,
  TokenUsage,
} from '@/lib/runtime/contracts/workflow'

/** High-level content category a generator can produce. */
export type GeneratorType = 'course' | 'presentation' | 'quiz' | 'document'

/** Inputs accepted by a content generator. */
export interface GeneratorInput {
  /** Topic / subject of the content. */
  topic: string
  /** Content category to produce. */
  contentType: GeneratorType
  /** Difficulty level (optional). */
  level?: 'beginner' | 'intermediate' | 'advanced'
  /** Number of modules / sections (optional). */
  modules?: number
  /** Target audience (optional). */
  audience?: string
  /** BCP-47 locale tag (optional). */
  language?: string
  /** Output format (optional). */
  format?: 'markdown' | 'docx' | 'pdf' | 'pptx'
  /** Free-form metadata bag (optional). */
  metadata?: Record<string, unknown>
}

/** Output produced by a content generator. */
export interface GeneratorOutput {
  /** Whether generation completed without error. */
  ok: boolean
  /** The generated content body (markdown / text / serialized JSON). */
  content: string
  /** Structured modules / sections (optional). */
  modules?: unknown[]
  /** Outline (optional). */
  outline?: string
  /** Generated title (optional). */
  title?: string
  /** Generated description (optional). */
  description?: string
  /** Artifacts produced (ready for the artifact store). */
  artifacts: WorkflowArtifact[]
  /** Token usage reported by the underlying provider, if applicable. */
  tokensUsed?: TokenUsage
  /** Cost incurred (platform currency units), if applicable. */
  cost?: number
  /** Provider name that handled the generation, if applicable. */
  provider?: string
  /** Model name that handled the generation, if applicable. */
  model?: string
  /** Error message when `ok === false`. */
  error?: string
}

/**
 * Content generator contract. Implementations are dispatched by
 * `canHandle(contentType)`; the runtime selects the first registered
 * generator that claims the content type.
 */
export interface IGenerator {
  /** Generator name (unique within the registry). */
  readonly name: string
  /** Content category this generator produces. */
  readonly generatorType: GeneratorType
  /** Generate content from a high-level input. */
  generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput>
  /** Whether this generator can handle the given content type. */
  canHandle(contentType: string): boolean
}
