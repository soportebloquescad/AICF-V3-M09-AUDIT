// =============================================================================
// AICF V3 — Sprint 4 — Correlation ID Middleware
// =============================================================================
// Provides correlation ID and request ID management for the Runtime.
//
// Sprint 4 enhancements:
//   - extractCorrelationIdFromHeaders(): reads X-Correlation-Id or
//     X-Request-Id from HTTP headers (for BFF → Runtime propagation)
//   - createCorrelationId(): generates a new correlation ID in the
//     format `corr-{timestamp-base36}-{random}` when none is provided
//   - ensureCorrelationId(): now uses createCorrelationId() instead of
//     defaulting to the requestId (so correlationId and requestId are
//     distinct values when the caller doesn't supply either)
//   - createRequestId(): generates `req-{timestamp-base36}-{random}`
//
// All IDs are propagated to logs via the existing logger (no logging
// system replacement).
// =============================================================================

import type { RuntimeRequest } from '../contracts/RuntimeRequest'

/**
 * Header name for the correlation ID (checked first).
 */
export const CORRELATION_ID_HEADER = 'x-correlation-id'

/**
 * Header name for the request ID (checked as fallback).
 */
export const REQUEST_ID_HEADER = 'x-request-id'

/**
 * Generates a new correlation ID in the format `corr-{timestamp}-{random}`.
 *
 * @example
 * createCorrelationId() // → "corr-ms6v9n22-9u70ab"
 */
export function createCorrelationId(): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `corr-${ts}-${rand}`
}

/**
 * Generates a new request ID in the format `req-{timestamp}-{random}`.
 *
 * @example
 * createRequestId() // → "req-ms6v9n22-9u70ab"
 */
export function createRequestId(): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `req-${ts}-${rand}`
}

/**
 * Extracts the correlation ID from HTTP request headers.
 *
 * Checks (case-insensitive):
 *   1. X-Correlation-Id
 *   2. X-Request-Id
 *
 * Returns null if neither header is present.
 *
 * @example
 * const headers = new Headers({ 'x-correlation-id': 'corr-abc-123' })
 * extractCorrelationIdFromHeaders(headers) // → "corr-abc-123"
 */
export function extractCorrelationIdFromHeaders(headers: Headers | Record<string, string | string[] | undefined> | undefined): string | null {
  if (!headers) return null

  // Support both Headers and plain record objects
  const get = (name: string): string | null => {
    if (headers instanceof Headers) {
      return headers.get(name)
    }
    // Case-insensitive lookup for plain objects
    const lower = name.toLowerCase()
    const record = headers as Record<string, string | string[] | undefined>
    for (const key of Object.keys(record)) {
      if (key.toLowerCase() === lower) {
        const val = record[key]
        if (typeof val === 'string') return val
        if (Array.isArray(val) && val.length > 0) return val[0] || null
        return null
      }
    }
    return null
  }

  const corrId = get(CORRELATION_ID_HEADER)
  if (corrId) return corrId

  const reqId = get(REQUEST_ID_HEADER)
  if (reqId) return reqId

  return null
}

/**
 * Ensures the request has a requestId. Generates one if missing.
 * Uses the format `req-{timestamp}-{random}`.
 */
export function ensureRequestId(request: RuntimeRequest): string {
  if (!request.requestId) {
    request.requestId = createRequestId()
  }
  return request.requestId
}

/**
 * Ensures the request has a correlationId. Generates one if missing.
 * Uses the format `corr-{timestamp}-{random}`.
 *
 * Sprint 4: previously defaulted to the requestId; now generates a distinct
 * correlation ID so that correlationId and requestId are independent tracing
 * dimensions.
 */
export function ensureCorrelationId(request: RuntimeRequest): string {
  if (!request.correlationId) {
    request.correlationId = createCorrelationId()
  }
  return request.correlationId
}

/**
 * Ensures both requestId and correlationId are present on the request.
 * Generates missing values using the standard formats.
 *
 * @returns The fully populated request (same reference, fields filled in).
 */
export function ensureTracingIds(request: RuntimeRequest): RuntimeRequest {
  ensureRequestId(request)
  ensureCorrelationId(request)
  return request
}
