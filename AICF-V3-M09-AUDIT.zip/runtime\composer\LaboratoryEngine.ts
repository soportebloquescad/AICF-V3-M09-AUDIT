// =============================================================================
// AICF V3 — Sprint 8 RC54 — LaboratoryEngine
// =============================================================================
// Generates practical lab exercises embedded in course HTML.
// =============================================================================

import type { CourseResult } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

export interface Lab {
  id: string
  title: string
  type: 'code-editor' | 'simulator' | 'prompt-playground' | 'case-study'
  html: string
}

export class LaboratoryEngine {
  private readonly log = logger.child({ component: 'LaboratoryEngine' })

  build(course: CourseResult): Lab[] {
    const labs: Lab[] = []
    const topic = course.topic.toLowerCase()

    // Code editor lab (for programming topics)
    if (topic.includes('python') || topic.includes('rust') || topic.includes('javascript') || topic.includes('programming') || topic.includes('code')) {
      labs.push(this.buildCodeEditor(course))
    }

    // Prompt playground (for AI/ML topics)
    if (topic.includes('ai') || topic.includes('machine learning') || topic.includes('ml') || topic.includes('llm')) {
      labs.push(this.buildPromptPlayground(course))
    }

    // Simulator (for business/finance/marketing)
    if (topic.includes('marketing') || topic.includes('finance') || topic.includes('business') || topic.includes('negocio')) {
      labs.push(this.buildSimulator(course))
    }

    // Always add a case study lab
    labs.push(this.buildCaseStudyLab(course))

    return labs
  }

  private buildCodeEditor(course: CourseResult): Lab {
    return {
      id: `lab-code-${course.id}`,
      title: `Code Lab: ${course.topic}`,
      type: 'code-editor',
      html: `<div class="lab code-lab">
  <h4>💻 Interactive Code Editor</h4>
  <p style="color:var(--muted)">Write and test code related to ${course.topic}.</p>
  <div style="display:flex;gap:1rem;">
    <textarea id="codeInput" style="flex:1;height:200px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:1rem;font-family:monospace;font-size:0.9rem;" placeholder="# Write your code here..."></textarea>
    <div style="flex:1;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1rem;overflow:auto;">
      <div id="codeOutput" style="font-family:monospace;font-size:0.85rem;color:var(--muted);">Output will appear here...</div>
    </div>
  </div>
  <button onclick="document.getElementById('codeOutput').textContent='Code execution simulated. In production, this connects to a sandboxed runtime.'" style="margin-top:0.5rem;background:var(--accent);color:white;border:none;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;">▶ Run</button>
</div>`,
    }
  }

  private buildPromptPlayground(course: CourseResult): Lab {
    return {
      id: `lab-prompt-${course.id}`,
      title: `AI Prompt Playground: ${course.topic}`,
      type: 'prompt-playground',
      html: `<div class="lab prompt-lab">
  <h4>🤖 AI Prompt Playground</h4>
  <p style="color:var(--muted)">Experiment with prompts related to ${course.topic}.</p>
  <textarea id="promptInput" style="width:100%;height:80px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:1rem;" placeholder="Enter your prompt..."></textarea>
  <button onclick="document.getElementById('promptOutput').textContent='In production, this connects to LiteLLM via the Runtime.'" style="margin-top:0.5rem;background:var(--accent);color:white;border:none;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;">Generate</button>
  <div id="promptOutput" style="margin-top:0.5rem;padding:1rem;background:var(--surface);border-radius:8px;color:var(--muted);">Response will appear here...</div>
</div>`,
    }
  }

  private buildSimulator(course: CourseResult): Lab {
    return {
      id: `lab-sim-${course.id}`,
      title: `Business Simulator: ${course.topic}`,
      type: 'simulator',
      html: `<div class="lab sim-lab">
  <h4>📊 Interactive Simulator</h4>
  <p style="color:var(--muted)">Adjust parameters and see results for ${course.topic}.</p>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
    <div><label>Budget ($)</label><input type="range" min="100" max="10000" value="1000" oninput="document.getElementById('simResult').textContent='Projected ROI: '+(this.value*2.5).toFixed(0)+'%'" style="width:100%;"></div>
    <div id="simResult" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:700;color:var(--accent);">Projected ROI: 2500%</div>
  </div>
</div>`,
    }
  }

  private buildCaseStudyLab(course: CourseResult): Lab {
    const firstCase = course.caseStudies[0]
    return {
      id: `lab-case-${course.id}`,
      title: `Case Study Lab: ${course.topic}`,
      type: 'case-study',
      html: `<div class="lab case-lab">
  <h4>📋 Case Study Analysis</h4>
  <p style="color:var(--muted)">${firstCase ? this.escape(firstCase.title) : 'Analyze a real-world scenario related to ' + course.topic}</p>
  <div style="background:var(--surface);border-radius:8px;padding:1rem;margin:0.5rem 0;">
    <p>${firstCase ? this.escape(firstCase.scenario || firstCase.background || 'Case study content') : 'Case study content will appear here based on the course topic.'}</p>
  </div>
  <textarea placeholder="Write your analysis..." style="width:100%;height:100px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:1rem;"></textarea>
  <button onclick="alert('Analysis saved! In production, this connects to the assessment engine.')" style="margin-top:0.5rem;background:var(--accent);color:white;border:none;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;">Submit Analysis</button>
</div>`,
    }
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  }
}
