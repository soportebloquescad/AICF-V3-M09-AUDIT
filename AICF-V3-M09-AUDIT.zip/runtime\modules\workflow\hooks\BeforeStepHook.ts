// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Before-Step Hook
// =============================================================================
// Re-exports `HookRegistry` and `FatalHookError` from `BeforeWorkflowHook`
// (single source of truth) and defines the `BeforeStepHook` interface.
// =============================================================================

export type { BeforeStepHook } from './BeforeWorkflowHook'
export { HookRegistry, FatalHookError } from './BeforeWorkflowHook'
