// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — CourseResult (extends ArtifactPackage)
// =============================================================================
// Course-specific artifact result. Extends the universal ArtifactPackage
// with fields specific to course generation (modules + quality).
//
// COMPATIBILITY: This is the Runtime-layer course result. The legacy
// src/lib/course/CourseResult.ts (BFF-layer) is NOT modified and remains
// used by CourseService / CourseWorker. This new contract is the universal
// artifact-layer course result that extends ArtifactPackage.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { ArtifactPackage } from './ArtifactPackage'

/**
 * A single module within a course.
 */
export interface Module {
  /** Unique module ID (e.g. 'module-1'). */
  id: string

  /** Module title. */
  title: string

  /** Module summary. */
  summary: string

  /** Lessons within this module. */
  lessons: Lesson[]
}

/**
 * A single lesson within a module.
 */
export interface Lesson {
  /** Unique lesson ID. */
  id: string

  /** Lesson title. */
  title: string

  /** Lesson content (markdown). */
  content: string

  /** Estimated duration in minutes. */
  durationMinutes?: number
}

/**
 * A quality check performed on a generated course.
 */
export interface QualityCheck {
  /** Check name (e.g. 'structure', 'coverage', 'accuracy'). */
  name: string

  /** Whether the check passed. */
  passed: boolean

  /** Check score (0-100). */
  score: number

  /** Optional message explaining the result. */
  message?: string
}

/**
 * A course-specific artifact result.
 *
 * Extends ArtifactPackage with course-generation fields:
 *   - modules: the structured course modules
 *   - qualityScore: overall quality (0-100)
 *   - qualityChecks: per-dimension quality checks
 *
 * The `type` field is fixed to 'course'.
 */
export interface CourseResult extends ArtifactPackage {
  /** The structured course modules. */
  modules: Module[]

  /** Overall quality score (0-100). */
  qualityScore: number

  /** Per-dimension quality checks. */
  qualityChecks: QualityCheck[]
}

/**
 * Factory: creates a CourseResult with sensible defaults.
 *
 * Sets `type: 'course'` automatically.
 *
 * @example
 * const result = createCourseResult({ id, title: 'Intro to Rust', content: '...', modules })
 */
export function createCourseResult(
  partial: Partial<CourseResult> & Pick<CourseResult, 'id' | 'title'>,
): CourseResult {
  return {
    type: 'course',
    description: '',
    content: '',
    sections: [],
    files: [],
    metadata: {},
    checksum: '',
    modules: [],
    qualityScore: 0,
    qualityChecks: [],
    ...partial,
  }
}
