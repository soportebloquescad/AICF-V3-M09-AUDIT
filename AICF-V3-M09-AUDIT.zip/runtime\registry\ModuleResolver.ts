// =============================================================================
// AICF V3 — Sprint 6 (RC33) — ModuleResolver
// =============================================================================
// Resolves dependencies between modules using topological sort.
//
// Given a list of ModuleDescriptors with `dependencies`, produces an
// initialization order where every module appears after its dependencies.
// Detects circular dependencies and reports them.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { ModuleDescriptor } from './ModuleDescriptor'

/**
 * The result of dependency resolution.
 */
export interface ResolutionResult {
  /** The initialization order (module IDs, dependencies first). */
  readonly order: readonly string[]
  /** Circular dependencies detected (empty if none). */
  readonly cycles: readonly string[][]
  /** Whether resolution succeeded (no cycles). */
  readonly ok: boolean
}

/**
 * Resolves module dependencies using topological sort.
 *
 * Used by ModuleLoader to determine the order in which to initialize
 * modules. Modules with no dependencies come first; modules that depend
 * on others come after their dependencies.
 */
export class ModuleResolver {
  /**
   * Resolves the initialization order for a set of module descriptors.
   *
   * @param descriptors - The module descriptors to resolve.
   * @returns Resolution result with order + any cycles detected.
   */
  resolve(descriptors: readonly ModuleDescriptor[]): ResolutionResult {
    const ids = new Set(descriptors.map((d) => d.id))
    const deps = new Map<string, readonly string[]>()
    const priority = new Map<string, number>()

    for (const d of descriptors) {
      deps.set(d.id, d.dependencies)
      priority.set(d.id, d.priority)
    }

    // Detect cycles via DFS
    const cycles = this.detectCycles(descriptors)
    if (cycles.length > 0) {
      return { order: [], cycles, ok: false }
    }

    // Topological sort (Kahn's algorithm, prioritized)
    const inDegree = new Map<string, number>()
    for (const d of descriptors) {
      inDegree.set(d.id, 0)
    }
    for (const d of descriptors) {
      for (const dep of d.dependencies) {
        if (ids.has(dep)) {
          inDegree.set(d.id, (inDegree.get(d.id) ?? 0) + 1)
        }
      }
    }

    // Start with modules that have no dependencies, sorted by priority
    let queue = descriptors
      .filter((d) => (inDegree.get(d.id) ?? 0) === 0)
      .sort((a, b) => a.priority - b.priority)
      .map((d) => d.id)

    const order: string[] = []
    const visited = new Set<string>()

    while (queue.length > 0) {
      const id = queue.shift()!
      if (visited.has(id)) continue
      visited.add(id)
      order.push(id)

      // Find modules that depend on this one and decrement their in-degree
      const next: string[] = []
      for (const d of descriptors) {
        if (visited.has(d.id)) continue
        if (d.dependencies.includes(id)) {
          const newDegree = (inDegree.get(d.id) ?? 0) - 1
          inDegree.set(d.id, newDegree)
          if (newDegree === 0) {
            next.push(d.id)
          }
        }
      }
      // Sort next batch by priority
      next.sort((a, b) => (priority.get(a) ?? 100) - (priority.get(b) ?? 100))
      queue.push(...next)
    }

    // Add any remaining (shouldn't happen if no cycles, but just in case)
    for (const d of descriptors) {
      if (!visited.has(d.id)) order.push(d.id)
    }

    return { order, cycles: [], ok: true }
  }

  /**
   * Detects circular dependencies using DFS.
   * Returns an array of cycles (each cycle is an array of module IDs).
   */
  private detectCycles(descriptors: readonly ModuleDescriptor[]): string[][] {
    const cycles: string[][] = []
    const visited = new Set<string>()
    const visiting = new Set<string>()
    const path: string[] = []

    const visit = (id: string): void => {
      if (visited.has(id)) return
      if (visiting.has(id)) {
        const cycleStart = path.indexOf(id)
        if (cycleStart >= 0) {
          cycles.push([...path.slice(cycleStart), id])
        }
        return
      }

      visiting.add(id)
      path.push(id)

      const desc = descriptors.find((d) => d.id === id)
      if (desc) {
        for (const dep of desc.dependencies) {
          if (descriptors.some((d) => d.id === dep)) {
            visit(dep)
          }
        }
      }

      path.pop()
      visiting.delete(id)
      visited.add(id)
    }

    for (const d of descriptors) {
      visit(d.id)
    }

    return cycles
  }
}
