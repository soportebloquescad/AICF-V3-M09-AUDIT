export type { RuntimeRequest, RuntimeOperation } from './RuntimeRequest'
export type { RuntimeResponse } from './RuntimeResponse'
export type { RuntimeContext, RuntimeMetrics } from './RuntimeContext'
export type { RuntimeModule, RuntimeStatus, RuntimeModuleCategory } from './RuntimeModule'
export type {
  ContentIntelligenceModule,
  RealGenerationModule,
  InfrastructureModule,
  WorkflowModule,
  LocalizationModule,
  AssetsModule,
  ReportsModule,
  PolicyDecision,
  ProviderRoute,
  GenerationResult,
  InfrastructureHealth,
  AssetResult,
  ReportResult,
} from './ModuleInterfaces'
export { createRuntimeRequest } from './RuntimeRequest'
export { createRuntimeResponse, createRuntimeErrorResponse } from './RuntimeResponse'
export { createRuntimeContext } from './RuntimeContext'

// --- Sprint Cierre Fase 0 — Universal Artifact Contracts --------------------
export type { ArtifactRequest, ArtifactType, ArtifactLevel } from './ArtifactRequest'
export { createArtifactRequest } from './ArtifactRequest'
export type {
  ArtifactPackage,
  ArtifactSection,
  ArtifactFile,
} from './ArtifactPackage'
export { createArtifactPackage } from './ArtifactPackage'
export type { ExecutionResult, ExecutionMetrics } from './ExecutionResult'
export {
  createEmptyMetrics,
  createSuccessExecutionResult,
  createFailedExecutionResult,
} from './ExecutionResult'
export type { ResearchPlan, ResearchDepth } from './ResearchPlan'
export { createResearchPlan } from './ResearchPlan'
export type { GenerationPlan, GenerationPlanItem } from './GenerationPlan'
export { createGenerationPlan } from './GenerationPlan'
export type { CourseRequest } from './CourseRequest'
export { createCourseRequest } from './CourseRequest'
export type {
  CourseResult,
  Module,
  Lesson,
  QualityCheck,
} from './CourseResult'
export { createCourseResult } from './CourseResult'
