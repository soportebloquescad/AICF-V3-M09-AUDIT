// =============================================================================
// AICF V3 — Epica 8 — Course Workflows
// =============================================================================
// High-level workflow methods that delegate to the CourseOrchestrator.
// Each workflow is a pre-configured pipeline variant optimized for a
// specific use case (quick preview, full course, certification track, etc.).
// =============================================================================
import type { AIFactory, GenerateCourseInput } from './AIFactory'
import type { CourseResult, CourseRequest, ContentType } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

export interface WorkflowResult {
  workflow: string
  course: CourseResult
  durationMs: number
  success: boolean
}

export class CourseWorkflows {
  constructor(private readonly factory: AIFactory) {}

  // 1. Quick preview — 2 modules, quick research, no extras
  async quickPreview(input: { topic: string; audience?: string; locale?: string }): Promise<WorkflowResult> {
    return this.runWorkflow('quick-preview', {
      topic: input.topic,
      audience: input.audience ?? 'learners',
      locale: input.locale ?? 'en-US',
      moduleCount: 2,
      researchDepth: 'quick',
      contentTypes: ['course', 'exercises'],
      mode: 'fast',
      budget: 0.2,
      certification: { finalExam: false, rubrics: false, certificate: false, badges: false, finalProject: false },
    })
  }

  // 2. Full course — default configuration
  async fullCourse(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('full-course', {
      moduleCount: 5,
      researchDepth: 'standard',
      contentTypes: ['course', 'exercises', 'quiz', 'assessment', 'presentation', 'guide'],
      mode: 'balanced',
      budget: 1.0,
      certification: { finalExam: true, rubrics: true, certificate: false, badges: false, finalProject: false },
      ...input,
    })
  }

  // 3. Certification track — final exam + rubrics + certificate
  async certificationTrack(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('certification-track', {
      moduleCount: 6,
      researchDepth: 'deep',
      contentTypes: ['course', 'exercises', 'quiz', 'assessment', 'case-study', 'presentation', 'guide'],
      mode: 'premium',
      budget: 2.0,
      certification: { finalExam: true, rubrics: true, certificate: true, badges: true, finalProject: true },
      ...input,
    })
  }

  // 4. Premium course — deep research, all content types
  async premiumCourse(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('premium-course', {
      moduleCount: 8,
      researchDepth: 'deep',
      contentTypes: ['course', 'exercises', 'quiz', 'assessment', 'case-study', 'checklist', 'template', 'presentation', 'guide'],
      mode: 'premium',
      budget: 3.0,
      certification: { finalExam: true, rubrics: true, certificate: true, badges: true, finalProject: true },
      ...input,
    })
  }

  // 5. Deep research course — focus on research depth
  async deepResearchCourse(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('deep-research', {
      moduleCount: 5,
      researchDepth: 'deep',
      contentTypes: ['course', 'exercises', 'quiz', 'assessment', 'guide'],
      mode: 'deep-research',
      budget: 2.5,
      certification: { finalExam: true, rubrics: false, certificate: false, badges: false, finalProject: false },
      ...input,
    })
  }

  // 6. Micro-course — single module, focused topic
  async microCourse(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('micro-course', {
      moduleCount: 1,
      researchDepth: 'quick',
      contentTypes: ['course', 'exercises'],
      mode: 'fast',
      budget: 0.3,
      certification: { finalExam: false, rubrics: false, certificate: false, badges: false, finalProject: false },
      ...input,
    })
  }

  // 7. Assessment-only — quizzes + assessments for an existing course
  async assessmentOnly(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('assessment-only', {
      moduleCount: 3,
      researchDepth: 'quick',
      contentTypes: ['quiz', 'assessment'] as ContentType[],
      mode: 'fast',
      budget: 0.5,
      certification: { finalExam: true, rubrics: true, certificate: false, badges: false, finalProject: false },
      ...input,
    })
  }

  // 8. Presentation-only — slides + guide
  async presentationOnly(input: GenerateCourseInput): Promise<WorkflowResult> {
    return this.runWorkflow('presentation-only', {
      moduleCount: 3,
      researchDepth: 'quick',
      contentTypes: ['presentation', 'guide'] as ContentType[],
      mode: 'fast',
      budget: 0.4,
      certification: { finalExam: false, rubrics: false, certificate: false, badges: false, finalProject: false },
      ...input,
    })
  }

  // 9. Resume course — resume an in-progress course
  async resumeCourse(courseId: string): Promise<WorkflowResult> {
    const start = Date.now()
    const course = await this.factory.resumeCourse(courseId)
    const durationMs = Date.now() - start
    if (!course) {
      return { workflow: 'resume', course: this.emptyResult(courseId), durationMs, success: false }
    }
    return { workflow: 'resume', course, durationMs, success: course.status === 'completed' }
  }

  private async runWorkflow(name: string, input: GenerateCourseInput): Promise<WorkflowResult> {
    const start = Date.now()
    logger.info({ workflow: name, topic: input.topic }, 'CourseWorkflows: starting')
    try {
      const course = await this.factory.generateCourse(input)
      const durationMs = Date.now() - start
      logger.info({ workflow: name, courseId: course.id, status: course.status, durationMs }, 'CourseWorkflows: completed')
      return { workflow: name, course, durationMs, success: course.status === 'completed' }
    } catch (err) {
      const durationMs = Date.now() - start
      const message = err instanceof Error ? err.message : String(err)
      logger.error({ workflow: name, error: message }, 'CourseWorkflows: failed')
      return {
        workflow: name,
        course: this.emptyResult('failed', input.topic ?? 'unknown', message),
        durationMs,
        success: false,
      }
    }
  }

  private emptyResult(id: string, topic = 'unknown', error?: string): CourseResult {
    const now = new Date().toISOString()
    return {
      id,
      version: '3.0.0',
      createdAt: now,
      updatedAt: now,
      generatorVersion: '3.0.0',
      provider: 'runtime-adapter',
      model: 'workflow',
      runtimeVersion: 'AICF-V3-RC1',
      courseRequestId: id,
      topic,
      title: topic,
      description: '',
      status: 'failed',
      curriculum: null,
      modules: [],
      lessons: [],
      exercises: [],
      quizzes: [],
      assessments: [],
      caseStudies: [],
      checklists: [],
      templates: [],
      presentation: null,
      guides: [],
      qualityReport: null,
      stages: [],
      zipBuffer: null,
      zipUrl: '',
      totalWordCount: 0,
      totalDurationMs: 0,
      totalCost: 0,
      error,
    }
  }

  listWorkflows(): string[] {
    return [
      'quick-preview',
      'full-course',
      'certification-track',
      'premium-course',
      'deep-research',
      'micro-course',
      'assessment-only',
      'presentation-only',
      'resume',
    ]
  }
}

export function createCourseWorkflows(factory: AIFactory): CourseWorkflows {
  return new CourseWorkflows(factory)
}

// Re-export for convenience
export type { CourseRequest }
