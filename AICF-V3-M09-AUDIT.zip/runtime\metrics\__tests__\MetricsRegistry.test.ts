// =============================================================================
// AICF V3 — MetricsRegistry Tests (Sprint 17: Runtime Foundation Consolidation)
// =============================================================================
// Tests for the per-module call metrics registry:
//   - recordCall()           → increments callCount, updates avg/p95/p99 latency
//   - recordCall(error)      → increments errorCount + sets lastError
//   - getMetrics(unknown)    → empty metrics
//   - getMetrics(known)      → recorded metrics
//   - getAllMetrics()        → all modules
//   - reset() / resetAll()   → drop records
//   - getModuleIds()         → IDs with recorded metrics
//   - totalDurationMs        → cumulative duration
//
// Records 100+ calls with varying durations to exercise percentile calculation
// (nearest-rank method, 100 samples → p95 = sorted[94], p99 = sorted[98]).
// No `any`.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { MetricsRegistry, createEmptyModuleMetrics } from '../MetricsRegistry'

describe('MetricsRegistry (Sprint 17)', () => {
  let registry: MetricsRegistry

  beforeEach(() => {
    registry = new MetricsRegistry()
  })

  // -------------------------------------------------------------------------
  // recordCall()
  // -------------------------------------------------------------------------
  describe('recordCall()', () => {
    it('increments callCount', () => {
      registry.recordCall('workflow', 10)
      registry.recordCall('workflow', 20)
      const m = registry.getMetrics('workflow')
      expect(m.callCount).toBe(2)
    })

    it('with error increments errorCount and sets lastError', () => {
      registry.recordCall('workflow', 10, 'timeout')
      registry.recordCall('workflow', 20, 'rate-limited')
      const m = registry.getMetrics('workflow')
      expect(m.errorCount).toBe(2)
      expect(m.lastError).toBe('rate-limited')
    })

    it('sets lastUsed to a fresh ISO timestamp on each call', () => {
      registry.recordCall('workflow', 10)
      const m1 = registry.getMetrics('workflow')
      expect(m1.lastUsed).not.toBeNull()
      const before = m1.lastUsed as string
      // Small delay then a second call — lastUsed should be updated.
      registry.recordCall('workflow', 20)
      const m2 = registry.getMetrics('workflow')
      expect(m2.lastUsed).not.toBeNull()
      const after = m2.lastUsed as string
      // lastUsed is monotonic (>= before). Use >= to avoid flakiness.
      expect(after >= before).toBe(true)
    })

    it('updates avgLatencyMs', () => {
      registry.recordCall('workflow', 10)
      registry.recordCall('workflow', 30)
      const m = registry.getMetrics('workflow')
      expect(m.avgLatencyMs).toBe(20)
    })

    it('updates p95LatencyMs after enough calls', () => {
      // 100 samples with durations 1..100. Nearest-rank p95 = sorted[94] = 95.
      for (let i = 1; i <= 100; i++) {
        registry.recordCall('workflow', i)
      }
      const m = registry.getMetrics('workflow')
      expect(m.callCount).toBe(100)
      expect(m.p95LatencyMs).toBe(95)
    })

    it('updates p99LatencyMs after enough calls', () => {
      // 100 samples with durations 1..100. Nearest-rank p99 = sorted[98] = 99.
      for (let i = 1; i <= 100; i++) {
        registry.recordCall('workflow', i)
      }
      const m = registry.getMetrics('workflow')
      expect(m.p99LatencyMs).toBe(99)
    })

    it('totalDurationMs accumulates', () => {
      registry.recordCall('workflow', 10)
      registry.recordCall('workflow', 20)
      registry.recordCall('workflow', 30)
      const m = registry.getMetrics('workflow')
      expect(m.totalDurationMs).toBe(60)
    })

    it('keeps lastError null when no errors are recorded', () => {
      registry.recordCall('workflow', 10)
      registry.recordCall('workflow', 20)
      const m = registry.getMetrics('workflow')
      expect(m.errorCount).toBe(0)
      expect(m.lastError).toBeNull()
    })
  })

  // -------------------------------------------------------------------------
  // getMetrics()
  // -------------------------------------------------------------------------
  describe('getMetrics()', () => {
    it('returns empty metrics for an unknown module', () => {
      const m = registry.getMetrics('never-seen')
      const empty = createEmptyModuleMetrics()
      expect(m).toEqual(empty)
      expect(m.callCount).toBe(0)
      expect(m.errorCount).toBe(0)
      expect(m.avgLatencyMs).toBe(0)
      expect(m.p95LatencyMs).toBe(0)
      expect(m.p99LatencyMs).toBe(0)
      expect(m.lastUsed).toBeNull()
      expect(m.lastError).toBeNull()
      expect(m.totalDurationMs).toBe(0)
    })

    it('returns recorded metrics for a known module', () => {
      registry.recordCall('workflow', 10, 'timeout')
      const m = registry.getMetrics('workflow')
      expect(m.callCount).toBe(1)
      expect(m.errorCount).toBe(1)
      expect(m.lastError).toBe('timeout')
      expect(m.totalDurationMs).toBe(10)
      expect(m.avgLatencyMs).toBe(10)
    })
  })

  // -------------------------------------------------------------------------
  // getAllMetrics()
  // -------------------------------------------------------------------------
  describe('getAllMetrics()', () => {
    it('returns metrics for all modules with recorded calls', () => {
      registry.recordCall('a', 5)
      registry.recordCall('b', 15)
      const all = registry.getAllMetrics()
      expect(Object.keys(all).sort()).toEqual(['a', 'b'])
      expect(all['a'].callCount).toBe(1)
      expect(all['b'].callCount).toBe(1)
    })

    it('returns empty record when nothing has been recorded', () => {
      expect(registry.getAllMetrics()).toEqual({})
    })
  })

  // -------------------------------------------------------------------------
  // reset()
  // -------------------------------------------------------------------------
  describe('reset()', () => {
    it('resets a specific module', () => {
      registry.recordCall('a', 5)
      registry.recordCall('b', 15)
      registry.reset('a')
      // 'a' is gone, 'b' survives.
      expect(registry.getMetrics('a').callCount).toBe(0)
      expect(registry.getMetrics('b').callCount).toBe(1)
    })

    it('is a no-op for an unknown module', () => {
      // Should not throw.
      registry.reset('never-seen')
      expect(registry.getMetrics('never-seen').callCount).toBe(0)
    })
  })

  // -------------------------------------------------------------------------
  // resetAll()
  // -------------------------------------------------------------------------
  describe('resetAll()', () => {
    it('resets all modules', () => {
      registry.recordCall('a', 5)
      registry.recordCall('b', 15)
      registry.resetAll()
      expect(registry.getMetrics('a').callCount).toBe(0)
      expect(registry.getMetrics('b').callCount).toBe(0)
      expect(registry.getModuleIds()).toEqual([])
    })
  })

  // -------------------------------------------------------------------------
  // getModuleIds()
  // -------------------------------------------------------------------------
  describe('getModuleIds()', () => {
    it('returns IDs with recorded metrics', () => {
      registry.recordCall('a', 5)
      registry.recordCall('b', 15)
      registry.recordCall('c', 25)
      const ids = registry.getModuleIds().sort()
      expect(ids).toEqual(['a', 'b', 'c'])
    })

    it('returns empty array when nothing has been recorded', () => {
      expect(registry.getModuleIds()).toEqual([])
    })
  })
})
