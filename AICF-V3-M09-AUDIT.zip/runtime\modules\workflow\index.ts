// =============================================================================
// AICF V3 — Workflow Runtime Module Index (Sprint 13+14)
// =============================================================================
// Public entry point for the Workflow Runtime Module.
// Exports all engine, steps, context, events, state, recovery, trace,
// artifacts, metrics, health, cache, secrets, policies, hooks, governance,
// features, queue, and scheduler components.
// =============================================================================

// --- Events ---
export { InMemoryEventBus } from './events/EventBus'
export { createWorkflowEvent } from './events/WorkflowEvents'

// --- Context ---
export { VariableResolver } from './context/VariableResolver'
export { RuntimeContextHolder } from './context/RuntimeContext'
export { ContextManager } from './context/ContextManager'

// --- Engine ---
export { WorkflowValidator } from './engine/WorkflowValidator'
export { CompensationHandler } from './engine/CompensationHandler'
export { WorkflowOrchestrator } from './engine/WorkflowOrchestrator'
export { WorkflowEngine } from './engine/WorkflowEngine'

// --- Steps ---
export { StepRegistry } from './steps/StepRegistry'
export { StepExecutorService } from './steps/StepExecutor'
export { ChatProvider } from './steps/providers/ChatProvider'
export { GenerationProvider } from './steps/providers/GenerationProvider'
export { ValidationProvider } from './steps/providers/ValidationProvider'
export { TransformationProvider } from './steps/providers/TransformationProvider'
export { ConditionalProvider } from './steps/providers/ConditionalProvider'

// --- State ---
export { InMemoryWorkflowStateStore } from './state/WorkflowStateStore'
export { ExecutionCheckpointManager } from './state/ExecutionCheckpoint'
export { ExecutionCheckpointManager as QueueExecutionCheckpointManager } from './queue/ExecutionCheckpoint'

// --- Recovery ---
export { RuntimeRecovery, type RecoveryReport } from './recovery/RuntimeRecovery'

// --- Trace ---
export { createTrace, type ExecutionTrace } from './trace/ExecutionTrace'
export { TraceStorage } from './trace/TraceStorage'

// --- Artifacts ---
export { InMemoryArtifactStorage } from './artifacts/ArtifactStorage'
export { ArtifactRegistry } from './artifacts/ArtifactRegistry'

// --- Metrics ---
export { MetricsCollector } from './metrics/MetricsCollector'

// --- Health ---
export { RuntimeHealth, type HealthReport, type HealthCheck } from './health/RuntimeHealth'

// --- Cache ---
export { ExecutionCache } from './cache/ExecutionCache'
export { PromptCache } from './cache/PromptCache'
export { EmbeddingCache } from './cache/EmbeddingCache'

// --- Secrets ---
export { SecretsResolver } from './secrets/SecretsResolver'

// --- Policies ---
export { PolicyMiddleware, type IPolicy, type PolicyDecision } from './policies/PolicyMiddleware'

// --- Hooks ---
export {
  HookRegistry,
  type BeforeWorkflowHook,
  type AfterWorkflowHook,
  type BeforeStepHook,
  type AfterStepHook,
} from './hooks/BeforeWorkflowHook'

// --- Registry ---
export { CapabilityRegistry } from './registry/CapabilityRegistry'

// --- Governance ---
export { ExecutionPolicy } from './governance/ExecutionPolicy'
export { ApprovalPolicy } from './governance/ApprovalPolicy'
export { QuotaPolicy } from './governance/QuotaPolicy'
export { BudgetPolicy } from './governance/BudgetPolicy'
export { SecurityPolicy } from './governance/SecurityPolicy'

// --- Features ---
export { FeatureFlags } from './features/FeatureFlags'

// --- Queue ---
export { ExecutionQueue } from './queue/ExecutionQueue'
export { Scheduler, type ScheduledJob } from './queue/Scheduler'

// --- WorkflowModule (RuntimeModule implementation) ---
export { WorkflowModule, type WorkflowModuleInterface } from './WorkflowModule'

// --- Factory ---
export { createWorkflowModule, type CreateWorkflowModuleDeps, type CreatedWorkflowModule } from './factory'
