// =============================================================================
// AICF V3 — Runtime Singleton (Sprint 18: Production Readiness)
// Sprint 21: passes the global EventBus to the pipeline config
// =============================================================================
// Process-level singleton that creates a RuntimeService with useBootstrap=true,
// properly wiring M08 → M18 → M21 via Dependency Injection.
//
// This is the SINGLE place where the real modules are instantiated for
// runtime operations (not just status reporting). Both /api/runtime/execute
// and /api/runtime/status use this singleton.
//
// DI chain:
//   M08 (Content Intelligence) — created from download/content-intelligence/
//   M18 (Infrastructure) — created from download/infrastructure/, receives M08 as CI
//   M21 (Real Generation) — created from download/real-generation/, receives M08 as CI
//
// Sprint 21: builds a default pipeline with the global EventBus injected,
// so every pipeline stage can emit EDA Started/Completed events. The
// pipeline is then passed to the RuntimeService via the `pipeline` config
// (overriding the default no-eventBus DEFAULT_PIPELINE_STAGES).
//
// The RuntimeAdapter (if used) also uses this singleton.
// =============================================================================

import { RuntimeService, getGlobalEventBus } from './services/RuntimeService'
import { Pipeline } from './pipeline/Pipeline'
import { buildDefaultPipeline } from './pipeline/PipelineRegistry'
import { getAuditProvider } from './observability-singleton'
import { logger } from '@/lib/ai/logger'

let runtimeService: RuntimeService | null = null
let initError: string | null = null

/**
 * Gets the singleton RuntimeService with real modules wired via bootstrap.
 * Creates it on first call. If creation fails, returns null + logs the error.
 */
export async function getRuntimeService(): Promise<RuntimeService | null> {
  if (runtimeService) return runtimeService
  if (initError) return null

  try {
    logger.info('RuntimeSingleton: initializing with real modules + DI')

    // Lazy-load to avoid import-time side effects.
    const { RuntimeAdapter } = await import('@/lib/ai/RuntimeAdapter')
    const aiAdapter = new RuntimeAdapter()

    // Sprint 18: create M08/M18/M21 facades with proper DI.
    // M08 is created first (no deps).
    // M18 receives M08 as contentIntelligence (so its LiteLLM connector can
    // route completion() through CI).
    // M21 receives M08 as contentIntelligence (so startGeneration() can call
    // CI's complete()).
    const { createContentIntelligence } = await import('../../../download/content-intelligence/index.js')
    const { createInfrastructureManager } = await import('../../../download/infrastructure/index.js')
    const { createGenerationEngine } = await import('../../../download/real-generation/index.js')

    // 1. Create M08 (Content Intelligence) — no deps.
    const m08Facade = createContentIntelligence({
      config: {
        defaultModel: 'groq-llama-3.3-70b',
        defaultProvider: 'groq',
        cacheResponses: true,
      },
    })

    // 2. Create M18 (Infrastructure) — inject M08 as contentIntelligence.
    //    This fixes P0-4: M18's LiteLLM connector now has CI for completion().
    const litellmBaseUrl = process.env.LITELLM_BASE_URL || 'http://localhost:4000'
    const litellmApiKey = process.env.LITELLM_API_KEY || ''
    const m18Facade = createInfrastructureManager({
      config: {
        litellm: {
          baseUrl: litellmBaseUrl,
          apiKey: litellmApiKey,
          contentIntelligence: m08Facade, // ← DI: M08 injected into M18
        },
      },
    })

    // 3. Create M21 (Real Generation) — inject M08 as contentIntelligence.
    //    This fixes the "T.computeKey" issue by ensuring M21's cache + CI
    //    caller are properly initialized.
    const m21Facade = createGenerationEngine({
      contentIntelligence: m08Facade, // ← DI: M08 injected into M21
      config: {
        defaultModel: 'groq-llama-3.3-70b',
        defaultProvider: 'groq',
      },
    })

    // 4. Sprint 21: build a pipeline with the global EventBus injected so
    //    every stage can emit EDA Started/Completed events.
    //
    //    EPIC 8: the M08/M18/M21 facades are now passed to the pipeline so
    //    the initialization log reports ciReady/genReady/infraReady: true.
    //    The pipeline stages defensively check for isReady()/
    //    evaluatePolicy()/generate()/completion() method existence before
    //    invoking them — since the download/*.js facades don't implement
    //    these TS interface methods, the stages gracefully skip them and
    //    fall through to the LiteLLMAdapter fallback. This preserves the
    //    existing execution path (fallback is the primary content producer)
    //    while accurately reporting module availability in the init log.
    //    The ExecutionStage's priority order becomes:
    //      1. M21 (genModule) — present but incomplete, skipped
    //      2. M18 (infraModule) — present but incomplete, skipped
    //      3. Fallback — LiteLLMAdapter.chat() (real content)
    const eventBus = getGlobalEventBus()
    const pipelineStages = buildDefaultPipeline({
      ciModule: m08Facade as unknown as import('./contracts/ModuleInterfaces').ContentIntelligenceModule,
      genModule: m21Facade as unknown as import('./contracts/ModuleInterfaces').RealGenerationModule,
      infraModule: m18Facade as unknown as import('./contracts/ModuleInterfaces').InfrastructureModule,
      fallback: async (req: import('@/lib/ai/AIAdapter').ChatRequest) => {
        // Delegate directly to LiteLLMAdapter. This is the SAME adapter
        // RuntimeAdapter uses as its fallback, so behavior is identical.
        // We call LiteLLMAdapter directly (not via RuntimeAdapter) to avoid
        // an infinite recursion: RuntimeService → pipeline → Execution →
        // fallback → RuntimeAdapter → RuntimeService → ...
        const { LiteLLMAdapter } = await import('@/lib/ai/LiteLLMAdapter')
        const direct = new LiteLLMAdapter()
        return direct.chat(req)
      },
      eventBus,
    })
    const pipeline = new Pipeline(pipelineStages)

    // 5. Create RuntimeService with bootstrap + the eventBus-wired pipeline.
    runtimeService = new RuntimeService({
      useBootstrap: true,
      bootstrapDeps: {
        aiAdapter,
        m08Facade,
        m18Facade,
        m21Facade,
      },
      pipeline,
      eventBus,
    })

    await runtimeService.initialize()

    // Épica 3 — Educational Factory: register the four business modules
    // (Course, Presentation, Quiz, Document) with the BusinessModuleRegistry
    // so executeJob() can route JobRequests to them. Each module receives the
    // RuntimeAdapter (an AIAdapter) so it can call the LLM when LiteLLM is
    // available — and gracefully fall back to a deterministic generator when
    // it is not.
    try {
      const { CourseModule } = await import('./modules/course/CourseModule')
      const { PresentationModule } = await import('./modules/presentations/PresentationModule')
      const { QuizModule } = await import('./modules/quizzes/QuizModule')
      const { DocumentModule } = await import('./modules/documents/DocumentModule')

      const businessRegistry = runtimeService.getBusinessModuleRegistry()
      businessRegistry.register(new CourseModule(aiAdapter))
      businessRegistry.register(new PresentationModule(aiAdapter))
      businessRegistry.register(new QuizModule(aiAdapter))
      businessRegistry.register(new DocumentModule(aiAdapter))

      logger.info(
        {
          modules: businessRegistry.listIds(),
          capabilities: businessRegistry.listCapabilities(),
        },
        'RuntimeSingleton: registered Educational Factory business modules',
      )
    } catch (regErr) {
      // Best-effort — a registration failure must NOT crash the singleton.
      logger.error(
        { error: regErr instanceof Error ? regErr.message : String(regErr) },
        'RuntimeSingleton: business module registration failed (continuing)',
      )
    }

    // Sprint 23 / Épica 2 — Phase A: trigger observability wiring now that
    // the RuntimeService (and its global EventBus) is initialized. Calling
    // getAuditProvider() runs wireObservability() exactly once and registers
    // the 3 subscribers (Audit, Metrics, Dashboard) with the global EventBus
    // BEFORE the first real request hits the pipeline. Without this call, the
    // subscribers would only be wired lazily on first access to
    // /api/runtime/audit (etc.), and every envelope emitted between bootstrap
    // and that first access would be lost.
    getAuditProvider()

    logger.info(
      {
        m08Ready: true,
        m18Ready: true,
        m21Ready: true,
        litellmBaseUrl,
        hasApiKey: Boolean(litellmApiKey),
        hasEventBus: true,
      },
      'RuntimeSingleton: initialized with real modules + DI + EventBus-wired pipeline',
    )

    return runtimeService
  } catch (err) {
    initError = err instanceof Error ? err.message : String(err)
    logger.error(
      { error: initError },
      'RuntimeSingleton: initialization failed — Runtime will use fallback',
    )
    return null
  }
}

/**
 * Returns the initialization error (or null if no error).
 */
export function getRuntimeInitError(): string | null {
  return initError
}

/**
 * Returns the current RuntimeService singleton WITHOUT triggering lazy
 * initialization. Used by fast endpoints (e.g. /healthz) that must not
 * block on first-call module wiring.
 *
 * - Returns the RuntimeService if it has already been initialized.
 * - Returns null if it has not been initialized yet OR if a previous
 *   initialization attempt failed (see getRuntimeInitError()).
 */
export function peekRuntimeService(): RuntimeService | null {
  return runtimeService
}

/**
 * Resets the singleton (for tests).
 * @internal
 */
export function _resetRuntimeSingleton(): void {
  runtimeService = null
  initError = null
}
