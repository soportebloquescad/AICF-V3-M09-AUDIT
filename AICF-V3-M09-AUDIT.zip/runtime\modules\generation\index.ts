// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Barrel + Factory
// =============================================================================
// Public surface for the generation runtime module. Re-exports the four
// templates, the four generators, the pipeline, the orchestrator, and the
// module class, plus a `createGenerationModule(deps)` factory that wires
// them together with sensible defaults.
//
// Sprint 13+14 spec requirements covered:
//   - Single import surface for external consumers:
//       import {
//         GenerationModule,
//         createGenerationModule,
//       } from '@/lib/runtime/modules/generation'
//   - `createGenerationModule(deps)` accepts a required `aiAdapter` and an
//     optional `eventBus`, then constructs all four generators, registers
//     them with an orchestrator, and wraps it in a `GenerationModule`.
//   - Returns `{ module, orchestrator, generators: {...} }` so callers can
//     reach into individual generators or the orchestrator if needed.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { IEventBus, IGenerator } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

// --- Templates ---------------------------------------------------------------
export { CourseTemplate } from './templates/CourseTemplate'
export { PresentationTemplate } from './templates/PresentationTemplate'
export { QuizTemplate } from './templates/QuizTemplate'
export { DocumentTemplate } from './templates/DocumentTemplate'

// --- Generators --------------------------------------------------------------
export { CourseGenerator } from './generators/CourseGenerator'
export { PresentationGenerator } from './generators/PresentationGenerator'
export { QuizGenerator } from './generators/QuizGenerator'
export { DocumentGenerator } from './generators/DocumentGenerator'

// --- Engine ------------------------------------------------------------------
export { GenerationPipeline } from './engine/GenerationPipeline'
export { GenerationOrchestrator } from './engine/GenerationOrchestrator'

// --- Module ------------------------------------------------------------------
export { GenerationModule } from './GenerationModule'

// =============================================================================
// Factory
// =============================================================================

import { CourseGenerator } from './generators/CourseGenerator'
import { PresentationGenerator } from './generators/PresentationGenerator'
import { QuizGenerator } from './generators/QuizGenerator'
import { DocumentGenerator } from './generators/DocumentGenerator'
import { GenerationOrchestrator } from './engine/GenerationOrchestrator'
import { GenerationModule } from './GenerationModule'

/** Optional dependencies accepted by `createGenerationModule`. */
export interface CreateGenerationModuleDeps {
  /** AI adapter used by every generator. Required. */
  aiAdapter: AIAdapter
  /** Optional event bus shared by every per-generator pipeline. */
  eventBus?: IEventBus
}

/** Bundle of named generators returned by `createGenerationModule`. */
export interface GenerationModuleGenerators {
  course: CourseGenerator
  presentation: PresentationGenerator
  quiz: QuizGenerator
  document: DocumentGenerator
}

/** Wired bundle returned by `createGenerationModule`. */
export interface GenerationModuleBundle {
  module: GenerationModule
  orchestrator: GenerationOrchestrator
  generators: GenerationModuleGenerators
}

/**
 * Build a fully-wired generation module bundle.
 *
 * @example
 *   const { module } = createGenerationModule({ aiAdapter })
 *   await module.initialize()
 *   const result = await module.generate(
 *     { topic: 'Rust ownership', contentType: 'course' },
 *     ctx,
 *   )
 */
export function createGenerationModule(
  deps: CreateGenerationModuleDeps,
): GenerationModuleBundle {
  if (!deps.aiAdapter) {
    throw new Error('createGenerationModule: aiAdapter is required')
  }

  // --- generators ------------------------------------------------------
  const course = new CourseGenerator(deps.aiAdapter)
  const presentation = new PresentationGenerator(deps.aiAdapter)
  const quiz = new QuizGenerator(deps.aiAdapter)
  const document = new DocumentGenerator(deps.aiAdapter)

  // --- registry + orchestrator ----------------------------------------
  const generatorMap = new Map<string, IGenerator>()
  generatorMap.set(course.generatorType, course)
  generatorMap.set(presentation.generatorType, presentation)
  generatorMap.set(quiz.generatorType, quiz)
  generatorMap.set(document.generatorType, document)
  const orchestrator = new GenerationOrchestrator(
    generatorMap,
    deps.eventBus,
  )

  // --- module ----------------------------------------------------------
  const generationModule = new GenerationModule(orchestrator)

  logger.debug(
    {
      generators: orchestrator.listGenerators(),
      hasEventBus: deps.eventBus !== undefined,
    },
    'generation module created',
  )

  return {
    module: generationModule,
    orchestrator,
    generators: { course, presentation, quiz, document },
  }
}
