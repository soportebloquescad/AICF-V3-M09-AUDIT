// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — ArtifactRegistry
// =============================================================================
// The ArtifactRegistry holds every artifact produced by a pipeline run:
// markdown lessons, JSON course manifests, PDFs, PPTXs, ZIP exports, etc.
//
// Each artifact carries:
//   - id           (unique)
//   - courseId     (the course it belongs to)
//   - type         (markdown / pdf / pptx / docx / html / json / quiz / slides / asset / zip)
//   - name         (filename within the ZIP)
//   - mimeType
//   - content      (string | Buffer)
//   - sizeBytes
//   - producedBy   (stage name that produced it)
//   - registeredAt (ISO timestamp)
//
// The registry is exposed as a globalThis singleton so artifacts survive
// Next.js hot-reloads during development.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * Artifact type. Covers every artifact kind the pipeline can produce.
 */
export type ArtifactType =
  | 'markdown'
  | 'pdf'
  | 'pptx'
  | 'docx'
  | 'html'
  | 'json'
  | 'quiz'
  | 'slides'
  | 'asset'
  | 'zip'

/**
 * A registered artifact.
 */
export interface RegisteredArtifact {
  /** Unique artifact id. */
  id: string
  /** Course id this artifact belongs to. */
  courseId: string
  /** Artifact type. */
  type: ArtifactType
  /** Filename (used inside the ZIP). */
  name: string
  /** MIME type. */
  mimeType: string
  /** Artifact content (string for text, Buffer for binary). */
  content: string | Buffer
  /** Content size in bytes. */
  sizeBytes: number
  /** Stage that produced this artifact. */
  producedBy: string
  /** ISO timestamp when the artifact was registered. */
  registeredAt: string
}

/**
 * MIME type mapping per artifact type.
 */
const MIME_TYPES: Record<ArtifactType, string> = {
  markdown: 'text/markdown; charset=utf-8',
  pdf: 'application/pdf',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  html: 'text/html; charset=utf-8',
  json: 'application/json; charset=utf-8',
  quiz: 'application/json; charset=utf-8',
  slides: 'application/json; charset=utf-8',
  asset: 'application/octet-stream',
  zip: 'application/zip',
}

/**
 * The ArtifactRegistry. Holds artifacts in memory keyed by id, with
 * indexes by courseId and by type for fast lookup.
 */
export class ArtifactRegistry {
  private readonly artifacts = new Map<string, RegisteredArtifact>()
  private readonly byCourse = new Map<string, Set<string>>()
  private readonly byType = new Map<ArtifactType, Set<string>>()

  /**
   * Register a new artifact. Returns the registered artifact (with
   * generated id, mimeType, sizeBytes, and registeredAt filled in).
   */
  register(input: {
    courseId: string
    type: ArtifactType
    name: string
    content: string | Buffer
    producedBy: string
    mimeType?: string
  }): RegisteredArtifact {
    const id = this.makeId('art')
    const content = input.content
    const sizeBytes = typeof content === 'string'
      ? Buffer.byteLength(content, 'utf-8')
      : content.byteLength
    const artifact: RegisteredArtifact = {
      id,
      courseId: input.courseId,
      type: input.type,
      name: input.name,
      mimeType: input.mimeType ?? MIME_TYPES[input.type],
      content,
      sizeBytes,
      producedBy: input.producedBy,
      registeredAt: new Date().toISOString(),
    }
    this.artifacts.set(id, artifact)
    this.index(this.byCourse, input.courseId, id)
    this.index(this.byType, input.type, id)
    logger.info(
      {
        artifactId: id,
        courseId: input.courseId,
        type: input.type,
        name: input.name,
        sizeBytes,
        producedBy: input.producedBy,
      },
      'ArtifactRegistry: artifact registered',
    )
    return artifact
  }

  /**
   * Get an artifact by id. Returns null if not found.
   */
  get(id: string): RegisteredArtifact | null {
    return this.artifacts.get(id) ?? null
  }

  /**
   * List all registered artifacts.
   */
  list(): RegisteredArtifact[] {
    return Array.from(this.artifacts.values())
  }

  /**
   * Find all artifacts for a given course.
   */
  findByCourse(courseId: string): RegisteredArtifact[] {
    const ids = this.byCourse.get(courseId)
    if (!ids) return []
    return Array.from(ids)
      .map((id) => this.artifacts.get(id)!)
      .filter(Boolean)
  }

  /**
   * Find all artifacts of a given type.
   */
  findByType(type: ArtifactType): RegisteredArtifact[] {
    const ids = this.byType.get(type)
    if (!ids) return []
    return Array.from(ids)
      .map((id) => this.artifacts.get(id)!)
      .filter(Boolean)
  }

  /**
   * Find all artifacts for a given course AND type.
   */
  findByCourseAndType(courseId: string, type: ArtifactType): RegisteredArtifact[] {
    return this.findByCourse(courseId).filter((a) => a.type === type)
  }

  /**
   * Delete an artifact by id. Returns true if deleted, false if not found.
   */
  delete(id: string): boolean {
    const artifact = this.artifacts.get(id)
    if (!artifact) return false
    this.artifacts.delete(id)
    this.unindex(this.byCourse, artifact.courseId, id)
    this.unindex(this.byType, artifact.type, id)
    return true
  }

  /**
   * Delete all artifacts for a course. Returns the number deleted.
   */
  deleteByCourse(courseId: string): number {
    const ids = this.byCourse.get(courseId)
    if (!ids) return 0
    const count = ids.size
    for (const id of Array.from(ids)) {
      this.delete(id)
    }
    return count
  }

  /**
   * Return the total number of registered artifacts.
   */
  size(): number {
    return this.artifacts.size
  }

  /**
   * Return the total size in bytes of all artifacts for a course.
   */
  getCourseSize(courseId: string): number {
    return this.findByCourse(courseId).reduce((sum, a) => sum + a.sizeBytes, 0)
  }

  /**
   * Clear all artifacts.
   */
  clear(): void {
    this.artifacts.clear()
    this.byCourse.clear()
    this.byType.clear()
    logger.debug('ArtifactRegistry: cleared')
  }

  private index<K>(map: Map<K, Set<string>>, key: K, id: string): void {
    let set = map.get(key)
    if (!set) {
      set = new Set()
      map.set(key, set)
    }
    set.add(id)
  }

  private unindex<K>(map: Map<K, Set<string>>, key: K, id: string): void {
    const set = map.get(key)
    if (!set) return
    set.delete(id)
    if (set.size === 0) map.delete(key)
  }

  private makeId(prefix: string): string {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 8)
    return `${prefix}-${ts}-${rand}`
  }
}

/**
 * globalThis-backed singleton key. Using globalThis ensures the registry
 * survives Next.js hot-reloads during development.
 */
const GLOBAL_KEY = '__AICF_ARTIFACT_REGISTRY__'

type GlobalWithArtifactRegistry = typeof globalThis & {
  [K in typeof GLOBAL_KEY]?: ArtifactRegistry
}

/**
 * Get the global ArtifactRegistry singleton. Creates it on first call.
 */
export function getGlobalArtifactRegistry(): ArtifactRegistry {
  const g = globalThis as GlobalWithArtifactRegistry
  if (!g[GLOBAL_KEY]) {
    g[GLOBAL_KEY] = new ArtifactRegistry()
  }
  return g[GLOBAL_KEY]!
}

/**
 * Reset the global singleton (for tests).
 */
export function resetGlobalArtifactRegistry(): void {
  const g = globalThis as GlobalWithArtifactRegistry
  delete g[GLOBAL_KEY]
}
