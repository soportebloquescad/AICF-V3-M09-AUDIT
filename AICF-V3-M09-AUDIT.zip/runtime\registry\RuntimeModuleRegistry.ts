// =============================================================================
// AICF V3 — Sprint 6 (RC33) — RuntimeModuleRegistry
// =============================================================================
// Unified module registry with dependency injection, lifecycle management,
// and dependency resolution.
//
// Distinct from ModuleRegistry (which registers by CATEGORY):
//   - ModuleRegistry: register(category, module) — used by RuntimeBootstrap
//   - RuntimeModuleRegistry: register(descriptor) — used by ModuleLoader
//
// RuntimeModuleRegistry adds:
//   - ID-based registration (not category-based)
//   - Dependency resolution (topological sort via ModuleResolver)
//   - DI: factory functions receive the registry to resolve deps
//   - Health aggregation
//   - Lifecycle: initializeAll() in dependency order, shutdownAll() reverse
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { logger } from '@/lib/ai/logger'
import type { ModuleDescriptor } from './ModuleDescriptor'
import { ModuleResolver } from './ModuleResolver'
import type { ResolutionResult } from './ModuleResolver'

/**
 * A registered module entry.
 */
export interface RuntimeModuleEntry {
  readonly descriptor: ModuleDescriptor
  /** The created instance (null until created). */
  instance: unknown
  /** Whether the module has been initialized. */
  initialized: boolean
}

/**
 * A health report for a single module.
 */
export interface RuntimeModuleHealth {
  readonly id: string
  readonly name: string
  readonly healthy: boolean
  readonly initialized: boolean
}

/**
 * The unified module registry with DI and dependency resolution.
 *
 * Usage:
 *   const registry = new RuntimeModuleRegistry()
 *   registry.register(descriptor)
 *   await registry.initializeAll()  // resolves deps, creates instances, inits
 *   const instance = registry.resolve<MyModule>('my-module-id')
 */
export class RuntimeModuleRegistry {
  private readonly entries = new Map<string, RuntimeModuleEntry>()
  private readonly resolver = new ModuleResolver()
  private readonly log = logger.child({ component: 'RuntimeModuleRegistry' })

  /**
   * Registers a module descriptor.
   * The instance is NOT created until initializeAll() is called.
   */
  register(descriptor: ModuleDescriptor): void {
    if (this.entries.has(descriptor.id)) {
      this.log.warn({ moduleId: descriptor.id }, 'Module already registered — replacing')
    }
    this.entries.set(descriptor.id, {
      descriptor,
      instance: null,
      initialized: false,
    })
    this.log.info(
      { moduleId: descriptor.id, name: descriptor.name, priority: descriptor.priority },
      'Module registered',
    )
  }

  /**
   * Unregisters a module by ID.
   */
  unregister(id: string): boolean {
    const removed = this.entries.delete(id)
    if (removed) {
      this.log.info({ moduleId: id }, 'Module unregistered')
    }
    return removed
  }

  /**
   * Resolves a module instance by ID (returns null if not created yet).
   *
   * This is the DI method — modules use it to resolve their dependencies.
   */
  resolve<T>(id: string): T | null {
    const entry = this.entries.get(id)
    return (entry?.instance as T) ?? null
  }

  /**
   * Returns whether a module is registered.
   */
  has(id: string): boolean {
    return this.entries.has(id)
  }

  /**
   * Returns the descriptor for a module.
   */
  getDescriptor(id: string): ModuleDescriptor | null {
    return this.entries.get(id)?.descriptor ?? null
  }

  /**
   * Lists all registered module IDs.
   */
  list(): string[] {
    return Array.from(this.entries.keys())
  }

  /**
   * Lists all registered module entries.
   */
  listEntries(): RuntimeModuleEntry[] {
    return Array.from(this.entries.values())
  }

  /**
   * Returns the number of registered modules.
   */
  size(): number {
    return this.entries.size
  }

  /**
   * Initializes all registered modules in dependency order.
   *
   * 1. Resolves dependencies via ModuleResolver (topological sort)
   * 2. Creates instances via factory functions (passing this registry for DI)
   * 3. Calls initialize() on modules that have it
   *
   * Fault-tolerant: one module failure doesn't stop the rest.
   */
  async initializeAll(): Promise<ResolutionResult> {
    const descriptors = Array.from(this.entries.values()).map((e) => e.descriptor)
    const result = this.resolver.resolve(descriptors)

    if (!result.ok) {
      this.log.error({ cycles: result.cycles }, 'Dependency resolution failed — cycles detected')
      return result
    }

    this.log.info({ order: result.order, count: result.order.length }, 'Initializing modules in order')

    for (const id of result.order) {
      const entry = this.entries.get(id)
      if (!entry || entry.initialized) continue

      try {
        // Create instance via factory (DI: pass this registry)
        if (entry.instance === null) {
          entry.instance = entry.descriptor.factory(this)
        }

        // Call initialize() if the instance has it
        const instance = entry.instance as { initialize?: () => Promise<void> }
        if (typeof instance?.initialize === 'function') {
          await instance.initialize()
        }

        entry.initialized = true
        this.log.info({ moduleId: id }, 'Module initialized')
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        this.log.error({ moduleId: id, error: msg }, 'Module init failed (continuing)')
      }
    }

    return result
  }

  /**
   * Shuts down all modules in reverse dependency order.
   * Fault-tolerant: one module failure doesn't stop the rest.
   */
  async shutdownAll(): Promise<void> {
    const descriptors = Array.from(this.entries.values()).map((e) => e.descriptor)
    const result = this.resolver.resolve(descriptors)
    const order = result.ok ? [...result.order].reverse() : Array.from(this.entries.keys())

    for (const id of order) {
      const entry = this.entries.get(id)
      if (!entry || !entry.initialized) continue

      try {
        const instance = entry.instance as { shutdown?: () => Promise<void> }
        if (typeof instance?.shutdown === 'function') {
          await instance.shutdown()
        }
        entry.initialized = false
        this.log.info({ moduleId: id }, 'Module shut down')
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        this.log.error({ moduleId: id, error: msg }, 'Module shutdown failed (continuing)')
      }
    }
  }

  /**
   * Returns the health of all registered modules.
   */
  async health(): Promise<RuntimeModuleHealth[]> {
    const results: RuntimeModuleHealth[] = []
    for (const [id, entry] of this.entries) {
      try {
        const instance = entry.instance as { health?: () => Promise<{ healthy: boolean }> }
        let healthy = false
        if (typeof instance?.health === 'function') {
          const h = await instance.health()
          healthy = h.healthy
        } else {
          healthy = entry.initialized
        }
        results.push({
          id,
          name: entry.descriptor.name,
          healthy,
          initialized: entry.initialized,
        })
      } catch {
        results.push({
          id,
          name: entry.descriptor.name,
          healthy: false,
          initialized: entry.initialized,
        })
      }
    }
    return results
  }

  /**
   * Returns whether the registry has been initialized.
   */
  isInitialized(): boolean {
    for (const entry of this.entries.values()) {
      if (!entry.initialized) return false
    }
    return this.entries.size > 0
  }
}

// --- Global singleton (survives Turbopack module re-evaluation) ---
const GLOBAL_REGISTRY_KEY = '__AICF_RUNTIME_MODULE_REGISTRY__'

/**
 * Returns the global RuntimeModuleRegistry singleton.
 */
export function getGlobalRuntimeModuleRegistry(): RuntimeModuleRegistry {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_REGISTRY_KEY]) {
    g[GLOBAL_REGISTRY_KEY] = new RuntimeModuleRegistry()
  }
  return g[GLOBAL_REGISTRY_KEY] as RuntimeModuleRegistry
}
