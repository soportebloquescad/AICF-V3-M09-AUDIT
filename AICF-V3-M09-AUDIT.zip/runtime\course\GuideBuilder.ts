// =============================================================================
// AICF V3 — Epica 8 — Guide Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Lesson, Curriculum, Guide, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export interface GuideBuilderInput {
  type: Guide['type']
  title: string
  lessons: Lesson[]
  curriculum: Curriculum
}

export class GuideBuilder implements EngineContract {
  readonly name = 'guide-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('GuideBuilder: invalid input — expected { type, title, lessons, curriculum }')
    }
    const typed = input as GuideBuilderInput
    if (this.opts.aiAdapter) {
      try {
        return await this.buildWithAI(typed)
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'GuideBuilder: AI failed, using fallback')
      }
    }
    return this.buildDeterministic(typed)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    if (typeof obj.type !== 'string') return false
    if (typeof obj.title !== 'string') return false
    if (!Array.isArray(obj.lessons)) return false
    if (typeof obj.curriculum !== 'object' || obj.curriculum === null) return false
    return true
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(input: GuideBuilderInput): Promise<Guide> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: `You are a ${input.type} guide writer. Create a structured guide with sections. Respond as JSON: { "title": string, "description": string, "sections": [{id, title, content}], "totalWords": number }`,
        },
        {
          role: 'user',
          content: `Guide type: ${input.type}\nCourse: ${input.title}\nCurriculum: ${input.curriculum.title}\nLessons: ${input.lessons.length}\n\nCreate a comprehensive ${input.type} guide covering course delivery, assessment, and support.`,
        },
      ],
      temperature: 0.5,
      maxTokens: 6144,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; description?: string; sections?: Array<{ id: string; title: string; content: string }>; totalWords?: number }
    return this.assembleGuide(
      input,
      {
        title: parsed.title ?? this.guideTitle(input),
        description: parsed.description ?? this.guideDescription(input),
        sections: parsed.sections ?? [],
        totalWords: typeof parsed.totalWords === 'number' ? parsed.totalWords : 0,
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(input: GuideBuilderInput): Promise<Guide> {
    const sections = this.buildSections(input)
    const totalWords = sections.reduce((sum, s) => sum + s.content.split(/\s+/).filter(Boolean).length, 0)
    const parsed = {
      title: this.guideTitle(input),
      description: this.guideDescription(input),
      sections,
      totalWords,
    }
    return Promise.resolve(this.assembleGuide(input, parsed, 'runtime-adapter', 'deterministic-fallback'))
  }

  private guideTitle(input: GuideBuilderInput): string {
    const map: Record<Guide['type'], string> = {
      teacher: `Teacher's Guide: ${input.title}`,
      student: `Student's Guide: ${input.title}`,
      facilitator: `Facilitator's Guide: ${input.title}`,
      administrator: `Administrator's Guide: ${input.title}`,
    }
    return map[input.type]
  }

  private guideDescription(input: GuideBuilderInput): string {
    const map: Record<Guide['type'], string> = {
      teacher: `A comprehensive guide for teachers delivering the course "${input.title}". Covers lesson preparation, delivery strategies, assessment administration, and student support. Includes guidance for ${input.lessons.length} lessons across the curriculum.`,
      student: `A comprehensive guide for students enrolled in "${input.title}". Covers study strategies, lesson navigation, assessment preparation, and resource utilization. Designed to support success across ${input.lessons.length} lessons.`,
      facilitator: `A comprehensive guide for facilitators leading the course "${input.title}". Covers session management, group dynamics, discussion facilitation, and progress monitoring across ${input.lessons.length} lessons.`,
      administrator: `A comprehensive guide for administrators overseeing the course "${input.title}". Covers enrollment management, progress tracking, reporting, and system configuration for ${input.lessons.length} lessons.`,
    }
    return map[input.type]
  }

  private buildSections(input: GuideBuilderInput): Array<{ id: string; title: string; content: string }> {
    switch (input.type) {
      case 'teacher':
        return this.buildTeacherSections(input)
      case 'student':
        return this.buildStudentSections(input)
      case 'facilitator':
        return this.buildFacilitatorSections(input)
      case 'administrator':
        return this.buildAdministratorSections(input)
    }
  }

  private buildTeacherSections(input: GuideBuilderInput): Array<{ id: string; title: string; content: string }> {
    return [
      {
        id: makeId('sec'),
        title: 'Course Overview & Preparation',
        content: `Welcome to the Teacher's Guide for "${input.title}". This course, based on the curriculum "${input.curriculum.title}", comprises ${input.lessons.length} lessons designed for ${input.curriculum.audience} at the ${input.curriculum.level} level. Before beginning, review the curriculum's learning outcomes: ${input.curriculum.learningOutcomes.join('; ')}. Prepare by familiarizing yourself with each lesson's objectives and key concepts. Allocate approximately ${input.curriculum.totalDurationHours} hours total for course delivery. Ensure you have access to all required materials and that your learning environment supports the activities described in each lesson.`,
      },
      {
        id: makeId('sec'),
        title: 'Lesson Delivery Strategies',
        content: `Each of the ${input.lessons.length} lessons follows a consistent structure: learning objectives, introduction, key concepts with subsections, practical application, common pitfalls, summary, and key takeaways. Begin each lesson by reviewing the objectives with students. Use the introduction to activate prior knowledge and build relevance. When presenting key concepts, use concrete examples and encourage student questions. The practical application section is critical — guide students through the three-step framework (identify, analyze, synthesize) and provide scaffolding as needed. Address common pitfalls proactively by discussing them before students encounter them. Close each lesson by revisiting the key takeaways and connecting them to upcoming material. Adapt your pacing based on student engagement and understanding; the suggested durations are guidelines, not rigid requirements.`,
      },
      {
        id: makeId('sec'),
        title: 'Assessment & Feedback',
        content: `Assessment in this course serves both formative and summative purposes. Formative assessments (quizzes and exercises) are embedded in each module and provide ongoing feedback on student understanding. Use quiz results to identify concepts that require additional instruction. The summative final exam assesses integration across modules. When providing feedback on exercises, refer to the rubric criteria: accuracy of concept recall, depth of understanding, clarity and organization, use of specific examples, and connection to broader themes. Provide specific, actionable feedback rather than general comments. Encourage students to revise their work based on feedback. Track student progress across lessons to identify patterns and intervene early when students struggle.`,
      },
      {
        id: makeId('sec'),
        title: 'Student Support & Differentiation',
        content: `Students will arrive with varying levels of prior knowledge and different learning preferences. Differentiate instruction by providing additional examples for students who need them, extension activities for advanced students, and alternative explanations for concepts that prove challenging. Be attentive to students who fall behind — the cumulative nature of the course means that gaps in early modules will compound. Offer office hours or supplementary sessions for students who need additional support. Encourage peer collaboration through structured study groups. Maintain open communication channels and respond promptly to student questions. Recognize that motivation fluctuates; celebrate progress and connect course material to students' personal and professional goals.`,
      },
      {
        id: makeId('sec'),
        title: 'Resources & Troubleshooting',
        content: `This course draws on the knowledge pack assembled during research. Key facts include: ${input.curriculum.topic} is a topic that encompasses foundational concepts, practical applications, and advanced techniques. Common student challenges include oversimplification of complex ideas, premature application of advanced concepts, and ignoring trade-offs. When students struggle, return to foundational concepts and rebuild understanding incrementally. Maintain a FAQ document based on student questions. Collaborate with other teachers delivering the same course to share strategies and resources. Document what works and what does not for future iterations of the course.`,
      },
    ]
  }

  private buildStudentSections(input: GuideBuilderInput): Array<{ id: string; title: string; content: string }> {
    return [
      {
        id: makeId('sec'),
        title: 'Welcome & Course Introduction',
        content: `Welcome to "${input.title}". This course will guide you through ${input.curriculum.topic} across ${input.lessons.length} lessons designed for ${input.curriculum.audience} at the ${input.curriculum.level} level. By the end of this course, you will be able to: ${input.curriculum.learningOutcomes.join('; ')}. Before starting, ensure you have the prerequisites: ${input.curriculum.prerequisites.join('; ')}. Plan to allocate approximately ${input.curriculum.totalDurationHours} hours total. Approach the course with curiosity and a willingness to engage actively with the material.`,
      },
      {
        id: makeId('sec'),
        title: 'Study Strategies for Success',
        content: `Success in this course depends on consistent, active engagement. For each of the ${input.lessons.length} lessons, follow this approach: (1) Review the learning objectives to understand what you should achieve; (2) Read the introduction to orient yourself; (3) Work through the key concepts slowly, taking notes in your own words; (4) Complete the practical application section actively, not passively; (5) Review the common pitfalls to avoid mistakes; (6) Summarize the key takeaways and connect them to previous lessons. Use the lesson-notes template provided to structure your study. Schedule regular study sessions rather than cramming. Aim for understanding, not just completion. When you encounter difficulty, revisit earlier concepts and seek help promptly.`,
      },
      {
        id: makeId('sec'),
        title: 'Navigating Lessons & Exercises',
        content: `Each lesson is structured consistently. The learning objectives tell you what you should be able to do after completing the lesson. The introduction provides context and relevance. Key concepts are presented in subsections — read these carefully and take notes. The practical application section asks you to apply concepts to a scenario; engage with this section actively to deepen your understanding. Exercises and quizzes provide opportunities to check your understanding. Complete exercises thoughtfully, using the rubric criteria as a guide to what constitutes a strong response. Use hints when you are stuck, but attempt the exercise first. Review quiz explanations for both correct and incorrect answers to deepen your understanding.`,
      },
      {
        id: makeId('sec'),
        title: 'Assessment Preparation',
        content: `The course includes formative assessments (quizzes and exercises) in each module, and a summative final exam covering all modules. To prepare effectively: (1) Complete all exercises and quizzes, even if optional; (2) Review your notes regularly, not just before assessments; (3) Form study groups to discuss concepts and quiz each other; (4) Practice explaining concepts in your own words — if you can explain it, you understand it; (5) Identify your weak areas and devote extra time to them; (6) Use the case studies to practice applying concepts to realistic scenarios; (7) Review the rubric criteria to understand how your work will be evaluated. The final exam requires integration across modules, so look for connections throughout the course.`,
      },
      {
        id: makeId('sec'),
        title: 'Resources & Getting Help',
        content: `If you encounter difficulties, several resources are available. Review the lesson content and your notes first. Use the checklists provided to ensure you have completed all preparation steps. Reach out to your teacher or facilitator with specific questions. Form study groups with peers. Use the lesson-notes template to organize your understanding and identify gaps. Remember that struggle is a normal part of learning — persist through difficulty and seek help when needed. The course is designed to be challenging but achievable; trust the process and engage actively with the material. Connect the course content to your own goals and context to maintain motivation.`,
      },
    ]
  }

  private buildFacilitatorSections(input: GuideBuilderInput): Array<{ id: string; title: string; content: string }> {
    return [
      {
        id: makeId('sec'),
        title: 'Facilitation Overview',
        content: `As a facilitator for "${input.title}", your role is to guide ${input.lessons.length} lessons for ${input.curriculum.audience}. Unlike a traditional teacher, your focus is on enabling learning rather than delivering content. Familiarize yourself with the curriculum outcomes: ${input.curriculum.learningOutcomes.join('; ')}. Prepare for each session by reviewing the lesson content and anticipating discussion points. Create a supportive environment where students feel comfortable sharing and asking questions. Your primary tools are active listening, thoughtful questioning, and skillful group management.`,
      },
      {
        id: makeId('sec'),
        title: 'Session Management',
        content: `Each lesson session should follow a rhythm: opening (5-10 minutes to review objectives and activate prior knowledge), content engagement (20-30 minutes working through key concepts), practical application (15-20 minutes on exercises and scenarios), and closing (5-10 minutes for summary and questions). Manage time carefully to ensure all sections are covered. Use a variety of facilitation techniques: think-pair-share, small group discussions, whole-class debriefs, and individual reflection. Be flexible — if students are engaged in a productive discussion, allow it to continue; if a section is not resonating, move on and revisit later. Document key insights and questions that arise during sessions.`,
      },
      {
        id: makeId('sec'),
        title: 'Discussion Facilitation',
        content: `Discussions are central to facilitated learning. Ask open-ended questions that prompt deeper thinking: "What surprised you about this concept?", "How does this connect to what we learned earlier?", "What would happen if...?" Listen actively and reflect student contributions back to the group. Encourage quieter students to participate by directly inviting their input. Manage dominant voices by acknowledging their contribution and redirecting to others. When disagreements arise, frame them as learning opportunities and guide students to explore different perspectives. Use the practical application scenarios as discussion starters. Capture important points on a shared visible surface (whiteboard, shared document) to reinforce learning.`,
      },
      {
        id: makeId('sec'),
        title: 'Progress Monitoring & Support',
        content: `Monitor student progress through observation, quiz results, and exercise completion. Identify students who are struggling early and offer additional support. Common signs of struggle include disengagement, incomplete exercises, and incorrect quiz responses. Intervene with one-on-one conversations, additional examples, or peer support arrangements. Celebrate progress publicly to maintain motivation. Keep records of student participation and progress for reporting purposes. Communicate regularly with the course teacher or administrator about student needs and session outcomes. Adapt your facilitation based on what is working and what is not.`,
      },
      {
        id: makeId('sec'),
        title: 'Closing & Reflection',
        content: `At the end of the course, facilitate a closing session that helps students consolidate their learning. Review the curriculum outcomes and ask students to reflect on their growth. Use the case studies for final integration activities. Gather feedback on the course and your facilitation. Encourage students to identify next steps for continued learning. As a facilitator, reflect on your own practice: what worked well, what could be improved, what would you do differently. Document lessons learned for future facilitation opportunities. Celebrate the completion of the journey with your students.`,
      },
    ]
  }

  private buildAdministratorSections(input: GuideBuilderInput): Array<{ id: string; title: string; content: string }> {
    return [
      {
        id: makeId('sec'),
        title: 'Administrative Overview',
        content: `This guide supports administrators overseeing the course "${input.title}", comprising ${input.lessons.length} lessons for ${input.curriculum.audience} at the ${input.curriculum.level} level. Your responsibilities include enrollment management, progress tracking, resource allocation, and reporting. The course is designed to run for approximately ${input.curriculum.totalDurationHours} hours. Familiarize yourself with the curriculum outcomes: ${input.curriculum.learningOutcomes.join('; ')}. Establish clear policies for enrollment, completion, and certification before the course begins.`,
      },
      {
        id: makeId('sec'),
        title: 'Enrollment & Access Management',
        content: `Manage student enrollment through your learning management system. Ensure all enrolled students meet the prerequisites: ${input.curriculum.prerequisites.join('; ')}. Provide students with access credentials and orientation materials before the course begins. Monitor enrollment capacity and maintain waitlists if necessary. Process enrollment changes (add/drop) according to established policies. Ensure teachers and facilitators have appropriate access to course materials and student data. Maintain accurate records of enrollment for reporting and compliance purposes.`,
      },
      {
        id: makeId('sec'),
        title: 'Progress Tracking & Reporting',
        content: `Monitor course progress through your LMS dashboard. Track completion rates for each of the ${input.lessons.length} lessons, quiz scores, and exercise submissions. Identify at-risk students based on incomplete work or low scores, and alert teachers or facilitators for intervention. Generate regular progress reports for stakeholders. At course completion, calculate final grades based on the assessment weights defined in the curriculum. Issue certificates or other credentials to students who meet completion criteria. Maintain records for accreditation and audit purposes.`,
      },
      {
        id: makeId('sec'),
        title: 'Resource & System Management',
        content: `Ensure all course resources are available and accessible. Verify that the LMS can deliver the ${input.lessons.length} lessons, quizzes, assessments, and supporting materials. Monitor system performance and address technical issues promptly. Provide technical support to students, teachers, and facilitators. Manage course backups and data retention according to institutional policies. Coordinate with IT for any system upgrades or integrations. Ensure compliance with accessibility standards and data protection regulations. Maintain documentation of system configuration and administrative procedures.`,
      },
      {
        id: makeId('sec'),
        title: 'Evaluation & Continuous Improvement',
        content: `After course completion, gather feedback from students, teachers, and facilitators. Analyze completion rates, assessment results, and satisfaction surveys. Identify strengths and areas for improvement. Document lessons learned and recommendations for future course iterations. Share findings with curriculum developers and instructional designers. Plan for course revisions based on evaluation data. Maintain a continuous improvement cycle to ensure the course remains current and effective. Report outcomes to institutional leadership and use data to inform strategic decisions about course offerings.`,
      },
    ]
  }

  private assembleGuide(
    input: GuideBuilderInput,
    parsed: { title: string; description: string; sections: Array<{ id: string; title: string; content: string }>; totalWords: number },
    provider: Provider,
    model: string,
  ): Guide {
    const now = new Date().toISOString()
    return {
      id: makeId('guide'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      type: input.type,
      title: parsed.title,
      description: parsed.description,
      sections: parsed.sections,
      totalWords: parsed.totalWords,
      audience: input.curriculum.audience,
    }
  }
}
