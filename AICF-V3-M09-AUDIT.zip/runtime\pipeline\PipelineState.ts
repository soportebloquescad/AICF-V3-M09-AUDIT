// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — PipelineState
// =============================================================================
// Tracks the lifecycle of a single pipeline execution: which stages have
// run, how long they took, whether they succeeded, and what the overall
// pipeline status is.
//
// A PipelineState is mutable — the CoursePipeline calls startStage(),
// completeStage() / failStage() / skipStage() as it walks the stages,
// and finally complete() / fail() / cancel() when the pipeline ends.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * Overall pipeline status.
 */
export type PipelineStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled'

/**
 * Per-stage status.
 */
export type StageStatus = 'pending' | 'running' | 'completed' | 'failed' | 'skipped'

/**
 * Progress record for a single stage within a pipeline execution.
 */
export interface StageProgress {
  /** Stage name (e.g. 'research', 'curriculum'). */
  stage: string
  /** Current status of the stage. */
  status: StageStatus
  /** ISO timestamp when the stage started. */
  startedAt: string | null
  /** ISO timestamp when the stage completed (success / failure / skip). */
  completedAt: string | null
  /** Duration in milliseconds. 0 if not yet completed. */
  durationMs: number
  /** Error message if the stage failed. */
  error: string | null
  /** Attempt number (1-indexed). >1 means the stage was retried. */
  attempt: number
}

/**
 * Mutable state for a single pipeline execution.
 */
export class PipelineState {
  /** Unique execution id. */
  executionId: string
  /** Course id this execution belongs to. Mutable (may be set after first stage). */
  courseId: string
  /** Current pipeline status. */
  status: PipelineStatus
  /** Per-stage progress records, in execution order. */
  stages: StageProgress[]
  /** ISO timestamp when the pipeline started. */
  startedAt: string | null
  /** ISO timestamp when the pipeline reached a terminal state. */
  completedAt: string | null
  /** Total duration in milliseconds. 0 if not yet terminal. */
  totalDurationMs: number
  /** Error message if the pipeline failed. */
  error: string | null
  /** Name of the currently-executing stage, or null if none. */
  currentStage: string | null

  constructor(executionId: string, courseId: string = '', stages: string[] = []) {
    this.executionId = executionId
    this.courseId = courseId
    this.status = 'queued'
    this.stages = stages.map((stage) => ({
      stage,
      status: 'pending' as StageStatus,
      startedAt: null,
      completedAt: null,
      durationMs: 0,
      error: null,
      attempt: 0,
    }))
    this.startedAt = null
    this.completedAt = null
    this.totalDurationMs = 0
    this.error = null
    this.currentStage = null
  }

  /**
   * Mark the pipeline as started. Sets status to 'running' and records the
   * start timestamp. No-op if already running.
   */
  start(): void {
    if (this.status === 'running') return
    this.status = 'running'
    this.startedAt = new Date().toISOString()
    logger.debug({ executionId: this.executionId }, 'PipelineState: started')
  }

  /**
   * Mark a stage as started. Increments the attempt counter.
   */
  startStage(stage: string): void {
    const s = this.stages.find((x) => x.stage === stage)
    if (!s) {
      // Stage not pre-declared — append it.
      this.stages.push({
        stage,
        status: 'running',
        startedAt: new Date().toISOString(),
        completedAt: null,
        durationMs: 0,
        error: null,
        attempt: 1,
      })
    } else {
      s.status = 'running'
      s.startedAt = new Date().toISOString()
      s.completedAt = null
      s.error = null
      s.attempt += 1
    }
    this.currentStage = stage
    if (this.status === 'queued') this.start()
  }

  /**
   * Mark a stage as completed successfully.
   */
  completeStage(stage: string): void {
    const s = this.stages.find((x) => x.stage === stage)
    if (!s) return
    s.status = 'completed'
    s.completedAt = new Date().toISOString()
    if (s.startedAt) {
      s.durationMs = Date.now() - new Date(s.startedAt).getTime()
    }
    if (this.currentStage === stage) this.currentStage = null
  }

  /**
   * Mark a stage as failed.
   */
  failStage(stage: string, error: string): void {
    const s = this.stages.find((x) => x.stage === stage)
    if (!s) return
    s.status = 'failed'
    s.completedAt = new Date().toISOString()
    s.error = error
    if (s.startedAt) {
      s.durationMs = Date.now() - new Date(s.startedAt).getTime()
    }
    if (this.currentStage === stage) this.currentStage = null
  }

  /**
   * Mark a stage as skipped (e.g. because a previous stage failed or the
   * stage is not applicable to this request).
   */
  skipStage(stage: string, reason?: string): void {
    const s = this.stages.find((x) => x.stage === stage)
    if (!s) return
    s.status = 'skipped'
    s.completedAt = new Date().toISOString()
    if (reason) s.error = reason
    if (this.currentStage === stage) this.currentStage = null
  }

  /**
   * Mark the pipeline as completed successfully.
   */
  complete(): void {
    this.status = 'completed'
    this.completedAt = new Date().toISOString()
    if (this.startedAt) {
      this.totalDurationMs = Date.now() - new Date(this.startedAt).getTime()
    }
    this.currentStage = null
    logger.debug(
      { executionId: this.executionId, durationMs: this.totalDurationMs },
      'PipelineState: completed',
    )
  }

  /**
   * Mark the pipeline as failed.
   */
  fail(error: string): void {
    this.status = 'failed'
    this.error = error
    this.completedAt = new Date().toISOString()
    if (this.startedAt) {
      this.totalDurationMs = Date.now() - new Date(this.startedAt).getTime()
    }
    this.currentStage = null
    logger.warn(
      { executionId: this.executionId, error, durationMs: this.totalDurationMs },
      'PipelineState: failed',
    )
  }

  /**
   * Mark the pipeline as cancelled (e.g. by user request).
   */
  cancel(): void {
    this.status = 'cancelled'
    this.completedAt = new Date().toISOString()
    if (this.startedAt) {
      this.totalDurationMs = Date.now() - new Date(this.startedAt).getTime()
    }
    this.currentStage = null
    logger.info(
      { executionId: this.executionId, durationMs: this.totalDurationMs },
      'PipelineState: cancelled',
    )
  }

  /**
   * Count of completed stages (status === 'completed').
   */
  getCompletedCount(): number {
    return this.stages.filter((s) => s.status === 'completed').length
  }

  /**
   * Progress percentage (0-100) based on completed stages.
   */
  getProgressPercent(): number {
    if (this.stages.length === 0) return 0
    return Math.round((this.getCompletedCount() / this.stages.length) * 100)
  }

  /**
   * Get the progress record for a specific stage. Returns null if not found.
   */
  getStageProgress(stage: string): StageProgress | null {
    return this.stages.find((s) => s.stage === stage) ?? null
  }

  /**
   * Returns true if the pipeline is in a terminal state (completed / failed / cancelled).
   */
  isTerminal(): boolean {
    return this.status === 'completed' || this.status === 'failed' || this.status === 'cancelled'
  }

  /**
   * Serialize to a plain object (for JSON responses).
   */
  toJSON(): {
    executionId: string
    courseId: string
    status: PipelineStatus
    stages: StageProgress[]
    startedAt: string | null
    completedAt: string | null
    totalDurationMs: number
    error: string | null
    currentStage: string | null
    progressPercent: number
    completedCount: number
  } {
    return {
      executionId: this.executionId,
      courseId: this.courseId,
      status: this.status,
      stages: this.stages,
      startedAt: this.startedAt,
      completedAt: this.completedAt,
      totalDurationMs: this.totalDurationMs,
      error: this.error,
      currentStage: this.currentStage,
      progressPercent: this.getProgressPercent(),
      completedCount: this.getCompletedCount(),
    }
  }
}

/**
 * Factory: creates a PipelineState with a generated execution id and the
 * given stages pre-declared as 'pending'.
 */
export function createPipelineState(
  executionId: string,
  courseId: string = '',
  stages: string[] = [],
): PipelineState {
  return new PipelineState(executionId, courseId, stages)
}
