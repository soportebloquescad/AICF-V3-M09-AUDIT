// =============================================================================
// AICF V3 — Sprint 13+14 — Runtime Recovery (Batch C2)
// =============================================================================
// Runs on startup (or on demand) to rehydrate workflow executions that
// were interrupted before reaching a terminal state. The recovery loop:
//   1. Asks the state store for every execution in a non-terminal status
//      (`pending` / `running` / `paused` / `compensating`).
//   2. For each, delegates to the engine's `resume(executionId)` to pick
//      up from the last checkpoint.
//   3. Tracks which executions recovered cleanly and which failed,
//      surfacing both as a structured `RecoveryReport`.
//   4. Emits a `workflow.resumed` event for each recovered execution so
//      subscribers (audit, metrics, UI) can react.
//
// Sprint 13+14 spec requirements covered:
//   - `recover()` — main entry, returns recovered + failed execution ids
//   - `recoverExecution(executionId)` — single-execution recovery
//   - `getRecoveryReport()` — last recovery report (timestamp + details)
//   - `RecoveryReport` interface with per-failure error messages
//
// Design notes:
//   - The engine dependency is a minimal structural interface
//     (`RecoveryEngine`) with just `resume(executionId)`. The full
//     `IWorkflowEngine` satisfies it, but recovery does not need
//     execute / dryRun / cancel / pause.
//   - Recovery is best-effort: a failure on one execution does NOT
//     abort recovery of the others. Each failure is recorded with its
//     error message.
//   - The `RecoveryReport` is retained on the instance so callers can
//     inspect it after `recover()` returns. A fresh `recover()` call
//     overwrites the previous report.
// =============================================================================

import type { IWorkflowStateStore, IEventBus } from '@/lib/runtime/interfaces'
import type {
  WorkflowEvent,
  ExecutionStatus,
} from '@/lib/runtime/contracts/workflow'
import { logger as defaultLogger } from '@/lib/ai/logger'

/**
 * Minimal engine surface required by `RuntimeRecovery`. The full
 * `IWorkflowEngine` satisfies this structurally, but recovery only
 * needs `resume`.
 */
export interface RecoveryEngine {
  /** Resume a paused / interrupted execution by id. */
  resume(executionId: string): Promise<unknown>
}

/**
 * Structural logger surface accepted by `RuntimeRecovery`. Matches the
 * relevant subset of the pino logger (`info` / `warn` / `error` /
 * `debug` with a context object + message). Callers can pass the
 * singleton `logger` from `@/lib/ai/logger` or a child logger.
 */
export interface RecoveryLogger {
  info(obj: Record<string, unknown>, msg: string): void
  warn(obj: Record<string, unknown>, msg: string): void
  error(obj: Record<string, unknown>, msg: string): void
  debug(obj: Record<string, unknown>, msg: string): void
}

/**
 * Structured recovery report. Retained on the `RuntimeRecovery`
 * instance after each `recover()` call.
 */
export interface RecoveryReport {
  /** Epoch ms when the recovery run completed. */
  timestamp: number
  /** Execution ids that were successfully resumed. */
  recovered: string[]
  /** Execution ids that failed to resume, with their error messages. */
  failed: Array<{ executionId: string; error: string }>
}

/** Empty report used before the first `recover()` call. */
const EMPTY_REPORT: RecoveryReport = {
  timestamp: 0,
  recovered: [],
  failed: [],
}

/** Terminal execution statuses — recovery skips these. */
const TERMINAL_STATUSES: ReadonlySet<ExecutionStatus> = new Set([
  'completed',
  'failed',
  'cancelled',
])

/**
 * Startup recovery loop. Construct once at boot, call `recover()` once
 * (or after a crash), then inspect `getRecoveryReport()`.
 *
 * One `RuntimeRecovery` instance can be reused across multiple
 * `recover()` calls; each call overwrites the previous report.
 */
export class RuntimeRecovery {
  /** Last recovery report (or an empty report before the first run). */
  private report: RecoveryReport = EMPTY_REPORT
  /** Per-call failure buffer, drained into the next `RecoveryReport`. */
  private readonly pendingFailures: Array<{ executionId: string; error: string }> = []

  constructor(
    private readonly stateStore: IWorkflowStateStore,
    private readonly engine: RecoveryEngine,
    private readonly eventBus: IEventBus,
    private readonly logger: RecoveryLogger = defaultLogger as unknown as RecoveryLogger,
  ) {}

  /**
   * Recover every pending execution known to the state store.
   *
   * @returns `{ recovered, failed }` — `recovered` is the list of
   *          execution ids that resumed cleanly; `failed` is the list
   *          of execution ids that failed (ids only; full error
   *          details are on the `RecoveryReport` returned by
   *          `getRecoveryReport()`).
   */
  async recover(): Promise<{ recovered: string[]; failed: string[] }> {
    const pending = await this.stateStore.listPending()
    this.logger.info(
      { count: pending.length },
      'RuntimeRecovery: starting recovery sweep',
    )

    // Reset the per-call failure buffer at the start of each sweep so
    // failures from a previous run do not leak into this report.
    this.pendingFailures.length = 0

    const recovered: string[] = []
    for (const exec of pending) {
      const ok = await this.recoverExecution(exec.executionId)
      if (ok) {
        recovered.push(exec.executionId)
      }
    }

    const report: RecoveryReport = {
      timestamp: Date.now(),
      recovered,
      failed: this.pendingFailures.splice(0, this.pendingFailures.length),
    }
    this.report = report

    this.logger.info(
      {
        recovered: report.recovered.length,
        failed: report.failed.length,
        total: pending.length,
      },
      'RuntimeRecovery: recovery sweep complete',
    )

    return {
      recovered: report.recovered,
      failed: report.failed.map((f) => f.executionId),
    }
  }

  /**
   * Recover a single execution by id. Emits `workflow.resumed` on
   * success. Returns `true` if the execution resumed cleanly, `false`
   * otherwise (including when the execution is unknown or already
   * terminal).
   *
   * Failures are recorded on the internal failure buffer so the next
   * `getRecoveryReport()` (or `recover()` return) reflects them.
   */
  async recoverExecution(executionId: string): Promise<boolean> {
    try {
      // Verify the execution exists and is still pending — it may
      // have reached a terminal state between the `listPending` call
      // and now (e.g. a concurrent caller cancelled it).
      const exec = await this.stateStore.loadExecution(executionId)
      if (!exec) {
        this.recordFailure(executionId, 'execution not found in state store')
        this.logger.warn(
          { executionId },
          'RuntimeRecovery: execution not found; skipping',
        )
        return false
      }
      if (TERMINAL_STATUSES.has(exec.status)) {
        this.logger.debug(
          { executionId, status: exec.status },
          'RuntimeRecovery: execution already terminal; skipping',
        )
        return false
      }

      // Delegate to the engine to pick up from the last checkpoint.
      await this.engine.resume(executionId)

      // Emit a `workflow.resumed` event so audit / metrics / UI
      // subscribers can react to the recovery.
      const event: WorkflowEvent = {
        type: 'workflow.resumed',
        timestamp: Date.now(),
        level: 'info',
        executionId,
        correlationId: exec.correlationId,
        data: {
          reason: 'runtime recovery',
          fromStatus: exec.status,
        },
      }
      await this.eventBus.publish(event)

      this.logger.info(
        { executionId, fromStatus: exec.status },
        'RuntimeRecovery: execution recovered',
      )
      return true
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'unknown recovery error'
      this.recordFailure(executionId, message)
      this.logger.error(
        { executionId, err: message },
        'RuntimeRecovery: execution recovery failed',
      )
      return false
    }
  }

  /**
   * Return the last recovery report. Before the first `recover()` call,
   * returns an empty report (`timestamp: 0`, empty arrays).
   */
  getRecoveryReport(): RecoveryReport {
    return this.report
  }

  // ----- Internal helpers ---------------------------------------------------

  /** Record a failure on the internal buffer. */
  private recordFailure(executionId: string, error: string): void {
    this.pendingFailures.push({ executionId, error })
  }
}
