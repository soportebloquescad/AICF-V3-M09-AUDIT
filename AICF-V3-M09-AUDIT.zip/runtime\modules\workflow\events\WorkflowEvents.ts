// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Events Module (Thin Namespace)
// =============================================================================
// Module-local event namespace. Re-exports the workflow event contract types
// and helpers from `@/lib/runtime/contracts/workflow` so internal engine
// files can import from a single workflow-module-local surface:
//
//   import { createWorkflowEvent, type WorkflowEvent } from './events/WorkflowEvents'
//
// Why a thin re-export file?
//   - Keeps imports inside the workflow module decoupled from the contracts
//     barrel path.
//   - Provides one seam where module-local event helpers (e.g. typed
//     `createWorkflowEvent` wrappers, severity mappers) can live without
//     polluting the public contract.
//
// Sprint 13+14 spec: events are the single source of truth for workflow
// observability — the audit log, UI progress, metrics aggregator, and saga
// compensation tracker all subscribe to this stream.
// =============================================================================

import type {
  WorkflowEvent,
  WorkflowEventType,
  WorkflowEventLevel,
  CreateEventOptions,
} from '@/lib/runtime/contracts/workflow'
import { createEvent } from '@/lib/runtime/contracts/workflow'

// Re-export the public contract surface for convenience.
export type {
  WorkflowEvent,
  WorkflowEventType,
  WorkflowEventLevel,
  CreateEventOptions,
}
export { createEvent, isWorkflowEvent } from '@/lib/runtime/contracts/workflow'

/**
 * Module-local convenience factory: same as `createEvent` from contracts,
 * but exposed under a workflow-module-local name to make call sites
 * self-documenting ("this event was produced by the workflow engine").
 *
 * Behavior is identical to the contract `createEvent`:
 *   - `timestamp` defaults to `Date.now()`.
 *   - `level` defaults to the per-type severity table.
 *
 * @param type  Event discriminator.
 * @param data  Type-specific payload.
 * @param opts  Optional overrides (executionId, stepId, correlationId,
 *              level, timestamp).
 */
export function createWorkflowEvent(
  type: WorkflowEventType,
  data: Record<string, unknown>,
  opts?: CreateEventOptions,
): WorkflowEvent {
  return createEvent(type, data, opts)
}
