// =============================================================================
// AICF V3 — Routing Stage (Sprint 21: emits RoutingStarted/RoutingCompleted)
// =============================================================================
// Decides which AI provider and model to use.
// Does NOT call LiteLLM — only decides.
// Uses Content Intelligence M08 if available; otherwise uses request defaults.
//
// Sprint 21: when an EventBus is provided (optional 2nd arg), the stage
// emits:
//   - RoutingStarted   (before selectProvider / fallback)
//   - RoutingCompleted  (after, with provider/model)
// Emission is best-effort — wrapped in try/catch, never throws, never blocks
// the pipeline.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { ContentIntelligenceModule } from '../contracts/ModuleInterfaces'
import type { RuntimeEventBus } from '../events/RuntimeEventBus'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import { logger } from '@/lib/ai/logger'

/** Default provider/model when no CI module is available. */
const DEFAULT_PROVIDER = 'litellm'
const DEFAULT_MODEL = 'groq-llama-3.3-70b'

/**
 * Best-effort: emits an envelope-wrapped EDA event. Wraps in try/catch so
 * emission failures never propagate to the pipeline.
 */
async function emitBestEffort(
  eventBus: RuntimeEventBus | undefined,
  type: 'RoutingStarted' | 'RoutingCompleted',
  opts: {
    correlationId: string
    requestId: string
    operation: string
    stageOrder: number
    durationMs?: number
    payload: Record<string, unknown>
  },
): Promise<void> {
  if (!eventBus) return
  try {
    const meta = createEventMetadata({
      correlationId: opts.correlationId,
      requestId: opts.requestId,
      operation: opts.operation,
      pipelineStage: 'Routing',
      stageOrder: opts.stageOrder,
      durationMs: opts.durationMs,
    })
    await eventBus.publishEnvelope(createEnvelope(meta, opts.payload), type)
  } catch (err) {
    logger.debug(
      { type, error: err instanceof Error ? err.message : String(err) },
      'Routing stage: event emission failed (best-effort)',
    )
  }
}

/**
 * Creates the Routing stage.
 * @param ciModule - Content Intelligence module (M08). If null, uses defaults.
 * @param eventBus - Optional. When set, emits RoutingStarted/RoutingCompleted events.
 */
export function createRoutingStage(
  ciModule: ContentIntelligenceModule | null,
  eventBus?: RuntimeEventBus,
): PipelineStage {
  return createPipelineStage('Routing', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const requestId = ctx.request.requestId
    const correlationId = ctx.request.correlationId
    const operation = ctx.request.operation

    await emitBestEffort(eventBus, 'RoutingStarted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 6,
      payload: { requestId, operation },
    })

    const started = Date.now()

    // If CI module is available, ask it to select the best provider
    if (ciModule && typeof ciModule.isReady === 'function' && ciModule.isReady() && typeof ciModule.selectProvider === 'function') {
      try {
        const route = await ciModule.selectProvider(ctx)
        const next = cloneRuntimeContext(ctx)
        next.provider = route.provider
        next.model = route.model
        logger.info(
          { requestId: ctx.request.requestId, provider: next.provider, model: next.model, strategy: route.strategy },
          'Routing: CI selected provider',
        )

        await emitBestEffort(eventBus, 'RoutingCompleted', {
          correlationId,
          requestId,
          operation,
          stageOrder: 7,
          durationMs: Date.now() - started,
          payload: {
            requestId,
            provider: next.provider || DEFAULT_PROVIDER,
            model: next.model || DEFAULT_MODEL,
          },
        })

        return next
      } catch (err) {
        logger.warn(
          { error: err instanceof Error ? err.message : String(err) },
          'Routing: CI selectProvider failed, falling back to defaults',
        )
      }
    }

    // Fallback: use request model or defaults
    const next = cloneRuntimeContext(ctx)
    next.provider = DEFAULT_PROVIDER
    next.model = ctx.request.model || DEFAULT_MODEL

    logger.info(
      { requestId: ctx.request.requestId, provider: next.provider, model: next.model },
      'Routing: using default provider',
    )

    await emitBestEffort(eventBus, 'RoutingCompleted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 7,
      durationMs: Date.now() - started,
      payload: {
        requestId,
        provider: next.provider,
        model: next.model,
      },
    })

    return next
  })
}
