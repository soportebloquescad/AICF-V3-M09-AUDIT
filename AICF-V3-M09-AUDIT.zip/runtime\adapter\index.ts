// =============================================================================
// AICF V3 — Sprint 2 — Adapter Barrel
// =============================================================================

export { RuntimeAdapter, type RuntimeAdapterConfig } from './RuntimeAdapter'
