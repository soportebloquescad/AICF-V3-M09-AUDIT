// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Quota Policy
// =============================================================================
// Enforces per-execution quota limits:
//   - max tokens per execution (ctx.tokens.totalTokens + estimated step tokens)
//   - max cost per execution (ctx.cost + estimated step cost)
//
// Estimates for the step's token / cost contribution are read from
// `step.config.estimatedTokens` and `step.config.estimatedCost` when present
// (default 0 — i.e. the policy is permissive when no estimate is supplied).
//
// Sprint 13+14 spec requirements covered:
//   - name: 'quota-policy'
//   - Constructor takes maxTokensPerExecution + maxCostPerExecution
//   - Denies when running this step would exceed either quota
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import type { IPolicy, PolicyDecision } from '@/lib/runtime/modules/workflow/policies/PolicyMiddleware'

/** Read a non-negative number from step config (0 when absent / invalid). */
function readNonNegative(
  config: Record<string, unknown>,
  key: string,
): number {
  const v = config[key]
  if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) return 0
  return v
}

/**
 * Enforces per-execution token + cost quotas. Implements `IPolicy`.
 */
export class QuotaPolicy implements IPolicy {
  readonly name = 'quota-policy'

  /**
   * @param maxTokensPerExecution Hard cap on total tokens per execution.
   * @param maxCostPerExecution   Hard cap on total cost per execution
   *                              (platform currency units).
   */
  constructor(
    private readonly maxTokensPerExecution: number,
    private readonly maxCostPerExecution: number,
  ) {}

  async check(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const estTokens = readNonNegative(step.config, 'estimatedTokens')
    const estCost = readNonNegative(step.config, 'estimatedCost')

    const projectedTokens = ctx.tokens.totalTokens + estTokens
    const projectedCost = ctx.cost + estCost

    const violations: string[] = []
    if (projectedTokens > this.maxTokensPerExecution) {
      violations.push(
        `projected tokens (${projectedTokens}) would exceed quota (${this.maxTokensPerExecution})`,
      )
    }
    if (projectedCost > this.maxCostPerExecution) {
      violations.push(
        `projected cost (${projectedCost}) would exceed quota (${this.maxCostPerExecution})`,
      )
    }

    return violations.length === 0
      ? { allowed: true, violations: [] }
      : {
          allowed: false,
          violations,
          reason: 'per-execution quota exceeded',
        }
  }
}
