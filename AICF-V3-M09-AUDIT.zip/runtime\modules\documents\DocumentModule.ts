// =============================================================================
// AICF V3 — Document Module (Épica 3 — Educational Factory)
// =============================================================================
// Business-layer module that handles document-related job types:
//   - generateDocument
//   - exportDocument
//
// Supports a set of document types — each producing a different structured
// markdown document with sections appropriate to its purpose:
//
//   workbook              — exercises + practice problems + answer key
//   teacher-guide         — learning objectives + teaching tips + rubric
//   student-guide         — overview + key concepts + study tips
//   implementation-guide  — phases + tasks + acceptance criteria
//   glossary              — alphabetical term definitions
//   checklist             — actionable checklist items
//   resources             — curated reading list / links
//
// When an AIAdapter is provided (constructor injection) the module prompts
// the LLM for structured JSON content and parses it into typed sections.
// When no adapter is available — or the AI call fails — the module falls
// back to a deterministic generator that always produces real, useful
// content from the requested topic.
//
// Strict TypeScript: no `any`. All `unknown` inputs are narrowed with type
// guards. No "Not implemented" returns.
// =============================================================================

import { BusinessModuleBase } from '@/lib/runtime/business/plugin/BusinessModuleBase'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import type { Capability } from '@/lib/runtime/business/contracts/Capability'
import { createCapability } from '@/lib/runtime/business/contracts/Capability'
import type { ExecutionResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import { createSuccessResult, createFailedResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import type { BusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import { getPromptBuilder } from '@/lib/ai/PromptBuilder'

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/** Document types supported by generateDocument. */
export type DocumentType =
  | 'workbook'
  | 'teacher-guide'
  | 'student-guide'
  | 'implementation-guide'
  | 'glossary'
  | 'checklist'
  | 'resources'

/** A single section inside a generated document. */
export interface DocumentSection {
  /** Section heading. */
  heading: string
  /** Markdown-formatted section body. */
  body: string
}

/** Output shape for generateDocument. */
export interface GeneratedDocument {
  /** Document title. */
  title: string
  /** Topic the document was generated from. */
  topic: string
  /** Document type that was generated. */
  type: DocumentType
  /** Output format (always 'markdown' for now). */
  format: 'markdown'
  /** Number of sections. */
  sections: number
  /** Ordered sections. */
  sectionList: DocumentSection[]
  /** Full document rendered as markdown. */
  content: string
  /** Standalone HTML5 representation of the markdown. */
  html: string
}

// ---------------------------------------------------------------------------
// Metadata + capabilities
// ---------------------------------------------------------------------------

export const DOCUMENT_MODULE_METADATA: PluginMetadata = {
  id: 'document',
  name: 'Document',
  description: 'Document generation and export (generateDocument, exportDocument)',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'document',
  priority: 35,
  dependencies: [],
  capabilities: ['generateDocument', 'exportDocument'],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'document.jobStarted',
    'document.jobCompleted',
    'document.jobFailed',
  ],
}

export const DOCUMENT_CAPABILITIES: Capability[] = [
  createCapability('generateDocument', 'Generate a structured document from a topic + outline'),
  createCapability('exportDocument', 'Export a document to a target format (pdf, docx, markdown, etc.)'),
]

// ---------------------------------------------------------------------------
// Helpers — input narrowing (no `any`)
// ---------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function asNumber(value: unknown, fallback: number, min = 1, max = 30): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), min), max)
}

function isDocumentType(value: unknown): value is DocumentType {
  return (
    value === 'workbook' ||
    value === 'teacher-guide' ||
    value === 'student-guide' ||
    value === 'implementation-guide' ||
    value === 'glossary' ||
    value === 'checklist' ||
    value === 'resources'
  )
}

// ---------------------------------------------------------------------------
// Fallback content generator — deterministic per (type, topic).
// ---------------------------------------------------------------------------

interface SectionTemplate {
  heading: (topic: string) => string
  body: (topic: string) => string
}

const SECTION_TEMPLATES: Record<DocumentType, SectionTemplate[]> = {
  workbook: [
    {
      heading: () => 'Overview',
      body: (t) =>
        `This workbook accompanies the **${t}** course. It provides hands-on exercises ` +
        `designed to reinforce the core concepts of ${t} through deliberate practice.`,
    },
    {
      heading: () => 'Exercises',
      body: (t) =>
        `1. **Concept recall**: write down, in your own words, the definition of ${t}.\n` +
        `2. **Compare and contrast**: identify two approaches related to ${t} and list their trade-offs.\n` +
        `3. **Diagram**: sketch the main components of ${t} and label each one.\n` +
        `4. **Application**: describe a real-world scenario where ${t} would be the right choice.\n` +
        `5. **Reflection**: which aspect of ${t} did you find most challenging, and why?`,
    },
    {
      heading: () => 'Practice Problems',
      body: (t) =>
        `**Problem 1.** Given a basic ${t} setup, identify three potential failure modes.\n\n` +
        `**Problem 2.** Design a minimal implementation of ${t} that satisfies the requirements from class.\n\n` +
        `**Problem 3.** Critique a sample ${t} solution and propose two concrete improvements.\n\n` +
        `**Problem 4.** Extend your ${t} solution to handle an edge case of your choice.\n\n` +
        `**Problem 5.** Write a short test plan that validates your ${t} implementation.`,
    },
    {
      heading: () => 'Answer Key',
      body: (t) =>
        `Answers are intentionally open-ended — they should reflect the learner's own reasoning. ` +
        `Instructors should look for: (a) accurate use of ${t} terminology, (b) justified trade-offs, ` +
        `(c) concrete examples drawn from real systems, and (d) a clear, repeatable process.`,
    },
    {
      heading: () => 'Self-Assessment',
      body: (t) =>
        `Rate your confidence with each of the following on a 1–5 scale:\n\n` +
        `- Explaining ${t} to a colleague\n- Implementing ${t} from scratch\n` +
        `- Diagnosing a failing ${t} system\n- Choosing between ${t} and alternatives\n` +
        `- Teaching the basics of ${t} to a beginner`,
    },
  ],
  'teacher-guide': [
    {
      heading: () => 'Learning Objectives',
      body: (t) =>
        `By the end of this unit on **${t}**, learners will be able to:\n\n` +
        `1. Define ${t} and explain its purpose.\n` +
        `2. Identify the core components of ${t}.\n` +
        `3. Apply ${t} to solve a representative problem.\n` +
        `4. Evaluate ${t} solutions against criteria such as correctness, clarity, and efficiency.\n` +
        `5. Critique alternative approaches to ${t}.`,
    },
    {
      heading: () => 'Teaching Tips',
      body: (t) =>
        `- Begin with a concrete, relatable example of ${t} before introducing formal definitions.\n` +
        `- Use a worked example for each new concept; pause for learner predictions.\n` +
        `- Surface common misconceptions about ${t} explicitly and discuss why they arise.\n` +
        `- Pair abstract content with a hands-on exercise using ${t}.\n` +
        `- Close with a synthesis activity that requires learners to combine two or more ${t} concepts.`,
    },
    {
      heading: () => 'Lesson Plan',
      body: (t) =>
        `**Total time:** 90 minutes\n\n` +
        `1. (10 min) Hook + real-world motivation for ${t}.\n` +
        `2. (15 min) Direct instruction: core ${t} concepts.\n` +
        `3. (10 min) Worked example with class participation.\n` +
        `4. (30 min) Guided practice in pairs on ${t} exercises.\n` +
        `5. (15 min) Whole-class debrief of common pitfalls.\n` +
        `6. (10 min) Exit ticket: one sentence summarising ${t}.`,
    },
    {
      heading: () => 'Assessment Rubric',
      body: (t) =>
        `| Criterion | Beginning (1) | Developing (2) | Proficient (3) | Exemplary (4) |\n` +
        `| --- | --- | --- | --- | --- |\n` +
        `| Conceptual grasp of ${t} | Misuses terminology | Partial definitions | Clear definitions | Nuanced, transferable |\n` +
        `| Application of ${t} | Unable to apply | Applies with help | Applies independently | Generalises to new contexts |\n` +
        `| Critique of ${t} solutions | Unable to critique | Surface-level critique | Substantive critique | Actionable, evidence-based |\n` +
        `| Communication | Unclear | Adequate | Clear | Engaging and precise |`,
    },
    {
      heading: () => 'Differentiation',
      body: (t) =>
        `- For learners who need more support: provide a partially-completed ${t} example.\n` +
        `- For advanced learners: introduce an optimisation or scaling challenge related to ${t}.\n` +
        `- For English-language learners: pre-teach key ${t} vocabulary with a glossary.\n` +
        `- For learners with attention needs: chunk the ${t} unit into 15-minute segments.`,
    },
  ],
  'student-guide': [
    {
      heading: () => 'Course Overview',
      body: (t) =>
        `Welcome to the **${t}** unit. This guide explains what you will learn, why it matters, ` +
        `and how to get the most out of the material.`,
    },
    {
      heading: () => 'Key Concepts',
      body: (t) =>
        `- **Definition**: what ${t} is and the problem it solves.\n` +
        `- **Components**: the building blocks that make up ${t}.\n` +
        `- **Workflow**: the typical end-to-end process for using ${t}.\n` +
        `- **Trade-offs**: when ${t} is the right tool, and when it is not.\n` +
        `- **Pitfalls**: common mistakes and how to avoid them.`,
    },
    {
      heading: () => 'How to Study',
      body: (t) =>
        `1. Read the assigned chapter on ${t} before class.\n` +
        `2. Take notes in your own words — especially definitions.\n` +
        `3. Attempt every exercise before checking the answer key.\n` +
        `4. Form a study group and explain ${t} concepts to each other.\n` +
        `5. Track your questions and bring them to the next session.`,
    },
    {
      heading: () => 'Resources',
      body: (t) =>
        `- Official documentation for ${t}.\n` +
        `- Curated video walkthroughs.\n` +
        `- Community forum where you can ask ${t} questions.\n` +
        `- Sample projects that demonstrate ${t} in practice.\n` +
        `- Office hours schedule for one-on-one help.`,
    },
    {
      heading: () => 'FAQ',
      body: (t) =>
        `**Q: Do I need prior experience with ${t}?**\nA: No — the unit starts from first principles.\n\n` +
        `**Q: How much time should I budget per week?**\nA: Plan for 3–5 hours including exercises.\n\n` +
        `**Q: Will ${t} still be relevant in five years?**\nA: The fundamentals are durable; specific tools evolve.`,
    },
  ],
  'implementation-guide': [
    {
      heading: () => 'Project Context',
      body: (t) =>
        `This guide describes how to implement **${t}** end-to-end inside an existing system. ` +
        `It is written for engineers who own the rollout from design through to production.`,
    },
    {
      heading: () => 'Phase 1 — Discovery',
      body: (t) =>
        `- Identify the stakeholders who depend on ${t}.\n` +
        `- Capture the functional and non-functional requirements for ${t}.\n` +
        `- Audit existing systems that ${t} will integrate with.\n` +
        `- Document constraints (budget, timeline, compliance, security).\n` +
        `- Exit criteria: signed-off requirements document.`,
    },
    {
      heading: () => 'Phase 2 — Design',
      body: (t) =>
        `- Propose a target architecture for ${t}.\n` +
        `- Map each requirement to one or more ${t} components.\n` +
        `- Identify data flows, contracts, and failure modes.\n` +
        `- Produce a sequence diagram and a deployment diagram.\n` +
        `- Exit criteria: design review approved by the architecture board.`,
    },
    {
      heading: () => 'Phase 3 — Implementation',
      body: (t) =>
        `- Stand up the ${t} skeleton with stubs for every component.\n` +
        `- Implement the highest-risk ${t} slice first.\n` +
        `- Add unit tests for every ${t} module as it lands.\n` +
        `- Wire CI to run the test suite on every commit.\n` +
        `- Exit criteria: feature-complete ${t} build that passes CI.`,
    },
    {
      heading: () => 'Phase 4 — Rollout',
      body: (t) =>
        `- Deploy ${t} behind a feature flag to a staging environment.\n` +
        `- Run an acceptance test plan covering every ${t} requirement.\n` +
        `- Schedule a canary release with monitoring dashboards.\n` +
        `- Roll out ${t} to production traffic incrementally.\n` +
        `- Exit criteria: ${t} running in production with no SLO breaches for one week.`,
    },
  ],
  glossary: [
    {
      heading: () => 'A',
      body: (t) =>
        `**${t} (core term)** — the central concept of this unit; see the main definition in the course material.\n\n` +
        `**Abstraction** — a technique for managing complexity by hiding implementation details behind a clean interface, frequently used when working with ${t}.`,
    },
    {
      heading: () => 'B',
      body: (t) =>
        `**Boundary** — the limit of what ${t} is responsible for; clearly drawn boundaries keep systems maintainable.\n\n` +
        `**Build** — the process of transforming ${t} source into a runnable artefact.`,
    },
    {
      heading: () => 'C',
      body: (t) =>
        `**Component** — a discrete piece of ${t} that has a single responsibility.\n\n` +
        `**Contract** — the agreed-upon interface between two ${t} components.\n\n` +
        `**Cache** — a short-lived store that speeds up repeated ${t} operations.`,
    },
    {
      heading: () => 'D',
      body: (t) =>
        `**Dependency** — another module or service that ${t} requires to function.\n\n` +
        `**Deployment** — the act of placing a ${t} build into an environment.`,
    },
    {
      heading: () => 'E–Z',
      body: (t) =>
        `**Edge case** — an unusual input or condition that ${t} must still handle gracefully.\n\n` +
        `**Idempotent** — an operation on ${t} that produces the same result no matter how many times it runs.\n\n` +
        `**Observability** — the ability to understand the internal state of ${t} from its external outputs.\n\n` +
        `**Regression** — a previously-working ${t} behaviour that has stopped working after a change.\n\n` +
        `**Test plan** — the structured set of checks used to validate ${t}.`,
    },
  ],
  checklist: [
    {
      heading: () => 'Pre-Launch Checklist',
      body: (t) =>
        `- [ ] Requirements for ${t} reviewed and signed off\n` +
        `- [ ] Design for ${t} reviewed by architecture\n` +
        `- [ ] All ${t} unit tests pass in CI\n` +
        `- [ ] ${t} integration tests pass on staging\n` +
        `- [ ] Security review of ${t} complete\n` +
        `- [ ] Documentation for ${t} published`,
    },
    {
      heading: () => 'Operational Readiness',
      body: (t) =>
        `- [ ] Dashboards for ${t} deployed\n` +
        `- [ ] Alerts for ${t} configured with runbooks\n` +
        `- [ ] On-call rotation for ${t} established\n` +
        `- [ ] Capacity forecast for ${t} reviewed\n` +
        `- [ ] Backup and restore for ${t} validated`,
    },
    {
      heading: () => 'Rollout Day',
      body: (t) =>
        `- [ ] Feature flag for ${t} enabled for canary cohort\n` +
        `- [ ] No error-budget burn for ${t} over 30 minutes\n` +
        `- [ ] ${t} rolled out to 50% of traffic\n` +
        `- [ ] ${t} rolled out to 100% of traffic\n` +
        `- [ ] Rollback plan for ${t} rehearsed`,
    },
    {
      heading: () => 'Post-Launch Review',
      body: (t) =>
        `- [ ] Incident-free week for ${t}\n` +
        `- [ ] User feedback on ${t} collected\n` +
        `- [ ] Performance of ${t} compared to targets\n` +
        `- [ ] Lessons learned for the next ${t} rollout documented`,
    },
  ],
  resources: [
    {
      heading: () => 'Getting Started',
      body: (t) =>
        `- **Official documentation** — the canonical reference for ${t}.\n` +
        `- **Quickstart tutorial** — a 30-minute hands-on intro to ${t}.\n` +
        `- **Sample repository** — a working ${t} project you can clone and run.\n` +
        `- **FAQ** — answers to the most common ${t} questions.`,
    },
    {
      heading: () => 'Going Deeper',
      body: (t) =>
        `- **Reference book** — comprehensive treatment of ${t} theory and practice.\n` +
        `- **Conference talks** — curated playlist on ${t}.\n` +
        `- **Advanced workshop** — instructor-led deep dive into ${t}.\n` +
        `- **Research papers** — seminal ${t} papers for context.`,
    },
    {
      heading: () => 'Community',
      body: (t) =>
        `- **Discussion forum** — the most active ${t} community.\n` +
        `- **Chat channel** — real-time ${t} help.\n` +
        `- **Local meetups** — in-person ${t} events.\n` +
        `- **Conference** — the leading annual ${t} conference.`,
    },
    {
      heading: () => 'Tools',
      body: (t) =>
        `- **CLI** — the canonical command-line tool for ${t}.\n` +
        `- **IDE plugins** — first-class ${t} support in your editor.\n` +
        `- **Linters and formatters** — keep ${t} code consistent.\n` +
        `- **Profiling tools** — diagnose performance issues in ${t}.`,
    },
  ],
}

function buildFallbackDocument(topic: string, type: DocumentType, sectionCount: number): DocumentSection[] {
  const templates = SECTION_TEMPLATES[type]
  const count = Math.min(Math.max(sectionCount, 1), templates.length)
  const out: DocumentSection[] = []
  for (let i = 0; i < count; i++) {
    const tpl = templates[i]
    out.push({ heading: tpl.heading(topic), body: tpl.body(topic) })
  }
  // If the caller asked for more sections than the templates provide, repeat
  // the templates with appended section numbers so the doc still has the
  // requested number of sections (no empty bodies).
  let cycle = 1
  while (out.length < sectionCount) {
    const tpl = templates[out.length % templates.length]
    out.push({
      heading: `${tpl.heading(topic)} (Part ${cycle + 1})`,
      body: tpl.body(topic),
    })
    if (out.length % templates.length === 0) cycle += 1
  }
  return out
}

// ---------------------------------------------------------------------------
// Markdown + HTML rendering
// ---------------------------------------------------------------------------

function renderMarkdown(title: string, type: DocumentType, sections: DocumentSection[]): string {
  const lines: string[] = [`# ${title}`, '', `> Document type: \`${type}\``, '']
  for (const s of sections) {
    lines.push(`## ${s.heading}`, '', s.body, '')
  }
  return lines.join('\n')
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/**
 * Minimal markdown → HTML renderer. Handles headings (#, ##), bullet lists
 * (-, *), numbered lists (1.), task lists (- [ ] / - [x]), tables, blockquotes
 * (>), bold (**text**), italics (*text*), inline code (`code`), and
 * paragraphs. Sufficient for the structured markdown this module produces.
 */
function renderHtml(title: string, type: DocumentType, sections: DocumentSection[]): string {
  const bodyParts: string[] = []
  for (const s of sections) {
    bodyParts.push(`<section class="doc-section"><h2>${escapeHtml(s.heading)}</h2>`)
    bodyParts.push(markdownToHtml(s.body))
    bodyParts.push('</section>')
  }
  const body = bodyParts.join('\n')

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="generator" content="AICF V3 DocumentModule" />
  <meta name="doc-type" content="${escapeHtml(type)}" />
  <style>
    :root { --accent: #047857; --bg: #f8fafc; --surface: #ffffff; --text: #0f172a; --muted: #475569; --code-bg: #e2e8f0; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: var(--bg); color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      line-height: 1.6; }
    main.doc { max-width: 820px; margin: 0 auto; padding: 32px 24px 80px; background: var(--surface); min-height: 100vh; }
    h1 { font-size: 2rem; border-bottom: 4px solid var(--accent); padding-bottom: 8px; }
    h2 { font-size: 1.5rem; margin-top: 32px; color: var(--accent); }
    .doc-section { margin-bottom: 32px; }
    blockquote { border-left: 4px solid var(--muted); margin: 12px 0; padding: 8px 16px; background: #f1f5f9; color: var(--muted); }
    code { background: var(--code-bg); padding: 2px 6px; border-radius: 4px; font-size: 0.95em; }
    table { border-collapse: collapse; width: 100%; margin: 12px 0; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; vertical-align: top; }
    th { background: #e2e8f0; }
    ul, ol { padding-left: 1.5rem; }
    li { margin-bottom: 6px; }
    @media print { body { background: white; } main.doc { max-width: none; padding: 0; } }
  </style>
</head>
<body>
  <main class="doc">
    <h1>${escapeHtml(title)}</h1>
    <p><em>Document type: ${escapeHtml(type)}</em></p>
${body}
  </main>
</body>
</html>`
}

function markdownToHtml(md: string): string {
  const lines = md.split('\n')
  const html: string[] = []
  let inUl = false
  let inOl = false
  let inTable = false
  const closeLists = () => {
    if (inUl) { html.push('</ul>'); inUl = false }
    if (inOl) { html.push('</ol>'); inOl = false }
  }
  const closeTable = () => {
    if (inTable) { html.push('</tbody></table>'); inTable = false }
  }
  for (const raw of lines) {
    const line = raw
    if (line.trim() === '') {
      closeLists()
      closeTable()
      continue
    }
    // Headings
    if (/^###\s+/.test(line)) { closeLists(); closeTable(); html.push(`<h3>${inline(line.replace(/^###\s+/, ''))}</h3>`); continue }
    if (/^##\s+/.test(line)) { closeLists(); closeTable(); html.push(`<h2>${inline(line.replace(/^##\s+/, ''))}</h2>`); continue }
    if (/^#\s+/.test(line)) { closeLists(); closeTable(); html.push(`<h1>${inline(line.replace(/^#\s+/, ''))}</h1>`); continue }
    // Blockquote
    if (/^>\s?/.test(line)) { closeLists(); closeTable(); html.push(`<blockquote>${inline(line.replace(/^>\s?/, ''))}</blockquote>`); continue }
    // Task list item
    const task = line.match(/^[-*]\s+\[( |x|X)\]\s+(.*)$/)
    if (task) {
      if (inOl) { html.push('</ol>'); inOl = false }
      if (!inUl) { html.push('<ul>'); inUl = true }
      const checked = task[1].toLowerCase() === 'x'
      html.push(`<li><input type="checkbox" disabled${checked ? ' checked' : ''} /> ${inline(task[2])}</li>`)
      continue
    }
    // Unordered list
    const ul = line.match(/^[-*]\s+(.*)$/)
    if (ul) {
      if (inOl) { html.push('</ol>'); inOl = false }
      if (!inUl) { html.push('<ul>'); inUl = true }
      html.push(`<li>${inline(ul[1])}</li>`)
      continue
    }
    // Ordered list
    const ol = line.match(/^\d+\.\s+(.*)$/)
    if (ol) {
      if (inUl) { html.push('</ul>'); inUl = false }
      if (!inOl) { html.push('<ol>'); inOl = true }
      html.push(`<li>${inline(ol[1])}</li>`)
      continue
    }
    // Table row
    if (line.includes('|')) {
      const cells = line.split('|').map((c) => c.trim()).filter((c, i, arr) => !(i === 0 && c === '') && !(i === arr.length - 1 && c === ''))
      // Skip separator rows (e.g., | --- | --- |)
      if (cells.every((c) => /^-+:?$|^:?-+:?$|^:?-+$/.test(c))) continue
      if (!inTable) { html.push('<table><tbody>'); inTable = true }
      const isHeader = false
      const tag = isHeader ? 'th' : 'td'
      html.push(`<tr>${cells.map((c) => `<${tag}>${inline(c)}</${tag}>`).join('')}</tr>`)
      continue
    }
    closeLists()
    closeTable()
    html.push(`<p>${inline(line)}</p>`)
  }
  closeLists()
  closeTable()
  return html.join('\n')

  function inline(s: string): string {
    let out = escapeHtml(s)
    // bold
    out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    // italic
    out = out.replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>')
    // inline code
    out = out.replace(/`([^`]+)`/g, '<code>$1</code>')
    return out
  }
}

// ---------------------------------------------------------------------------
// Module
// ---------------------------------------------------------------------------

/**
 * Document module — generates structured documents (workbook, teacher guide,
 * glossary, …) with optional AI assistance and a deterministic fallback.
 */
export class DocumentModule extends BusinessModuleBase {
  readonly name = 'document'
  readonly version = '1.0.0'

  private readonly aiAdapter?: AIAdapter
  private readonly model: string

  constructor(aiAdapter?: AIAdapter, model = 'groq-llama-3.3-70b') {
    super()
    this.aiAdapter = aiAdapter
    this.model = model
  }

  getMetadata(): PluginMetadata {
    return DOCUMENT_MODULE_METADATA
  }

  getCapabilities(): Capability[] {
    return [...DOCUMENT_CAPABILITIES]
  }

  async executeJob(
    jobType: string,
    input: Record<string, unknown>,
    _ctx: BusinessContext,
  ): Promise<ExecutionResult> {
    this.markUsed()
    const start = Date.now()

    try {
      if (jobType === 'generateDocument' || jobType === 'exportDocument') {
        const topic = asString(input.topic, 'Untitled Document')
        const rawType = input.type ?? input.documentType ?? 'workbook'
        const type: DocumentType = isDocumentType(rawType) ? rawType : 'workbook'
        const sectionCount = asNumber(input.sections, SECTION_TEMPLATES[type].length, 1, 30)

        let sections: DocumentSection[]

        if (this.aiAdapter) {
          try {
            sections = await this.generateSectionsViaAI(topic, type, sectionCount)
          } catch (aiErr) {
            this.recordError(aiErr)
            sections = buildFallbackDocument(topic, type, sectionCount)
          }
        } else {
          sections = buildFallbackDocument(topic, type, sectionCount)
        }

        const title = `${typeLabel(type)}: ${topic}`
        const content = renderMarkdown(title, type, sections)
        const html = renderHtml(title, type, sections)

        const doc: GeneratedDocument = {
          title,
          topic,
          type,
          format: 'markdown',
          sections: sections.length,
          sectionList: sections,
          content,
          html,
        }

        return createSuccessResult(
          { document: doc, format: 'markdown', sections: sections.length },
          {
            durationMs: Date.now() - start,
            artifacts: [
              { id: `doc-${Date.now()}`, type: 'document', name: `${type}-${topic.toLowerCase().replace(/\s+/g, '-')}.md` },
            ],
            metrics: { providerCalls: this.aiAdapter ? 1 : 0 },
          },
        )
      }

      return createFailedResult(`Unknown job type: ${jobType}`, { durationMs: Date.now() - start })
    } catch (err) {
      this.recordError(err)
      return createFailedResult(err instanceof Error ? err.message : String(err), {
        durationMs: Date.now() - start,
      })
    }
  }

  /**
   * Calls the AI adapter with a structured prompt and parses the response
   * into typed sections. Throws on parse failure so the caller can fall back.
   */
  private async generateSectionsViaAI(
    topic: string,
    type: DocumentType,
    sectionCount: number,
  ): Promise<DocumentSection[]> {
    const promptBuilder = getPromptBuilder()
    const prompts = promptBuilder.buildDocument({
      topic,
      type,
      sections: sectionCount,
      language: 'en',
    })
    // The DocumentModule uses { heading, body } shape (not { title, content }).
    // Append the original constraints.
    const userPrompt = `${prompts.user}
Produce exactly ${sectionCount} sections.

Respond in this exact JSON shape:
{
  "title": "string — document title",
  "sections": [
    { "heading": "string", "body": "markdown body for the section" }
  ]
}

Each section body must be at least one paragraph of real content. Use markdown lists and tables where appropriate.`

    const req: ChatRequest = {
      model: this.model,
      messages: [
        { role: 'system', content: prompts.system },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.7,
      maxTokens: 4096,
    }

    const response = await this.aiAdapter!.chat(req)
    const parsed = JSON.parse(response.content) as { sections?: unknown }

    if (!parsed || !Array.isArray(parsed.sections)) {
      throw new Error('AI response missing "sections" array')
    }

    const out: DocumentSection[] = (parsed.sections as unknown[]).map((raw, i): DocumentSection => {
      const obj = (raw ?? {}) as Record<string, unknown>
      const heading = asString(obj.heading, `Section ${i + 1}`)
      const body = asString(obj.body, `Content for section ${i + 1} about ${topic}.`)
      return { heading, body }
    })

    if (out.length === 0) {
      throw new Error('AI response had zero sections')
    }
    return out
  }
}

function typeLabel(type: DocumentType): string {
  switch (type) {
    case 'workbook': return 'Workbook'
    case 'teacher-guide': return 'Teacher Guide'
    case 'student-guide': return 'Student Guide'
    case 'implementation-guide': return 'Implementation Guide'
    case 'glossary': return 'Glossary'
    case 'checklist': return 'Checklist'
    case 'resources': return 'Resources'
    default: return 'Document'
  }
}
