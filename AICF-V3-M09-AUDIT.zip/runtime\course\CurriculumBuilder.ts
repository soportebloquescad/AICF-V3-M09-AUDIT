// =============================================================================
// AICF V3 — Epica 8 — Curriculum Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { CourseRequest, Curriculum, KnowledgePack, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export interface CurriculumBuilderInput {
  knowledgePack: KnowledgePack
  courseRequest: CourseRequest
}

export class CurriculumBuilder implements EngineContract {
  readonly name = 'curriculum-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
    logger.info({ engine: this.name }, 'CurriculumBuilder: initialized')
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('CurriculumBuilder: invalid input — expected { knowledgePack, courseRequest }')
    }
    const typed = input as CurriculumBuilderInput
    if (this.opts.aiAdapter) {
      try {
        return await this.buildWithAI(typed)
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'CurriculumBuilder: AI failed, using fallback')
      }
    }
    return this.buildDeterministic(typed)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    if (typeof obj.knowledgePack !== 'object' || obj.knowledgePack === null) return false
    if (typeof obj.courseRequest !== 'object' || obj.courseRequest === null) return false
    const kp = obj.knowledgePack as Record<string, unknown>
    const cr = obj.courseRequest as Record<string, unknown>
    return typeof kp.topic === 'string' && typeof cr.topic === 'string' && typeof cr.moduleCount === 'number'
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider, latencyMs: h.latencyMs } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(input: CurriculumBuilderInput): Promise<Curriculum> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are an instructional designer. Create a curriculum with title, description, learning outcomes (array of strings), and prerequisites (array of strings). Respond in valid JSON only.',
        },
        {
          role: 'user',
          content: `Topic: ${input.courseRequest.topic}\nLevel: ${input.courseRequest.level}\nAudience: ${input.courseRequest.audience}\nModule count: ${input.courseRequest.moduleCount}\nKnowledge summary: ${input.knowledgePack.summary}\nKey facts: ${input.knowledgePack.keyFacts.slice(0, 5).join('; ')}\n\nRespond as JSON: { "title": string, "description": string, "learningOutcomes": string[], "prerequisites": string[] }`,
        },
      ],
      temperature: 0.4,
      maxTokens: 2048,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; description?: string; learningOutcomes?: string[]; prerequisites?: string[] }
    return this.assembleCurriculum(
      input,
      {
        title: parsed.title ?? `${input.courseRequest.topic} Course`,
        description: parsed.description ?? `A comprehensive course on ${input.courseRequest.topic}.`,
        learningOutcomes: parsed.learningOutcomes ?? [],
        prerequisites: parsed.prerequisites ?? [],
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(input: CurriculumBuilderInput): Curriculum {
    const parsed = {
      title: `${input.courseRequest.topic}: A ${input.courseRequest.level.charAt(0).toUpperCase() + input.courseRequest.level.slice(1)} Course`,
      description: `This curriculum provides a structured, comprehensive exploration of ${input.courseRequest.topic} for ${input.courseRequest.audience}. It builds from foundational concepts through advanced applications, drawing on the research summary and key facts assembled in the knowledge pack. Students will progress through ${input.courseRequest.moduleCount} modules designed around Bloom's taxonomy and ADDIE principles.`,
      learningOutcomes: [
        `Explain the foundational principles of ${input.courseRequest.topic}`,
        `Apply ${input.courseRequest.topic} concepts to real-world scenarios relevant to ${input.courseRequest.audience}`,
        `Analyze and evaluate different approaches within ${input.courseRequest.topic}`,
        `Design and implement ${input.courseRequest.topic} solutions appropriate to context`,
        `Critically assess the effectiveness of ${input.courseRequest.topic} strategies`,
      ],
      prerequisites: [
        `Basic familiarity with the subject area of ${input.courseRequest.topic}`,
        `General reading and analytical skills at the ${input.courseRequest.level} level`,
        `Access to a learning environment supporting ${input.courseRequest.locale} language`,
      ],
    }
    return this.assembleCurriculum(input, parsed, 'runtime-adapter', 'deterministic-fallback')
  }

  private assembleCurriculum(
    input: CurriculumBuilderInput,
    parsed: { title: string; description: string; learningOutcomes: string[]; prerequisites: string[] },
    provider: Provider,
    model: string,
  ): Curriculum {
    const now = new Date().toISOString()
    const totalDurationHours = input.courseRequest.moduleCount * 2
    return {
      id: makeId('curr'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      topic: input.courseRequest.topic,
      title: parsed.title,
      description: parsed.description,
      level: input.courseRequest.level,
      audience: input.courseRequest.audience,
      locale: input.courseRequest.locale,
      learningOutcomes: parsed.learningOutcomes,
      prerequisites: parsed.prerequisites,
      moduleCount: input.courseRequest.moduleCount,
      totalDurationHours,
      knowledgePackId: input.knowledgePack.id,
      courseRequestId: input.courseRequest.id,
    }
  }
}
