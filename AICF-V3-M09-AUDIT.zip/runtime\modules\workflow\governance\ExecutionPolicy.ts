// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Execution Policy
// =============================================================================
// Enforces per-step + workflow-wide execution guard rails:
//   - step.retries must not exceed workflow policies.maxRetries
//   - step.timeout must not exceed workflow policies.timeoutMs
//
// Workflow policies are read from `ctx.metadata.policies` when present (the
// orchestrator is expected to stash the declared `WorkflowPolicies` there
// for governance checks). When no policies are attached to the context,
// the policy allows the step (no guard rails to enforce).
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
  WorkflowPolicies,
} from '@/lib/runtime/contracts/workflow'
import type { IPolicy, PolicyDecision } from '@/lib/runtime/modules/workflow/policies/PolicyMiddleware'

/** Read workflow policies from `ctx.metadata.policies` if present. */
function readPolicies(ctx: WorkflowContext): WorkflowPolicies | null {
  const meta = ctx.metadata
  if (!meta) return null
  const p = (meta as Record<string, unknown>).policies
  if (p === null || typeof p !== 'object') return null
  return p as WorkflowPolicies
}

/**
 * Enforces per-step + workflow-wide execution guard rails. Implements
 * `IPolicy`.
 */
export class ExecutionPolicy implements IPolicy {
  readonly name = 'execution-policy'

  async check(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const policies = readPolicies(ctx)
    if (!policies) {
      // No workflow policies attached — allow.
      return { allowed: true, violations: [] }
    }
    const violations: string[] = []

    // maxRetries: step.retries must not exceed policies.maxRetries.
    if (policies.maxRetries !== undefined && step.retries > policies.maxRetries) {
      violations.push(
        `step.retries (${step.retries}) exceeds policies.maxRetries (${policies.maxRetries})`,
      )
    }

    // timeoutMs: step.timeout must not exceed policies.timeoutMs.
    if (
      policies.timeoutMs !== undefined &&
      step.timeout !== undefined &&
      step.timeout > policies.timeoutMs
    ) {
      violations.push(
        `step.timeout (${step.timeout}ms) exceeds policies.timeoutMs (${policies.timeoutMs}ms)`,
      )
    }

    return violations.length === 0
      ? { allowed: true, violations: [] }
      : {
          allowed: false,
          violations,
          reason: 'execution guard rails violated',
        }
  }
}
