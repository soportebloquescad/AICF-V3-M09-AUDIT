// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Feature Flags
// =============================================================================
// Simple boolean feature-flag registry. Defaults match Sprint 13+14 GA:
//   - scheduler : false  (cron / delayed jobs — experimental)
//   - queue     : true   (durable execution queue)
//   - cache     : true   (prompt / execution / embedding caches)
//   - audit     : true   (audit log writes)
//   - plugins   : false  (third-party plugin loading — experimental)
//
// Sprint 13+14 spec requirements covered:
//   - isEnabled(flag) — read the current value
//   - enable / disable / toggle / set — mutate flags at runtime
//   - list() — return every known flag and its value
//   - registerFlag(flag, defaultValue) — declare a new flag
// =============================================================================

import { logger } from '@/lib/ai/logger'

/** Default flag values. */
const DEFAULT_FLAGS: Readonly<Record<string, boolean>> = Object.freeze({
  scheduler: false,
  queue: true,
  cache: true,
  audit: true,
  plugins: false,
})

/**
 * Boolean feature-flag registry. Construct with the defaults above; flags
 * can be added, removed, or toggled at runtime.
 */
export class FeatureFlags {
  /** Map<flag, value>. */
  private readonly flags = new Map<string, boolean>()

  constructor() {
    for (const [flag, value] of Object.entries(DEFAULT_FLAGS)) {
      this.flags.set(flag, value)
    }
  }

  /** Whether the named flag is enabled. Unknown flags return `false`. */
  isEnabled(flag: string): boolean {
    return this.flags.get(flag) ?? false
  }

  /** Enable a flag (no-op if already enabled). */
  enable(flag: string): void {
    this.set(flag, true)
  }

  /** Disable a flag (no-op if already disabled). */
  disable(flag: string): void {
    this.set(flag, false)
  }

  /** Toggle a flag's value. Unknown flags become `true`. */
  toggle(flag: string): void {
    const next = !this.isEnabled(flag)
    this.set(flag, next)
  }

  /** Set a flag to an explicit value. */
  set(flag: string, value: boolean): void {
    const prev = this.flags.get(flag)
    this.flags.set(flag, value)
    if (prev !== value) {
      logger.debug({ flag, prev, value }, 'FeatureFlags: flag changed')
    }
  }

  /** Return every known flag and its current value. */
  list(): Record<string, boolean> {
    const out: Record<string, boolean> = {}
    for (const [flag, value] of this.flags) {
      out[flag] = value
    }
    return out
  }

  /**
   * Register a new flag with a default value. No-op if the flag already
   * exists (the existing value is preserved).
   */
  registerFlag(flag: string, defaultValue: boolean): void {
    if (this.flags.has(flag)) return
    this.flags.set(flag, defaultValue)
    logger.debug({ flag, defaultValue }, 'FeatureFlags: flag registered')
  }
}
