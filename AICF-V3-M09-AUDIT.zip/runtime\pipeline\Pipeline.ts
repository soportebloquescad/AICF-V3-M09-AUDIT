// =============================================================================
// AICF V3 — Pipeline
// =============================================================================
// Executes stages sequentially. Each stage receives the RuntimeContext
// from the previous stage and returns a NEW RuntimeContext (immutability).
//
// Sprint 4 — Immutability:
//   - Each stage receives a readonly RuntimeContext and MUST return a new
//     instance (via cloneRuntimeContext). The original is never mutated.
//   - The Pipeline reassigns `ctx = await stage.execute(ctx)` so the next
//     stage receives the returned context.
//   - When a stage throws, the Pipeline clones the context before recording
//     the error (so the original is preserved).
//   - The final response/metrics updates are done on a clone.
// =============================================================================

import type { RuntimeContext, WritableRuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { PipelineStage } from './PipelineStage'
import { logger } from '@/lib/ai/logger'

/**
 * A pipeline that executes stages sequentially.
 */
export class Pipeline {
  private readonly stages: PipelineStage[]

  constructor(stages: PipelineStage[]) {
    this.stages = stages
  }

  /**
   * Executes all stages in order.
   * If a stage sets ctx.response.ok = false, remaining stages are skipped.
   *
   * Sprint 4: each stage returns a NEW context; the Pipeline reassigns.
   * The original context passed to run() is never mutated.
   */
  async run(ctx: RuntimeContext): Promise<RuntimeContext> {
    let current: WritableRuntimeContext = cloneRuntimeContext(ctx)
    const executedStages: string[] = []

    for (const stage of this.stages) {
      if (!current.response.ok) {
        logger.debug(
          { stage: stage.name, reason: 'previous stage failed' },
          'Pipeline: skipping stage',
        )
        break
      }

      const stageStart = Date.now()
      try {
        // Stage returns a NEW context (immutability — Sprint 4)
        const next = await stage.execute(current)
        // Clone the returned context so we have a writable copy for the
        // stageResults update. If the stage returned the same reference
        // (didn't clone), this also ensures we don't mutate the original.
        current = cloneRuntimeContext(next)
        executedStages.push(stage.name)

        logger.debug(
          { stage: stage.name, durationMs: Date.now() - stageStart },
          'Pipeline: stage completed',
        )

        // Record stage result in a clone (immutability)
        current = cloneRuntimeContext(current)
        current.stageResults.set(stage.name, { ok: true, durationMs: Date.now() - stageStart })
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err)
        // Clone before recording the error (immutability)
        current = cloneRuntimeContext(current)
        current.errors = [...current.errors, { stage: stage.name, message }]
        current.response = {
          ...current.response,
          ok: false,
          error: `Stage '${stage.name}' failed: ${message}`,
          errorCode: 'PIPELINE_STAGE_ERROR',
        }
        current.stageResults.set(stage.name, { ok: false, durationMs: Date.now() - stageStart, error: message })

        logger.error(
          { stage: stage.name, error: message, durationMs: Date.now() - stageStart },
          'Pipeline: stage failed',
        )
        break
      }
    }

    // Finalize response — clone to maintain immutability
    const finalCtx = cloneRuntimeContext(current)
    const durationMs = Date.now() - finalCtx.startedAt
    finalCtx.response = {
      ...finalCtx.response,
      stages: executedStages,
      durationMs,
    }
    finalCtx.metrics = {
      ...finalCtx.metrics,
      latencyMs: durationMs,
      executionTimeMs: durationMs,
    }

    return finalCtx
  }

  /**
   * Returns the names of all stages in this pipeline.
   */
  getStageNames(): string[] {
    return this.stages.map((s) => s.name)
  }
}
