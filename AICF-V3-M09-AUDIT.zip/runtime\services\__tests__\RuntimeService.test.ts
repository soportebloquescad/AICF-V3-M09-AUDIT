// =============================================================================
// AICF V3 — RuntimeService Tests (Sprint 19: All 9 Modules Real)
// =============================================================================
// Tests for the RuntimeService with bootstrap support.
//
// Sprint 19: the ModuleRegistry constructor no longer stubs any modules.
// Tests that need modules in the registry register them explicitly via
// `register()` (using the exported `StubModule` class or real modules).
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeService, _resetGlobalBootstrap } from '../RuntimeService'
import { ModuleRegistry, StubModule } from '@/lib/runtime/registry/ModuleRegistry'
import type { RuntimeModule, ModuleHealth } from '@/lib/runtime/contracts/RuntimeModule'

describe('RuntimeService (Sprint 15)', () => {
  beforeEach(() => {
    _resetGlobalBootstrap()
  })

  it('should construct without bootstrap (backward compat)', () => {
    const service = new RuntimeService()
    expect(service).toBeDefined()
    expect(service.getBootstrap()).toBeNull()
  })

  it('should construct with bootstrap when useBootstrap=true', () => {
    const service = new RuntimeService({ useBootstrap: true, bootstrapDeps: {} })
    expect(service.getBootstrap()).not.toBeNull()
  })

  it('should initialize without bootstrap (empty registry)', async () => {
    // Sprint 19: registry starts empty — no stubs.
    const service = new RuntimeService()
    await service.initialize()
    expect(service.getModuleStatus().length).toBe(0)
  })

  it('should return runtime health for an empty registry', async () => {
    // Sprint 19: with zero modules, status is 'ready' (no modules are failing).
    const service = new RuntimeService()
    await service.initialize()
    const health = await service.getRuntimeHealth()

    expect(health).toBeDefined()
    expect(health.totalModules).toBe(0)
    expect(health.readyModules).toBe(0)
    expect(health.status).toBe('ready')
  })

  it('should return the event bus', () => {
    const service = new RuntimeService()
    const bus = service.getEventBus()
    expect(bus).toBeDefined()
    expect(typeof bus.emit).toBe('function')
  })

  it('should return the module registry', () => {
    const service = new RuntimeService()
    const reg = service.getModuleRegistry()
    expect(reg).toBeInstanceOf(ModuleRegistry)
  })

  it('should return pipeline stages', () => {
    const service = new RuntimeService()
    const stages = service.getPipelineStages()
    expect(Array.isArray(stages)).toBe(true)
    expect(stages.length).toBeGreaterThan(0)
  })

  it('should report status as degraded when some modules are ready', async () => {
    // Register one ready workflow mock plus some not-ready stubs.
    const registry = new ModuleRegistry()
    const mock: RuntimeModule = {
      name: 'test',
      version: '1.0.0',
      isReady: () => true,
      getStatus: () => ({ name: 'test', ready: true, version: '1.0.0' }),
      async initialize() {},
      async health(): Promise<ModuleHealth> {
        return {
          ready: true,
          status: 'healthy',
          startupTime: new Date().toISOString(),
          dependencies: [],
          version: '1.0.0',
          lastInitialization: new Date().toISOString(),
        }
      },
    }
    registry.register('workflow', mock)
    // Add not-ready stubs so readyModules (1) < totalModules (>1).
    registry.register('localization', new StubModule('localization', '1.0.0', 'localization'))
    registry.register('assets', new StubModule('assets', '1.0.0', 'assets'))

    const service = new RuntimeService({ moduleRegistry: registry })
    await service.initialize()
    const health = await service.getRuntimeHealth()

    expect(health.readyModules).toBe(1)
    expect(health.totalModules).toBe(3)
    expect(health.status).toBe('degraded')
  })
})
