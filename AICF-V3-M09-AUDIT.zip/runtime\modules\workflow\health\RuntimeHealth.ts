// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Runtime Health
// =============================================================================
// Aggregated health-report builder for the workflow runtime. Probes every
// subsystem (queue, provider latency, memory, workers, LiteLLM, n8n, Docker,
// Database) and returns a single `HealthReport` suitable for the `/health`
// HTTP endpoint.
//
// Sprint 13+14 spec requirements covered:
//   - Aggregated boolean `healthy` + per-subsystem `HealthCheck` breakdown
//   - Pluggable external checks (LiteLLM / n8n / Docker / Database) injected
//     via the constructor
//   - Process-memory + uptime probes (zero-dependency)
//   - Per-check latency tracking
// =============================================================================

import { logger } from '@/lib/ai/logger'
import type { MetricsCollector } from '@/lib/runtime/modules/workflow/metrics/MetricsCollector'
import type { ExecutionQueue } from '@/lib/runtime/modules/workflow/queue/ExecutionQueue'

/** A single subsystem health probe result. */
export interface HealthCheck {
  /** Subsystem name (e.g. "workflowQueue", "memory"). */
  name: string
  /** Whether the subsystem is healthy. */
  healthy: boolean
  /** Probe latency in milliseconds, when measurable. */
  latencyMs?: number
  /** Free-form details (queue size, memory bytes, etc.). */
  details?: Record<string, unknown>
  /** Error message when `healthy === false`. */
  error?: string
}

/** Aggregated health report. */
export interface HealthReport {
  /** True iff every check reported `healthy === true`. */
  healthy: boolean
  /** Epoch ms when the report was generated. */
  timestamp: number
  /** Per-subsystem checks, keyed by subsystem name. */
  checks: Record<string, HealthCheck>
  /** Human-readable summary line. */
  summary: string
}

/** External check function: returns a `HealthCheck`. */
export type ExternalCheckFn = () => Promise<HealthCheck>

/**
 * Runtime health probe orchestrator. Construct with a `MetricsCollector`
 * (required) and optional `queue` / `externalChecks`. `check()` runs every
 * probe and returns a `HealthReport`.
 */
export class RuntimeHealth {
  /** Process start time (used for uptime). */
  private readonly startedAt: number

  /**
   * @param metricsCollector Provides provider latency + call counts.
   * @param queue            Optional execution queue (probes queue size).
   * @param externalChecks   Optional named external probes (LiteLLM, n8n,
   *                         Docker, Database, ...). Keys become check names.
   */
  constructor(
    private readonly metricsCollector: MetricsCollector,
    private readonly queue?: ExecutionQueue,
    private readonly externalChecks: Record<string, ExternalCheckFn> = {},
  ) {
    // `process.uptime()` returns seconds since the Node process started.
    // We capture the start time so `getUptime()` can compute it on demand.
    this.startedAt = Date.now() - Math.floor(getProcessUptimeSeconds() * 1000)
  }

  /**
   * Run every configured probe and return an aggregated `HealthReport`.
   * Each probe is wrapped in a try/catch so a single failing probe cannot
   * abort the whole report.
   */
  async check(): Promise<HealthReport> {
    const checks: Record<string, HealthCheck> = {}

    // --- workflowQueue ----------------------------------------------------
    checks['workflowQueue'] = this.checkQueue()

    // --- providerLatency (from MetricsCollector) --------------------------
    checks['providerLatency'] = this.checkProviderLatency()

    // --- memory -----------------------------------------------------------
    checks['memory'] = this.checkMemory()

    // --- workers ----------------------------------------------------------
    checks['workers'] = this.checkWorkers()

    // --- external checks (LiteLLM / n8n / Docker / Database / ...) --------
    for (const [name, fn] of Object.entries(this.externalChecks)) {
      checks[name] = await this.runExternal(name, fn)
    }

    const healthy = Object.values(checks).every((c) => c.healthy)
    const failedCount = Object.values(checks).filter((c) => !c.healthy).length
    const summary = healthy
      ? `all ${Object.keys(checks).length} checks healthy`
      : `${failedCount} of ${Object.keys(checks).length} checks failed`

    const report: HealthReport = {
      healthy,
      timestamp: Date.now(),
      checks,
      summary,
    }
    logger.debug(
      { healthy, failedCount, checkCount: Object.keys(checks).length },
      'RuntimeHealth: check complete',
    )
    return report
  }

  /** Process uptime in seconds. */
  getUptime(): number {
    return Math.floor((Date.now() - this.startedAt) / 1000)
  }

  // ----- Individual probes -------------------------------------------------

  /** Probe the workflow execution queue size (when present). */
  private checkQueue(): HealthCheck {
    if (!this.queue) {
      return {
        name: 'workflowQueue',
        healthy: true,
        details: { configured: false },
      }
    }
    try {
      const size = this.queue.size()
      const max = 1000 // soft threshold — surface as unhealthy if exceeded
      return {
        name: 'workflowQueue',
        healthy: size <= max,
        details: { size, max },
        ...(size > max ? { error: `queue size ${size} exceeds ${max}` } : {}),
      }
    } catch (err) {
      return {
        name: 'workflowQueue',
        healthy: false,
        error: err instanceof Error ? err.message : 'queue probe failed',
      }
    }
  }

  /** Probe provider latency / error rates from the MetricsCollector. */
  private checkProviderLatency(): HealthCheck {
    try {
      const agg = this.metricsCollector.getAggregateMetrics()
      const providers = Object.values(agg.providerMetrics)
      if (providers.length === 0) {
        return {
          name: 'providerLatency',
          healthy: true,
          details: { providers: 0 },
        }
      }
      // Unhealthy if any provider has a >50% failure rate.
      const bad = providers.filter(
        (p) => p.totalCalls > 0 && p.failureCount / p.totalCalls > 0.5,
      )
      const maxLatency = Math.max(...providers.map((p) => p.avgLatencyMs))
      return {
        name: 'providerLatency',
        healthy: bad.length === 0,
        details: {
          providers: providers.length,
          maxAvgLatencyMs: maxLatency,
          failingProviders: bad.map((p) => p.provider),
        },
        ...(bad.length > 0
          ? {
              error: `${bad.length} provider(s) with >50% failure rate`,
            }
          : {}),
      }
    } catch (err) {
      return {
        name: 'providerLatency',
        healthy: false,
        error: err instanceof Error ? err.message : 'provider probe failed',
      }
    }
  }

  /** Probe process memory usage. Unhealthy if RSS exceeds 1.5 GB. */
  private checkMemory(): HealthCheck {
    try {
      const mem = process.memoryUsage()
      const rssMb = mem.rss / (1024 * 1024)
      const heapUsedMb = mem.heapUsed / (1024 * 1024)
      const heapTotalMb = mem.heapTotal / (1024 * 1024)
      const thresholdMb = 1500
      return {
        name: 'memory',
        healthy: rssMb <= thresholdMb,
        details: {
          rssMb: Math.round(rssMb),
          heapUsedMb: Math.round(heapUsedMb),
          heapTotalMb: Math.round(heapTotalMb),
          externalMb: Math.round(mem.external / (1024 * 1024)),
        },
        ...(rssMb > thresholdMb
          ? { error: `RSS ${rssMb}MB exceeds ${thresholdMb}MB` }
          : {}),
      }
    } catch (err) {
      return {
        name: 'memory',
        healthy: false,
        error: err instanceof Error ? err.message : 'memory probe failed',
      }
    }
  }

  /**
   * Probe workers. The runtime currently exposes no formal worker registry
   * (CourseWorker / ResearchWorker / WorkflowRuntime exist as standalone
   * modules), so this check returns a constant healthy=true with a note
   * describing the probe's limitation.
   */
  private checkWorkers(): HealthCheck {
    return {
      name: 'workers',
      healthy: true,
      details: {
        activeCount: 0,
        note: 'worker registry not yet wired; probe is a stub',
      },
    }
  }

  /** Run an external check function, catching any error. */
  private async runExternal(
    name: string,
    fn: ExternalCheckFn,
  ): Promise<HealthCheck> {
    const start = Date.now()
    try {
      const result = await fn()
      return {
        ...result,
        name,
        latencyMs: Date.now() - start,
      }
    } catch (err) {
      return {
        name,
        healthy: false,
        latencyMs: Date.now() - start,
        error: err instanceof Error ? err.message : 'external check failed',
      }
    }
  }
}

// ----- Helpers --------------------------------------------------------------

/** Safely read `process.uptime()` as seconds (0 if unavailable). */
function getProcessUptimeSeconds(): number {
  try {
    if (typeof process !== 'undefined' && typeof process.uptime === 'function') {
      return process.uptime()
    }
  } catch {
    // ignore — best-effort
  }
  return 0
}
