// =============================================================================
// AICF V3 — Sprint 10 — InteractiveHtmlEngine (premium HTML slides)
// =============================================================================
// Generates a self-contained HTML slide deck from GeneratedSlide[].
// Features: cover, index, quizzes, dark mode, navigation, progress bar,
// speaker notes, SVG images, Mermaid diagrams, print CSS, responsive.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import type { GeneratedSlide, PremiumGeneratedSlide } from './SlideGenerator'
import { logger } from '@/lib/ai/logger'

export class InteractiveHtmlEngine {
  private readonly log = logger.child({ component: 'InteractiveHtmlEngine' })

  build(opts: {
    title: string
    slides: GeneratedSlide[]
    theme: ThemePreset
    countryName?: string
  }): string {
    const { title, slides, theme, countryName } = opts
    this.log.info({ slideCount: slides.length, theme: theme.name }, 'InteractiveHtmlEngine: building')

    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderBaseCss(theme)
    const slidesHtml = slides.map((s) => this.buildSlideHtml(s, theme)).join('\n')
    const tocHtml = this.buildToc(slides)

    return `<!DOCTYPE html>
<html lang="${countryName ? 'es' : 'en'}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escape(title)} — Premium Slides</title>
  <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
  <style>
    ${themeCss}
    body { overflow: hidden; }
    .slide-deck { height: 100vh; display: flex; flex-direction: column; }
    .progress-bar { height: 4px; background: var(--color-border); flex-shrink: 0; }
    .progress-fill { height: 100%; background: var(--color-accent); transition: width 0.3s; }
    .slide-container { flex: 1; position: relative; overflow: hidden; }
    .slide { position: absolute; inset: 0; display: none; flex-direction: column; padding: 3rem; overflow-y: auto; animation: slideIn 0.4s ease; }
    .slide.active { display: flex; }
    @keyframes slideIn { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
    .slide h1 { font-size: 2.5rem; color: var(--color-primary); margin-bottom: 0.5rem; }
    .slide h2 { font-size: 1.8rem; color: var(--color-primary); margin-bottom: 1rem; }
    .slide .subtitle { font-size: 1.2rem; color: var(--color-text-muted); margin-bottom: 2rem; }
    .slide .content { font-size: 1.1rem; line-height: 1.8; flex: 1; }
    .slide .bullets { list-style: none; padding: 0; }
    .slide .bullets li { padding: 0.5rem 0; border-bottom: 1px solid var(--color-border); }
    .slide .bullets li:last-child { border-bottom: none; }
    .slide .svg-image { margin: 1rem 0; border-radius: var(--radius); overflow: hidden; }
    .slide .svg-image svg { width: 100%; height: auto; display: block; }
    .slide .mermaid { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1rem; margin: 1rem 0; text-align: center; }
    .slide .speaker-notes { background: var(--color-surface); border-top: 2px solid var(--color-border); padding: 1rem; font-size: 0.85rem; color: var(--color-text-muted); display: none; margin-top: auto; }
    .slide .speaker-notes.visible { display: block; }
    .slide.cover { justify-content: center; align-items: center; text-align: center; }
    .slide.cover .svg-image { max-width: 800px; }
    .slide.quiz .content { background: var(--color-surface); border-radius: var(--radius); padding: 2rem; }
    .toc-panel { position: fixed; top: 0; left: -280px; width: 280px; height: 100vh; background: var(--color-surface); border-right: 1px solid var(--color-border); overflow-y: auto; transition: left 0.3s; z-index: 200; padding: 1rem; }
    .toc-panel.visible { left: 0; }
    .toc-panel h3 { color: var(--color-primary); margin-bottom: 1rem; }
    .toc-panel a { display: block; padding: 0.5rem; color: var(--color-text); border-radius: var(--radius); cursor: pointer; }
    .toc-panel a:hover { background: var(--color-border); }
    .controls { padding: 0.5rem 2rem; background: var(--color-surface); border-top: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; }
    .btn { background: var(--color-accent); color: white; border: none; padding: 0.5rem 1.5rem; border-radius: var(--radius); cursor: pointer; font-size: 0.9rem; font-family: var(--font-heading); }
    .btn:disabled { opacity: 0.3; cursor: not-allowed; }
    .btn.secondary { background: transparent; color: var(--color-text); border: 1px solid var(--color-border); }
    .counter { color: var(--color-text-muted); font-size: 0.85rem; }
    .theme-btn, .notes-btn, .toc-btn { position: fixed; top: 1rem; right: 1rem; background: var(--color-accent); color: white; border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 1.2rem; z-index: 100; display: flex; align-items: center; justify-content: center; }
    .notes-btn { right: 4rem; border-radius: var(--radius); width: auto; padding: 0 0.8rem; font-size: 0.85rem; }
    .toc-btn { right: 8rem; border-radius: var(--radius); width: auto; padding: 0 0.8rem; font-size: 0.85rem; }
    [data-theme="light"] { --color-background: #ffffff; --color-surface: #f8fafc; --color-text: #1e293b; --color-text-muted: #64748b; --color-border: #e2e8f0; }
    [data-theme="dark"] { --color-background: #0f172a; --color-surface: #1e293b; --color-text: #f1f5f9; --color-text-muted: #94a3b8; --color-border: #334155; }
    @media (max-width: 768px) { .slide { padding: 1.5rem; } .slide h1 { font-size: 1.8rem; } .toc-btn, .notes-btn { display: none; } }
    @media print { .slide { position: relative; page-break-after: always; display: flex !important; } .controls, .theme-btn, .notes-btn, .toc-btn, .toc-panel { display: none !important; } }
  </style>
</head>
<body>
  <button class="toc-btn" onclick="toggleToc()">☰ Index</button>
  <button class="notes-btn" onclick="toggleNotes()">📝 Notes</button>
  <button class="theme-btn" onclick="toggleTheme()">🌓</button>
  <div class="toc-panel" id="tocPanel">
    <h3>Index</h3>
    ${tocHtml}
  </div>
  <div class="slide-deck">
    <div class="progress-bar"><div class="progress-fill" id="progress" style="width: 0%"></div></div>
    <div class="slide-container" id="container">
      ${slidesHtml}
    </div>
    <div class="controls">
      <button class="btn secondary" id="prev" onclick="prev()" disabled>← Prev</button>
      <span class="counter" id="counter">1 / ${slides.length}</span>
      <button class="btn" id="next" onclick="next()">Next →</button>
    </div>
  </div>
  <script>
    let current = 0;
    const total = ${slides.length};
    const slides = document.querySelectorAll('.slide');
    const counter = document.getElementById('counter');
    const progress = document.getElementById('progress');
    const prevBtn = document.getElementById('prev');
    const nextBtn = document.getElementById('next');

    function show(idx) {
      slides.forEach((s, i) => s.classList.toggle('active', i === idx));
      counter.textContent = (idx + 1) + ' / ' + total;
      progress.style.width = ((idx + 1) / total * 100) + '%';
      prevBtn.disabled = idx === 0;
      nextBtn.disabled = idx === total - 1;
      current = idx;
      // Render mermaid diagrams
      if (window.mermaid) {
        const active = slides[idx];
        const mermaidDivs = active.querySelectorAll('.mermaid:not([data-rendered])');
        mermaidDivs.forEach((d) => {
          d.setAttribute('data-rendered', 'true');
          try { mermaid.run({ nodes: [d] }); } catch(e) {}
        });
      }
    }
    function next() { if (current < total - 1) show(current + 1); }
    function prev() { if (current > 0) show(current - 1); }
    function toggleTheme() { document.body.dataset.theme = document.body.dataset.theme === 'dark' ? 'light' : 'dark'; }
    function toggleNotes() { const active = slides[current]; const notes = active.querySelector('.speaker-notes'); if (notes) notes.classList.toggle('visible'); }
    function toggleToc() { document.getElementById('tocPanel').classList.toggle('visible'); }
    function goTo(idx) { show(idx); toggleToc(); }
    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') next();
      if (e.key === 'ArrowLeft') prev();
      if (e.key === 'n') toggleNotes();
      if (e.key === 't') toggleTheme();
      if (e.key === 'Escape') document.getElementById('tocPanel').classList.remove('visible');
    });
    if (window.mermaid) mermaid.initialize({ startOnLoad: false, theme: 'default' });
    show(0);
  </script>
</body>
</html>`
  }

  private buildToc(slides: GeneratedSlide[]): string {
    return slides.map((s, i) => {
      const icon = this.slideIcon(s.type)
      return `<a onclick="goTo(${i})">${icon} ${i + 1}. ${this.escape(s.title)}</a>`
    }).join('')
  }

  private buildSlideHtml(slide: GeneratedSlide, theme: ThemePreset): string {
    const bulletsHtml = slide.bullets.length > 0
      ? `<ul class="bullets">${slide.bullets.map((b) => `<li>${this.escape(b)}</li>`).join('')}</ul>`
      : ''
    const imageHtml = slide.svgImage ? `<div class="svg-image">${slide.svgImage}</div>` : ''
    const mermaidHtml = slide.mermaidDiagram ? `<div class="mermaid">${slide.mermaidDiagram}</div>` : ''
    const countryBadge = slide.countryName ? `<div style="margin-bottom:1rem"><span style="background:var(--color-accent);color:white;padding:0.2rem 0.8rem;border-radius:var(--radius);font-size:0.8rem;font-weight:bold;">🌍 ${this.escape(slide.countryName)}</span></div>` : ''

    return `<div class="slide ${slide.type}" data-index="${slide.index}">
      <h1>${this.escape(slide.title)}</h1>
      <p class="subtitle">${this.escape(slide.subtitle)}</p>
      ${countryBadge}
      <div class="content">
        ${imageHtml}
        ${mermaidHtml}
        ${bulletsHtml}
      </div>
      <div class="speaker-notes">📝 ${this.escape(slide.speakerNotes)}</div>
    </div>`
  }

  private slideIcon(type: string): string {
    const icons: Record<string, string> = {
      cover: '🎬', agenda: '📋', content: '📖', diagram: '📊',
      quiz: '❓', summary: '✅', country: '🌍',
      'quiz-interactive': '🧠', exercise: '💪', 'case-study': '📋',
    }
    return icons[type] ?? '📄'
  }

  // ===========================================================================
  // Sprint 11A — Premium slide deck builder
  // ===========================================================================
  // Renders PremiumGeneratedSlide[] (with quiz, exercise, caseStudy) into
  // interactive HTML. The existing build() method is preserved.
  // ===========================================================================

  buildPremium(opts: {
    title: string
    slides: PremiumGeneratedSlide[]
    theme: ThemePreset
    countryName?: string
  }): string {
    const { title, slides, theme, countryName } = opts
    this.log.info({ slideCount: slides.length, theme: theme.name }, 'InteractiveHtmlEngine: building premium')

    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderBaseCss(theme)
    const slidesHtml = slides.map((s) => this.buildPremiumSlideHtml(s)).join('\n')
    const tocHtml = this.buildPremiumToc(slides)

    return `<!DOCTYPE html>
<html lang="${countryName ? 'es' : 'en'}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escape(title)} — Premium Slides</title>
  <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
  <style>
    ${themeCss}
    body { overflow: hidden; }
    .slide-deck { height: 100vh; display: flex; flex-direction: column; }
    .progress-bar { height: 4px; background: var(--color-border); flex-shrink: 0; }
    .progress-fill { height: 100%; background: var(--color-accent); transition: width 0.3s; }
    .slide-container { flex: 1; position: relative; overflow: hidden; }
    .slide { position: absolute; inset: 0; display: none; flex-direction: column; padding: 2.5rem; overflow-y: auto; animation: slideIn 0.4s ease; }
    .slide.active { display: flex; }
    @keyframes slideIn { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
    .slide h1 { font-size: 2rem; color: var(--color-primary); margin-bottom: 0.4rem; }
    .slide .subtitle { font-size: 1.1rem; color: var(--color-text-muted); margin-bottom: 1.5rem; }
    .slide .content { font-size: 1rem; line-height: 1.7; flex: 1; }
    .slide .bullets { list-style: none; padding: 0; }
    .slide .bullets li { padding: 0.4rem 0; border-bottom: 1px solid var(--color-border); }
    .slide .bullets li:last-child { border-bottom: none; }
    .slide .svg-image { margin: 0.8rem 0; border-radius: var(--radius); overflow: hidden; }
    .slide .svg-image svg { width: 100%; height: auto; display: block; }
    .slide .mermaid { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1rem; margin: 0.8rem 0; text-align: center; }
    .slide .speaker-notes { background: var(--color-surface); border-top: 2px solid var(--color-border); padding: 0.8rem; font-size: 0.8rem; color: var(--color-text-muted); display: none; margin-top: auto; }
    .slide .speaker-notes.visible { display: block; }
    .slide.cover { justify-content: center; align-items: center; text-align: center; }
    .slide .country-badge { background: var(--color-accent); color: white; padding: 0.2rem 0.8rem; border-radius: var(--radius); font-size: 0.75rem; font-weight: bold; display: inline-block; margin-bottom: 0.8rem; }
    .slide .objectives { background: var(--color-surface); border-left: 4px solid var(--color-accent); padding: 0.8rem 1rem; margin: 0.8rem 0; border-radius: 0 var(--radius) var(--radius) 0; }
    .slide .objectives ul { margin: 0; padding-left: 1.2rem; }
    .slide .objectives li { font-size: 0.9rem; color: var(--color-text); margin: 0.3rem 0; }
    .slide .quote { font-style: italic; color: var(--color-text-muted); border-left: 3px solid var(--color-accent); padding-left: 1rem; margin: 0.8rem 0; font-size: 0.95rem; }
    .slide .example { background: var(--color-surface); border-radius: var(--radius); padding: 1rem; margin: 0.8rem 0; }
    .slide .example h4 { color: var(--color-accent); margin: 0 0 0.5rem; font-size: 0.9rem; }
    .slide .example p { font-size: 0.85rem; color: var(--color-text); margin: 0 0 0.5rem; }
    .slide .example pre { background: var(--color-background); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 0.6rem; overflow-x: auto; font-size: 0.8rem; }
    .slide .example code { font-family: 'JetBrains Mono', monospace; }
    .slide .quiz-question { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1rem; margin: 0.8rem 0; }
    .slide .quiz-question h4 { color: var(--color-primary); margin: 0 0 0.5rem; font-size: 0.95rem; }
    .slide .quiz-option { display: block; padding: 0.5rem 0.8rem; margin: 0.3rem 0; border: 1px solid var(--color-border); border-radius: var(--radius); cursor: pointer; font-size: 0.85rem; transition: all 0.2s; }
    .slide .quiz-option:hover { background: var(--color-border); }
    .slide .quiz-option.correct { background: var(--color-success); color: white; border-color: var(--color-success); }
    .slide .quiz-option.incorrect { background: var(--color-danger); color: white; border-color: var(--color-danger); }
    .slide .quiz-feedback { display: none; margin-top: 0.5rem; padding: 0.6rem; background: var(--color-background); border-radius: var(--radius); font-size: 0.8rem; color: var(--color-text); }
    .slide .quiz-feedback.visible { display: block; }
    .slide .exercise-steps { counter-reset: step; }
    .slide .exercise-step { counter-increment: step; padding: 0.6rem 0 0.6rem 2.5rem; position: relative; border-bottom: 1px solid var(--color-border); }
    .slide .exercise-step::before { content: counter(step); position: absolute; left: 0; top: 0.6rem; width: 1.8rem; height: 1.8rem; background: var(--color-primary); color: var(--color-primary-fg); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; }
    .slide .exercise-step h4 { margin: 0 0 0.3rem; font-size: 0.9rem; color: var(--color-primary); }
    .slide .exercise-step p { margin: 0; font-size: 0.82rem; color: var(--color-text-muted); }
    .slide .exercise-step pre { margin: 0.4rem 0 0; background: var(--color-background); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 0.5rem; font-size: 0.78rem; overflow-x: auto; }
    .slide .rubric { width: 100%; border-collapse: collapse; margin: 0.8rem 0; font-size: 0.82rem; }
    .slide .rubric th { background: var(--color-primary); color: var(--color-primary-fg); padding: 0.5rem; text-align: left; }
    .slide .rubric td { padding: 0.5rem; border-bottom: 1px solid var(--color-border); }
    .slide .rubric td.weight { font-weight: bold; color: var(--color-accent); }
    .slide .case-study { background: var(--color-surface); border-radius: var(--radius); padding: 1rem; margin: 0.8rem 0; }
    .slide .case-study h4 { color: var(--color-accent); margin: 0 0 0.5rem; font-size: 0.9rem; }
    .slide .case-study p { font-size: 0.85rem; margin: 0.3rem 0; color: var(--color-text); }
    .slide .case-study .takeaway { background: var(--color-background); border-left: 3px solid var(--color-success); padding: 0.5rem 0.8rem; margin-top: 0.5rem; font-style: italic; }
    .toc-panel { position: fixed; top: 0; left: -280px; width: 280px; height: 100vh; background: var(--color-surface); border-right: 1px solid var(--color-border); overflow-y: auto; transition: left 0.3s; z-index: 200; padding: 1rem; }
    .toc-panel.visible { left: 0; }
    .toc-panel h3 { color: var(--color-primary); margin-bottom: 1rem; }
    .toc-panel a { display: block; padding: 0.4rem; color: var(--color-text); border-radius: var(--radius); cursor: pointer; font-size: 0.85rem; }
    .toc-panel a:hover { background: var(--color-border); }
    .controls { padding: 0.5rem 2rem; background: var(--color-surface); border-top: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; }
    .btn { background: var(--color-accent); color: white; border: none; padding: 0.5rem 1.5rem; border-radius: var(--radius); cursor: pointer; font-size: 0.85rem; font-family: var(--font-heading); }
    .btn:disabled { opacity: 0.3; cursor: not-allowed; }
    .btn.secondary { background: transparent; color: var(--color-text); border: 1px solid var(--color-border); }
    .counter { color: var(--color-text-muted); font-size: 0.8rem; }
    .theme-btn, .notes-btn, .toc-btn { position: fixed; top: 1rem; right: 1rem; background: var(--color-accent); color: white; border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 1.2rem; z-index: 100; display: flex; align-items: center; justify-content: center; }
    .notes-btn { right: 4rem; border-radius: var(--radius); width: auto; padding: 0 0.8rem; font-size: 0.8rem; }
    .toc-btn { right: 8rem; border-radius: var(--radius); width: auto; padding: 0 0.8rem; font-size: 0.8rem; }
    [data-theme="light"] { --color-background: #ffffff; --color-surface: #f8fafc; --color-text: #1e293b; --color-text-muted: #64748b; --color-border: #e2e8f0; }
    [data-theme="dark"] { --color-background: #0f172a; --color-surface: #1e293b; --color-text: #f1f5f9; --color-text-muted: #94a3b8; --color-border: #334155; }
    @media (max-width: 768px) { .slide { padding: 1.5rem; } .slide h1 { font-size: 1.5rem; } .toc-btn, .notes-btn { display: none; } }
    @media print { .slide { position: relative; page-break-after: always; display: flex !important; } .controls, .theme-btn, .notes-btn, .toc-btn, .toc-panel { display: none !important; } }
  </style>
</head>
<body>
  <button class="toc-btn" onclick="toggleToc()">☰ Index</button>
  <button class="notes-btn" onclick="toggleNotes()">📝 Notes</button>
  <button class="theme-btn" onclick="toggleTheme()">🌓</button>
  <div class="toc-panel" id="tocPanel"><h3>Index</h3>${tocHtml}</div>
  <div class="slide-deck">
    <div class="progress-bar"><div class="progress-fill" id="progress" style="width: 0%"></div></div>
    <div class="slide-container" id="container">${slidesHtml}</div>
    <div class="controls">
      <button class="btn secondary" id="prev" onclick="prev()" disabled>← Prev</button>
      <span class="counter" id="counter">1 / ${slides.length}</span>
      <button class="btn" id="next" onclick="next()">Next →</button>
    </div>
  </div>
  <script>
    let current = 0; const total = ${slides.length};
    const slides = document.querySelectorAll('.slide');
    const counter = document.getElementById('counter');
    const progress = document.getElementById('progress');
    const prevBtn = document.getElementById('prev'); const nextBtn = document.getElementById('next');
    function show(idx) {
      slides.forEach((s, i) => s.classList.toggle('active', i === idx));
      counter.textContent = (idx + 1) + ' / ' + total;
      progress.style.width = ((idx + 1) / total * 100) + '%';
      prevBtn.disabled = idx === 0; nextBtn.disabled = idx === total - 1; current = idx;
      if (window.mermaid) { const active = slides[idx]; const mermaidDivs = active.querySelectorAll('.mermaid:not([data-rendered])');
        mermaidDivs.forEach((d) => { d.setAttribute('data-rendered', 'true'); try { mermaid.run({ nodes: [d] }); } catch(e) {} }); }
    }
    function next() { if (current < total - 1) show(current + 1); }
    function prev() { if (current > 0) show(current - 1); }
    function toggleTheme() { document.body.dataset.theme = document.body.dataset.theme === 'dark' ? 'light' : 'dark'; }
    function toggleNotes() { const active = slides[current]; const notes = active.querySelector('.speaker-notes'); if (notes) notes.classList.toggle('visible'); }
    function toggleToc() { document.getElementById('tocPanel').classList.toggle('visible'); }
    function goTo(idx) { show(idx); toggleToc(); }
    function checkAnswer(qIdx, optIdx, correctIdx) {
      const question = document.querySelectorAll('.quiz-question')[qIdx];
      if (!question) return;
      const options = question.querySelectorAll('.quiz-option');
      options.forEach((opt, i) => {
        opt.classList.remove('correct', 'incorrect');
        if (i === correctIdx) opt.classList.add('correct');
        else if (i === optIdx) opt.classList.add('incorrect');
      });
      const feedback = question.querySelector('.quiz-feedback');
      if (feedback) feedback.classList.add('visible');
    }
    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') next();
      if (e.key === 'ArrowLeft') prev();
      if (e.key === 'n') toggleNotes(); if (e.key === 't') toggleTheme();
      if (e.key === 'Escape') document.getElementById('tocPanel').classList.remove('visible');
    });
    if (window.mermaid) mermaid.initialize({ startOnLoad: false, theme: 'default' });
    show(0);
  </script>
</body>
</html>`
  }

  private buildPremiumToc(slides: PremiumGeneratedSlide[]): string {
    return slides.map((s, i) => {
      const icon = this.slideIcon(s.type)
      return `<a onclick="goTo(${i})">${icon} ${i + 1}. ${this.escape(s.title)}</a>`
    }).join('')
  }

  private buildPremiumSlideHtml(slide: PremiumGeneratedSlide): string {
    const bulletsHtml = slide.bullets.length > 0
      ? `<ul class="bullets">${slide.bullets.map((b) => `<li>${this.escape(b)}</li>`).join('')}</ul>` : ''
    const imageHtml = slide.svgImage ? `<div class="svg-image">${slide.svgImage}</div>` : ''
    const mermaidHtml = slide.mermaidDiagram ? `<div class="mermaid">${slide.mermaidDiagram}</div>` : ''
    const countryBadge = slide.countryName ? `<div class="country-badge">🌍 ${this.escape(slide.countryName)}</div>` : ''
    const objectivesHtml = slide.learningObjectives.length > 0
      ? `<div class="objectives"><strong>Learning objectives:</strong><ul>${slide.learningObjectives.map((o) => `<li>${this.escape(o)}</li>`).join('')}</ul></div>` : ''
    const quoteHtml = slide.quote ? `<div class="quote">${this.escape(slide.quote)}</div>` : ''
    const exampleHtml = slide.practicalExample ? `<div class="example"><h4>📝 ${this.escape(slide.practicalExample.title)}</h4><p>${this.escape(slide.practicalExample.description)}</p>${slide.practicalExample.code ? `<pre><code>${this.escape(slide.practicalExample.code)}</code></pre>` : ''}</div>` : ''
    const caseStudyHtml = slide.caseStudy ? `<div class="case-study"><h4>📋 ${this.escape(slide.caseStudy.title)}</h4><p><strong>Scenario:</strong> ${this.escape(slide.caseStudy.scenario)}</p><p><strong>Challenge:</strong> ${this.escape(slide.caseStudy.challenge)}</p><p><strong>Solution:</strong> ${this.escape(slide.caseStudy.solution)}</p><p><strong>Outcome:</strong> ${this.escape(slide.caseStudy.outcome)}</p><div class="takeaway">💡 ${this.escape(slide.caseStudy.takeaway)}</div></div>` : ''
    const quizHtml = slide.quiz && slide.quiz.length > 0
      ? slide.quiz.map((q, qi) => `<div class="quiz-question" data-quiz="${qi}"><h4>Q${qi + 1}: ${this.escape(q.question)}</h4>${q.options.map((opt, oi) => `<label class="quiz-option" onclick="checkAnswer(${qi}, ${oi}, ${q.correctIndex})">${this.escape(opt)}</label>`).join('')}<div class="quiz-feedback">💡 ${this.escape(q.explanation)}</div></div>`).join('') : ''
    const exerciseHtml = slide.exercise ? `<div class="exercise"><p><strong>Difficulty:</strong> ${this.escape(slide.exercise.difficulty)} | <strong>Time:</strong> ${slide.exercise.estimatedMinutes} min</p><div class="exercise-steps">${slide.exercise.steps.map((step) => `<div class="exercise-step"><h4>${this.escape(step.title)}</h4><p>${this.escape(step.description)}</p>${step.code ? `<pre><code>${this.escape(step.code)}</code></pre>` : ''}</div>`).join('')}</div>${slide.exercise.exampleCode ? `<div class="example"><h4>Example code</h4><pre><code>${this.escape(slide.exercise.exampleCode)}</code></pre></div>` : ''}<h4 style="margin-top:0.8rem;color:var(--color-primary)">Evaluation Rubric</h4><table class="rubric"><thead><tr><th>Criterion</th><th>Weight</th><th>Description</th></tr></thead><tbody>${slide.exercise.rubric.map((r) => `<tr><td>${this.escape(r.name)}</td><td class="weight">${r.weight}%</td><td>${this.escape(r.description)}</td></tr>`).join('')}</tbody></table></div>` : ''

    return `<div class="slide ${slide.type}" data-index="${slide.index}">
      <h1>${this.escape(slide.title)}</h1>
      <p class="subtitle">${this.escape(slide.subtitle)}</p>
      ${countryBadge}
      <div class="content">
        ${imageHtml}
        ${mermaidHtml}
        ${objectivesHtml}
        ${quoteHtml}
        ${exampleHtml}
        ${caseStudyHtml}
        ${quizHtml}
        ${exerciseHtml}
        ${bulletsHtml}
      </div>
      <div class="speaker-notes">📝 ${this.escape(slide.speakerNotes)}</div>
    </div>`
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }
}
