// =============================================================================
// AICF V3 — Epica 8 — Quality Assurance Engine
// =============================================================================
// Implements EngineContract with 6 validators:
// validateCurriculum, validateLessons, validateCoverage, validateConsistency,
// validateDuplication, validatePedagogy.
// =============================================================================
import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { CourseResult, QualityReport, QualityValidatorResult, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

/**
 * EPIC 10 — Content Quality Report contract.
 * 6 pedagogical checks per lesson.
 */
export interface ContentQualityReport {
  lessonId: string
  checks: {
    noPlaceholders: { passed: boolean; details: string[] }
    specificity: { passed: boolean; details: string[] }
    realExamples: { passed: boolean; details: string[] }
    coherence: { passed: boolean; details: string[] }
    progression: { passed: boolean; details: string[] }
    objectivesMet: { passed: boolean; details: string[] }
  }
  score: number
  issues: string[]
  recommendations: string[]
}

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

function nowIso(): string {
  return new Date().toISOString()
}

export class QualityAssurance implements EngineContract {
  readonly name = 'quality-assurance'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('QualityAssurance: invalid input — expected CourseResult')
    }
    const course = input as CourseResult
    return this.validateCourse(course)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    return typeof obj.id === 'string' && typeof obj.topic === 'string' && Array.isArray(obj.lessons)
  }

  async health(): Promise<HealthStatus> {
    return { healthy: this.healthy, details: { validators: 6 } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  validateCourse(course: CourseResult): QualityReport {
    const validators: QualityValidatorResult[] = []
    validators.push(this.validateCurriculum(course))
    validators.push(this.validateLessons(course))
    validators.push(this.validateCoverage(course))
    validators.push(this.validateConsistency(course))
    validators.push(this.validateDuplication(course))
    validators.push(this.validatePedagogy(course))

    const allIssues = validators.flatMap((v) => v.issues)
    const passed = validators.every((v) => v.passed)
    const score = Math.round(validators.reduce((sum, v) => sum + v.score, 0) / validators.length)
    const recommendations = this.buildRecommendations(validators)
    const reasons = this.buildReasons(course, validators, score)
    const warnings = this.buildWarnings(course, validators)
    const provider: Provider = course.provider
    const model = course.model

    const report: QualityReport = {
      id: makeId('qr'),
      version: ENGINE_VERSION,
      createdAt: nowIso(),
      updatedAt: nowIso(),
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      courseResultId: course.id,
      overallScore: score,
      passed,
      validators,
      issues: allIssues,
      recommendations,
      reasons,
      warnings,
    }
    logger.info({ courseId: course.id, score, passed, issues: allIssues.length }, 'QualityAssurance: validation complete')
    return report
  }

  /**
   * EPIC 10 — Content QA: produces a ContentQualityReport with the 6 checks
   * specified by EPIC 10 (noPlaceholders, specificity, realExamples, coherence,
   * progression, objectivesMet). Reuses the existing validator logic but maps
   * results into the ContentQualityReport contract.
   */
  validateContent(course: CourseResult): ContentQualityReport {
    const reports: ContentQualityReport[] = course.lessons.map((lesson) => {
      const noPlaceholders = this.checkNoPlaceholders(lesson)
      const specificity = this.checkSpecificity(lesson, course.topic)
      const realExamples = this.checkRealExamples(lesson)
      const coherence = this.checkCoherence(lesson, course)
      const progression = this.checkProgression(lesson, course.lessons)
      const objectivesMet = this.checkObjectivesMet(lesson)

      const checks = [noPlaceholders, specificity, realExamples, coherence, progression, objectivesMet]
      const passedCount = checks.filter((c) => c.passed).length
      const score = Math.round((passedCount / checks.length) * 100)
      const issues = checks.filter((c) => !c.passed).flatMap((c) => c.details)
      const recommendations = issues.map((i) => `Improve: ${i}`)

      return {
        lessonId: lesson.id,
        checks: { noPlaceholders, specificity, realExamples, coherence, progression, objectivesMet },
        score,
        issues,
        recommendations,
      }
    })

    // Return aggregate if multiple lessons, else return single
    if (reports.length === 0) {
      return {
        lessonId: 'none',
        checks: {
          noPlaceholders: { passed: true, details: ['No lessons to validate'] },
          specificity: { passed: true, details: ['No lessons to validate'] },
          realExamples: { passed: true, details: ['No lessons to validate'] },
          coherence: { passed: true, details: ['No lessons to validate'] },
          progression: { passed: true, details: ['No lessons to validate'] },
          objectivesMet: { passed: true, details: ['No lessons to validate'] },
        },
        score: 100,
        issues: [],
        recommendations: [],
      }
    }

    // For multi-lesson courses, return the aggregate (average score)
    if (reports.length === 1) return reports[0]
    const avgScore = Math.round(reports.reduce((s, r) => s + r.score, 0) / reports.length)
    const allIssues = reports.flatMap((r) => r.issues)
    return {
      lessonId: `aggregate (${reports.length} lessons)`,
      checks: reports[0].checks, // representative
      score: avgScore,
      issues: allIssues,
      recommendations: allIssues.slice(0, 10),
    }
  }

  // EPIC 10 content QA helpers
  private checkNoPlaceholders(lesson: { content: string; title: string }): { passed: boolean; details: string[] } {
    const details: string[] = []
    const placeholderPatterns = [/lorem\s+ipsum/i, /TODO/i, /FIXME/i, /placeholder/i, /<insert/i, /<your/i, /TBD/i, /xxx/i]
    let found = false
    for (const p of placeholderPatterns) {
      if (p.test(lesson.content)) {
        details.push(`Placeholder pattern '${p.source}' found in lesson "${lesson.title}"`)
        found = true
      }
    }
    if (lesson.content.trim().length < 100) {
      details.push(`Lesson "${lesson.title}" content too short (<100 chars)`)
      found = true
    }
    return { passed: !found, details: details.length > 0 ? details : ['No placeholders detected'] }
  }

  private checkSpecificity(lesson: { content: string; title: string }, topic: string): { passed: boolean; details: string[] } {
    const details: string[] = []
    const genericPhrases = ['this topic', 'this concept', 'this subject', 'as mentioned', 'in general', 'various aspects', 'etc']
    let genericCount = 0
    for (const g of genericPhrases) {
      const matches = lesson.content.toLowerCase().split(g).length - 1
      genericCount += matches
    }
    if (genericCount > 3) {
      details.push(`Lesson "${lesson.title}" uses ${genericCount} generic phrases`)
    }
    // Check if topic keyword appears at least once
    const topicWords = topic.toLowerCase().split(/\s+/).filter((w) => w.length > 3)
    const contentLower = lesson.content.toLowerCase()
    const topicMentions = topicWords.filter((w) => contentLower.includes(w)).length
    if (topicMentions === 0 && topicWords.length > 0) {
      details.push(`Lesson "${lesson.title}" does not mention the topic keywords`)
    }
    return { passed: details.length === 0, details: details.length > 0 ? details : ['Content is specific to the topic'] }
  }

  private checkRealExamples(lesson: { content: string; title: string }): { passed: boolean; details: string[] } {
    const details: string[] = []
    const exampleIndicators = [/example/i, /for instance/i, /such as/i, /e\.g\./i, /case/i, /scenario/i, /in practice/i]
    const hasExample = exampleIndicators.some((p) => p.test(lesson.content))
    if (!hasExample) {
      details.push(`Lesson "${lesson.title}" lacks concrete examples`)
    }
    return { passed: hasExample, details: details.length > 0 ? details : ['Contains concrete examples'] }
  }

  private checkCoherence(lesson: { content: string; title: string; keyTakeaways: string[] }, course: CourseResult): { passed: boolean; details: string[] } {
    const details: string[] = []
    // Check if lesson title keywords appear in content
    const titleWords = lesson.title.toLowerCase().split(/\s+/).filter((w) => w.length > 3)
    const contentLower = lesson.content.toLowerCase()
    const titleMentions = titleWords.filter((w) => contentLower.includes(w)).length
    if (titleMentions < Math.ceil(titleWords.length / 2)) {
      details.push(`Lesson "${lesson.title}" content does not sufficiently reference the title concept`)
    }
    return { passed: details.length === 0, details: details.length > 0 ? details : ['Content is coherent with title'] }
  }

  private checkProgression(lesson: { bloomLevel: string; lessonIndex: number }, allLessons: Array<{ bloomLevel: string; lessonIndex: number; title: string }>): { passed: boolean; details: string[] } {
    const details: string[] = []
    const bloomOrder = ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create']
    const currentBloomIdx = bloomOrder.indexOf(lesson.bloomLevel)
    if (currentBloomIdx === -1) {
      details.push(`Lesson has invalid Bloom level: ${lesson.bloomLevel}`)
    } else {
      // Check if earlier lessons have lower or equal Bloom levels
      const earlier = allLessons.filter((l) => l.lessonIndex < lesson.lessonIndex)
      for (const e of earlier) {
        const eIdx = bloomOrder.indexOf(e.bloomLevel)
        if (eIdx > currentBloomIdx) {
          details.push(`Progression issue: earlier lesson "${e.title}" has higher Bloom level (${e.bloomLevel}) than current (${lesson.bloomLevel})`)
        }
      }
    }
    return { passed: details.length === 0, details: details.length > 0 ? details : ['Bloom progression is sound'] }
  }

  private checkObjectivesMet(lesson: { content: string; learningObjectives: string[]; title: string }): { passed: boolean; details: string[] } {
    const details: string[] = []
    if (lesson.learningObjectives.length === 0) {
      details.push(`Lesson "${lesson.title}" has no learning objectives`)
      return { passed: false, details }
    }
    const contentLower = lesson.content.toLowerCase()
    const unmet = lesson.learningObjectives.filter((obj) => {
      const keywords = obj.toLowerCase().split(/\s+/).filter((w) => w.length > 4)
      return keywords.length > 0 && !keywords.some((k) => contentLower.includes(k))
    })
    if (unmet.length > 0) {
      details.push(`Lesson "${lesson.title}": ${unmet.length} objective(s) not reflected in content`)
    }
    return { passed: details.length === 0, details: details.length > 0 ? details : ['All objectives reflected in content'] }
  }

  // 1. Curriculum validation
  private validateCurriculum(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    if (!course.curriculum) {
      issues.push('No curriculum defined')
      score = 0
    } else {
      if (course.curriculum.learningOutcomes.length === 0) {
        issues.push('Curriculum has no learning outcomes')
        score -= 20
      }
      if (course.curriculum.prerequisites.length === 0) {
        issues.push('Curriculum has no prerequisites listed')
        score -= 10
      }
      if (course.curriculum.moduleCount !== course.modules.length) {
        issues.push(`Curriculum expects ${course.curriculum.moduleCount} modules, found ${course.modules.length}`)
        score -= 15
      }
      if (course.curriculum.topic !== course.topic) {
        issues.push(`Curriculum topic mismatch: "${course.curriculum.topic}" vs "${course.topic}"`)
        score -= 10
      }
      details.outcomeCount = course.curriculum.learningOutcomes.length
      details.prerequisiteCount = course.curriculum.prerequisites.length
      details.moduleCountMatch = course.curriculum.moduleCount === course.modules.length
    }

    return { name: 'curriculum', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  // 2. Lessons validation
  private validateLessons(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    if (course.lessons.length === 0) {
      issues.push('No lessons generated')
      score = 0
    } else {
      const shortLessons = course.lessons.filter((l) => l.wordCount < 100)
      if (shortLessons.length > 0) {
        issues.push(`${shortLessons.length} lessons have fewer than 100 words`)
        score -= shortLessons.length * 5
      }
      const lessonsWithoutObjectives = course.lessons.filter((l) => l.learningObjectives.length === 0)
      if (lessonsWithoutObjectives.length > 0) {
        issues.push(`${lessonsWithoutObjectives.length} lessons have no learning objectives`)
        score -= lessonsWithoutObjectives.length * 5
      }
      const lessonsWithoutTakeaways = course.lessons.filter((l) => l.keyTakeaways.length === 0)
      if (lessonsWithoutTakeaways.length > 0) {
        issues.push(`${lessonsWithoutTakeaways.length} lessons have no key takeaways`)
        score -= lessonsWithoutTakeaways.length * 3
      }
      const totalWords = course.lessons.reduce((s, l) => s + l.wordCount, 0)
      const avgWords = totalWords / course.lessons.length
      details.totalWords = totalWords
      details.averageWords = Math.round(avgWords)
      details.shortLessonCount = shortLessons.length
    }

    return { name: 'lessons', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  // 3. Coverage validation
  private validateCoverage(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    const lessonsByModule = new Map<string, number>()
    for (const lesson of course.lessons) {
      lessonsByModule.set(lesson.moduleId, (lessonsByModule.get(lesson.moduleId) ?? 0) + 1)
    }
    const modulesWithoutLessons = course.modules.filter((m) => (lessonsByModule.get(m.id) ?? 0) === 0)
    if (modulesWithoutLessons.length > 0) {
      issues.push(`${modulesWithoutLessons.length} modules have no lessons`)
      score -= modulesWithoutLessons.length * 15
    }

    const lessonsWithExercises = new Set(course.exercises.map((e) => e.lessonId))
    const lessonsWithoutExercises = course.lessons.filter((l) => !lessonsWithExercises.has(l.id))
    if (lessonsWithoutExercises.length > 0) {
      issues.push(`${lessonsWithoutExercises.length} lessons have no exercises`)
      score -= lessonsWithoutExercises.length * 3
    }

    const modulesWithQuizzes = new Set(course.quizzes.map((q) => q.moduleId))
    const modulesWithoutQuizzes = course.modules.filter((m) => !modulesWithQuizzes.has(m.id))
    if (modulesWithoutQuizzes.length > 0) {
      issues.push(`${modulesWithoutQuizzes.length} modules have no quizzes`)
      score -= modulesWithoutQuizzes.length * 5
    }

    details.modulesWithoutLessons = modulesWithoutLessons.length
    details.lessonsWithoutExercises = lessonsWithoutExercises.length
    details.modulesWithoutQuizzes = modulesWithoutQuizzes.length

    return { name: 'coverage', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  // 4. Consistency validation
  private validateConsistency(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    const bloomLevels = new Set(course.lessons.map((l) => l.bloomLevel))
    if (bloomLevels.size === 1) {
      issues.push(`All lessons use the same Bloom level (${Array.from(bloomLevels)[0]}) — no progression`)
      score -= 10
    }

    const moduleProviders = new Set(course.modules.map((m) => m.provider))
    if (moduleProviders.size > 2) {
      issues.push(`Modules generated by ${moduleProviders.size} different providers — possible inconsistency`)
      score -= 5
    }

    if (course.curriculum) {
      const curriculumLocale = course.curriculum.locale
      const lessonWithDifferentLocale = course.lessons.find((l) => !l.content.toLowerCase().includes(course.curriculum!.topic.toLowerCase().split(' ')[0] ?? ''))
      if (lessonWithDifferentLocale) {
        details.localeCheck = 'topic keyword present in lessons'
      }
      details.expectedLocale = curriculumLocale
    }

    const avgDuration = course.lessons.length > 0 ? course.lessons.reduce((s, l) => s + l.durationMinutes, 0) / course.lessons.length : 0
    const durationVariance = course.lessons.length > 0
      ? Math.sqrt(course.lessons.reduce((s, l) => s + Math.pow(l.durationMinutes - avgDuration, 2), 0) / course.lessons.length)
      : 0
    if (durationVariance > avgDuration * 0.5) {
      issues.push(`High variance in lesson durations (avg ${Math.round(avgDuration)}min, stddev ${Math.round(durationVariance)}min)`)
      score -= 8
    }
    details.avgDurationMinutes = Math.round(avgDuration)
    details.durationStddev = Math.round(durationVariance)

    return { name: 'consistency', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  // 5. Duplication validation
  private validateDuplication(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    const lessonTitles = course.lessons.map((l) => l.title.toLowerCase())
    const titleSet = new Set<string>()
    const duplicates: string[] = []
    for (const title of lessonTitles) {
      if (titleSet.has(title)) duplicates.push(title)
      titleSet.add(title)
    }
    if (duplicates.length > 0) {
      issues.push(`${duplicates.length} duplicate lesson titles found`)
      score -= duplicates.length * 5
    }

    const phraseMap = new Map<string, number>()
    for (const lesson of course.lessons) {
      const phrases = lesson.content.toLowerCase().match(/\b(\w+\s+){4,}\w+\b/g) ?? []
      for (const p of phrases) {
        phraseMap.set(p, (phraseMap.get(p) ?? 0) + 1)
      }
    }
    const repeatedAcrossLessons = Array.from(phraseMap.entries()).filter(([, count]) => count > 1)
    if (repeatedAcrossLessons.length > 5) {
      issues.push(`${repeatedAcrossLessons.length} phrases repeated across multiple lessons — possible duplication`)
      score -= Math.min(20, repeatedAcrossLessons.length)
    }
    details.duplicateTitles = duplicates.length
    details.repeatedPhrases = repeatedAcrossLessons.length

    return { name: 'duplication', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  // 6. Pedagogy validation
  private validatePedagogy(course: CourseResult): QualityValidatorResult {
    const issues: string[] = []
    const details: Record<string, unknown> = {}
    let score = 100

    const validBloomLevels = ['remember', 'understand', 'apply', 'analyze', 'evaluate', 'create']
    const invalidBloom = course.lessons.filter((l) => !validBloomLevels.includes(l.bloomLevel.toLowerCase()))
    if (invalidBloom.length > 0) {
      issues.push(`${invalidBloom.length} lessons have invalid Bloom levels`)
      score -= invalidBloom.length * 5
    }

    const bloomProgression = course.lessons.map((l) => validBloomLevels.indexOf(l.bloomLevel.toLowerCase()))
    let hasProgression = false
    for (let i = 1; i < bloomProgression.length; i++) {
      if (bloomProgression[i]! > bloomProgression[i - 1]!) {
        hasProgression = true
        break
      }
    }
    if (course.lessons.length > 3 && !hasProgression) {
      issues.push('No Bloom-level progression detected across lessons')
      score -= 10
    }

    const lessonsWithObjectives = course.lessons.filter((l) => l.learningObjectives.length >= 2).length
    const objectivesRatio = course.lessons.length > 0 ? lessonsWithObjectives / course.lessons.length : 0
    if (objectivesRatio < 0.8) {
      issues.push(`${Math.round((1 - objectivesRatio) * 100)}% of lessons have fewer than 2 learning objectives`)
      score -= 10
    }

    if (course.assessments.length === 0) {
      issues.push('No assessments defined — pedagogical evaluation missing')
      score -= 15
    }

    details.bloomProgression = hasProgression
    details.objectivesRatio = Math.round(objectivesRatio * 100) / 100
    details.assessmentCount = course.assessments.length

    return { name: 'pedagogy', passed: issues.length === 0, score: Math.max(0, score), issues, details }
  }

  private buildRecommendations(validators: QualityValidatorResult[]): string[] {
    const recommendations: string[] = []
    for (const v of validators) {
      if (v.passed) continue
      switch (v.name) {
        case 'curriculum':
          recommendations.push('Review curriculum completeness: ensure learning outcomes, prerequisites, and module count are aligned with generated content.')
          break
        case 'lessons':
          recommendations.push('Strengthen lessons: add learning objectives, expand short lessons, and include key takeaways.')
          break
        case 'coverage':
          recommendations.push('Improve coverage: ensure every module has lessons, every lesson has exercises, and every module has a quiz.')
          break
        case 'consistency':
          recommendations.push('Improve consistency: vary Bloom levels, reduce provider diversity, and normalize lesson durations.')
          break
        case 'duplication':
          recommendations.push('Remove duplication: rewrite lessons with duplicate titles or heavily repeated phrases.')
          break
        case 'pedagogy':
          recommendations.push('Strengthen pedagogy: ensure valid Bloom levels, progression across lessons, and adequate assessments.')
          break
      }
    }
    if (recommendations.length === 0) {
      recommendations.push('Course meets all quality criteria. Ready for publication.')
    }
    return recommendations
  }

  private buildReasons(course: CourseResult, validators: QualityValidatorResult[], score: number): string[] {
    const reasons: string[] = []
    reasons.push(`Overall score: ${score}/100 (threshold: 80)`)
    reasons.push(`Modules: ${course.modules.length}, Lessons: ${course.lessons.length}, Exercises: ${course.exercises.length}, Quizzes: ${course.quizzes.length}`)
    reasons.push(`Total words: ${course.totalWordCount}`)
    const passedCount = validators.filter((v) => v.passed).length
    reasons.push(`Validators passed: ${passedCount}/${validators.length}`)
    for (const v of validators) {
      if (!v.passed) reasons.push(`${v.name} validator scored ${v.score}/100: ${v.issues.join('; ')}`)
    }
    if (score >= 80) reasons.push('Course passed the quality threshold.')
    else reasons.push('Course FAILED the quality threshold.')
    return reasons
  }

  private buildWarnings(course: CourseResult, _validators: QualityValidatorResult[]): string[] {
    const warnings: string[] = []
    if (course.lessons.length === 0) warnings.push('No lessons generated.')
    for (const lesson of course.lessons) {
      if (lesson.content.includes('[placeholder') || lesson.content.includes('TODO') || lesson.content.includes('Lorem ipsum')) {
        warnings.push(`Lesson "${lesson.title}" contains placeholder text.`)
      }
      if (lesson.wordCount < 100) warnings.push(`Lesson "${lesson.title}" is very short (${lesson.wordCount} words).`)
      const codeBlockCount = (lesson.content.match(/```/g) ?? []).length
      if (codeBlockCount % 2 !== 0) warnings.push(`Lesson "${lesson.title}" has an unclosed code block.`)
    }
    if (course.quizzes.length < course.modules.length) warnings.push(`Only ${course.quizzes.length} quizzes for ${course.modules.length} modules.`)
    if (course.exercises.length < course.lessons.length) warnings.push(`Only ${course.exercises.length} exercises for ${course.lessons.length} lessons.`)
    return warnings
  }
}
