// =============================================================================
// AICF V3 — Sprint 13+14 — Artifact Storage Interface
// =============================================================================
// Persistent storage for `WorkflowArtifact`s. Implementations may back this
// with a local filesystem, an object store (S3 / GCS / Azure Blob), or a
// database — the contract is identical.
//
// Sprint 13+14 spec requirements covered:
//   - CRUD over artifacts keyed by id
//   - Lookup by execution and by step (for the UI's drill-down views)
//   - `getLineage` returns the provenance graph for reproducibility /
//     "regenerate from prompt" workflows
// =============================================================================

import type {
  WorkflowArtifact,
  ArtifactLineage,
} from '@/lib/runtime/contracts/workflow'

/**
 * Artifact storage contract. Implementations SHOULD be content-addressed: an
 * artifact with the same `hash` may be stored once and referenced by id.
 */
export interface IArtifactStorage {
  /** Persist an artifact. Idempotent on `id`. */
  save(artifact: WorkflowArtifact): Promise<void>
  /** Load an artifact by id, or null if not found. */
  load(id: string): Promise<WorkflowArtifact | null>
  /** Delete an artifact by id. No-op if not found. */
  delete(id: string): Promise<void>
  /** List all artifacts produced by an execution. */
  listByExecution(executionId: string): Promise<WorkflowArtifact[]>
  /** List all artifacts produced by a specific step within an execution. */
  listByStep(executionId: string, stepId: string): Promise<WorkflowArtifact[]>
  /** Return the provenance graph for an artifact, or null if not found. */
  getLineage(id: string): Promise<ArtifactLineage | null>
}
