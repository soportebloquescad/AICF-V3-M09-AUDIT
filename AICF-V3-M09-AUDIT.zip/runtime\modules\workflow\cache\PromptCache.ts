// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Prompt Cache
// =============================================================================
// Caches LLM completions keyed by a SHA-256 hash of (prompt + model + params).
// Enables deduplication of identical prompt calls within a workflow run.
//
// Sprint 13+14 spec requirements covered:
//   - `get(promptHash)` / `set(promptHash, response, ttlMs?)`
//   - `computeHash(prompt, model, params)` — deterministic SHA-256
//   - `clear()` for forced invalidation
//   - `getStats()` returns entry count + hit rate (tracks hits + misses)
// =============================================================================

import { createHash } from 'crypto'
import { logger } from '@/lib/ai/logger'

/** A cached prompt response. */
export interface CachedPrompt {
  /** SHA-256 hash of (prompt + model + params). */
  hash: string
  /** The cached response content. */
  content: string
  /** Model that produced the cached response. */
  model: string
  /** Epoch ms when the entry was created. */
  createdAt: number
  /** Epoch ms when the entry expires (Infinity = no TTL). */
  expiresAt: number
}

/** Options for constructing a `PromptCache`. */
export interface PromptCacheOptions {
  /** Default TTL applied when `set` is called without an explicit TTL. */
  defaultTtlMs?: number
}

/**
 * In-memory prompt-response cache. Keys are SHA-256 hashes computed by
 * `computeHash(prompt, model, params)`; values are `CachedPrompt` envelopes
 * that carry the response, the model attribution, and the expiry timestamp.
 */
export class PromptCache {
  /** Map<hash, CachedPrompt>. */
  private readonly entries = new Map<string, CachedPrompt>()
  /** Default TTL applied when `set` is called without an explicit TTL. */
  private readonly defaultTtlMs: number
  /** Total cache hits since construction. */
  private hits = 0
  /** Total cache misses since construction. */
  private misses = 0

  constructor(opts: PromptCacheOptions = {}) {
    this.defaultTtlMs = opts.defaultTtlMs ?? 0
  }

  /**
   * Look up a cached response by hash. Returns null on miss or expiry.
   * Counts the lookup as either a hit or a miss.
   */
  async get(promptHash: string): Promise<CachedPrompt | null> {
    const entry = this.entries.get(promptHash)
    if (!entry) {
      this.misses += 1
      return null
    }
    if (entry.expiresAt !== Infinity && entry.expiresAt <= Date.now()) {
      this.entries.delete(promptHash)
      this.misses += 1
      return null
    }
    this.hits += 1
    return entry
  }

  /**
   * Store a cached response. Overwrites any prior entry for the same hash.
   * When `ttlMs` is omitted and no default was configured, the entry never
   * expires.
   */
  async set(
    promptHash: string,
    response: string,
    ttlMs?: number,
  ): Promise<void> {
    const ttl = ttlMs ?? this.defaultTtlMs
    const now = Date.now()
    this.entries.set(promptHash, {
      hash: promptHash,
      content: response,
      model: '', // populated by the caller via a separate `set` overload?
      createdAt: now,
      expiresAt: ttl > 0 ? now + ttl : Infinity,
    })
  }

  /**
   * Store a cached response WITH model attribution. Convenience overload
   * for callers that want to record which model produced the response.
   */
  async setWithModel(
    promptHash: string,
    response: string,
    model: string,
    ttlMs?: number,
  ): Promise<void> {
    const ttl = ttlMs ?? this.defaultTtlMs
    const now = Date.now()
    this.entries.set(promptHash, {
      hash: promptHash,
      content: response,
      model,
      createdAt: now,
      expiresAt: ttl > 0 ? now + ttl : Infinity,
    })
  }

  /**
   * Compute a deterministic SHA-256 hash over (prompt, model, params).
   * The params object is canonicalized (sorted keys at every level) before
   * hashing so that `{ a: 1, b: 2 }` and `{ b: 2, a: 1 }` produce the same
   * hash.
   */
  computeHash(
    prompt: string,
    model: string,
    params: Record<string, unknown>,
  ): string {
    const canonical = canonicalJson({
      prompt,
      model,
      params,
    })
    return createHash('sha256').update(canonical).digest('hex')
  }

  /** Clear all cached entries. Resets hit/miss counters? No — those are
   * lifetime counters and persist across clears. */
  clear(): void {
    this.entries.clear()
    logger.debug('PromptCache: cleared')
  }

  /**
   * Return cache statistics. `hitRate` is `hits / (hits + misses)` (0 when
   * no lookups have occurred).
   */
  getStats(): { entries: number; hitRate: number } {
    const total = this.hits + this.misses
    return {
      entries: this.entries.size,
      hitRate: total > 0 ? this.hits / total : 0,
    }
  }
}

// ----- Helpers --------------------------------------------------------------

/** Canonical JSON serializer (sorted keys at every level). */
function canonicalJson(value: unknown): string {
  if (value === null) return 'null'
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'null'
  if (typeof value === 'boolean') return String(value)
  if (Array.isArray(value)) {
    const items = value.map((v) => canonicalJson(v)).join(',')
    return `[${items}]`
  }
  if (typeof value === 'object') {
    const obj = value as Record<string, unknown>
    const keys = Object.keys(obj).sort()
    const pairs = keys
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`)
      .join(',')
    return `{${pairs}}`
  }
  return 'null'
}
