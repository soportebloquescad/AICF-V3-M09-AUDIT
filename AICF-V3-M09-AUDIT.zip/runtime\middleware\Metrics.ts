// =============================================================================
// AICF V3 — Sprint 2 — Metrics Middleware
// =============================================================================
import type { RuntimeMetrics } from '../contracts/RuntimeContext'

export function createEmptyMetrics(): RuntimeMetrics {
  return {
    latencyMs: 0,
    tokensPrompt: 0,
    tokensCompletion: 0,
    tokensTotal: 0,
    provider: null,
    model: null,
    cost: 0,
    estimatedCost: 0,
    cacheHit: false,
    retryCount: 0,
    executionTimeMs: 0,
    pipelineTimeMs: 0,
    providerTimeMs: 0,
  }
}

export interface MetricsCollector {
  record(stage: string, durationMs: number): void
  get(stage: string): number | undefined
  getAll(): Record<string, number>
}

export function createMetricsCollector(): MetricsCollector {
  const metrics = new Map<string, number>()
  return {
    record(stage: string, durationMs: number): void {
      metrics.set(stage, durationMs)
    },
    get(stage: string): number | undefined {
      return metrics.get(stage)
    },
    getAll(): Record<string, number> {
      const result: Record<string, number> = {}
      for (const [key, value] of metrics) {
        result[key] = value
      }
      return result
    },
  }
}
