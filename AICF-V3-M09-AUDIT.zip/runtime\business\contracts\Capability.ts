// =============================================================================
// AICF V3 — Business Capability Contract (Épica 2 — AI Factory Core)
// =============================================================================
// A Capability is a typed declaration of a single business operation a
// module exposes. Capabilities are registered with the
// BusinessCapabilityRegistry (B6) so the BusinessModuleRegistry (B5) can
// route a JobRequest to the right module by `jobType` -> capability name.
//
// Differences vs the existing `Capabilities.ts` (which lists string
// constants for the Runtime-layer modules):
//   - This Capability is a structured descriptor with optional JSON-Schema-
//     shaped input/output schemas and a version string. It mirrors the
//     shape third-party plugins will eventually publish.
//   - The Runtime-layer capability strings stay where they are; the Business
//     layer uses `Capability.name` (e.g. 'createCourse') as its own key.
//
// No `any`.
// =============================================================================

/**
 * A typed declaration of a single business operation a module exposes.
 */
export interface Capability {
  /** Capability name (e.g. 'createCourse', 'createSlides'). */
  name: string

  /** Human-readable description of what this capability does. */
  description: string

  /**
   * Optional JSON-Schema-shaped description of the input the capability
   * accepts. Used by the Business layer to validate JobRequest.input before
   * dispatching.
   */
  inputSchema?: Record<string, unknown>

  /**
   * Optional JSON-Schema-shaped description of the output the capability
   * produces. Used for contract testing + dashboard rendering.
   */
  outputSchema?: Record<string, unknown>

  /** Semantic version of this capability (defaults to '1.0.0'). */
  version: string
}

/**
 * Factory: creates a Capability with sensible defaults.
 *
 * @example
 * const cap = createCapability('createCourse', 'Generate a full course', {
 *   version: '1.2.0',
 *   inputSchema: { type: 'object', properties: { topic: { type: 'string' } } },
 * })
 */
export function createCapability(
  name: string,
  description: string,
  opts?: {
    inputSchema?: Record<string, unknown>
    outputSchema?: Record<string, unknown>
    version?: string
  },
): Capability {
  return {
    name,
    description,
    inputSchema: opts?.inputSchema,
    outputSchema: opts?.outputSchema,
    version: opts?.version ?? '1.0.0',
  }
}
