// =============================================================================
// AICF V3 — CapabilityRegistry Tests (Sprint 16)
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { CapabilityRegistry } from '../CapabilityRegistry'

describe('CapabilityRegistry', () => {
  let registry: CapabilityRegistry

  beforeEach(() => {
    registry = new CapabilityRegistry()
  })

  it('should register a module with capabilities', () => {
    registry.register('content-intelligence', ['routeModel', 'applyPolicy'])
    expect(registry.getCapabilities('content-intelligence')).toEqual(['routeModel', 'applyPolicy'])
  })

  it('should return empty array for unknown module', () => {
    expect(registry.getCapabilities('unknown')).toEqual([])
  })

  it('should find modules by capability', () => {
    registry.register('content-intelligence', ['routeModel', 'applyPolicy'])
    registry.register('infrastructure', ['chatCompletion', 'health'])
    expect(registry.getModulesByCapability('routeModel')).toEqual(['content-intelligence'])
    expect(registry.getModulesByCapability('chatCompletion')).toEqual(['infrastructure'])
    expect(registry.getModulesByCapability('unknown')).toEqual([])
  })

  it('should find multiple modules with the same capability', () => {
    registry.register('m1', ['generate'])
    registry.register('m2', ['generate'])
    const modules = registry.getModulesByCapability('generate')
    expect(modules).toContain('m1')
    expect(modules).toContain('m2')
    expect(modules.length).toBe(2)
  })

  it('should unregister a module and clean up capability mappings', () => {
    registry.register('m1', ['cap1', 'cap2'])
    registry.unregister('m1')
    expect(registry.getCapabilities('m1')).toEqual([])
    expect(registry.getModulesByCapability('cap1')).toEqual([])
    expect(registry.getModulesByCapability('cap2')).toEqual([])
  })

  it('should check if a module has a specific capability', () => {
    registry.register('m1', ['cap1', 'cap2'])
    expect(registry.hasCapability('m1', 'cap1')).toBe(true)
    expect(registry.hasCapability('m1', 'cap3')).toBe(false)
  })

  it('should list all modules', () => {
    registry.register('m1', ['cap1'])
    registry.register('m2', ['cap2'])
    expect(registry.getModules()).toContain('m1')
    expect(registry.getModules()).toContain('m2')
  })

  it('should list all capabilities', () => {
    registry.register('m1', ['cap1', 'cap2'])
    registry.register('m2', ['cap3'])
    const caps = registry.getAllCapabilities()
    expect(caps).toContain('cap1')
    expect(caps).toContain('cap2')
    expect(caps).toContain('cap3')
  })

  it('should return descriptors', () => {
    registry.register('m1', ['cap1', 'cap2'])
    const descriptors = registry.getDescriptors()
    expect(descriptors.length).toBe(2)
    expect(descriptors.some((d) => d.moduleId === 'm1' && d.capability === 'cap1')).toBe(true)
  })

  it('should return a serializable snapshot', () => {
    registry.register('m1', ['cap1'])
    registry.register('m2', ['cap2'])
    const snap = registry.snapshot()
    expect(snap.length).toBe(2)
    expect(snap.some((s) => s.moduleId === 'm1' && s.capabilities.includes('cap1'))).toBe(true)
  })

  it('should clear all registrations', () => {
    registry.register('m1', ['cap1'])
    registry.clear()
    expect(registry.getModules().length).toBe(0)
    expect(registry.getAllCapabilities().length).toBe(0)
  })
})
