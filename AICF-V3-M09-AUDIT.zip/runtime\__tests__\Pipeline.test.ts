// =============================================================================
// AICF V3 — Pipeline Tests
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { Pipeline } from '../pipeline/Pipeline'
import { createPipelineStage } from '../pipeline/PipelineStage'
import { createRuntimeContext, cloneRuntimeContext } from '../contracts/RuntimeContext'
import { createRuntimeRequest } from '../contracts/RuntimeRequest'

describe('Pipeline', () => {
  it('should execute stages sequentially', async () => {
    const order: string[] = []

    const stages = [
      createPipelineStage('A', async (ctx) => {
        order.push('A')
        const next = cloneRuntimeContext(ctx)
        next.provider = 'test-provider'
        return next
      }),
      createPipelineStage('B', async (ctx) => {
        order.push('B')
        const next = cloneRuntimeContext(ctx)
        next.model = 'test-model'
        return next
      }),
      createPipelineStage('C', async (ctx) => {
        order.push('C')
        const next = cloneRuntimeContext(ctx)
        next.content = 'test-content'
        return next
      }),
    ]

    const pipeline = new Pipeline(stages)
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const result = await pipeline.run(ctx)

    expect(order).toEqual(['A', 'B', 'C'])
    expect(result.provider).toBe('test-provider')
    expect(result.model).toBe('test-model')
    expect(result.content).toBe('test-content')
  })

  it('should stop on stage failure', async () => {
    const order: string[] = []

    const stages = [
      createPipelineStage('A', async (ctx) => {
        order.push('A')
        return ctx
      }),
      createPipelineStage('B', async (ctx) => {
        order.push('B')
        const next = cloneRuntimeContext(ctx)
        next.response = { ...next.response, ok: false, error: 'Stage B failed' }
        return next
      }),
      createPipelineStage('C', async (ctx) => {
        order.push('C')
        return ctx
      }),
    ]

    const pipeline = new Pipeline(stages)
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const result = await pipeline.run(ctx)

    expect(order).toEqual(['A', 'B'])
    expect(result.response.ok).toBe(false)
    expect(result.response.error).toContain('Stage B failed')
  })

  it('should catch thrown errors', async () => {
    const stages = [
      createPipelineStage('Boom', async (ctx) => {
        throw new Error('Explosion!')
      }),
    ]

    const pipeline = new Pipeline(stages)
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const result = await pipeline.run(ctx)

    expect(result.response.ok).toBe(false)
    expect(result.response.error).toContain('Explosion')
    expect(result.errors.length).toBe(1)
    expect(result.errors[0].stage).toBe('Boom')
  })

  it('should record executed stage names', async () => {
    const stages = [
      createPipelineStage('Validate', async (ctx) => ctx),
      createPipelineStage('Policy', async (ctx) => ctx),
      createPipelineStage('Response', async (ctx) => ctx),
    ]

    const pipeline = new Pipeline(stages)
    const request = createRuntimeRequest({ operation: 'chat' })
    const ctx = createRuntimeContext(request)

    const result = await pipeline.run(ctx)

    expect(result.response.stages).toEqual(['Validate', 'Policy', 'Response'])
  })
})
