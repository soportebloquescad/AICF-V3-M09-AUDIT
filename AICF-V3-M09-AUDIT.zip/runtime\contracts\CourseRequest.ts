// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — CourseRequest (extends ArtifactRequest)
// =============================================================================
// Course-specific artifact request. Extends the universal ArtifactRequest
// with fields specific to course generation.
//
// COMPATIBILITY: This is the Runtime-layer course request. The legacy
// src/lib/course/CourseRequest.ts (BFF-layer) is NOT modified and remains
// used by CourseService / CourseWorker. This new contract is the universal
// artifact-layer course request that extends ArtifactRequest.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { ArtifactRequest, ArtifactLevel } from './ArtifactRequest'
import type { ResearchDepth } from './ResearchPlan'

/**
 * A course-specific artifact request.
 *
 * Extends ArtifactRequest with course-generation fields:
 *   - moduleCount: how many modules to generate
 *   - researchDepth: how deep the research phase should go
 *   - includeExercises / includeQuizzes / includeSlides / includeGuides
 *     (toggles for companion artifacts)
 *
 * The `type` field is fixed to 'course' — callers should use
 * createCourseRequest() which sets it automatically.
 */
export interface CourseRequest extends ArtifactRequest {
  /** Number of modules to generate. */
  moduleCount: number

  /** Depth of the research phase before generation. */
  researchDepth: ResearchDepth

  /** Whether to generate exercises for each module. */
  includeExercises: boolean

  /** Whether to generate quizzes for each module. */
  includeQuizzes: boolean

  /** Whether to generate slide decks for each module. */
  includeSlides: boolean

  /** Whether to generate study guides for each module. */
  includeGuides: boolean
}

/**
 * Factory: creates a CourseRequest with sensible defaults.
 *
 * Sets `type: 'course'` automatically and defaults the toggles to true.
 *
 * @example
 * const req = createCourseRequest({ topic: 'Intro to Rust', moduleCount: 5 })
 */
export function createCourseRequest(
  partial: Partial<CourseRequest> & Pick<CourseRequest, 'topic'>,
): CourseRequest {
  return {
    type: 'course',
    level: 'intermediate' as ArtifactLevel,
    language: 'en',
    audience: 'general learners',
    metadata: {},
    parameters: {},
    moduleCount: 3,
    researchDepth: 'standard',
    includeExercises: true,
    includeQuizzes: true,
    includeSlides: false,
    includeGuides: true,
    ...partial,
  }
}
