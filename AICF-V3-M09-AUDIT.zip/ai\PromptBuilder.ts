// =============================================================================
// AICF V3 — Épica 1 — PromptBuilder (Centralized Prompts)
// =============================================================================
// Single source of truth for ALL AI prompts in AICF V3. Replaces the 4×
// duplication of the "expert instructional designer" prompt that lived inline
// in CourseModule, PresentationModule, QuizModule, DocumentModule, plus the
// unused ai/prompts/ module.
//
// Design (per Épica 1 spec): SPECIFIC methods per product type — no generic
// build(). Each method returns { system, user } ready to feed into a
// ChatRequest.
//
// No `any` — `unknown` everywhere. Narrow with type guards.
// =============================================================================

// ---------------------------------------------------------------------------
// Input types — one per product type
// ---------------------------------------------------------------------------

export interface CourseInput {
  topic: string
  level: string
  moduleCount: number
  language: string
  /** 'outline' | 'modules' — CourseModule does 2 AI calls. */
  phase: 'outline' | 'modules'
  /** For phase='modules' — the resolved course title. */
  courseTitle?: string
}

export interface PresentationInput {
  topic: string
  slideCount: number
  language: string
  /** Optional audience hint. */
  audience?: string
}

export interface QuizInput {
  topic: string
  questionCount: number
  difficulty: string
  language: string
}

export interface DocumentInput {
  topic: string
  /** 'workbook' | 'teacher-guide' | 'student-guide' | 'implementation-guide' | 'glossary' | 'checklist' | 'resources' */
  type: string
  /** Optional number of sections (DocumentModule accepts this). */
  sections?: number
  language: string
}

export interface ChatInput {
  /** The user's message. */
  message: string
  /** Optional topic context. */
  topic?: string
}

export interface SystemInput {
  /** Free-form purpose, e.g. 'generate lesson content'. */
  purpose: string
  /** Optional topic. */
  topic?: string
  /** Optional JSON schema hint. */
  jsonSchemaHint?: string
}

// ---------------------------------------------------------------------------
// Shared system prompt (the "expert instructional designer" prompt that was
// duplicated 4× across the codebase).
// ---------------------------------------------------------------------------

/**
 * The canonical "expert instructional designer" system prompt. Used by every
 * product-type builder. Centralized here to eliminate the 4× duplication
 * flagged in the RC3 audit.
 */
export const EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM =
  'You are an expert instructional designer. Respond ONLY with valid JSON. ' +
  'The JSON must match the requested schema exactly — no markdown fences, no commentary.'

/**
 * The default chat system prompt (previously in ai/prompts/chat/index.ts).
 */
export const DEFAULT_CHAT_SYSTEM =
  'You are AICF Assistant, a helpful AI course factory assistant. ' +
  'You help users create courses, generate content, and answer questions about the AICF V3 platform. ' +
  'Always be clear, concise, and professional.'

// ---------------------------------------------------------------------------
// PromptBuilder interface — specific methods per product type
// ---------------------------------------------------------------------------

export interface PromptBuilder {
  buildCourse(input: CourseInput): { system: string; user: string }
  buildPresentation(input: PresentationInput): { system: string; user: string }
  buildQuiz(input: QuizInput): { system: string; user: string }
  buildDocument(input: DocumentInput): { system: string; user: string }
  buildChat(input: ChatInput): { system: string; user: string }
  buildSystem(input: SystemInput): { system: string; user: string }
}

// ---------------------------------------------------------------------------
// Concrete implementation
// ---------------------------------------------------------------------------

class DefaultPromptBuilder implements PromptBuilder {
  buildCourse(input: CourseInput): { system: string; user: string } {
    if (input.phase === 'outline') {
      return {
        system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
        user: `Generate a course outline for: "${input.topic}"
Audience: ${input.level}
Level: ${input.level}
Language: ${input.language}
Number of modules: ${input.moduleCount}

Respond in this exact JSON shape:
{
  "title": "string — course title",
  "description": "string — 1 to 3 sentence description",
  "outline": "string — one-line-per-module outline"
}`,
      }
    }
    // phase === 'modules'
    const title = input.courseTitle ?? input.topic
    return {
      system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
      user: `Generate ${input.moduleCount} modules for the course: "${title}"
Topic: ${input.topic}
Level: ${input.level}
Language: ${input.language}

Respond in this exact JSON shape:
{
  "modules": [
    {
      "title": "string — module title",
      "summary": "string — 1-2 sentence summary",
      "lessons": [
        { "title": "string — lesson title", "content": "string — 1-2 paragraph lesson content", "duration": 15 }
      ]
    }
  ]
}`,
    }
  }

  buildPresentation(input: PresentationInput): { system: string; user: string } {
    const audienceLine = input.audience ? `Audience: ${input.audience}\n` : ''
    return {
      system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
      user: `Generate a ${input.slideCount}-slide presentation about: "${input.topic}".
${audienceLine}Language: ${input.language}

Respond in this exact JSON shape:
{
  "title": "string — presentation title",
  "slides": [
    {
      "title": "string — slide title",
      "bullets": ["string — bullet 1", "string — bullet 2"],
      "notes": "string — speaker notes"
    }
  ]
}`,
    }
  }

  buildQuiz(input: QuizInput): { system: string; user: string } {
    return {
      system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
      user: `Generate a ${input.difficulty} multiple-choice quiz about: "${input.topic}".
Number of questions: ${input.questionCount}
Language: ${input.language}

Respond in this exact JSON shape:
{
  "questions": [
    {
      "question": "string — question prompt",
      "options": ["string — option A", "string — option B", "string — option C", "string — option D"],
      "correctIndex": 0,
      "explanation": "string — why the correct answer is correct"
    }
  ]
}`,
    }
  }

  buildDocument(input: DocumentInput): { system: string; user: string } {
    const sectionsLine = input.sections ? `Number of sections: ${input.sections}\n` : ''
    return {
      system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
      user: `Generate a "${input.type}" document about: "${input.topic}".
${sectionsLine}Language: ${input.language}

Respond in this exact JSON shape:
{
  "title": "string — document title",
  "sections": [
    {
      "title": "string — section title",
      "content": "string — section content in markdown"
    }
  ]
}`,
    }
  }

  buildChat(input: ChatInput): { system: string; user: string } {
    const system = input.topic
      ? `${DEFAULT_CHAT_SYSTEM}\n\nThe user is interested in: ${input.topic}`
      : DEFAULT_CHAT_SYSTEM
    return { system, user: input.message }
  }

  buildSystem(input: SystemInput): { system: string; user: string } {
    const schemaLine = input.jsonSchemaHint
      ? `\n\nRespond in this JSON shape:\n${input.jsonSchemaHint}`
      : ''
    return {
      system: EXPERT_INSTRUCTIONAL_DESIGNER_SYSTEM,
      user: `${input.purpose}${input.topic ? `\n\nTopic: ${input.topic}` : ''}${schemaLine}`,
    }
  }
}

// ---------------------------------------------------------------------------
// Singleton + factory
// ---------------------------------------------------------------------------

let singleton: PromptBuilder | null = null

/**
 * Returns the singleton PromptBuilder. Creates it on first call.
 */
export function getPromptBuilder(): PromptBuilder {
  if (!singleton) {
    singleton = new DefaultPromptBuilder()
  }
  return singleton
}

/**
 * Replaces the singleton (for tests). Returns the new builder.
 */
export function setPromptBuilder(builder: PromptBuilder): PromptBuilder {
  singleton = builder
  return singleton
}
