// =============================================================================
// AICF V3 — Runtime Context Contract
// =============================================================================
// The RuntimeContext flows through every pipeline stage. Each stage reads
// from and writes to the context. This is the single shared state object
// during a Runtime operation.
// =============================================================================

import type { RuntimeRequest } from './RuntimeRequest'
import type { RuntimeResponse } from './RuntimeResponse'
import type { ChatUsage, AIModel } from '@/lib/ai/AIAdapter'

/**
 * Metrics collected during pipeline execution.
 */
export interface RuntimeMetrics {
  latencyMs: number
  tokensPrompt: number
  tokensCompletion: number
  tokensTotal: number
  provider: string | null
  model: string | null
  cost: number
  estimatedCost: number
  cacheHit: boolean
  retryCount: number
  executionTimeMs: number
  pipelineTimeMs: number
  providerTimeMs: number
}

/**
 * The context that flows through the pipeline.
 *
 * Sprint 4 — Immutability:
 *   All top-level properties are `readonly`. Pipeline stages MUST NOT mutate
 *   the context they receive. Instead, each stage calls `cloneRuntimeContext(ctx)`
 *   to create a new instance, modifies the clone, and returns it. The Pipeline
 *   reassigns its `ctx` variable to the returned value.
 *
 *   This ensures `ctx !== newCtx` (different reference) after each stage,
 *   enabling safe debugging, audit trails, and potential parallel execution.
 */
export interface RuntimeContext {
  /** The original request. */
  readonly request: RuntimeRequest

  /** The response being built. */
  readonly response: RuntimeResponse

  /** Pipeline stage results (stage name → result data). */
  readonly stageResults: Map<string, unknown>

  /** Resolved provider (set by Routing stage). */
  readonly provider: string | null

  /** Resolved model (set by Routing stage). */
  readonly model: string | null

  /** Built prompt messages (set by PromptBuilder stage). */
  readonly messages: import('@/lib/ai/AIAdapter').ChatMessage[] | null

  /** AI response content (set by Execution stage). */
  readonly content: string | null

  /** Token usage (set by Execution stage). */
  readonly usage: ChatUsage | null

  /** Available models (set by Routing stage for models operation). */
  readonly models: AIModel[] | null

  /** Workflow result (set by Execution stage for workflow operations). */
  readonly workflowResult: Record<string, unknown> | null

  /** Whether the response was served from cache. */
  readonly cached: boolean

  /** Metrics collected during execution. */
  readonly metrics: RuntimeMetrics

  /** Timestamp when the context was created. */
  readonly startedAt: number

  /** Errors collected during pipeline execution. */
  readonly errors: ReadonlyArray<{ stage: string; message: string; code?: string }>

  /**
   * Trace ID for distributed tracing (Sprint 15).
   * Propagated end-to-end: BFF → Runtime → Modules → LiteLLM.
   * Defaults to the request's correlationId when not explicitly set.
   */
  readonly traceId: string
}

/**
 * Factory: creates a fresh RuntimeContext from a request.
 */
export function createRuntimeContext(request: RuntimeRequest): RuntimeContext {
  const ts = Date.now()
  return {
    request,
    response: {
      ok: true,
      requestId: request.requestId,
      correlationId: request.correlationId,
      durationMs: 0,
    },
    stageResults: new Map(),
    provider: null,
    model: null,
    messages: null,
    content: null,
    usage: null,
    models: null,
    workflowResult: null,
    cached: false,
    metrics: {
      latencyMs: 0,
      tokensPrompt: 0,
      tokensCompletion: 0,
      tokensTotal: 0,
      provider: null,
      model: null,
      cost: 0,
      estimatedCost: 0,
      cacheHit: false,
      retryCount: 0,
      executionTimeMs: 0,
      pipelineTimeMs: 0,
      providerTimeMs: 0,
    },
    startedAt: ts,
    errors: [],
    // Sprint 15: traceId defaults to correlationId for end-to-end propagation.
    // Callers can override via request.metadata.traceId if they want a distinct trace.
    traceId: (request.metadata?.traceId as string) || request.correlationId,
  }
}

/**
 * Sprint 4 — A writable version of RuntimeContext used internally by stages
 * and the Pipeline when they need to modify a cloned context. The public
 * RuntimeContext interface has readonly properties; this type removes the
 * readonly so stages can assign new values to the clone before returning it.
 *
 * Stages receive a `RuntimeContext` (readonly) and return a
 * `RuntimeContext` (readonly). Internally they work with
 * `WritableRuntimeContext` via `cloneRuntimeContext()`.
 */
export type WritableRuntimeContext = {
  -readonly [K in keyof RuntimeContext]: RuntimeContext[K]
}

/**
 * Sprint 4 — Creates a shallow clone of a RuntimeContext with cloned nested
 * mutable structures (response, metrics, errors, stageResults).
 *
 * Stages call this to get a new context they can safely modify without
 * affecting the original. The returned context has a different reference
 * (`ctx !== cloneRuntimeContext(ctx)` is always true).
 *
 * The return type is `WritableRuntimeContext` so stages can assign new
 * values to properties. Callers that need to return a `RuntimeContext`
 * can simply return the clone (it's structurally identical — readonly is
 * a compile-time concept only).
 *
 * @example
 * const next = cloneRuntimeContext(ctx)
 * next.response = { ...next.response, ok: false }
 * return next
 */
export function cloneRuntimeContext(ctx: RuntimeContext): WritableRuntimeContext {
  return {
    request: ctx.request,
    response: { ...ctx.response },
    stageResults: new Map(ctx.stageResults),
    provider: ctx.provider,
    model: ctx.model,
    messages: ctx.messages ? [...ctx.messages] : null,
    content: ctx.content,
    usage: ctx.usage ? { ...ctx.usage } : null,
    models: ctx.models ? [...ctx.models] : null,
    workflowResult: ctx.workflowResult ? { ...ctx.workflowResult } : null,
    cached: ctx.cached,
    metrics: { ...ctx.metrics },
    startedAt: ctx.startedAt,
    errors: [...ctx.errors],
    traceId: ctx.traceId,
  }
}
