// =============================================================================
// AICF V3 — Execution Stage (Sprint 18: M21 → M18 → LiteLLM Fallback)
// Sprint 21: emits ExecutionStarted/ExecutionFinished
// =============================================================================
// This is where the actual AI generation happens.
//
// Architecture:
//   Execution Stage → Real Generation (M21) → Infrastructure (M18) → LiteLLM
//
// Priority (per Sprint 18 fallback matrix):
//   1. M21 (Real Generation) — if ready, try startGeneration()
//      → on failure (ok=false or throw), fall through to M18
//   2. M18 (Infrastructure) — if ready, try completion() via LiteLLM connector
//      → on failure (throws because CI not injected, or CI has no llmClient),
//        fall through to fallback
//   3. LiteLLMAdapter fallback — always available, always works (if LiteLLM
//      gateway is reachable)
//
// The Runtime NEVER calls LiteLLM directly. It delegates to M21 or M18.
// When both M21 and M18 fail, it uses the fallback (LiteLLMAdapter).
//
// IMPORTANT (Sprint 18): Each priority level is wrapped in try/catch so
// failures don't crash the pipeline — they just fall through to the next
// priority. The "lastActiveModule" field records which module actually
// produced the response (for the /api/runtime/status "active" state).
//
// Sprint 21: when an EventBus is provided (optional `eventBus` in the
// ExecutionStageConfig), the stage emits:
//   - ExecutionStarted  (before trying M21/M18/fallback)
//   - ExecutionFinished (after, with success/durationMs/module)
// Emission is best-effort — wrapped in try/catch, never throws, never blocks
// the pipeline.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { RealGenerationModule, GenerationResult, InfrastructureModule } from '../contracts/ModuleInterfaces'
import type { ChatRequest, ChatResponse } from '@/lib/ai/AIAdapter'
import type { RuntimeEventBus } from '../events/RuntimeEventBus'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import { logger } from '@/lib/ai/logger'

/** Fallback function type (used when no module is ready). */
export type FallbackGenerateFn = (request: ChatRequest) => Promise<ChatResponse>

/**
 * Configuration for the Execution stage.
 */
export interface ExecutionStageConfig {
  /** Real Generation module (M21). */
  genModule?: RealGenerationModule | null

  /** Infrastructure module (M18). */
  infraModule?: InfrastructureModule | null

  /** Fallback generate function (typically LiteLLMAdapter.chat). */
  fallback: FallbackGenerateFn

  /** Sprint 21: optional EventBus. When set, emits Execution* events. */
  eventBus?: RuntimeEventBus
}

/** Tracks which module was active in the last Execution call. */
let lastActiveModule: 'm21' | 'm18' | 'fallback' | null = null

/**
 * Returns which module was active in the last successful Execution call.
 * Used by /api/runtime/status to report the "active" state.
 */
export function getLastActiveModule(): 'm21' | 'm18' | 'fallback' | null {
  return lastActiveModule
}

/**
 * Best-effort: emits an envelope-wrapped EDA event. Wraps in try/catch so
 * emission failures never propagate to the pipeline.
 */
async function emitBestEffort(
  eventBus: RuntimeEventBus | undefined,
  type: 'ExecutionStarted' | 'ExecutionFinished',
  opts: {
    correlationId: string
    requestId: string
    operation: string
    stageOrder: number
    durationMs?: number
    payload: Record<string, unknown>
  },
): Promise<void> {
  if (!eventBus) return
  try {
    const meta = createEventMetadata({
      correlationId: opts.correlationId,
      requestId: opts.requestId,
      operation: opts.operation,
      pipelineStage: 'Execution',
      stageOrder: opts.stageOrder,
      durationMs: opts.durationMs,
    })
    await eventBus.publishEnvelope(createEnvelope(meta, opts.payload), type)
  } catch (err) {
    logger.debug(
      { type, error: err instanceof Error ? err.message : String(err) },
      'Execution stage: event emission failed (best-effort)',
    )
  }
}

/**
 * Creates the Execution stage.
 * Delegates to M21 (priority 1), M18 (priority 2), or fallback (priority 3).
 * Each priority is wrapped in try/catch so failures fall through gracefully.
 */
export function createExecutionStage(config: ExecutionStageConfig): PipelineStage {
  const genModule = config.genModule || null
  const infraModule = config.infraModule || null
  const fallback = config.fallback
  const eventBus = config.eventBus

  return createPipelineStage('Execution', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const requestId = ctx.request.requestId
    const correlationId = ctx.request.correlationId
    const operation = ctx.request.operation
    const started = Date.now()

    // -----------------------------------------------------------------------
    // operation: 'models' — list available models (NOT a chat request)
    // -----------------------------------------------------------------------
    if (operation === 'models') {
      await emitBestEffort(eventBus, 'ExecutionStarted', {
        correlationId,
        requestId,
        operation,
        stageOrder: 8,
        payload: { requestId, provider: ctx.provider || null, model: ctx.model || null },
      })

      let models: import('@/lib/ai/AIAdapter').AIModel[] = []
      try {
        // Priority 1: Infrastructure module (M18) → LiteLLM connector
        if (infraModule && typeof infraModule.isReady === 'function' && infraModule.isReady() && typeof infraModule.models === 'function') {
          logger.info({ requestId }, 'Execution: listing models via Infrastructure (M18)')
          models = await infraModule.models()
        } else {
          // Priority 2: Fallback — LiteLLMAdapter.models() directly
          logger.info({ requestId }, 'Execution: listing models via fallback (LiteLLMAdapter)')
          const { LiteLLMAdapter } = await import('@/lib/ai/LiteLLMAdapter')
          const direct = new LiteLLMAdapter()
          models = await direct.models()
        }
        lastActiveModule = 'fallback'
      } catch (err) {
        logger.warn(
          { requestId, error: err instanceof Error ? err.message : String(err) },
          'Execution: models listing failed',
        )
        const next = cloneRuntimeContext(ctx)
        next.response = {
          ...next.response,
          ok: false,
          error: `Execution: models listing failed: ${err instanceof Error ? err.message : String(err)}`,
          errorCode: 'MODELS_ERROR',
        }
        await emitBestEffort(eventBus, 'ExecutionFinished', {
          correlationId,
          requestId,
          operation,
          stageOrder: 9,
          durationMs: Date.now() - started,
          payload: { requestId, success: false, module: 'fallback', durationMs: Date.now() - started },
        })
        return next
      }

      const next = cloneRuntimeContext(ctx)
      next.models = models
      next.response = {
        ...next.response,
        ok: true,
        models,
        provider: 'litellm',
      }
      logger.info({ requestId, modelCount: models.length }, 'Execution: models listed')

      await emitBestEffort(eventBus, 'ExecutionFinished', {
        correlationId,
        requestId,
        operation,
        stageOrder: 9,
        durationMs: Date.now() - started,
        payload: { requestId, success: true, module: 'fallback', durationMs: Date.now() - started, modelCount: models.length },
      })
      return next
    }

    if (!ctx.messages || ctx.messages.length === 0) {
      logger.debug({ requestId: ctx.request.requestId }, 'Execution: no messages, skipping')
      return ctx
    }

    await emitBestEffort(eventBus, 'ExecutionStarted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 8,
      payload: {
        requestId,
        provider: ctx.provider || null,
        model: ctx.model || null,
      },
    })

    const chatRequest: ChatRequest = {
      model: ctx.model || ctx.request.model || 'groq-llama-3.3-70b',
      messages: ctx.messages,
      ...(ctx.request.parameters?.temperature !== undefined && { temperature: ctx.request.parameters.temperature }),
      ...(ctx.request.parameters?.maxTokens !== undefined && { maxTokens: ctx.request.parameters.maxTokens }),
      ...(ctx.request.parameters?.topP !== undefined && { topP: ctx.request.parameters.topP }),
      ...(ctx.request.parameters?.stop !== undefined && { stop: ctx.request.parameters.stop }),
      ...(ctx.request.parameters?.stream !== undefined && { stream: ctx.request.parameters.stream }),
    }

    // -----------------------------------------------------------------------
    // Priority 1: Real Generation module (M21)
    // -----------------------------------------------------------------------
    if (genModule && typeof genModule.isReady === 'function' && genModule.isReady() && typeof genModule.generate === 'function') {
      try {
        logger.info({ requestId: ctx.request.requestId }, 'Execution: trying Real Generation (M21)')

        const result: GenerationResult = await genModule.generate(ctx)

        // Validate the result has actual content.
        if (result.content && result.content.length > 0) {
          const next = cloneRuntimeContext(ctx)
          next.content = result.content
          next.usage = result.usage
          next.provider = result.provider
          next.model = result.model
          next.cached = result.cached
          next.metrics.providerTimeMs = result.durationMs
          lastActiveModule = 'm21'

          logger.info(
            { requestId: ctx.request.requestId, provider: result.provider, model: result.model },
            'Execution: M21 succeeded',
          )

          await emitBestEffort(eventBus, 'ExecutionFinished', {
            correlationId,
            requestId,
            operation,
            stageOrder: 9,
            durationMs: Date.now() - started,
            payload: {
              requestId,
              success: true,
              module: 'm21',
              durationMs: Date.now() - started,
            },
          })

          return next
        }

        logger.warn(
          { requestId: ctx.request.requestId, reason: 'empty content' },
          'Execution: M21 returned empty content, falling through to M18',
        )
      } catch (err) {
        logger.warn(
          {
            requestId: ctx.request.requestId,
            error: err instanceof Error ? err.message : String(err),
          },
          'Execution: M21 failed, falling through to M18',
        )
      }
    }

    // -----------------------------------------------------------------------
    // Priority 2: Infrastructure module (M18) → LiteLLM connector
    // -----------------------------------------------------------------------
    if (infraModule && typeof infraModule.isReady === 'function' && infraModule.isReady() && typeof infraModule.completion === 'function') {
      try {
        logger.info({ requestId: ctx.request.requestId }, 'Execution: trying Infrastructure (M18) → LiteLLM')

        const result = await infraModule.completion({
          model: chatRequest.model,
          messages: chatRequest.messages,
          ...(chatRequest.temperature !== undefined && { temperature: chatRequest.temperature }),
          ...(chatRequest.maxTokens !== undefined && { maxTokens: chatRequest.maxTokens }),
        })

        // Validate the result has actual content.
        if (result.content && result.content.length > 0) {
          const next = cloneRuntimeContext(ctx)
          next.content = result.content
          next.usage = result.usage
          next.provider = result.provider
          next.model = result.model
          next.cached = false
          next.metrics.providerTimeMs = result.durationMs
          lastActiveModule = 'm18'

          logger.info(
            { requestId: ctx.request.requestId, provider: result.provider, model: result.model },
            'Execution: M18 succeeded',
          )

          await emitBestEffort(eventBus, 'ExecutionFinished', {
            correlationId,
            requestId,
            operation,
            stageOrder: 9,
            durationMs: Date.now() - started,
            payload: {
              requestId,
              success: true,
              module: 'm18',
              durationMs: Date.now() - started,
            },
          })

          return next
        }

        logger.warn(
          { requestId: ctx.request.requestId, reason: 'empty content' },
          'Execution: M18 returned empty content, falling through to fallback',
        )
      } catch (err) {
        logger.warn(
          {
            requestId: ctx.request.requestId,
            error: err instanceof Error ? err.message : String(err),
          },
          'Execution: M18 failed, falling through to fallback (LiteLLMAdapter)',
        )
      }
    }

    // -----------------------------------------------------------------------
    // Priority 3: Fallback (LiteLLMAdapter) — always available
    // -----------------------------------------------------------------------
    logger.info({ requestId: ctx.request.requestId }, 'Execution: using fallback (LiteLLMAdapter)')

    try {
      const result: ChatResponse = await fallback(chatRequest)

      const next = cloneRuntimeContext(ctx)
      next.content = result.content
      next.usage = result.usage
      next.provider = result.provider
      next.model = result.model
      next.cached = false
      next.metrics.providerTimeMs = result.durationMs
      lastActiveModule = 'fallback'

      await emitBestEffort(eventBus, 'ExecutionFinished', {
        correlationId,
        requestId,
        operation,
        stageOrder: 9,
        durationMs: Date.now() - started,
        payload: {
          requestId,
          success: true,
          module: 'fallback',
          durationMs: Date.now() - started,
        },
      })

      return next
    } catch (err) {
      // Best-effort: emit ExecutionFinished(success:false) then re-throw so
      // the pipeline handles the error as before (preserving backward-compat
      // for errorCode/message).
      logger.error(
        {
          requestId: ctx.request.requestId,
          error: err instanceof Error ? err.message : String(err),
        },
        'Execution: fallback failed',
      )

      await emitBestEffort(eventBus, 'ExecutionFinished', {
        correlationId,
        requestId,
        operation,
        stageOrder: 9,
        durationMs: Date.now() - started,
        payload: {
          requestId,
          success: false,
          module: 'fallback',
          durationMs: Date.now() - started,
        },
      })

      throw err
    }
  })
}
