// =============================================================================
// AICF V3 — Épica 6 — Research Source
// =============================================================================
export interface ResearchSource {
  id: string
  title: string
  url?: string
  content: string
  confidence: number
  provider: string
  retrievedAt: Date
  hash: string
  type: 'web' | 'document' | 'memory' | 'rag' | 'knowledge-base'
}

export function createResearchSource(input: {
  title: string
  content: string
  type?: ResearchSource['type']
  url?: string
  confidence?: number
}): ResearchSource {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return {
    id: `rs-${ts}-${rand}`,
    title: input.title,
    url: input.url,
    content: input.content,
    confidence: input.confidence ?? 0.8,
    provider: 'runtime-adapter',
    retrievedAt: new Date(),
    hash: computeResearchHash(input.content),
    type: input.type ?? 'memory',
  }
}

import { createHash } from 'node:crypto'

export function computeResearchHash(content: string): string {
  return createHash('sha256').update(content).digest('hex')
}
