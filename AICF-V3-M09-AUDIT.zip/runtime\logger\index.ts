// =============================================================================
// AICF V3 — Sprint 2 — Runtime Logger
// =============================================================================
// Re-exports the logger from the AI layer for runtime consumers.
// The logger itself lives in src/lib/ai/logger.ts (frozen BFF).
// =============================================================================

export { logger } from '@/lib/ai/logger'
