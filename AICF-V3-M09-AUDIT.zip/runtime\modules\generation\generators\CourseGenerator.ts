// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Course Generator
// =============================================================================
// Concrete `IGenerator` implementation for the "course" content category.
// Produces a finished course (title + description + outline + modules of
// lessons) by orchestrating two AI adapter calls — one for the outline and
// one for the modules — mirroring the prompt strategy of the legacy
// `CourseWorker`, but adapted to the `IGenerator` interface and emitting
// `WorkflowArtifact` entries ready for the artifact store.
//
// Sprint 13+14 spec requirements covered:
//   - Implements `IGenerator` (uniform generator contract)
//   - `generatorType = 'course'` (registry dispatch key)
//   - `canHandle('course')` returns true
//   - Returns `GeneratorOutput` with content, modules, outline, title,
//     description, artifacts, and provider/model/token attribution
//   - Emits typed `WorkflowArtifact`s via `createArtifact` (with lineage
//     including generator name, execution id, model, and provider)
// =============================================================================

import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type {
  GeneratorInput,
  GeneratorOutput,
  GeneratorType,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  TokenUsage,
  WorkflowArtifact,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { createArtifact } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Per-token cost estimate (platform currency units). */
const COST_PER_TOKEN = 0.000_002

/** Default model when neither the input nor context specify one. */
const DEFAULT_MODEL = 'groq-llama-3.3-70b'

/**
 * Resolve the model to use for this generation. Falls back through
 * `ctx.model`, a string `metadata.model`, then the default. Returns a
 * string in all cases.
 */
function resolveModel(
  ctx: WorkflowContext,
  input: GeneratorInput,
  fallback: string,
): string {
  if (typeof ctx.model === 'string' && ctx.model.length > 0) return ctx.model
  const metaModel = input.metadata?.['model']
  if (typeof metaModel === 'string' && metaModel.length > 0) return metaModel
  return fallback
}

/** Course module shape produced by the generator. */
interface CourseModule {
  id: string
  title: string
  summary: string
  lessons: CourseLesson[]
}

/** Course lesson shape produced by the generator. */
interface CourseLesson {
  id: string
  title: string
  content: string
  duration?: number
}

/** Outline payload returned by the first AI call. */
interface OutlinePayload {
  title: string
  description: string
  outline: string
}

/** Modules payload returned by the second AI call. */
interface ModulesPayload {
  modules: Array<{
    title?: string
    summary?: string
    lessons?: Array<{
      title?: string
      content?: string
      duration?: number
    }>
  }>
}

/**
 * Course generator. Uses a two-step prompt strategy (outline → modules) to
 * produce a complete course from a topic. Each AI response is parsed as
 * JSON; on parse failure, the raw response is used as a graceful fallback
 * so the generator never throws for malformed JSON.
 */
export class CourseGenerator implements IGenerator {
  public readonly name = 'course-generator'
  public readonly generatorType: GeneratorType = 'course'
  private readonly adapter: AIAdapter

  constructor(aiAdapter: AIAdapter) {
    this.adapter = aiAdapter
  }

  public canHandle(contentType: string): boolean {
    return contentType === 'course'
  }

  /**
   * Generate a complete course from `input.topic`. Emits a primary course
   * artifact plus a markdown rendering of the same content.
   */
  public async generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const startMs = Date.now()
    const model = resolveModel(ctx, input, DEFAULT_MODEL)
    const topic = input.topic
    const moduleCount = input.modules ?? 5

    logger.info(
      {
        generator: this.name,
        executionId: ctx.executionId,
        topic,
        moduleCount,
        model,
      },
      'CourseGenerator: starting',
    )

    try {
      // --- Stage 1: outline ------------------------------------------------
      const outlinePrompt = buildOutlinePrompt(input, moduleCount)
      const outlineResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert instructional designer. Respond in valid JSON only.',
          },
          { role: 'user', content: outlinePrompt },
        ],
        temperature: 0.7,
        maxTokens: 1024,
      } satisfies ChatRequest)

      const outline = parseOutline(outlineResponse.content, topic)

      // --- Stage 2: modules ------------------------------------------------
      const modulesPrompt = buildModulesPrompt(input, outline.title, moduleCount)
      const modulesResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert instructional designer. Respond in valid JSON only.',
          },
          { role: 'user', content: modulesPrompt },
        ],
        temperature: 0.7,
        maxTokens: 4096,
      } satisfies ChatRequest)

      const modules = parseModules(modulesResponse.content, modulesResponse.model)

      // --- Aggregate token usage ------------------------------------------
      const tokensUsed = addUsage(
        usageFromResponse(outlineResponse.usage),
        usageFromResponse(modulesResponse.usage),
      )
      const cost = tokensUsed.totalTokens * COST_PER_TOKEN

      // --- Assemble content body ------------------------------------------
      const content = renderCourseMarkdown(topic, outline, modules)
      const artifacts = await buildCourseArtifacts(
        ctx.executionId,
        this.name,
        outline,
        modules,
        content,
        {
          model,
          provider: modulesResponse.provider || outlineResponse.provider,
        },
      )

      logger.info(
        {
          generator: this.name,
          executionId: ctx.executionId,
          durationMs: Date.now() - startMs,
          moduleCount: modules.length,
          tokens: tokensUsed.totalTokens,
        },
        'CourseGenerator: completed',
      )

      return {
        ok: true,
        content,
        modules,
        outline: outline.outline,
        title: outline.title,
        description: outline.description,
        artifacts,
        tokensUsed,
        cost,
        provider: modulesResponse.provider || outlineResponse.provider,
        model,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.error(
        { generator: this.name, executionId: ctx.executionId, error: message },
        'CourseGenerator: failed',
      )
      return {
        ok: false,
        content: '',
        artifacts: [],
        error: message,
        model,
      }
    }
  }
}

// =============================================================================
// Prompt builders
// =============================================================================

function buildOutlinePrompt(input: GeneratorInput, moduleCount: number): string {
  return `Generate a course outline for: "${input.topic}"
Audience: ${input.audience ?? 'general'}
Level: ${input.level ?? 'beginner'}
Language: ${input.language ?? 'English'}
Number of modules: ${moduleCount}

Respond in JSON format:
{
  "title": "Course Title",
  "description": "Course description (2-3 sentences)",
  "outline": "Brief outline of the course structure"
}`
}

function buildModulesPrompt(
  input: GeneratorInput,
  courseTitle: string,
  moduleCount: number,
): string {
  return `Generate ${moduleCount} modules for the course: "${courseTitle}"
Topic: ${input.topic}
Level: ${input.level ?? 'beginner'}

Respond in JSON format:
{
  "modules": [
    {
      "title": "Module Title",
      "summary": "Module summary",
      "lessons": [
        { "title": "Lesson Title", "content": "Lesson content summary", "duration": 15 }
      ]
    }
  ]
}`
}

// =============================================================================
// JSON parsing helpers (graceful fallback on malformed JSON)
// =============================================================================

function parseOutline(raw: string, topic: string): OutlinePayload {
  try {
    const parsed = JSON.parse(raw) as Partial<OutlinePayload>
    return {
      title: typeof parsed.title === 'string' && parsed.title.length > 0
        ? parsed.title
        : topic,
      description: typeof parsed.description === 'string' ? parsed.description : '',
      outline: typeof parsed.outline === 'string' ? parsed.outline : raw,
    }
  } catch {
    return {
      title: topic,
      description: raw.slice(0, 200),
      outline: raw,
    }
  }
}

function parseModules(raw: string, model: string): CourseModule[] {
  try {
    const parsed = JSON.parse(raw) as Partial<ModulesPayload>
    const rawModules = parsed.modules ?? []
    return rawModules.map(
      (m, index): CourseModule => ({
        id: `mod-${index + 1}`,
        title: typeof m.title === 'string' && m.title.length > 0
          ? m.title
          : `Module ${index + 1}`,
        summary: typeof m.summary === 'string' ? m.summary : '',
        lessons: (m.lessons ?? []).map(
          (l, lIndex): CourseLesson => ({
            id: `lesson-${index + 1}-${lIndex + 1}`,
            title: typeof l.title === 'string' && l.title.length > 0
              ? l.title
              : `Lesson ${lIndex + 1}`,
            content: typeof l.content === 'string' ? l.content : '',
            ...(typeof l.duration === 'number'
              ? { duration: l.duration }
              : {}),
          }),
        ),
      }),
    )
  } catch {
    return [
      {
        id: 'mod-1',
        title: 'Generated Content',
        summary: `AI-generated course content (model: ${model})`,
        lessons: [
          {
            id: 'lesson-1-1',
            title: 'Introduction',
            content: raw.slice(0, 1000),
          },
        ],
      },
    ]
  }
}

// =============================================================================
// Markdown rendering
// =============================================================================

function renderCourseMarkdown(
  topic: string,
  outline: OutlinePayload,
  modules: CourseModule[],
): string {
  const lines: string[] = []
  lines.push(`# ${outline.title}`)
  lines.push('')
  lines.push(`> ${outline.description}`)
  lines.push('')
  lines.push(`**Topic:** ${topic}`)
  lines.push('')
  lines.push('## Outline')
  lines.push('')
  lines.push(outline.outline)
  lines.push('')
  for (const m of modules) {
    lines.push(`## ${m.title}`)
    lines.push('')
    if (m.summary.length > 0) {
      lines.push(m.summary)
      lines.push('')
    }
    for (const l of m.lessons) {
      lines.push(`### ${l.title}`)
      lines.push('')
      lines.push(l.content)
      if (l.duration !== undefined) {
        lines.push('')
        lines.push(`_Duration: ${l.duration} min_`)
      }
      lines.push('')
    }
  }
  return lines.join('\n')
}

// =============================================================================
// Artifact construction
// =============================================================================

async function buildCourseArtifacts(
  executionId: string,
  generatorName: string,
  outline: OutlinePayload,
  modules: CourseModule[],
  markdown: string,
  attribution: { model: string; provider: string },
): Promise<WorkflowArtifact[]> {
  const json = JSON.stringify(
    {
      title: outline.title,
      description: outline.description,
      outline: outline.outline,
      modules,
    },
    null,
    2,
  )

  const [courseArtifact, markdownArtifact] = await Promise.all([
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (course)`,
      'course',
      json,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (markdown)`,
      'markdown',
      markdown,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
  ])

  return [courseArtifact, markdownArtifact]
}

// =============================================================================
// Token usage helpers
// =============================================================================

function usageFromResponse(usage: {
  promptTokens: number
  completionTokens: number
  totalTokens: number
} | null): TokenUsage {
  if (!usage) {
    return { promptTokens: 0, completionTokens: 0, totalTokens: 0 }
  }
  return {
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
    totalTokens: usage.totalTokens,
  }
}

function addUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    promptTokens: a.promptTokens + b.promptTokens,
    completionTokens: a.completionTokens + b.completionTokens,
    totalTokens: a.totalTokens + b.totalTokens,
  }
}
