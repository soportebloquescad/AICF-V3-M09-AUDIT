// =============================================================================
// AICF V3 — PDF Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a print-ready HTML document designed for
// browser-to-PDF conversion (Ctrl+P / Cmd+P) or headless rendering (Puppeteer,
// Playwright, wkhtmltopdf). The output is a complete `<!DOCTYPE html>`
// document whose CSS is tuned for paper: it declares `@page` margins, a
// `@media print` block that hides screen-only chrome, and page-break rules
// so headings do not get orphaned at the bottom of a page.
//
// The exporter NEVER generates or modifies content — it only re-formats the
// supplied Markdown into HTML and wraps it with print-optimised styles.
// Metadata is projected into <head> meta tags and a visible cover block.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { escapeHtml, markdownToHtml } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by PDFExporter.export(). */
export type PdfExportMetadata = Record<string, unknown>

/** Page size preset (millimetres — matches CSS @page size units). */
export interface PdfPageSetup {
  /** CSS page-size keyword or explicit dimensions, e.g. "A4" or "8.5in 11in". */
  size: string
  /** Top margin (mm). */
  marginTop: string
  /** Bottom margin (mm). */
  marginBottom: string
  /** Left margin (mm). */
  marginLeft: string
  /** Right margin (mm). */
  marginRight: string
}

const DEFAULT_PAGE: PdfPageSetup = {
  size: 'A4',
  marginTop: '20mm',
  marginBottom: '20mm',
  marginLeft: '18mm',
  marginRight: '18mm',
}

/**
 * PDFExporter — transforms Markdown to a print-ready HTML document.
 */
export class PDFExporter {
  /**
   * Transform `content` (Markdown) into a print-ready HTML document string.
   *
   * @param content  Markdown source text.
   * @param metadata Optional metadata: { title, author, description, language, subject, pageSetup, ... }.
   * @returns A self-contained `<!DOCTYPE html>` document tuned for print.
   */
  export(content: string, metadata?: PdfExportMetadata): string {
    const meta = metadata ?? {}
    const title = asString(meta.title, asString(meta.topic, 'Exported Document'))
    const author = asString(meta.author, '')
    const description = asString(meta.description, '')
    const subject = asString(meta.subject, '')
    const language = asString(meta.language, 'en').toLowerCase()
    const generator = asString(meta.generator, 'AICF V3 PDFExporter')
    const page = this.resolvePageSetup(meta.pageSetup)

    const bodyHtml = markdownToHtml(content ?? '')
    const css = this.buildCss(page)
    const coverBlock = this.buildCover(title, author, description, subject, meta)
    const footerBlock = this.buildFooter(generator)

    return [
      '<!DOCTYPE html>',
      `<html lang="${escapeHtml(language)}">`,
      '<head>',
      '  <meta charset="utf-8" />',
      '  <meta name="viewport" content="width=device-width, initial-scale=1" />',
      `  <title>${escapeHtml(title)}</title>`,
      this.buildHeadMeta(title, author, description, subject, generator),
      '  <style>',
      css,
      '  </style>',
      '</head>',
      '<body>',
      '  <main class="document" role="main">',
      coverBlock,
      '    <article class="content">',
      bodyHtml,
      '    </article>',
      footerBlock,
      '  </main>',
      '</body>',
      '</html>',
      '',
    ].join('\n')
  }

  // -------------------------------------------------------------------------
  // Internal helpers
  // -------------------------------------------------------------------------

  private resolvePageSetup(raw: unknown): PdfPageSetup {
    if (!raw || typeof raw !== 'object') return DEFAULT_PAGE
    const obj = raw as Record<string, unknown>
    const str = (key: keyof PdfPageSetup, fallback: string): string => {
      const v = obj[key]
      return typeof v === 'string' && v.length > 0 ? v : fallback
    }
    return {
      size: str('size', DEFAULT_PAGE.size),
      marginTop: str('marginTop', DEFAULT_PAGE.marginTop),
      marginBottom: str('marginBottom', DEFAULT_PAGE.marginBottom),
      marginLeft: str('marginLeft', DEFAULT_PAGE.marginLeft),
      marginRight: str('marginRight', DEFAULT_PAGE.marginRight),
    }
  }

  private buildHeadMeta(
    title: string,
    author: string,
    description: string,
    subject: string,
    generator: string,
  ): string {
    const lines: string[] = []
    lines.push(`  <meta name="generator" content="${escapeHtml(generator)}" />`)
    if (author) {
      lines.push(`  <meta name="author" content="${escapeHtml(author)}" />`)
    }
    if (description) {
      lines.push(`  <meta name="description" content="${escapeHtml(description)}" />`)
    }
    if (subject) {
      lines.push(`  <meta name="subject" content="${escapeHtml(subject)}" />`)
    }
    lines.push('  <meta name="dcterms.created" content="' + new Date().toISOString() + '" />')
    return lines.join('\n')
  }

  private buildCover(
    title: string,
    author: string,
    description: string,
    subject: string,
    meta: PdfExportMetadata,
  ): string {
    const lines: string[] = []
    lines.push('    <section class="cover">')
    lines.push(`      <h1 class="cover-title">${escapeHtml(title)}</h1>`)
    if (subject) {
      lines.push(`      <p class="cover-subject">${escapeHtml(subject)}</p>`)
    }
    if (author) {
      lines.push(`      <p class="cover-author">${escapeHtml(author)}</p>`)
    }
    if (description) {
      lines.push(`      <p class="cover-description">${escapeHtml(description)}</p>`)
    }
    // Optional metadata rendered as a definition list
    const knownKeys = new Set([
      'title', 'author', 'description', 'language', 'generator', 'topic',
      'subject', 'pageSetup',
    ])
    const extraEntries = Object.entries(meta).filter(([k]) => !knownKeys.has(k))
    if (extraEntries.length > 0) {
      lines.push('      <dl class="cover-meta">')
      for (const [k, v] of extraEntries) {
        const value = typeof v === 'string' ? v : safeStringify(v)
        lines.push(`        <dt>${escapeHtml(k)}</dt>`)
        lines.push(`        <dd>${escapeHtml(value)}</dd>`)
      }
      lines.push('      </dl>')
    }
    lines.push('    </section>')
    return lines.join('\n')
  }

  private buildFooter(generator: string): string {
    const lines: string[] = []
    lines.push('    <footer class="document-footer">')
    lines.push('      <p class="footer-generated">Generated by ' + escapeHtml(generator) + '</p>')
    lines.push('    </footer>')
    return lines.join('\n')
  }

  private buildCss(page: PdfPageSetup): string {
    return [
      '    /* ----- Page setup ----- */',
      `    @page {`,
      `      size: ${page.size};`,
      `      margin: ${page.marginTop} ${page.marginRight} ${page.marginBottom} ${page.marginLeft};`,
      '    }',
      '',
      '    /* ----- Screen styles ----- */',
      '    :root {',
      '      --accent: #1d4ed8;',
      '      --accent-dark: #1e3a8a;',
      '      --text: #0f172a;',
      '      --muted: #475569;',
      '      --border: #cbd5e1;',
      '      --code-bg: #f1f5f9;',
      '    }',
      '    * { box-sizing: border-box; }',
      '    html { -webkit-text-size-adjust: 100%; }',
      '    body {',
      '      margin: 0;',
      '      color: var(--text);',
      "      font-family: Georgia, 'Times New Roman', serif;",
      '      line-height: 1.55;',
      '      font-size: 11pt;',
      '      background: #ffffff;',
      '    }',
      '    main.document {',
      '      max-width: 760px;',
      '      margin: 0 auto;',
      '      padding: 32px 24px;',
      '    }',
      '',
      '    /* ----- Cover page ----- */',
      '    section.cover {',
      '      page-break-after: always;',
      '      min-height: 90vh;',
      '      display: flex;',
      '      flex-direction: column;',
      '      justify-content: center;',
      '      padding: 24px 0;',
      '      border-bottom: 2px solid var(--accent);',
      '    }',
      '    h1.cover-title {',
      '      font-size: 32pt;',
      '      color: var(--accent-dark);',
      '      margin: 0 0 12pt 0;',
      '      line-height: 1.15;',
      '      font-weight: bold;',
      '    }',
      '    .cover-subject {',
      '      font-size: 14pt;',
      '      color: var(--muted);',
      '      margin: 4pt 0;',
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '    }',
      '    .cover-author {',
      '      font-size: 12pt;',
      '      color: var(--text);',
      '      margin: 6pt 0;',
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '    }',
      '    .cover-description {',
      '      font-size: 11pt;',
      '      color: var(--muted);',
      '      font-style: italic;',
      '      margin: 8pt 0 0 0;',
      '      max-width: 540px;',
      '    }',
      '    dl.cover-meta {',
      '      margin: 16pt 0 0 0;',
      '      font-size: 10pt;',
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '    }',
      '    dl.cover-meta dt {',
      '      display: inline-block;',
      '      color: var(--muted);',
      '      font-weight: 600;',
      '      min-width: 100px;',
      '    }',
      '    dl.cover-meta dd {',
      '      display: inline;',
      '      margin: 0;',
      '    }',
      '    dl.cover-meta dd::after { content: "\\A"; white-space: pre; }',
      '',
      '    /* ----- Content ----- */',
      '    article.content h1, article.content h2, article.content h3,',
      '    article.content h4, article.content h5, article.content h6 {',
      '      color: var(--accent-dark);',
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '      line-height: 1.3;',
      '      margin-top: 1.6em;',
      '      margin-bottom: 0.5em;',
      '      page-break-after: avoid;',
      '    }',
      '    article.content h1 { font-size: 20pt; border-bottom: 1px solid var(--border); padding-bottom: 4pt; }',
      '    article.content h2 { font-size: 16pt; page-break-before: auto; }',
      '    article.content h3 { font-size: 13pt; }',
      '    article.content h4 { font-size: 11pt; }',
      '    article.content h5, article.content h6 { font-size: 10pt; }',
      '    article.content p { margin: 0.7em 0; orphans: 3; widows: 3; }',
      '    article.content ul, article.content ol { margin: 0.7em 0; padding-left: 1.5em; }',
      '    article.content li { margin: 0.25em 0; }',
      '    article.content a { color: var(--accent); text-decoration: underline; }',
      '    article.content blockquote {',
      "      border-left: 3px solid var(--accent);",
      '      margin: 1em 0;',
      '      padding: 4pt 12pt;',
      '      color: var(--muted);',
      "      font-family: Georgia, serif;",
      '      font-style: italic;',
      '    }',
      '    article.content hr {',
      "      border: none;",
      "      border-top: 1px solid var(--border);",
      '      margin: 1.5em 0;',
      '    }',
      '    article.content pre {',
      '      background: var(--code-bg);',
      '      border: 1px solid var(--border);',
      '      border-radius: 4px;',
      '      padding: 10pt;',
      '      overflow-x: auto;',
      "      font-family: 'Courier New', monospace;",
      '      font-size: 9.5pt;',
      '      line-height: 1.4;',
      '      page-break-inside: avoid;',
      '      white-space: pre-wrap;',
      '      word-wrap: break-word;',
      '    }',
      '    article.content code {',
      "      font-family: 'Courier New', monospace;",
      '      font-size: 9.5pt;',
      '    }',
      '    article.content :not(pre) > code {',
      '      background: var(--code-bg);',
      '      padding: 1pt 3pt;',
      '      border-radius: 2px;',
      '    }',
      '    article.content table {',
      '      border-collapse: collapse;',
      '      margin: 1em 0;',
      '      width: 100%;',
      '      page-break-inside: avoid;',
      '    }',
      '    article.content th, article.content td {',
      "      border: 1px solid var(--border);",
      '      padding: 5pt 8pt;',
      '      text-align: left;',
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '      font-size: 10pt;',
      '    }',
      '    article.content th { background: #f8fafc; font-weight: 600; }',
      '',
      '    /* ----- Footer ----- */',
      '    footer.document-footer {',
      '      margin-top: 32pt;',
      '      padding-top: 8pt;',
      "      border-top: 1px solid var(--border);",
      "      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;",
      '      font-size: 9pt;',
      '      color: var(--muted);',
      '      text-align: center;',
      '    }',
      '',
      '    /* ----- Print-specific rules ----- */',
      '    @media print {',
      '      body { background: #ffffff; font-size: 10.5pt; }',
      '      main.document { max-width: none; padding: 0; }',
      '      section.cover { min-height: 0; padding: 0 0 24pt 0; }',
      '      a { color: var(--text); text-decoration: underline; }',
      '      a[href]::after {',
      '        content: " (" attr(href) ")";',
      "        font-family: 'Courier New', monospace;",
      '        font-size: 9pt;',
      '        color: var(--muted);',
      '      }',
      '      /* Avoid link-expansion for internal anchors */',
      '      a[href^="#"]::after { content: ""; }',
      '      pre, blockquote, table, figure { page-break-inside: avoid; }',
      '      h1, h2, h3, h4, h5, h6 { page-break-after: avoid; }',
      '      .no-print { display: none !important; }',
      '    }',
    ].join('\n')
  }
}

// -------------------------------------------------------------------------
// Small input-narrowing helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function safeStringify(value: unknown): string {
  if (value === null) return 'null'
  if (value === undefined) return 'undefined'
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return String(value)
  }
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}
