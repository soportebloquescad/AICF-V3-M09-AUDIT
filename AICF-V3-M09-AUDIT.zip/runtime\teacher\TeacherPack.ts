// =============================================================================
// AICF V3 — Premium RC51 — TeacherPack
// =============================================================================
// Generates teaching materials: guide, answer key, rubrics, question bank,
// suggested activities, schedule, final project.
// =============================================================================

import type { CourseResult, Exercise, Quiz } from '../course/CourseContracts'
import { logger } from '@/lib/ai/logger'

export interface TeacherPackData {
  guide: { title: string; sections: Array<{ title: string; content: string }> }
  answerKey: Array<{ exerciseId: string; question: string; answer: string }>
  questionBank: Array<{ question: string; options: string[]; correctIndex: number; module: string }>
  suggestedActivities: string[]
  schedule: Array<{ week: number; modules: string[]; activities: string }>
  finalProject: { title: string; description: string; deliverables: string[]; rubricCriteria: string[] }
}

export class TeacherPack {
  private readonly log = logger.child({ component: 'TeacherPack' })

  generate(course: CourseResult): TeacherPackData {
    this.log.info({ courseId: course.id }, 'TeacherPack: generating')

    return {
      guide: {
        title: `Teacher Guide: ${course.title}`,
        sections: [
          { title: 'Course Overview', content: `This course covers ${course.topic} for ${course.curriculum?.audience ?? 'general learners'} at ${course.curriculum?.level ?? 'intermediate'} level. It contains ${course.modules.length} modules and ${course.lessons.length} lessons.` },
          { title: 'Teaching Strategy', content: 'Use a project-based approach. Each module builds on the previous. Encourage hands-on practice after each lesson. Use quizzes for formative assessment.' },
          { title: 'Assessment Strategy', content: `Use the ${course.quizzes.length} quizzes for formative assessment. The final exam covers all modules. Exercises should be graded using the provided rubrics.` },
          { title: 'Differentiation', content: 'For advanced students: assign additional exercises and case studies. For struggling students: provide extra examples and one-on-one support during exercise time.' },
          { title: 'Technology Requirements', content: 'Students need a computer with internet access. All materials are available in HTML, PDF, and DOCX formats. The interactive presentation works in any modern browser.' },
        ],
      },
      answerKey: this.generateAnswerKey(course),
      questionBank: this.generateQuestionBank(course),
      suggestedActivities: [
        'Group discussion: How does this topic apply to real-world scenarios?',
        'Peer review: Students review each other\'s exercise answers',
        'Mini-project: Apply concepts to a personal use case',
        'Lightning talks: Each student presents one key takeaway',
        'Role play: Act out scenarios using course concepts',
      ],
      schedule: this.generateSchedule(course),
      finalProject: {
        title: `Final Project: Apply ${course.topic}`,
        description: `Create a comprehensive project that demonstrates mastery of ${course.topic}. The project should integrate concepts from all ${course.modules.length} modules.`,
        deliverables: [
          'Project report (minimum 1000 words)',
          'Presentation (10-15 slides)',
          'Working prototype or demonstration',
          'Self-reflection document',
        ],
        rubricCriteria: [
          'Content accuracy and depth (25%)',
          'Application of course concepts (25%)',
          'Creativity and originality (20%)',
          'Presentation quality (15%)',
          'Documentation and reflection (15%)',
        ],
      },
    }
  }

  private generateAnswerKey(course: CourseResult): Array<{ exerciseId: string; question: string; answer: string }> {
    return course.exercises.map(e => ({
      exerciseId: e.id,
      question: e.question,
      answer: e.expectedAnswer,
    }))
  }

  private generateQuestionBank(course: CourseResult): Array<{ question: string; options: string[]; correctIndex: number; module: string }> {
    return course.quizzes.flatMap(q => q.questions.map(question => ({
      question: question.question,
      options: question.options,
      correctIndex: question.correctIndex,
      module: q.moduleTitle,
    })))
  }

  private generateSchedule(course: CourseResult): Array<{ week: number; modules: string[]; activities: string }> {
    const schedule: Array<{ week: number; modules: string[]; activities: string }> = []
    const modulesPerWeek = Math.max(1, Math.ceil(course.modules.length / 8))
    for (let i = 0; i < course.modules.length; i += modulesPerWeek) {
      const weekNum = Math.floor(i / modulesPerWeek) + 1
      const weekModules = course.modules.slice(i, i + modulesPerWeek).map(m => m.title)
      schedule.push({
        week: weekNum,
        modules: weekModules,
        activities: weekNum % 2 === 0 ? 'Quiz + Group discussion' : 'Exercises + Peer review',
      })
    }
    return schedule
  }
}
