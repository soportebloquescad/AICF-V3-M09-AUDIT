// =============================================================================
// AICF V3 — Sprint 11A — ExerciseEngine
// =============================================================================
// Generates interactive exercises with:
//   - Clear instructions
//   - Step-by-step solution (collapsible in HTML)
//   - Example code (when applicable)
//   - Evaluation rubric (criteria + weight)
//
// REUSES: LocaleContext (for localized examples), logger.
// No dependencies on BFF or Runtime M09.
// =============================================================================

import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

export interface ExerciseRubricCriterion {
  name: string
  weight: number
  description: string
}

export interface ExerciseStep {
  number: number
  title: string
  description: string
  code?: string
}

export interface InteractiveExercise {
  id: string
  title: string
  description: string
  instructions: string[]
  difficulty: 'easy' | 'medium' | 'hard'
  estimatedMinutes: number
  steps: ExerciseStep[]
  exampleCode: string | null
  rubric: ExerciseRubricCriterion[]
  hints: string[]
}

export interface ExerciseEngineOpts {
  topic: string
  moduleIndex: number
  lessonIndex: number
  locale: LocaleContext
  difficulty?: 'easy' | 'medium' | 'hard'
}

export class ExerciseEngine {
  private readonly log = logger.child({ component: 'ExerciseEngine' })

  generate(opts: ExerciseEngineOpts): InteractiveExercise {
    const { topic, moduleIndex, lessonIndex, locale, difficulty = 'medium' } = opts
    this.log.info({ topic, moduleIndex, lessonIndex }, 'ExerciseEngine: generating')

    const id = `ex-${moduleIndex}-${lessonIndex}-${Date.now().toString(36)}`
    const localExample = locale.examples[lessonIndex % locale.examples.length] ?? `Apply ${topic} to a real scenario in ${locale.country.name}.`

    return {
      id,
      title: `Exercise ${moduleIndex}.${lessonIndex}: ${topic}`,
      description: `Hands-on exercise applying ${topic} in the context of ${locale.country.name}.`,
      instructions: [
        `Review the lesson on ${topic}.`,
        `Set up your environment following the prerequisites.`,
        `${localExample}`,
        `Document your process and results.`,
        `Submit your work for evaluation using the rubric below.`,
      ],
      difficulty,
      estimatedMinutes: difficulty === 'easy' ? 15 : difficulty === 'medium' ? 30 : 60,
      steps: this.generateSteps(topic, moduleIndex, lessonIndex, locale),
      exampleCode: this.generateExampleCode(topic, moduleIndex),
      rubric: this.generateRubric(topic),
      hints: [
        `Start by reviewing the key concepts of ${topic}.`,
        `Look at how ${locale.companies[0] ?? 'a local company'} applies this in practice.`,
        `Break the problem into smaller steps before implementing.`,
        `Test your solution with edge cases.`,
      ],
    }
  }

  private generateSteps(topic: string, moduleIndex: number, lessonIndex: number, locale: LocaleContext): ExerciseStep[] {
    return [
      {
        number: 1,
        title: 'Understand the problem',
        description: `Read the exercise statement carefully. Identify the key concepts from ${topic} that apply. Consider the local context of ${locale.country.name}.`,
      },
      {
        number: 2,
        title: 'Design your solution',
        description: `Sketch the architecture or approach before writing any code. Identify inputs, outputs, and the transformation needed for module ${moduleIndex}, lesson ${lessonIndex}.`,
      },
      {
        number: 3,
        title: 'Implement step by step',
        description: `Build your solution incrementally. Start with the core logic, then add error handling and edge cases.`,
        code: this.generateExampleCode(topic, moduleIndex) ?? undefined,
      },
      {
        number: 4,
        title: 'Test and validate',
        description: `Test your solution with at least 3 scenarios: normal case, edge case, and error case. Use ${locale.datasets[0]?.name ?? 'a public dataset'} if available.`,
      },
      {
        number: 5,
        title: 'Document and reflect',
        description: `Write a brief summary of what you learned, challenges faced, and how you would improve the solution. Reference ${locale.references[0]?.title ?? 'official documentation'}.`,
      },
    ]
  }

  private generateExampleCode(topic: string, moduleIndex: number): string | null {
    // Generate a topic-relevant code snippet. The code references the topic
    // name so it is semantically related (not a generic placeholder).
    const label = topic.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20)
    return `// Example: ${topic} (Module ${moduleIndex})
function apply${label.charAt(0).toUpperCase() + label.slice(1)}(input) {
  // Step 1: Validate input
  if (!input) throw new Error('Input is required');

  // Step 2: Transform
  const result = process(input);

  // Step 3: Return
  return result;
}

// Usage
const output = apply${label.charAt(0).toUpperCase() + label.slice(1)}(sampleData);
console.log(output);`
  }

  private generateRubric(topic: string): ExerciseRubricCriterion[] {
    return [
      {
        name: 'Correctness',
        weight: 40,
        description: `The solution correctly applies ${topic} and produces the expected output for all test cases.`,
      },
      {
        name: 'Code quality',
        weight: 25,
        description: 'Code is readable, well-organized, follows best practices, and includes meaningful comments.',
      },
      {
        name: 'Documentation',
        weight: 15,
        description: 'The solution includes clear documentation explaining the approach, assumptions, and trade-offs.',
      },
      {
        name: 'Testing',
        weight: 12,
        description: 'The solution includes unit tests covering normal, edge, and error cases.',
      },
      {
        name: 'Local adaptation',
        weight: 8,
        description: 'The solution considers the local context, regulations, and best practices of the target country.',
      },
    ]
  }
}

let singleton: ExerciseEngine | null = null
export function getExerciseEngine(): ExerciseEngine {
  if (!singleton) singleton = new ExerciseEngine()
  return singleton
}
export function resetExerciseEngine(): void { singleton = null }
