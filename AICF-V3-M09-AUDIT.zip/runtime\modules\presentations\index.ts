// =============================================================================
// AICF V3 — Presentations Module (barrel)
// =============================================================================
// Re-exports the public typed contracts of the Presentations module plus the
// concrete PresentationModule (Épica 3 — Educational Factory).
// =============================================================================

export type {
  PresentationsModule,
  PresentationOptions,
  PresentationSlide,
  PresentationResult,
} from './interfaces'

export {
  PresentationModule,
  PRESENTATION_MODULE_METADATA,
  PRESENTATION_CAPABILITIES,
} from './PresentationModule'

export type { Slide, SlideDeck } from './PresentationModule'
