// =============================================================================
// AICF V3 — M08 Content Intelligence — PolicyEngine
// =============================================================================
// The PolicyEngine holds the registry of named policies (fast / balanced /
// premium / deep-research / economy / ...). Given a RuntimeRequest, it
// resolves the appropriate policy and returns a PolicyDefinition that the
// ContentIntelligenceEngine uses to clamp temperature, maxTokens, priority,
// cache/retry behavior, and the cost ceiling.
//
// Policies are extensible: callers can register custom modes with
// `engine.register({...})`. The PolicyMode type is intentionally permissive
// (`string & {}`) so external modules can extend it without forking the type.
// =============================================================================

import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import type {
  CachePolicy,
  RetryPolicy,
  FallbackStrategy,
  DecisionPriority,
} from './DecisionPlan'
import {
  DEFAULT_CACHE_POLICY,
  DEFAULT_RETRY_POLICY,
  DEFAULT_FALLBACK_STRATEGY,
} from './DecisionPlan'
import { logger } from '@/lib/ai/logger'

/**
 * Policy mode name. Built-in modes are 'fast' | 'balanced' | 'premium' |
 * 'deep-research' | 'economy'. The `& {}` allows external modules to
 * register additional modes without modifying this type.
 */
export type PolicyMode = 'fast' | 'balanced' | 'premium' | 'deep-research' | 'economy' | (string & {})

/**
 * Definition of a single policy mode. The ContentIntelligenceEngine consults
 * these fields when constructing a DecisionPlan.
 */
export interface PolicyDefinition {
  /** Policy mode name (unique within the engine). */
  mode: PolicyMode
  /** Human-readable description of what the policy optimizes for. */
  description: string
  /** Allowed temperature range — requests are clamped into [min, max]. */
  temperatureRange: { min: number; max: number }
  /** Default temperature when the request does not specify one. */
  defaultTemperature: number
  /** Default top-p value. */
  defaultTopP: number
  /** Hard cap on maxTokens for this policy. */
  maxTokensLimit: number
  /** Default maxTokens when the request does not specify one. */
  defaultMaxTokens: number
  /** Priority assigned to requests using this policy. */
  priority: DecisionPriority
  /** Cache policy applied to requests using this policy. */
  cachePolicy: CachePolicy
  /** Retry policy applied to requests using this policy. */
  retryPolicy: RetryPolicy
  /** Fallback strategy applied to requests using this policy. */
  fallbackStrategy: FallbackStrategy
  /** Maximum allowed cost in USD per request. 0 = unlimited. */
  costCeilingUsd: number
}

/**
 * Result returned by `PolicyEngine.evaluate()`.
 */
export interface PolicyEvaluationResult {
  /** The resolved policy definition. */
  policy: PolicyDefinition
  /** The mode name that was resolved. */
  mode: PolicyMode
  /** Whether the request explicitly requested this mode. */
  explicit: boolean
}

/**
 * The 5 built-in policy modes. Registered in the constructor.
 */
const BUILTIN_POLICIES: PolicyDefinition[] = [
  {
    mode: 'fast',
    description: 'Optimizes for latency. Low temperature, small token budget, economy provider.',
    temperatureRange: { min: 0, max: 0.5 },
    defaultTemperature: 0.3,
    defaultTopP: 0.9,
    maxTokensLimit: 1024,
    defaultMaxTokens: 1024,
    priority: 'high',
    cachePolicy: { ...DEFAULT_CACHE_POLICY, ttlSeconds: 600 },
    retryPolicy: { ...DEFAULT_RETRY_POLICY, maxAttempts: 2 },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY },
    costCeilingUsd: 0.05,
  },
  {
    mode: 'balanced',
    description: 'Default mode. Balances cost, quality, and latency for typical workloads.',
    temperatureRange: { min: 0, max: 1 },
    defaultTemperature: 0.7,
    defaultTopP: 1,
    maxTokensLimit: 8192,
    defaultMaxTokens: 4096,
    priority: 'normal',
    cachePolicy: { ...DEFAULT_CACHE_POLICY },
    retryPolicy: { ...DEFAULT_RETRY_POLICY },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY },
    costCeilingUsd: 0.5,
  },
  {
    mode: 'premium',
    description: 'Optimizes for quality. Higher temperature, larger token budget, premium provider.',
    temperatureRange: { min: 0.2, max: 1.2 },
    defaultTemperature: 0.8,
    defaultTopP: 1,
    maxTokensLimit: 16384,
    defaultMaxTokens: 8192,
    priority: 'high',
    cachePolicy: { ...DEFAULT_CACHE_POLICY, checkCache: false },
    retryPolicy: { ...DEFAULT_RETRY_POLICY, maxAttempts: 3 },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY, enabled: true },
    costCeilingUsd: 2.0,
  },
  {
    mode: 'deep-research',
    description: 'Long-form research. Low temperature for factual output, very large token budget.',
    temperatureRange: { min: 0, max: 0.7 },
    defaultTemperature: 0.4,
    defaultTopP: 0.95,
    maxTokensLimit: 32768,
    defaultMaxTokens: 16384,
    priority: 'critical',
    cachePolicy: { ...DEFAULT_CACHE_POLICY, checkCache: false, ttlSeconds: 0 },
    retryPolicy: { ...DEFAULT_RETRY_POLICY, maxAttempts: 5 },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY, enabled: true },
    costCeilingUsd: 5.0,
  },
  {
    mode: 'economy',
    description: 'Minimizes cost. Economy provider, small token budget, aggressive caching.',
    temperatureRange: { min: 0, max: 0.8 },
    defaultTemperature: 0.5,
    defaultTopP: 0.95,
    maxTokensLimit: 2048,
    defaultMaxTokens: 1024,
    priority: 'low',
    cachePolicy: { ...DEFAULT_CACHE_POLICY, ttlSeconds: 3600 },
    retryPolicy: { ...DEFAULT_RETRY_POLICY, maxAttempts: 2 },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY },
    costCeilingUsd: 0.02,
  },
]

/**
 * The PolicyEngine. Holds a registry of named policies and resolves the
 * appropriate one for a given RuntimeRequest.
 */
export class PolicyEngine {
  private readonly policies = new Map<PolicyMode, PolicyDefinition>()

  constructor() {
    for (const policy of BUILTIN_POLICIES) {
      this.policies.set(policy.mode, policy)
    }
    logger.debug(
      { count: this.policies.size, modes: this.listModes() },
      'PolicyEngine: built-in policies registered',
    )
  }

  /**
   * Register a custom policy. Overwrites any existing policy with the same mode.
   */
  register(policy: PolicyDefinition): void {
    this.policies.set(policy.mode, policy)
    logger.info({ mode: policy.mode }, 'PolicyEngine: policy registered')
  }

  /**
   * Get a policy by mode name. Returns null if not registered.
   */
  get(mode: PolicyMode): PolicyDefinition | null {
    return this.policies.get(mode) ?? null
  }

  /**
   * Returns true if a policy with the given mode is registered.
   */
  has(mode: PolicyMode): boolean {
    return this.policies.has(mode)
  }

  /**
   * List all registered policy mode names.
   */
  listModes(): PolicyMode[] {
    return Array.from(this.policies.keys())
  }

  /**
   * Evaluate the request and resolve the appropriate policy.
   *
   * Resolution order:
   *   1. request.metadata.mode
   *   2. request.metadata.policyMode
   *   3. fallback to 'balanced'
   */
  evaluate(request: RuntimeRequest): PolicyEvaluationResult {
    const explicitMode = this.extractMode(request)
    const policy = this.policies.get(explicitMode.mode) ?? this.policies.get('balanced')!
    return {
      policy,
      mode: policy.mode,
      explicit: explicitMode.explicit,
    }
  }

  private extractMode(request: RuntimeRequest): { mode: PolicyMode; explicit: boolean } {
    const meta = (request.metadata ?? {}) as Record<string, unknown>
    const rawMode = (meta.mode ?? meta.policyMode) as string | undefined
    if (typeof rawMode === 'string' && this.policies.has(rawMode)) {
      return { mode: rawMode, explicit: true }
    }
    if (typeof rawMode === 'string' && !this.policies.has(rawMode)) {
      logger.warn(
        { requestedMode: rawMode, fallback: 'balanced' },
        'PolicyEngine: unknown mode requested, falling back to balanced',
      )
    }
    return { mode: 'balanced', explicit: false }
  }
}

/**
 * Singleton PolicyEngine with built-in policies pre-registered.
 */
let singleton: PolicyEngine | null = null

export function getPolicyEngine(): PolicyEngine {
  if (!singleton) {
    singleton = new PolicyEngine()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetPolicyEngine(): void {
  singleton = null
}
