// =============================================================================
// AICF V3 — Epica 7 — Prompt Registry V2
// =============================================================================
// Versioned prompt templates with activation + archival semantics.
// Seeds 8 default prompts that map to the 8 Epica 6 PromptOrchestrator
// templates but with richer metadata (versioning, activation, archive).
// =============================================================================

export interface PromptTemplateV2 {
  id: string
  name: string
  version: string
  system: string
  user: string
  variables: string[]
  description: string
  category: 'research' | 'curriculum' | 'lesson' | 'exercise' | 'assessment' | 'slides' | 'document' | 'consistency'
  active: boolean
  archived: boolean
  createdAt: string
  updatedAt: string
  metadata: Record<string, unknown>
}

interface StoredPrompt extends PromptTemplateV2 {
  versionId: string
}

const DEFAULT_PROMPTS: Array<Pick<StoredPrompt, 'id' | 'name' | 'version' | 'system' | 'user' | 'variables' | 'description' | 'category'>> = [
  {
    id: 'research',
    name: 'Research',
    version: '2.0.0',
    system: 'You are a research assistant specializing in course topics. Respond in valid JSON with fields: summary (string), keyFacts (string[]), gaps (string[]), confidence (number 0-1).',
    user: 'Research the topic "{{topic}}" for a course in locale {{locale}} at depth {{depth}}. Return JSON only.',
    variables: ['topic', 'locale', 'depth'],
    description: 'Generates a structured research pack with summary, key facts, gaps, and confidence score.',
    category: 'research',
  },
  {
    id: 'curriculum',
    name: 'Curriculum Design',
    version: '2.0.0',
    system: 'You are an instructional designer following ADDIE and Backward Design. Create a curriculum with modules, lessons, learning outcomes, and prerequisites. Respond in valid JSON.',
    user: 'Design a {{moduleCount}}-module curriculum for "{{topic}}" at {{level}} level for {{audience}} in {{language}}. Include learning outcomes and prerequisites per module.',
    variables: ['topic', 'moduleCount', 'level', 'audience', 'language'],
    description: 'Builds a structured curriculum with modules, learning outcomes, and prerequisites.',
    category: 'curriculum',
  },
  {
    id: 'lesson',
    name: 'Lesson Writing',
    version: '2.0.0',
    system: 'You are a lesson writer producing clear, pedagogically sound lessons aligned with Bloom\'s taxonomy. Use Markdown with H2/H3 headings, learning objectives, key concepts, and key takeaways.',
    user: 'Write a {{length}} lesson about "{{topic}}" for {{audience}} at {{level}} level targeting Bloom\'s {{bloomLevel}}. Use language {{language}}. Include objectives, content (500+ words), and takeaways.',
    variables: ['topic', 'length', 'audience', 'level', 'bloomLevel', 'language'],
    description: 'Produces a complete lesson with objectives, 500+ words of content, and takeaways.',
    category: 'lesson',
  },
  {
    id: 'exercise',
    name: 'Exercise Writing',
    version: '2.0.0',
    system: 'You are an exercise designer creating realistic, scaffolded exercises. Each exercise has a question, context, expected answer, hints, and rubric criteria. Respond in valid JSON.',
    user: 'Create a {{type}} exercise for lesson "{{lessonTitle}}" on topic "{{topic}}" at {{difficulty}} difficulty in {{language}}. Include question, context, expected answer, hints, and rubric.',
    variables: ['topic', 'lessonTitle', 'type', 'difficulty', 'language'],
    description: 'Generates exercises with question, context, answer, hints, and rubric criteria.',
    category: 'exercise',
  },
  {
    id: 'assessment',
    name: 'Assessment',
    version: '2.0.0',
    system: 'You are an assessment designer creating valid, reliable, fair assessments. Return JSON with questions array; each question has id, question, options, correctIndex, explanation, difficulty, bloomLevel.',
    user: 'Create {{questionCount}} assessment questions for topic "{{topic}}" at {{level}} level in {{language}}. Mix Bloom levels. Return JSON only.',
    variables: ['topic', 'questionCount', 'level', 'language'],
    description: 'Creates valid assessment questions with explanations and Bloom-level mapping.',
    category: 'assessment',
  },
  {
    id: 'slides',
    name: 'Slide Generation',
    version: '2.0.0',
    system: 'You are a slide designer creating concise, visually-oriented slides. Return JSON with slides array; each slide has id, index, title, bullets, notes, layout.',
    user: 'Create {{slideCount}} slides for "{{topic}}" for {{audience}} in {{language}}. Use a mix of title/content/section layouts. Include speaker notes.',
    variables: ['topic', 'slideCount', 'audience', 'language'],
    description: 'Generates slide deck JSON with titles, bullets, notes, and layouts.',
    category: 'slides',
  },
  {
    id: 'document',
    name: 'Document Generation',
    version: '2.0.0',
    system: 'You are a document writer producing well-structured Markdown documents with overview, sections, and summary. Use H2 for sections, H3 for subsections.',
    user: 'Write a {{type}} document about "{{topic}}" in {{language}} for {{audience}}. Include overview, at least 3 sections, and summary.',
    variables: ['topic', 'type', 'language', 'audience'],
    description: 'Produces structured Markdown documents (teacher/student guide, workbook, etc.).',
    category: 'document',
  },
  {
    id: 'consistency',
    name: 'Consistency Check',
    version: '2.0.0',
    system: 'You are a consistency editor. Review content for terminology, style, definition, reference, naming, length, and language consistency. Respond in JSON with score (0-100), issues[], recommendations[].',
    user: 'Review the following content for consistency issues. Terminology guide: {{terminology}}. Content: {{content}}',
    variables: ['terminology', 'content'],
    description: 'Reviews content for 7 consistency dimensions and returns score + issues.',
    category: 'consistency',
  },
]

class PromptRegistryV2Impl {
  private readonly prompts = new Map<string, StoredPrompt[]>()
  private readonly activeVersion = new Map<string, string>()

  constructor() {
    for (const def of DEFAULT_PROMPTS) {
      this.seedDefault(def)
    }
  }

  private seedDefault(def: Pick<StoredPrompt, 'id' | 'name' | 'version' | 'system' | 'user' | 'variables' | 'description' | 'category'>): void {
    const now = new Date().toISOString()
    const versionId = `${def.id}@${def.version}`
    const stored: StoredPrompt = {
      ...def,
      versionId,
      active: true,
      archived: false,
      createdAt: now,
      updatedAt: now,
      metadata: { seeded: true, source: 'default-v2' },
    }
    this.prompts.set(def.id, [stored])
    this.activeVersion.set(def.id, versionId)
  }

  register(template: Omit<PromptTemplateV2, 'createdAt' | 'updatedAt' | 'active' | 'archived'>): string {
    const now = new Date().toISOString()
    const versionId = `${template.id}@${template.version}`
    const stored: StoredPrompt = {
      ...template,
      versionId,
      active: false,
      archived: false,
      createdAt: now,
      updatedAt: now,
      metadata: { ...template.metadata, seeded: false },
    }
    const versions = this.prompts.get(template.id) ?? []
    versions.push(stored)
    this.prompts.set(template.id, versions)
    if (!this.activeVersion.has(template.id)) {
      this.activate(template.id, versionId)
    }
    return versionId
  }

  get(id: string, versionId?: string): PromptTemplateV2 | null {
    const versions = this.prompts.get(id)
    if (!versions || versions.length === 0) return null
    if (versionId) {
      return versions.find((v) => v.versionId === versionId) ?? null
    }
    const activeId = this.activeVersion.get(id)
    return versions.find((v) => v.versionId === activeId) ?? versions[versions.length - 1]
  }

  listVersions(id: string): string[] {
    const versions = this.prompts.get(id) ?? []
    return versions.filter((v) => !v.archived).map((v) => v.versionId)
  }

  list(): string[] {
    return Array.from(this.prompts.keys()).sort()
  }

  archive(id: string, versionId: string): boolean {
    const versions = this.prompts.get(id)
    if (!versions) return false
    const v = versions.find((pv) => pv.versionId === versionId)
    if (!v) return false
    v.archived = true
    v.updatedAt = new Date().toISOString()
    if (this.activeVersion.get(id) === versionId) {
      const next = versions.find((pv) => !pv.archived)
      if (next) this.activeVersion.set(id, next.versionId)
      else this.activeVersion.delete(id)
    }
    return true
  }

  activate(id: string, versionId: string): boolean {
    const versions = this.prompts.get(id)
    if (!versions) return false
    const v = versions.find((pv) => pv.versionId === versionId && !pv.archived)
    if (!v) return false
    for (const pv of versions) {
      pv.active = pv.versionId === versionId
      pv.updatedAt = new Date().toISOString()
    }
    this.activeVersion.set(id, versionId)
    return true
  }

  getActiveVersion(id: string): string | null {
    return this.activeVersion.get(id) ?? null
  }

  render(id: string, variables: Record<string, string | number>): { system: string; user: string } | null {
    const template = this.get(id)
    if (!template) return null
    const system = this.interpolate(template.system, variables)
    const user = this.interpolate(template.user, variables)
    return { system, user }
  }

  private interpolate(template: string, variables: Record<string, string | number>): string {
    return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
      const v = variables[key]
      if (v === undefined || v === null) return `{{${key}}}`
      return String(v)
    })
  }

  size(): number {
    return this.prompts.size
  }

  totalVersions(): number {
    let total = 0
    for (const versions of this.prompts.values()) {
      total += versions.length
    }
    return total
  }
}

export const promptRegistryV2 = new PromptRegistryV2Impl()
