// =============================================================================
// AICF V3 — Runtime Events (Sprint 16: Extended Event Types)
// =============================================================================
// Event types emitted by the RuntimeBootstrap, RuntimeEventBus, and the
// pipeline. Sprint 15 covered module lifecycle; Sprint 16 adds request,
// pipeline, and health-change events. Sprint Foundation-Core adds the full
// Enterprise Architecture EDA event set (request lifecycle: receive →
// validate → policy → route → execute → audit → respond).
// =============================================================================

/**
 * All Runtime event types.
 *
 * Sprint 15 (module lifecycle):
 *   - module.loaded, module.initializing, module.initialized, module.failed,
 *     module.registered, module.disposed
 *   - runtime.bootstrap.start, runtime.bootstrap.complete, runtime.bootstrap.failed,
 *     runtime.ready, runtime.shutdown
 *
 * Sprint 16 (request + pipeline + health):
 *   - ModuleRegistered (with capabilities)
 *   - ModuleReady
 *   - ModuleFailed (with error)
 *   - ModuleHealthChanged (with health status)
 *   - RequestStarted (with operation)
 *   - RequestFinished (with durationMs)
 *   - PipelineStarted (with stages)
 *   - PipelineFinished (with status)
 *
 * Sprint Foundation-Core (full EDA request lifecycle):
 *   - RequestReceived, ResponseReturned
 *   - ValidationStarted, ValidationCompleted
 *   - PolicyStarted, PolicyCompleted
 *   - RoutingStarted, RoutingCompleted
 *   - ExecutionStarted, ExecutionFinished
 *   - AuditStarted, AuditCompleted
 */
export type RuntimeEventType =
  // Sprint 15 — module lifecycle
  | 'module.loaded'
  | 'module.initializing'
  | 'module.initialized'
  | 'module.failed'
  | 'module.registered'
  | 'module.disposed'
  | 'runtime.bootstrap.start'
  | 'runtime.bootstrap.complete'
  | 'runtime.bootstrap.failed'
  | 'runtime.ready'
  | 'runtime.shutdown'
  // Sprint 16 — extended events
  | 'ModuleRegistered'
  | 'ModuleReady'
  | 'ModuleFailed'
  | 'ModuleHealthChanged'
  | 'RequestStarted'
  | 'RequestFinished'
  | 'PipelineStarted'
  | 'PipelineFinished'
  // Sprint Foundation-Core — full EDA request lifecycle
  | 'RequestReceived'
  | 'ValidationStarted'
  | 'ValidationCompleted'
  | 'PolicyStarted'
  | 'PolicyCompleted'
  | 'RoutingStarted'
  | 'RoutingCompleted'
  | 'ExecutionStarted'
  | 'ExecutionFinished'
  | 'AuditStarted'
  | 'AuditCompleted'
  | 'ResponseReturned'

/**
 * A Runtime event emitted by the RuntimeEventBus.
 */
export interface RuntimeEvent {
  /** Event type. */
  type: RuntimeEventType

  /** ISO timestamp. */
  timestamp: string

  /** Module ID (for module.* events). */
  moduleId?: string

  /** Optional error message (for *.failed events). */
  error?: string

  /** Optional payload. */
  data?: Record<string, unknown>

  /** Optional request ID (for request.* and pipeline.* events). */
  requestId?: string

  /** Optional operation (for request.* events). */
  operation?: string

  /** Optional health status (for health-changed events). */
  health?: 'healthy' | 'degraded' | 'unhealthy'

  /** Optional capabilities list (for ModuleRegistered events). */
  capabilities?: string[]

  /** Optional duration in ms (for RequestFinished events). */
  durationMs?: number

  /** Optional stages list (for PipelineStarted events). */
  stages?: string[]

  /** Optional pipeline status (for PipelineFinished events) OR HTTP status
   * code (for ResponseReturned / ExecutionFinished events). The union
   * preserves both existing callers (string status) and the new EDA
   * lifecycle callers (numeric HTTP status).
   */
  status?: 'completed' | 'failed' | number

  // -------------------------------------------------------------------------
  // Sprint Foundation-Core — EDA lifecycle event fields
  // -------------------------------------------------------------------------

  /** Whether the validation step passed (for ValidationCompleted events). */
  valid?: boolean

  /** Validation errors (for ValidationCompleted events). */
  errors?: string[]

  /** Whether the policy check allowed the operation (for PolicyCompleted). */
  allowed?: boolean

  /** Provider selected by the routing step (for RoutingCompleted events). */
  provider?: string

  /** Model selected by the routing step (for RoutingCompleted events). */
  model?: string

  /** Module that produced or handled this event (for Execution* / Audit*). */
  module?: string

  /** Whether the execution succeeded (for ExecutionFinished events). */
  success?: boolean
}

/**
 * Factory: creates a RuntimeEvent with the current timestamp.
 * Supports all Sprint 16 fields plus the Sprint Foundation-Core EDA
 * lifecycle fields (valid, errors, allowed, provider, model, module,
 * success, numeric status).
 */
export function createRuntimeEvent(
  type: RuntimeEventType,
  opts?: {
    moduleId?: string
    error?: string
    data?: Record<string, unknown>
    requestId?: string
    operation?: string
    health?: 'healthy' | 'degraded' | 'unhealthy'
    capabilities?: string[]
    durationMs?: number
    stages?: string[]
    status?: 'completed' | 'failed' | number
    // Sprint Foundation-Core EDA lifecycle fields
    valid?: boolean
    errors?: string[]
    allowed?: boolean
    provider?: string
    model?: string
    module?: string
    success?: boolean
  },
): RuntimeEvent {
  return {
    type,
    timestamp: new Date().toISOString(),
    moduleId: opts?.moduleId,
    error: opts?.error,
    data: opts?.data,
    requestId: opts?.requestId,
    operation: opts?.operation,
    health: opts?.health,
    capabilities: opts?.capabilities,
    durationMs: opts?.durationMs,
    stages: opts?.stages,
    status: opts?.status,
    valid: opts?.valid,
    errors: opts?.errors,
    allowed: opts?.allowed,
    provider: opts?.provider,
    model: opts?.model,
    module: opts?.module,
    success: opts?.success,
  }
}
