// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Template Interface
// =============================================================================
// A workflow template is a parameterized factory for `WorkflowDefinition`s.
// Templates let non-developer users register reusable workflows (e.g. "Course
// from Topic", "Quiz from Outline") without writing raw DAGs.
//
// Sprint 13+14 spec requirements covered:
//   - `load()` returns a fully-formed `WorkflowDefinition` ready to execute
//   - `validate(inputs)` lets callers check inputs before invoking the engine
//   - Self-describing `name` / `version` / `description` for registry listing
// =============================================================================

import type { WorkflowDefinition } from '@/lib/runtime/contracts/workflow'

/**
 * Workflow template contract. Implementations typically wrap a JSON
 * definition with parameter substitution; `validate` runs before `load`.
 */
export interface ITemplate {
  /** Template name (unique within the registry). */
  readonly name: string
  /** Semver version of the template. */
  readonly version: string
  /** Short human-readable description. */
  readonly description: string
  /** Materialize the template into a fully-resolved workflow definition. */
  load(): Promise<WorkflowDefinition>
  /** Validate caller-supplied inputs against the template's input schema. */
  validate(inputs: Record<string, unknown>): { valid: boolean; errors: string[] }
}
