// =============================================================================
// AICF V3 — PPTX Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a PPTX-compatible slide structure, returned
// as a JSON string. The JSON shape is:
//
//   [
//     {
//       "title":   "Slide title",
//       "bullets": ["Bullet one", "Bullet two"],
//       "notes":   "Speaker notes for the slide"
//     },
//     ...
//   ]
//
// The structure can be consumed by `pptxgenjs` (or any other slide library)
// to produce a real .pptx file. Slides are split at level-1 and level-2
// Markdown headings; subsequent non-blank lines become bullet points.
//
// The exporter NEVER generates or modifies content — it only re-formats the
// supplied Markdown into the slide-structure JSON. Metadata is projected into
// a leading title slide and a trailing closing slide when present.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { markdownToSlides } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by PPTXExporter.export(). */
export type PptxExportMetadata = Record<string, unknown>

/** A single slide in the PPTX structure. */
export interface PptxSlide {
  /** Slide title. */
  title: string
  /** Bullet points on the slide. */
  bullets: string[]
  /** Speaker notes for the slide. */
  notes: string
}

/**
 * PPTXExporter — transforms Markdown to a PPTX-compatible slide structure JSON.
 */
export class PPTXExporter {
  /**
   * Transform `content` (Markdown) into a JSON-encoded slide array.
   *
   * @param content  Markdown source text. Headings (#, ##) start new slides.
   * @param metadata Optional metadata: { title, author, description, topic, ... }.
   * @returns A JSON string of `PptxSlide[]`.
   */
  export(content: string, metadata?: PptxExportMetadata): string {
    const meta = metadata ?? {}
    const slides = this.buildSlides(content ?? '', meta)
    return JSON.stringify(slides, null, 2)
  }

  // -------------------------------------------------------------------------
  // Internal helpers
  // -------------------------------------------------------------------------

  private buildSlides(content: string, meta: PptxExportMetadata): PptxSlide[] {
    const slides: PptxSlide[] = []
    const title = asString(meta.title, asString(meta.topic, ''))
    const author = asString(meta.author, '')
    const description = asString(meta.description, '')
    const topic = asString(meta.topic, '')

    // Title slide — only emit when we have a title (from metadata or content)
    if (title) {
      const titleBullets: string[] = []
      if (topic && topic !== title) titleBullets.push(topic)
      if (description) titleBullets.push(description)
      if (author) titleBullets.push(`Presenter: ${author}`)
      slides.push({
        title,
        bullets: titleBullets,
        notes: 'Opening slide. Welcome the audience and introduce the topic.',
      })
    }

    // Body slides from Markdown
    const bodySlides = markdownToSlides(content)
    for (const s of bodySlides) {
      // If the first body slide has the same title as the title slide, drop
      // its title to avoid duplication — keep its bullets.
      if (
        slides.length > 0 &&
        slides[0].title === s.title &&
        s.bullets.length === 0
      ) {
        continue
      }
      slides.push({
        title: s.title || `Slide ${slides.length + 1}`,
        bullets: s.bullets,
        notes: s.notes,
      })
    }

    // Closing slide
    slides.push({
      title: 'Thank You',
      bullets: title ? [title] : [],
      notes: 'Closing slide. Invite questions and share next steps.',
    })

    // If we somehow produced zero slides (empty content + no metadata),
    // emit a single placeholder so the output is never an empty array.
    if (slides.length === 0) {
      slides.push({
        title: 'Untitled Slide',
        bullets: [],
        notes: 'No content provided.',
      })
    }

    return slides
  }
}

// -------------------------------------------------------------------------
// Small input-narrowing helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}
