// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Quiz Generator
// =============================================================================
// Concrete `IGenerator` implementation for the "quiz" content category.
// Produces a finished quiz (title + description + outline + multiple-choice
// questions with options, correctIndex, and explanation) by orchestrating
// two AI adapter calls — one for the outline and one for the questions.
// Mirrors the prompt strategy of the legacy `CourseWorker` pattern,
// specialized for assessments, and emits `WorkflowArtifact` entries ready
// for the artifact store.
//
// Sprint 13+14 spec requirements covered:
//   - Implements `IGenerator` (uniform generator contract)
//   - `generatorType = 'quiz'` (registry dispatch key)
//   - `canHandle('quiz')` returns true
//   - Returns `GeneratorOutput` with content, modules (questions), outline,
//     title, description, artifacts, and provider/model/token attribution
//   - Emits typed `WorkflowArtifact`s via `createArtifact`
// =============================================================================

import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type {
  GeneratorInput,
  GeneratorOutput,
  GeneratorType,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  TokenUsage,
  WorkflowArtifact,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { createArtifact } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Per-token cost estimate (platform currency units). */
const COST_PER_TOKEN = 0.000_002

/** Default model when neither the input nor context specify one. */
const DEFAULT_MODEL = 'groq-llama-3.3-70b'

/**
 * Resolve the model to use for this generation. Falls back through
 * `ctx.model`, a string `metadata.model`, then the default. Returns a
 * string in all cases.
 */
function resolveModel(
  ctx: WorkflowContext,
  input: GeneratorInput,
  fallback: string,
): string {
  if (typeof ctx.model === 'string' && ctx.model.length > 0) return ctx.model
  const metaModel = input.metadata?.['model']
  if (typeof metaModel === 'string' && metaModel.length > 0) return metaModel
  return fallback
}

/** Question shape produced by the generator. */
interface QuizQuestion {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation?: string
}

/** Outline payload returned by the first AI call. */
interface OutlinePayload {
  title: string
  description: string
  outline: string
}

/** Questions payload returned by the second AI call. */
interface QuestionsPayload {
  questions: Array<{
    question?: string
    options?: unknown
    correctIndex?: unknown
    explanation?: string
  }>
}

/**
 * Quiz generator. Uses a two-step prompt strategy (outline → questions) to
 * produce a complete quiz from a topic.
 */
export class QuizGenerator implements IGenerator {
  public readonly name = 'quiz-generator'
  public readonly generatorType: GeneratorType = 'quiz'
  private readonly adapter: AIAdapter

  constructor(aiAdapter: AIAdapter) {
    this.adapter = aiAdapter
  }

  public canHandle(contentType: string): boolean {
    return contentType === 'quiz'
  }

  /**
   * Generate a complete quiz from `input.topic`. Emits a primary quiz
   * artifact plus a markdown rendering of the same content.
   */
  public async generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const startMs = Date.now()
    const model = resolveModel(ctx, input, DEFAULT_MODEL)
    const topic = input.topic
    const questionCount = input.modules ?? 10

    logger.info(
      {
        generator: this.name,
        executionId: ctx.executionId,
        topic,
        questionCount,
        model,
      },
      'QuizGenerator: starting',
    )

    try {
      // --- Stage 1: outline ------------------------------------------------
      const outlineResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert assessment designer. Generate a quiz outline covering the key concepts. Respond in valid JSON only.',
          },
          { role: 'user', content: buildOutlinePrompt(input, questionCount) },
        ],
        temperature: 0.7,
        maxTokens: 1024,
      } satisfies ChatRequest)

      const outline = parseOutline(outlineResponse.content, topic)

      // --- Stage 2: questions ---------------------------------------------
      const questionsResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert assessment designer. Generate multiple-choice questions, each with options and the index of the correct option. Respond in valid JSON only.',
          },
          { role: 'user', content: buildQuestionsPrompt(input, outline.title, questionCount) },
        ],
        temperature: 0.7,
        maxTokens: 4096,
      } satisfies ChatRequest)

      const questions = parseQuestions(questionsResponse.content)

      // --- Aggregate token usage ------------------------------------------
      const tokensUsed = addUsage(
        usageFromResponse(outlineResponse.usage),
        usageFromResponse(questionsResponse.usage),
      )
      const cost = tokensUsed.totalTokens * COST_PER_TOKEN

      // --- Assemble content body ------------------------------------------
      const content = renderQuizMarkdown(topic, outline, questions)
      const artifacts = await buildQuizArtifacts(
        ctx.executionId,
        this.name,
        outline,
        questions,
        content,
        {
          model,
          provider: questionsResponse.provider || outlineResponse.provider,
        },
      )

      logger.info(
        {
          generator: this.name,
          executionId: ctx.executionId,
          durationMs: Date.now() - startMs,
          questionCount: questions.length,
          tokens: tokensUsed.totalTokens,
        },
        'QuizGenerator: completed',
      )

      return {
        ok: true,
        content,
        modules: questions,
        outline: outline.outline,
        title: outline.title,
        description: outline.description,
        artifacts,
        tokensUsed,
        cost,
        provider: questionsResponse.provider || outlineResponse.provider,
        model,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.error(
        { generator: this.name, executionId: ctx.executionId, error: message },
        'QuizGenerator: failed',
      )
      return {
        ok: false,
        content: '',
        artifacts: [],
        error: message,
        model,
      }
    }
  }
}

// =============================================================================
// Prompt builders
// =============================================================================

function buildOutlinePrompt(input: GeneratorInput, questionCount: number): string {
  return `Generate a quiz outline for: "${input.topic}"
Audience: ${input.audience ?? 'general'}
Level: ${input.level ?? 'beginner'}
Language: ${input.language ?? 'English'}
Target question count: ${questionCount}

Respond in JSON format:
{
  "title": "Quiz Title",
  "description": "Quiz description (2-3 sentences)",
  "outline": "Brief outline of the quiz scope"
}`
}

function buildQuestionsPrompt(
  input: GeneratorInput,
  quizTitle: string,
  questionCount: number,
): string {
  return `Generate ${questionCount} multiple-choice questions for the quiz: "${quizTitle}"
Topic: ${input.topic}
Level: ${input.level ?? 'beginner'}
Language: ${input.language ?? 'English'}

Each question MUST have an options array and a correctIndex integer. Respond in JSON format:
{
  "questions": [
    {
      "question": "Question text?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctIndex": 0,
      "explanation": "Why this is the correct answer"
    }
  ]
}`
}

// =============================================================================
// JSON parsing helpers (graceful fallback on malformed JSON)
// =============================================================================

function parseOutline(raw: string, topic: string): OutlinePayload {
  try {
    const parsed = JSON.parse(raw) as Partial<OutlinePayload>
    return {
      title: typeof parsed.title === 'string' && parsed.title.length > 0
        ? parsed.title
        : topic,
      description: typeof parsed.description === 'string' ? parsed.description : '',
      outline: typeof parsed.outline === 'string' ? parsed.outline : raw,
    }
  } catch {
    return {
      title: topic,
      description: raw.slice(0, 200),
      outline: raw,
    }
  }
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value
    .filter((v): v is string => typeof v === 'string' && v.length > 0)
    .map((v) => v)
}

function parseQuestions(raw: string): QuizQuestion[] {
  try {
    const parsed = JSON.parse(raw) as Partial<QuestionsPayload>
    const rawQuestions = parsed.questions ?? []
    return rawQuestions.map(
      (q, index): QuizQuestion => {
        const options = asStringArray(q.options)
        const rawIdx = q.correctIndex
        const correctIndex =
          typeof rawIdx === 'number' && Number.isInteger(rawIdx)
            ? Math.max(0, Math.min(rawIdx, Math.max(0, options.length - 1)))
            : 0
        const question: QuizQuestion = {
          id: `q-${index + 1}`,
          question:
            typeof q.question === 'string' && q.question.length > 0
              ? q.question
              : `Question ${index + 1}`,
          options:
            options.length > 0
              ? options
              : ['Option A', 'Option B', 'Option C', 'Option D'],
          correctIndex,
        }
        if (typeof q.explanation === 'string' && q.explanation.length > 0) {
          question.explanation = q.explanation
        }
        return question
      },
    )
  } catch {
    return [
      {
        id: 'q-1',
        question: 'Generated Question',
        options: ['Option A', 'Option B', 'Option C', 'Option D'],
        correctIndex: 0,
        explanation: raw.slice(0, 500),
      },
    ]
  }
}

// =============================================================================
// Markdown rendering
// =============================================================================

function renderQuizMarkdown(
  topic: string,
  outline: OutlinePayload,
  questions: QuizQuestion[],
): string {
  const lines: string[] = []
  lines.push(`# ${outline.title}`)
  lines.push('')
  lines.push(`> ${outline.description}`)
  lines.push('')
  lines.push(`**Topic:** ${topic}`)
  lines.push('')
  lines.push('## Outline')
  lines.push('')
  lines.push(outline.outline)
  lines.push('')
  lines.push('## Questions')
  lines.push('')
  questions.forEach((q, idx) => {
    lines.push(`### ${idx + 1}. ${q.question}`)
    lines.push('')
    q.options.forEach((opt, oIdx) => {
      const marker = oIdx === q.correctIndex ? '*' : ' '
      lines.push(`${marker}- [${oIdx === q.correctIndex ? 'x' : ' '}] ${opt}`)
    })
    if (q.explanation !== undefined && q.explanation.length > 0) {
      lines.push('')
      lines.push(`_Explanation: ${q.explanation}_`)
    }
    lines.push('')
  })
  return lines.join('\n')
}

// =============================================================================
// Artifact construction
// =============================================================================

async function buildQuizArtifacts(
  executionId: string,
  generatorName: string,
  outline: OutlinePayload,
  questions: QuizQuestion[],
  markdown: string,
  attribution: { model: string; provider: string },
): Promise<WorkflowArtifact[]> {
  const json = JSON.stringify(
    {
      title: outline.title,
      description: outline.description,
      outline: outline.outline,
      questions,
    },
    null,
    2,
  )

  const [quizArtifact, markdownArtifact] = await Promise.all([
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (quiz)`,
      'quiz',
      json,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (markdown)`,
      'markdown',
      markdown,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
  ])

  return [quizArtifact, markdownArtifact]
}

// =============================================================================
// Token usage helpers
// =============================================================================

function usageFromResponse(usage: {
  promptTokens: number
  completionTokens: number
  totalTokens: number
} | null): TokenUsage {
  if (!usage) {
    return { promptTokens: 0, completionTokens: 0, totalTokens: 0 }
  }
  return {
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
    totalTokens: usage.totalTokens,
  }
}

function addUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    promptTokens: a.promptTokens + b.promptTokens,
    completionTokens: a.completionTokens + b.completionTokens,
    totalTokens: a.totalTokens + b.totalTokens,
  }
}
