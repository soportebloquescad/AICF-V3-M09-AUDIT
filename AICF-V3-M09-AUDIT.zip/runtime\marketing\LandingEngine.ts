// =============================================================================
// AICF V3 — Sprint 11B — LandingEngine
// =============================================================================
// Single responsibility: generate marketing landing pages.
//
// Generates a self-contained HTML landing page with:
//   - Hero section (title, subtitle, description)
//   - Benefits list
//   - Course modules
//   - Pricing
//   - Call-to-action button
//
// REUSES: ThemePreset (colors, typography), LocaleContext (local examples),
// logger. No dependencies on BFF or Runtime M09.
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import type { LocaleContext } from '../locale/CountryEngine'
import { logger } from '@/lib/ai/logger'

export interface LandingData {
  title: string
  subtitle: string
  description: string
  benefits: string[]
  modules: Array<{ title: string; description: string }>
  price: number
  currency: string
  ctaText: string
}

export interface LandingResult {
  html: string
  data: LandingData
}

export class LandingEngine {
  private readonly log = logger.child({ component: 'LandingEngine' })

  generate(opts: {
    title: string
    subtitle: string
    description: string
    moduleCount: number
    price: number
    currency: string
    locale: LocaleContext
    theme: ThemePreset
  }): LandingResult {
    const { title, subtitle, description, moduleCount, price, currency, locale, theme } = opts

    const benefits = [
      `${moduleCount} comprehensive modules`,
      `Adapted for ${locale.country.name}`,
      `${locale.examples.length}+ practical examples`,
      `Interactive exercises with solutions`,
      `Certificate of completion`,
      `Premium slide deck included`,
    ]

    const modules = Array.from({ length: moduleCount }, (_, i) => ({
      title: `Module ${i + 1}`,
      description: locale.examples[i % locale.examples.length] ?? `Key concepts of ${title}, module ${i + 1}.`,
    }))

    const data: LandingData = {
      title, subtitle, description, benefits, modules,
      price, currency, ctaText: 'Enroll Now',
    }

    const html = this.buildHtml(data, theme, locale)
    this.log.info({ title, moduleCount, price }, 'LandingEngine: generated')
    return { html, data }
  }

  private buildHtml(data: LandingData, theme: ThemePreset, locale: LocaleContext): string {
    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderBaseCss(theme)
    const c = theme.colors
    const formattedPrice = new Intl.NumberFormat(locale.locale, {
      style: 'currency', currency: data.currency,
    }).format(data.price)

    return `<!DOCTYPE html>
<html lang="${locale.locale}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escape(data.title)} — Premium Course</title>
  <meta name="description" content="${this.escape(data.description)}">
  <style>
    ${themeCss}
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: var(--font-body); color: var(--color-text); line-height: 1.6; }
    .hero { background: linear-gradient(135deg, var(--color-primary), var(--color-accent)); color: var(--color-primary-fg); padding: 5rem 2rem; text-align: center; }
    .hero h1 { font-size: 3rem; margin-bottom: 1rem; font-family: var(--font-heading); }
    .hero .subtitle { font-size: 1.3rem; opacity: 0.9; max-width: 600px; margin: 0 auto 1rem; }
    .hero .description { font-size: 1.1rem; opacity: 0.8; max-width: 700px; margin: 0 auto 2rem; }
    .hero .cta { background: var(--color-background); color: var(--color-primary); padding: 1rem 2.5rem; border-radius: var(--radius); text-decoration: none; font-weight: 700; font-size: 1.2rem; display: inline-block; font-family: var(--font-heading); transition: transform 0.2s; }
    .hero .cta:hover { transform: scale(1.05); }
    .section { max-width: 900px; margin: 3rem auto; padding: 0 2rem; }
    .section h2 { color: var(--color-primary); text-align: center; margin-bottom: 2rem; font-family: var(--font-heading); }
    .benefits-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; }
    .benefit { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1.5rem; text-align: center; }
    .benefit .icon { font-size: 2.5rem; margin-bottom: 0.5rem; }
    .benefit .text { font-size: 1rem; color: var(--color-text); }
    .modules { display: grid; gap: 1rem; }
    .module { background: var(--color-surface); border-left: 4px solid var(--color-primary); padding: 1rem 1.5rem; border-radius: 0 var(--radius) var(--radius) 0; }
    .module h3 { color: var(--color-text); margin: 0 0 0.3rem; font-family: var(--font-heading); }
    .module p { color: var(--color-text-muted); font-size: 0.9rem; margin: 0; }
    .pricing { text-align: center; background: var(--color-surface); border-radius: var(--radius); padding: 3rem 2rem; max-width: 500px; margin: 3rem auto; }
    .pricing .price { font-size: 3rem; font-weight: 700; color: var(--color-primary); font-family: var(--font-heading); }
    .pricing .currency { font-size: 1.5rem; vertical-align: top; }
    .pricing .cta { background: var(--color-success); color: white; padding: 1rem 3rem; border-radius: var(--radius); text-decoration: none; font-weight: 700; font-size: 1.2rem; display: inline-block; margin-top: 1.5rem; font-family: var(--font-heading); }
    .footer { background: var(--color-text); color: var(--color-text-muted); text-align: center; padding: 2rem; margin-top: 3rem; }
    .footer a { color: var(--color-accent); }
    @media (max-width: 768px) { .hero h1 { font-size: 2rem; } .benefits-grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <div class="hero">
    <h1>${this.escape(data.title)}</h1>
    <p class="subtitle">${this.escape(data.subtitle)}</p>
    <p class="description">${this.escape(data.description)}</p>
    <a href="#pricing" class="cta">${this.escape(data.ctaText)}</a>
  </div>

  <div class="section">
    <h2>What You'll Get</h2>
    <div class="benefits-grid">
      ${data.benefits.map((b, i) => {
        const icons = ['📚', '🌍', '💡', '✏️', '🏆', '🎨']
        return `<div class="benefit"><div class="icon">${icons[i % icons.length]}</div><div class="text">${this.escape(b)}</div></div>`
      }).join('')}
    </div>
  </div>

  <div class="section">
    <h2>Course Modules</h2>
    <div class="modules">
      ${data.modules.map((m) => `<div class="module"><h3>${this.escape(m.title)}</h3><p>${this.escape(m.description)}</p></div>`).join('')}
    </div>
  </div>

  <div id="pricing" class="pricing">
    <h2>Investment</h2>
    <div class="price"><span class="currency">${this.escape(data.currency)}</span>${data.price}</div>
    <p style="color: var(--color-text-muted); margin: 0.5rem 0;">One-time payment · Lifetime access · Certificate included</p>
    <a href="#" class="cta">${this.escape(data.ctaText)}</a>
  </div>

  <div class="footer">
    <p>&copy; ${new Date().getFullYear()} AICF V3 Academy · Adapted for ${this.escape(locale.country.name)}</p>
    <p style="margin-top: 0.5rem; font-size: 0.85rem;">Generated by AICF V3 LandingEngine</p>
  </div>
</body>
</html>`
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }
}

let singleton: LandingEngine | null = null
export function getLandingEngine(): LandingEngine {
  if (!singleton) singleton = new LandingEngine()
  return singleton
}
export function resetLandingEngine(): void { singleton = null }
