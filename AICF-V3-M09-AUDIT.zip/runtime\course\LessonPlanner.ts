// =============================================================================
// AICF V3 — Epica 8 — Lesson Planner Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { ModulePlan, LessonPlan, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export class LessonPlanner implements EngineContract {
  readonly name = 'lesson-planner'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('LessonPlanner: invalid input — expected ModulePlan[]')
    }
    const modules = input as ModulePlan[]
    if (this.opts.aiAdapter) {
      try {
        return await this.planWithAI(modules)
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'LessonPlanner: AI failed, using fallback')
      }
    }
    return this.planDeterministic(modules)
  }

  validate(input: unknown): boolean {
    if (!Array.isArray(input)) return false
    if (input.length === 0) return false
    for (const item of input) {
      if (typeof item !== 'object' || item === null) return false
      const obj = item as Record<string, unknown>
      if (typeof obj.id !== 'string' || typeof obj.title !== 'string') return false
    }
    return true
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async planWithAI(modules: ModulePlan[]): Promise<LessonPlan[]> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a lesson planner. For each module, generate 3 lessons. Respond as JSON array. Each lesson has: moduleId, moduleTitle, lessonIndex, title, summary, learningObjectives (string[]), bloomLevel (Remember|Understand|Apply|Analyze|Evaluate|Create), length (short|standard|long), durationMinutes (number), keyConcepts (string[]).',
        },
        {
          role: 'user',
          content: `Modules: ${JSON.stringify(modules.map((m) => ({ id: m.id, title: m.title, summary: m.summary, outcomes: m.learningOutcomes })))}\n\nReturn JSON array of lessons.`,
        },
      ],
      temperature: 0.4,
      maxTokens: 6144,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as Array<Partial<LessonPlan>>
    return parsed.map((p, i) => this.assembleLessonPlan(p, modules, i, resp.provider as Provider, resp.model))
  }

  private planDeterministic(modules: ModulePlan[]): LessonPlan[] {
    const lessons: LessonPlan[] = []
    const lessonArcs = [
      { title: 'Introduction & Foundations', bloom: 'Remember', length: 'short', minutes: 30 },
      { title: 'Core Concepts & Applications', bloom: 'Understand', length: 'standard', minutes: 45 },
      { title: 'Practice & Deep Dive', bloom: 'Apply', length: 'long', minutes: 60 },
    ]
    for (const mod of modules) {
      for (let i = 0; i < mod.lessonCount; i++) {
        const arc = lessonArcs[i % lessonArcs.length]
        const parsed: Partial<LessonPlan> = {
          moduleId: mod.id,
          moduleTitle: mod.title,
          lessonIndex: i,
          title: `${arc.title}: ${mod.title}`,
          summary: `Lesson ${i + 1} of ${mod.title} covers ${arc.title.toLowerCase()} relevant to the module. Students will explore the key concepts, work through examples, and apply their understanding through guided practice.`,
          learningObjectives: [
            `Identify the foundational concepts of ${mod.title}`,
            `Explain how ${arc.title.toLowerCase()} apply to ${mod.title}`,
            `Apply learned concepts to practical exercises`,
          ],
          bloomLevel: arc.bloom,
          length: arc.length as 'short' | 'standard' | 'long',
          durationMinutes: arc.minutes,
          keyConcepts: ['core principle', 'practical application', 'common pitfalls', 'best practice'],
        }
        lessons.push(this.assembleLessonPlan(parsed, modules, lessons.length, 'runtime-adapter', 'deterministic-fallback'))
      }
    }
    return lessons
  }

  private assembleLessonPlan(
    parsed: Partial<LessonPlan>,
    modules: ModulePlan[],
    index: number,
    provider: Provider,
    model: string,
  ): LessonPlan {
    const now = new Date().toISOString()
    const moduleId = parsed.moduleId ?? modules[0]?.id ?? 'unknown'
    const moduleTitle = parsed.moduleTitle ?? modules.find((m) => m.id === moduleId)?.title ?? 'Module'
    return {
      id: makeId('lp'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      moduleId,
      moduleTitle,
      lessonIndex: parsed.lessonIndex ?? index,
      title: parsed.title ?? `Lesson ${index + 1}`,
      summary: parsed.summary ?? '',
      learningObjectives: parsed.learningObjectives ?? [],
      bloomLevel: parsed.bloomLevel ?? 'Understand',
      length: parsed.length ?? 'standard',
      durationMinutes: parsed.durationMinutes ?? 45,
      keyConcepts: parsed.keyConcepts ?? [],
    }
  }
}
