// =============================================================================
// AICF V3 — Sprint 7 (RC34.1) — WorkflowRegistry
// =============================================================================
// Registers workflow definitions by ID and executes them on demand.
//
// REUSES the existing WorkflowEngine (src/lib/runtime/modules/workflow/engine/
// WorkflowEngine.ts) — does NOT duplicate it. The registry is a lookup table
// that maps workflow IDs to definitions and delegates execution to the engine.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import type { WorkflowDefinition } from '../contracts/workflow/WorkflowDefinition'
import type { WorkflowResult } from '../contracts/workflow/WorkflowResult'
import type { WorkflowContext } from '../contracts/workflow/WorkflowContext'
import { logger } from '@/lib/ai/logger'

/**
 * The result of a registry execution.
 */
export interface WorkflowRegistryResult {
  readonly ok: boolean
  readonly workflowId: string
  readonly executionId: string
  readonly result: WorkflowResult | null
  readonly error: string | null
}

/**
 * The Workflow Registry — stores workflow definitions and executes them.
 *
 * REUSES the existing WorkflowEngine for execution. This registry is a
 * thin lookup layer that maps IDs to definitions.
 */
export class WorkflowRegistry {
  private readonly definitions = new Map<string, WorkflowDefinition>()
  private readonly log = logger.child({ component: 'WorkflowRegistry' })
  private readonly executions: Array<{ id: string; workflowId: string; status: string; timestamp: string }> = []

  /**
   * Registers a workflow definition.
   */
  register(definition: WorkflowDefinition): void {
    const id = definition.metadata.id
    if (this.definitions.has(id)) {
      this.log.warn({ workflowId: id }, 'WorkflowRegistry: already registered — replacing')
    }
    this.definitions.set(id, definition)
    this.log.info({ workflowId: id, version: definition.version }, 'WorkflowRegistry: registered')
  }

  /**
   * Returns a workflow definition by ID, or null.
   */
  get(id: string): WorkflowDefinition | null {
    return this.definitions.get(id) ?? null
  }

  /**
   * Returns whether a workflow is registered.
   */
  has(id: string): boolean {
    return this.definitions.has(id)
  }

  /**
   * Lists all registered workflow IDs.
   */
  list(): string[] {
    return Array.from(this.definitions.keys())
  }

  /**
   * Lists all registered workflow definitions.
   */
  listDefinitions(): WorkflowDefinition[] {
    return Array.from(this.definitions.values())
  }

  /**
   * Returns the number of registered workflows.
   */
  size(): number {
    return this.definitions.size
  }

  /**
   * Unregisters a workflow by ID.
   */
  unregister(id: string): boolean {
    return this.definitions.delete(id)
  }

  /**
   * Executes a registered workflow by ID.
   *
   * Delegates to the provided executor function (typically the WorkflowEngine).
   * If no executor is provided, returns an error.
   */
  async execute(
    id: string,
    context: WorkflowContext,
    executor?: (definition: WorkflowDefinition, context: WorkflowContext) => Promise<WorkflowResult>,
  ): Promise<WorkflowRegistryResult> {
    const definition = this.definitions.get(id)
    if (!definition) {
      return {
        ok: false,
        workflowId: id,
        executionId: '',
        result: null,
        error: `Workflow '${id}' not found`,
      }
    }

    if (!executor) {
      return {
        ok: false,
        workflowId: id,
        executionId: '',
        result: null,
        error: 'No executor provided',
      }
    }

    const executionId = `wf-exec-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
    this.log.info({ workflowId: id, executionId }, 'WorkflowRegistry: executing')

    try {
      const result = await executor(definition, context)
      this.executions.push({
        id: executionId,
        workflowId: id,
        status: result.status,
        timestamp: new Date().toISOString(),
      })
      return { ok: true, workflowId: id, executionId, result, error: null }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      this.log.error({ workflowId: id, executionId, error: msg }, 'WorkflowRegistry: execution failed')
      this.executions.push({
        id: executionId,
        workflowId: id,
        status: 'failed',
        timestamp: new Date().toISOString(),
      })
      return { ok: false, workflowId: id, executionId, result: null, error: msg }
    }
  }

  /**
   * Returns the execution history.
   */
  getHistory(): Array<{ id: string; workflowId: string; status: string; timestamp: string }> {
    return [...this.executions]
  }
}

// --- Global singleton ---
const GLOBAL_WORKFLOW_REGISTRY_KEY = '__AICF_WORKFLOW_REGISTRY__'

export function getGlobalWorkflowRegistry(): WorkflowRegistry {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_WORKFLOW_REGISTRY_KEY]) {
    g[GLOBAL_WORKFLOW_REGISTRY_KEY] = new WorkflowRegistry()
  }
  return g[GLOBAL_WORKFLOW_REGISTRY_KEY] as WorkflowRegistry
}
