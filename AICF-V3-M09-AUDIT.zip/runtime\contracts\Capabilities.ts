// =============================================================================
// AICF V3 — Capabilities Contract (Sprint 16: Runtime Plugin Integration)
// =============================================================================
// Standardized capability strings that modules can expose.
// Modules declare their capabilities in the manifest; the CapabilityRegistry
// indexes them for lookup.
// =============================================================================

/**
 * Standard capability strings for M08 (Content Intelligence).
 */
export const CONTENT_INTELLIGENCE_CAPABILITIES = [
  'routeModel',        // Select provider + model
  'buildPrompt',       // Build prompt messages
  'applyPolicy',       // Evaluate request against policy rules
  'selectProvider',    // Choose the best provider
  'checkBudget',       // Check token/cost budget
] as const

/**
 * Standard capability strings for M18 (Infrastructure).
 */
export const INFRASTRUCTURE_CAPABILITIES = [
  'chatCompletion',    // LLM chat completion
  'embeddings',        // Text embeddings
  'models',            // List available models
  'health',            // Health check
] as const

/**
 * Standard capability strings for M21 (Real Generation).
 */
export const REAL_GENERATION_CAPABILITIES = [
  'generateCourse',      // Generate a full course
  'generateLesson',      // Generate a single lesson
  'generateSlides',      // Generate presentation slides
  'generateQuiz',        // Generate quiz questions
  'generateDocument',    // Generate a structured document
] as const

/**
 * Standard capability strings for the Workflow module.
 */
export const WORKFLOW_CAPABILITIES = [
  'executeWorkflow',    // Execute a workflow definition
  'dryRunWorkflow',     // Dry-run a workflow (no AI calls)
  'cancelWorkflow',     // Cancel a running workflow
  'pauseWorkflow',      // Pause a running workflow
  'resumeWorkflow',     // Resume a paused workflow
] as const

/**
 * Standard capability strings for the Generation module.
 */
export const GENERATION_CAPABILITIES = [
  'generateContent',    // Generate content by type
  'dryRunContent',      // Dry-run content generation
] as const

/**
 * Standard capability strings for the Observability module.
 */
export const OBSERVABILITY_CAPABILITIES = [
  'collectMetrics',     // Collect metrics
  'collectTraces',      // Collect traces
  'getHealthSnapshot',  // Get combined health snapshot
] as const

/**
 * Standard capability strings for the Localization module.
 * Sprint 19: i18n, translations, and regional formatting.
 */
export const LOCALIZATION_CAPABILITIES = [
  'translate',           // Translate text to a target language
  'detectLanguage',      // Detect the language of a text
  'getSupportedLocales', // List supported locales
  'formatDate',          // Format a date for a locale
  'formatNumber',        // Format a number for a locale
] as const

/**
 * Standard capability strings for the Assets module.
 * Sprint 19: in-memory storage of images, documents, and static files.
 */
export const ASSETS_CAPABILITIES = [
  'storeAsset',    // Store an asset (base64 content + mime type)
  'getAsset',      // Retrieve an asset by ID
  'deleteAsset',   // Delete an asset by ID
  'listAssets',    // List assets (optionally filtered)
  'getAssetUrl',   // Get a data URL for an asset
] as const

/**
 * Standard capability strings for the Reports module.
 * Sprint 19: report generation, status, listing, and export.
 */
export const REPORTS_CAPABILITIES = [
  'generateReport',   // Generate a report by type
  'getReportStatus',  // Get the status of a report
  'listReports',      // List reports (optionally filtered)
  'exportReport',     // Export a report to a format
] as const

/**
 * All standard capability strings, grouped by module.
 */
export const STANDARD_CAPABILITIES = {
  'content-intelligence': CONTENT_INTELLIGENCE_CAPABILITIES,
  'infrastructure': INFRASTRUCTURE_CAPABILITIES,
  'real-generation': REAL_GENERATION_CAPABILITIES,
  'workflow': WORKFLOW_CAPABILITIES,
  'generation': GENERATION_CAPABILITIES,
  'observability': OBSERVABILITY_CAPABILITIES,
  'localization': LOCALIZATION_CAPABILITIES,
  'assets': ASSETS_CAPABILITIES,
  'reports': REPORTS_CAPABILITIES,
} as const

/**
 * A capability descriptor: which module provides it, plus optional metadata.
 */
export interface CapabilityDescriptor {
  /** The capability string (e.g., 'chatCompletion'). */
  capability: string

  /** ID of the module that provides this capability. */
  moduleId: string

  /** Optional human-readable description. */
  description?: string
}

/**
 * Returns all standard capability strings (flattened).
 */
export function getAllCapabilities(): string[] {
  return Object.values(STANDARD_CAPABILITIES).flat()
}

/**
 * Returns true if the given string is a known standard capability.
 */
export function isStandardCapability(capability: string): boolean {
  return getAllCapabilities().includes(capability as never)
}
