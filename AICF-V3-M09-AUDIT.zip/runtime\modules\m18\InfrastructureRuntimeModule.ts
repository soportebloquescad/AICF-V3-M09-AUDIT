// =============================================================================
// AICF V3 — Infrastructure Module (M18) — Sprint 16 Plugin
// =============================================================================
// Wraps the M18 facade (download/infrastructure/) as a first-class
// Runtime plugin.
//
// Capabilities: chatCompletion, embeddings, models, health
// Mission: M18
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import { INFRASTRUCTURE_CAPABILITIES } from '@/lib/runtime/contracts/Capabilities'
import type { HotReloadable } from '@/lib/runtime/contracts/HotReloadable'
import { logger } from '@/lib/ai/logger'

/**
 * The shape of the M18 facade (from download/infrastructure/).
 */
export interface M18Facade {
  initialize(): Promise<void>
  getConnector(name: string): unknown
  getHealth(): Promise<{ healthy: boolean; connectors?: Record<string, unknown> }>
  getStatus(): { version: string; initialized: boolean; connectors: Record<string, boolean> }
  shutdown(): Promise<void>
}

/**
 * Plugin metadata for the Infrastructure module.
 */
export const INFRASTRUCTURE_METADATA: PluginMetadata = {
  id: 'infrastructure',
  name: 'Infrastructure',
  description: 'LiteLLM, Docker, n8n, OpenWebUI, Postgres connectors',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'M18',
  priority: 10,
  dependencies: [],
  capabilities: [...INFRASTRUCTURE_CAPABILITIES],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: ['connector.health', 'connector.connected', 'connector.disconnected'],
}

/**
 * Infrastructure Runtime Module (M18).
 */
export class InfrastructureRuntimeModule implements RuntimeModule, HotReloadable {
  readonly name = INFRASTRUCTURE_METADATA.name
  readonly version = INFRASTRUCTURE_METADATA.version

  private initialized = false
  private disposed = false
  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0
  private operationCount = 0
  private errorCount = 0
  private lastUsed: string | null = null

  constructor(private readonly infra: M18Facade) {}

  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
    logger.info({ initLatencyMs: this.initLatencyMs }, 'InfrastructureModule: initialized')
  }

  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        source: 'download/infrastructure',
        capabilities: INFRASTRUCTURE_CAPABILITIES,
        startupTime: this.startupTime,
      },
    }
  }

  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  async dispose(): Promise<void> {
    this.disposed = true
    logger.info('InfrastructureModule: disposed')
  }

  async shutdown(): Promise<void> {
    this.disposed = true
    logger.info('InfrastructureModule: shut down')
  }

  // --- HotReloadable ---
  async load(): Promise<void> { await this.initialize() }
  async unload(): Promise<void> { await this.dispose() }
  async reload(): Promise<void> {
    await this.dispose()
    this.disposed = false
    this.initialized = false
    await this.initialize()
  }

  // --- M18 capabilities ---
  getConnector(name: string) { return this.infra.getConnector(name) }
  async getHealth() { return this.infra.getHealth() }

  getMetadata(): PluginMetadata {
    return INFRASTRUCTURE_METADATA
  }

  /**
   * Executes an AI call using the parameters from a DecisionPlan (M08).
   * M18 does NOT decide provider, model, or parameters — those come from
   * the DecisionPlan. M18 only executes.
   */
  async executeWithPlan(
    plan: import('../m08/DecisionPlan').DecisionPlan,
    messages: import('@/lib/ai/AIAdapter').ChatMessage[],
  ): Promise<InfrastructureExecutionResult> {
    const startMs = Date.now()
    this.operationCount++
    this.lastUsed = new Date().toISOString()
    try {
      const { AIService } = await import('@/lib/ai/AIService')
      const service = new AIService()
      const chatResponse = await service.chat({
        model: plan.model,
        messages,
        temperature: plan.temperature,
        maxTokens: plan.maxTokens,
        topP: plan.topP,
        stop: plan.stop.length > 0 ? [...plan.stop] : undefined,
      })
      const durationMs = Date.now() - startMs
      logger.info({ provider: plan.provider, model: plan.model, durationMs, tokens: chatResponse.usage?.totalTokens ?? 0 }, 'InfrastructureModule: executeWithPlan completed')
      return { ok: true, provider: plan.provider, model: chatResponse.model, content: chatResponse.content, usage: chatResponse.usage, latencyMs: durationMs, error: null }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      this.errorCount++
      this.lastError = msg
      const durationMs = Date.now() - startMs
      logger.error({ provider: plan.provider, model: plan.model, error: msg, durationMs }, 'InfrastructureModule: executeWithPlan failed')
      return { ok: false, provider: plan.provider, model: plan.model, content: '', usage: null, latencyMs: durationMs, error: msg }
    }
  }
}

export interface InfrastructureExecutionResult {
  readonly ok: boolean
  readonly provider: string
  readonly model: string
  readonly content: string
  readonly usage: import('@/lib/ai/AIAdapter').ChatUsage | null
  readonly latencyMs: number
  readonly error: string | null
}

/**
 * Factory: creates an InfrastructureRuntimeModule from the M18 facade.
 */
export function createInfrastructureModule(infra: M18Facade): InfrastructureRuntimeModule {
  return new InfrastructureRuntimeModule(infra)
}
