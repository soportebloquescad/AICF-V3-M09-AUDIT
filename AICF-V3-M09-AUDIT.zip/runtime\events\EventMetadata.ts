// =============================================================================
// AICF V3 — Event Metadata & Envelope (Sprint 21: EDA Runtime Observability)
// =============================================================================
// Provides:
//   - EventMetadata: structured per-event metadata (correlationId, requestId,
//     operation, pipelineStage, stageOrder, runtimeVersion, emittedAt, durationMs)
//   - RuntimeEventEnvelope<T>: a versioned wrapper around an event payload
//   - createEventMetadata(): factory that auto-generates eventId + timestamp
//   - createEnvelope(): wraps metadata + payload into a versioned envelope
//
// Sprint 21: every EDA event published by the pipeline stages is wrapped in a
// RuntimeEventEnvelope before being delivered to subscribers. The envelope
// version is fixed at '1.0' for Sprint 21; future sprints may bump it.
//
// The runtimeVersion reported in event metadata re-uses the canonical
// RUNTIME_VERSION constant from ../contracts/VersionedContract.
// =============================================================================

import { randomUUID } from 'crypto'
import { RUNTIME_VERSION } from '../contracts/VersionedContract'

/**
 * Structured metadata attached to every EDA event emitted by the runtime
 * pipeline. Carries correlation + request IDs for distributed tracing, the
 * pipeline stage that emitted the event (with its order in the pipeline),
 * the runtime version, the emission timestamp, and an optional stage
 * duration measurement.
 */
export interface EventMetadata {
  /** Unique event ID (UUIDv4). Used for idempotency in the EventBus. */
  eventId: string

  /** Correlation ID propagated end-to-end (BFF → Runtime → Modules). */
  correlationId: string

  /** Request ID for the in-flight Runtime request. */
  requestId: string

  /** Operation name (chat, models, status, generate, ...). */
  operation: string

  /** AICF V3 runtime version that produced the event. */
  runtimeVersion: string

  /** Name of the pipeline stage that emitted the event. */
  pipelineStage: string

  /** 1-based ordinal of the stage within the pipeline (1-12 for the 12 EDA events). */
  stageOrder: number

  /** ISO 8601 timestamp the event was emitted. */
  emittedAt: string

  /** Optional duration (ms) the emitting stage took to execute. */
  durationMs?: number
}

/**
 * Versioned wrapper around an EDA event payload. The version field is
 * currently fixed at '1.0' — subscribers should check it before unwrapping.
 */
export interface RuntimeEventEnvelope<T> {
  metadata: EventMetadata
  payload: T
  version: '1.0'
}

/**
 * Factory: builds an EventMetadata with an auto-generated eventId and the
 * current ISO timestamp. All other fields come from the caller.
 */
export function createEventMetadata(opts: {
  correlationId: string
  requestId: string
  operation: string
  pipelineStage: string
  stageOrder: number
  durationMs?: number
}): EventMetadata {
  return {
    eventId: randomUUID(),
    correlationId: opts.correlationId,
    requestId: opts.requestId,
    operation: opts.operation,
    runtimeVersion: RUNTIME_VERSION,
    pipelineStage: opts.pipelineStage,
    stageOrder: opts.stageOrder,
    emittedAt: new Date().toISOString(),
    durationMs: opts.durationMs,
  }
}

/**
 * Factory: wraps metadata + payload into a versioned RuntimeEventEnvelope.
 * The version is fixed at '1.0' for Sprint 21.
 */
export function createEnvelope<T>(metadata: EventMetadata, payload: T): RuntimeEventEnvelope<T> {
  return { metadata, payload, version: '1.0' }
}

// Re-export RUNTIME_VERSION so callers importing from this module don't
// need a second import.
export { RUNTIME_VERSION } from '../contracts/VersionedContract'
