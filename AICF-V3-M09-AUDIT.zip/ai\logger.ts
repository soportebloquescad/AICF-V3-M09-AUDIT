// =============================================================================
// AICF V3 — Centralized Logger
// =============================================================================
// Uses pino for structured logging. Never logs secrets (API keys, passwords,
// tokens). All log entries are JSON-structured for production observability.
// =============================================================================

import pino from 'pino'

const isDev = process.env.NODE_ENV !== 'production'

/**
 * Singleton pino logger instance.
 * In development: pretty-printed to stdout.
 * In production: newline-delimited JSON to stdout.
 */
export const logger = pino({
  level: process.env.LOG_LEVEL || (isDev ? 'debug' : 'info'),
  ...(isDev
    ? {
        transport: {
          target: 'pino-pretty',
          options: { colorize: true, translateTime: 'SYS:standard' },
        },
      }
    : {}),
  redact: {
    paths: [
      '*.apiKey',
      '*.api_key',
      '*.password',
      '*.token',
      '*.secret',
      'req.headers.authorization',
      'req.headers["x-api-key"]',
      'LITELLM_API_KEY',
      'NEXTAUTH_SECRET',
      'N8N_ENCRYPTION_KEY',
      '*.LITELLM_API_KEY',
      '*.NEXTAUTH_SECRET',
    ],
    censor: '[REDACTED]',
  },
})

/**
 * Creates a child logger with additional context (e.g. requestId, userId).
 * @param context - Key-value pairs to include in every log entry.
 */
export function createLogger(context: Record<string, unknown>) {
  return logger.child(context)
}
