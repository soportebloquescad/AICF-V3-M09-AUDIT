// =============================================================================
// AICF V3 — Sprint 5 (RC32) — CourseMetrics
// =============================================================================
// Records per-course generation metrics: duration, quality, size, tokens.
// Reuses the same in-memory pattern as MetricsRegistry but tracks
// course-specific data.
//
// BFF FROZEN: does NOT import or modify anything in src/lib/ai/.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * A single course generation metric entry.
 */
export interface CourseMetricEntry {
  readonly courseId: string
  readonly title: string
  readonly topic: string
  readonly provider: string
  readonly model: string
  readonly mode: string
  readonly qualityScore: number
  readonly wordCount: number
  readonly moduleCount: number
  readonly lessonCount: number
  readonly durationMs: number
  readonly zipSizeBytes: number
  readonly tokens: number
  readonly createdAt: string
}

/**
 * Aggregated course metrics snapshot.
 */
export interface CourseMetricsSnapshot {
  readonly totalCourses: number
  readonly completedCourses: number
  readonly averageQuality: number
  readonly averageDurationMs: number
  readonly averageZipSizeBytes: number
  readonly averageWordCount: number
  readonly totalTokens: number
  readonly totalWordCount: number
  readonly byProvider: Record<string, number>
  readonly byModel: Record<string, number>
  readonly byMode: Record<string, number>
  readonly last24hCount: number
  readonly timestamp: string
}

/** Maximum entries kept in memory. */
const MAX_ENTRIES = 500

/**
 * Course-specific metrics collector.
 *
 * Records one entry per course generation. Provides aggregated snapshots
 * for the /api/course/metrics endpoint.
 */
export class CourseMetrics {
  private readonly entries: CourseMetricEntry[] = []
  private readonly maxEntries: number
  private readonly log = logger.child({ component: 'CourseMetrics' })

  constructor(maxEntries: number = MAX_ENTRIES) {
    this.maxEntries = maxEntries
  }

  /**
   * Records a course generation metric.
   */
  record(entry: CourseMetricEntry): void {
    this.entries.push(entry)
    if (this.entries.length > this.maxEntries) {
      this.entries.shift()
    }
    this.log.info(
      {
        courseId: entry.courseId,
        qualityScore: entry.qualityScore,
        durationMs: entry.durationMs,
        wordCount: entry.wordCount,
      },
      'CourseMetrics: recorded',
    )
  }

  /**
   * Returns the aggregated metrics snapshot.
   */
  getSnapshot(): CourseMetricsSnapshot {
    const total = this.entries.length
    if (total === 0) {
      return {
        totalCourses: 0,
        completedCourses: 0,
        averageQuality: 0,
        averageDurationMs: 0,
        averageZipSizeBytes: 0,
        averageWordCount: 0,
        totalTokens: 0,
        totalWordCount: 0,
        byProvider: {},
        byModel: {},
        byMode: {},
        last24hCount: 0,
        timestamp: new Date().toISOString(),
      }
    }

    let qualitySum = 0
    let durationSum = 0
    let zipSum = 0
    let wordSum = 0
    let tokenSum = 0
    let completed = 0
    const byProvider: Record<string, number> = {}
    const byModel: Record<string, number> = {}
    const byMode: Record<string, number> = {}
    const now = Date.now()
    const cutoff24h = now - 24 * 60 * 60 * 1000
    let last24h = 0

    for (const e of this.entries) {
      qualitySum += e.qualityScore
      durationSum += e.durationMs
      zipSum += e.zipSizeBytes
      wordSum += e.wordCount
      tokenSum += e.tokens
      if (e.qualityScore >= 80) completed++
      byProvider[e.provider] = (byProvider[e.provider] ?? 0) + 1
      byModel[e.model] = (byModel[e.model] ?? 0) + 1
      byMode[e.mode] = (byMode[e.mode] ?? 0) + 1
      const created = new Date(e.createdAt).getTime()
      if (created >= cutoff24h) last24h++
    }

    return {
      totalCourses: total,
      completedCourses: completed,
      averageQuality: Math.round((qualitySum / total) * 100) / 100,
      averageDurationMs: Math.round(durationSum / total),
      averageZipSizeBytes: Math.round(zipSum / total),
      averageWordCount: Math.round(wordSum / total),
      totalTokens: tokenSum,
      totalWordCount: wordSum,
      byProvider,
      byModel,
      byMode,
      last24hCount: last24h,
      timestamp: new Date().toISOString(),
    }
  }

  /**
   * Returns the raw entries (newest last).
   */
  getEntries(): readonly CourseMetricEntry[] {
    return [...this.entries]
  }

  /**
   * Returns the number of recorded entries.
   */
  count(): number {
    return this.entries.length
  }

  /**
   * Clears all entries.
   */
  reset(): void {
    this.entries.length = 0
    this.log.info('CourseMetrics: reset')
  }
}

// --- Global singleton (survives Turbopack module re-evaluation) ---
const GLOBAL_COURSE_METRICS_KEY = '__AICF_COURSE_METRICS__'

/**
 * Returns the global CourseMetrics singleton.
 */
export function getGlobalCourseMetrics(): CourseMetrics {
  const g = globalThis as unknown as Record<string, unknown>
  if (!g[GLOBAL_COURSE_METRICS_KEY]) {
    g[GLOBAL_COURSE_METRICS_KEY] = new CourseMetrics()
  }
  return g[GLOBAL_COURSE_METRICS_KEY] as CourseMetrics
}
