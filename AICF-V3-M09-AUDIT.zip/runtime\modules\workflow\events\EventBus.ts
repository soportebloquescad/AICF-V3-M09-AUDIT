// =============================================================================
// AICF V3 — Sprint 13+14 — In-Memory Event Bus
// =============================================================================
// Concrete implementation of `IEventBus` for the workflow module. Uses an
// in-memory `Map<eventType, Set<EventHandler>>` for typed subscriptions plus
// a `Set<EventHandler>` for `subscribeAll` cross-cutting consumers (audit,
// metrics, telemetry).
//
// Sprint 13+14 spec requirements covered:
//   - Typed publish / subscribe by `WorkflowEventType`
//   - `subscribeAll` for cross-cutting consumers
//   - `getHistory` for replay / audit queries, optionally scoped by execution
//   - Subscribers return an unsubscribe function (no manual bookkeeping)
//   - Delivery failures in one subscriber MUST NOT block other subscribers
//     (we catch + log via `@/lib/ai/logger`)
//   - History is capped (1000 events) to bound memory in long-running
//     processes — older events are dropped FIFO
//
// This bus is process-local. For cross-service fan-out, pair it with a
// durable message bus; this contract is the in-process surface only.
// =============================================================================

import type { IEventBus, EventHandler } from '@/lib/runtime/interfaces'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Maximum number of historical events retained in memory. */
const MAX_HISTORY = 1000

/**
 * In-memory event bus. Safe to call from concurrent publishers; delivery
 * order to each subscriber is preserved per the contract.
 */
export class InMemoryEventBus implements IEventBus {
  /** Per-event-type subscribers. */
  private readonly handlers = new Map<string, Set<EventHandler>>()
  /** Cross-cutting subscribers (receive every event). */
  private readonly allHandlers = new Set<EventHandler>()
  /** Capped FIFO history of every published event. */
  private readonly history: WorkflowEvent[] = []

  /**
   * Publish an event to all matching subscribers. Delivery failures in any
   * single subscriber are caught and logged; they do NOT block delivery to
   * other subscribers and do NOT throw back to the publisher.
   */
  async publish(event: WorkflowEvent): Promise<void> {
    // Record into history (cap enforced below).
    this.history.push(event)
    if (this.history.length > MAX_HISTORY) {
      // Drop the oldest entries to stay within the cap.
      this.history.splice(0, this.history.length - MAX_HISTORY)
    }

    // Type-specific subscribers.
    const typed = this.handlers.get(event.type)
    if (typed) {
      for (const handler of typed) {
        await this.invokeHandler(handler, event)
      }
    }
    // Cross-cutting subscribers.
    for (const handler of this.allHandlers) {
      await this.invokeHandler(handler, event)
    }
  }

  /**
   * Subscribe to a single event type. Returns an unsubscribe function that
   * removes the handler (idempotent: calling it more than once is safe).
   */
  subscribe(eventType: string, handler: EventHandler): () => void {
    let set = this.handlers.get(eventType)
    if (!set) {
      set = new Set<EventHandler>()
      this.handlers.set(eventType, set)
    }
    set.add(handler)
    return () => {
      const s = this.handlers.get(eventType)
      if (s) {
        s.delete(handler)
        if (s.size === 0) {
          this.handlers.delete(eventType)
        }
      }
    }
  }

  /**
   * Subscribe to every event type. Returns an unsubscribe function.
   */
  subscribeAll(handler: EventHandler): () => void {
    this.allHandlers.add(handler)
    return () => {
      this.allHandlers.delete(handler)
    }
  }

  /**
   * Return recorded events, optionally scoped by execution id. Returns a
   * shallow copy so callers can iterate without mutating internal state.
   */
  async getHistory(executionId?: string): Promise<WorkflowEvent[]> {
    if (executionId === undefined) {
      return [...this.history]
    }
    return this.history.filter((e) => e.executionId === executionId)
  }

  /**
   * Clear all recorded history. Does NOT unsubscribe handlers (per contract).
   */
  clear(): void {
    this.history.length = 0
  }

  /**
   * Invoke a single handler with the event, catching any error (sync or
   * async) so a misbehaving subscriber cannot break delivery to others.
   */
  private async invokeHandler(
    handler: EventHandler,
    event: WorkflowEvent,
  ): Promise<void> {
    try {
      await handler(event)
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'unknown event handler error'
      logger.warn(
        {
          eventType: event.type,
          executionId: event.executionId,
          stepId: event.stepId,
          err: message,
        },
        'workflow event handler threw; continuing delivery to other subscribers',
      )
    }
  }
}
