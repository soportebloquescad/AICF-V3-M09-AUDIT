// =============================================================================
// AICF V3 — ModuleFactory Tests (Sprint 16)
// =============================================================================
import { describe, it, expect } from 'bun:test'
import { ModuleFactory } from '../ModuleFactory'
import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

/** Mock AIAdapter for testing. */
class MockAdapter implements AIAdapter {
  async chat(_request: ChatRequest): Promise<ChatResponse> {
    return { content: 'mock', model: 'mock', provider: 'mock', usage: null, durationMs: 1 }
  }
  async models(): Promise<AIModel[]> { return [{ id: 'mock', provider: 'mock' }] }
  async health(): Promise<AIHealth> { return { healthy: true, provider: 'mock' } }
}

/** Mock M08 facade. */
const mockM08 = {
  getPolicyEngine: () => ({ evaluate: () => ({ allowed: true }) }),
  getBudgetManager: () => ({ reserve: () => ({ ok: true }) }),
  getProvider: () => ({ select: () => ({ name: 'groq', available: true }) }),
}

/** Mock M18 facade. */
const mockM18 = {
  initialize: async () => {},
  getConnector: () => null,
  getHealth: async () => ({ healthy: true }),
  getStatus: () => ({ version: '1.0.0', initialized: true, connectors: {} }),
  shutdown: async () => {},
}

/** Mock M21 facade. */
const mockM21 = {
  startGeneration: async () => ({
    ok: true, content: 'generated', model: 'mock', provider: 'mock',
    usage: null, durationMs: 1, cached: false,
  }),
  getGenerationHistory: () => [],
  getTokenUsage: () => ({}),
  getGenerationCost: () => ({}),
}

describe('ModuleFactory', () => {
  it('should list all supported module IDs', () => {
    const ids = ModuleFactory.list()
    expect(ids).toContain('workflow')
    expect(ids).toContain('generation')
    expect(ids).toContain('observability')
    expect(ids).toContain('content-intelligence')
    expect(ids).toContain('infrastructure')
    expect(ids).toContain('real-generation')
  })

  it('should return true for canCreate with known IDs', () => {
    expect(ModuleFactory.canCreate('workflow')).toBe(true)
    expect(ModuleFactory.canCreate('content-intelligence')).toBe(true)
    expect(ModuleFactory.canCreate('unknown')).toBe(false)
  })

  it('should create an observability module', () => {
    const mod = ModuleFactory.create('observability')
    expect(mod).toBeDefined()
    expect(mod.name).toBe('observability')
  })

  it('should create a workflow module with aiAdapter', () => {
    const mod = ModuleFactory.create('workflow', { aiAdapter: new MockAdapter() })
    expect(mod).toBeDefined()
    expect(mod.name).toBe('workflow-runtime')
  })

  it('should throw when creating workflow without aiAdapter', () => {
    expect(() => ModuleFactory.create('workflow')).toThrow(/aiAdapter/)
  })

  it('should create a generation module with aiAdapter', () => {
    const mod = ModuleFactory.create('generation', { aiAdapter: new MockAdapter() })
    expect(mod).toBeDefined()
    expect(mod.name).toBe('generation')
  })

  it('should create a content-intelligence module with m08Facade', () => {
    const mod = ModuleFactory.create('content-intelligence', { m08Facade: mockM08 as never })
    expect(mod).toBeDefined()
    expect(mod.name).toBe('Content Intelligence')
  })

  it('should throw when creating content-intelligence without m08Facade', () => {
    expect(() => ModuleFactory.create('content-intelligence')).toThrow(/m08Facade/)
  })

  it('should create an infrastructure module with m18Facade', () => {
    const mod = ModuleFactory.create('infrastructure', { m18Facade: mockM18 as never })
    expect(mod).toBeDefined()
    expect(mod.name).toBe('Infrastructure')
  })

  it('should create a real-generation module with m21Facade', () => {
    const mod = ModuleFactory.create('real-generation', { m21Facade: mockM21 as never })
    expect(mod).toBeDefined()
    expect(mod.name).toBe('Real Generation')
  })

  it('should throw for unknown module ID', () => {
    expect(() => ModuleFactory.create('unknown')).toThrow(/unknown module/)
  })

  it('should create modules that implement the full lifecycle', () => {
    const mod = ModuleFactory.create('content-intelligence', { m08Facade: mockM08 as never })
    expect(typeof mod.initialize).toBe('function')
    expect(typeof mod.isReady).toBe('function')
    expect(typeof mod.getStatus).toBe('function')
    expect(typeof mod.health).toBe('function')
    expect(typeof mod.dispose).toBe('function')
    expect(typeof mod.shutdown).toBe('function')
    expect(typeof mod.getMetrics).toBe('function')
  })
})
