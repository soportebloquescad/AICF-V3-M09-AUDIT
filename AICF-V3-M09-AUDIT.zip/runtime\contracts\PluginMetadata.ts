// =============================================================================
// AICF V3 — Plugin Metadata Contract (Sprint 16: Runtime Plugin Integration)
// =============================================================================
// Metadata that every Runtime plugin (module) must expose.
// Used for discovery, dashboard rendering, and dependency resolution.
// =============================================================================

import type { VersionedContract } from './VersionedContract'

/**
 * Metadata describing a Runtime plugin (module).
 *
 * @example
 * const meta: PluginMetadata = {
 *   id: 'content-intelligence',
 *   name: 'Content Intelligence',
 *   description: 'Policy, budget, provider routing, prompt building',
 *   author: 'AICF V3',
 *   version: '1.0.0',
 *   mission: 'M08',
 *   priority: 15,
 *   dependencies: [],
 *   capabilities: ['routeModel', 'buildPrompt', 'applyPolicy', 'selectProvider', 'checkBudget'],
 *   contracts: { schemaVersion: '1.0.0', contractVersion: '1.0.0', runtimeVersion: '3.0.0', compatibility: 'compatible' },
 * }
 */
export interface PluginMetadata {
  /** Unique module ID (e.g., 'content-intelligence'). */
  id: string

  /** Human-readable name (e.g., 'Content Intelligence'). */
  name: string

  /** Short description of what the module does. */
  description: string

  /** Author / owner. */
  author: string

  /** Semantic version of the module. */
  version: string

  /** Mission reference (e.g., 'M08', 'M18', 'M21'). */
  mission: string

  /** Priority (lower = initialized first). */
  priority: number

  /** IDs of modules this module depends on. */
  dependencies: string[]

  /** List of capability strings this module exposes. */
  capabilities: string[]

  /** Versioned contract info. */
  contracts: VersionedContract

  /** Events this module emits (for documentation + dashboard). */
  events?: string[]

  /** Optional homepage / docs URL. */
  homepage?: string

  /** Optional license. */
  license?: string
}
