// =============================================================================
// AICF V3 — MetricsSubscriber (Sprint 22)
// =============================================================================
// Records EDA events into a MetricsRegistry (per-stage call count, latency)
// and also maintains an internal per-event-type counter map.
//
// Sprint 22 (this file) replaces the Sprint 21 stub with a real
// MetricsRegistry-backed implementation:
//   - onEvent() calls metricsRegistry.recordCall(pipelineStage, durationMs, undefined)
//     so every emitted EDA event becomes one "call" against the emitting
//     stage's metric record.
//   - In parallel, an internal Map<string, number> tracks per-event-type
//     counts (keyed by pipelineStage). Exposed via getEventCounts().
//   - getTotalEvents() returns the grand total of events received.
//
// All side-effects are best-effort: onEvent() never throws.
// =============================================================================

import type { RuntimeEventEnvelope } from '../events/EventMetadata'
import type { MetricsRegistry } from '../metrics/MetricsRegistry'
import { logger } from '@/lib/ai/logger'
import type { EventSubscriber } from './AuditSubscriber'

/**
 * Metrics subscriber — aggregates counters + latencies per event type/stage.
 *
 * Each envelope received by `onEvent()` is translated into one
 * `recordCall(stage, durationMs)` invocation on the MetricsRegistry, plus an
 * increment of the internal per-stage counter map.
 */
export class MetricsSubscriber implements EventSubscriber {
  readonly name = 'metrics-subscriber'
  private ready = false

  /** Per-stage (pipelineStage) counter for events received. */
  private readonly eventCounts = new Map<string, number>()

  /** Grand total of events received. */
  private totalEvents = 0

  constructor(private readonly metricsRegistry: MetricsRegistry) {}

  /**
   * Initializes the subscriber. Flips the ready flag.
   */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug({ subscriber: this.name }, 'MetricsSubscriber: initialized')
  }

  isReady(): boolean {
    return this.ready
  }

  async onEvent(event: RuntimeEventEnvelope<unknown>): Promise<void> {
    try {
      const stage = event.metadata.pipelineStage
      const durationMs = event.metadata.durationMs ?? 0

      // Record into the shared MetricsRegistry (per-stage call metrics).
      this.metricsRegistry.recordCall(stage, durationMs)

      // Update the internal per-stage counter map.
      this.eventCounts.set(stage, (this.eventCounts.get(stage) ?? 0) + 1)
      this.totalEvents += 1
    } catch (err) {
      logger.error(
        {
          subscriber: this.name,
          eventId: event.metadata.eventId,
          error: err instanceof Error ? err.message : String(err),
        },
        'MetricsSubscriber: onEvent failed (swallowed)',
      )
    }
  }

  /**
   * Returns a snapshot of per-stage event counts (keyed by pipelineStage).
   * The returned object is a copy — mutating it does not affect the
   * subscriber's internal state.
   */
  getEventCounts(): Record<string, number> {
    const snapshot: Record<string, number> = {}
    for (const [stage, count] of this.eventCounts.entries()) {
      snapshot[stage] = count
    }
    return snapshot
  }

  /**
   * Returns the grand total of events received since the subscriber was
   * created.
   */
  getTotalEvents(): number {
    return this.totalEvents
  }
}

/**
 * Factory: creates a MetricsSubscriber bound to the given MetricsRegistry.
 *
 * @example
 * const sub = createMetricsSubscriber(metricsRegistry)
 * await sub.initialize()
 */
export function createMetricsSubscriber(metricsRegistry: MetricsRegistry): MetricsSubscriber {
  return new MetricsSubscriber(metricsRegistry)
}
