// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — GenerationModule Integration Tests
// =============================================================================
// End-to-end integration tests for the GenerationModule factory and its
// four generators (Course / Presentation / Quiz / Document). Uses a
// MockAdapter that returns canned JSON responses for the two-stage
// (outline → content) prompt strategy.
//
// Covers:
//   - createGenerationModule wires all 4 generators
//   - CourseGenerator.generate returns output with content
//   - PresentationGenerator.generate returns output with slides
//   - QuizGenerator.generate returns output with questions
//   - DocumentGenerator.generate returns output with sections
//   - GenerationOrchestrator dispatches by contentType
//   - GenerationOrchestrator.listGenerators returns all 4 types
//   - GenerationPipeline.dryRun returns estimated tokens without AI calls
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import {
  createGenerationModule,
  CourseGenerator,
  PresentationGenerator,
  QuizGenerator,
  DocumentGenerator,
  GenerationOrchestrator,
  GenerationPipeline,
} from '../index'
import type {
  GeneratorInput,
} from '@/lib/runtime/interfaces'
import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import { createWorkflowContext } from '@/lib/runtime/contracts/workflow'
import type {
  AIAdapter,
  ChatRequest,
  ChatResponse,
  AIModel,
  AIHealth,
} from '@/lib/ai/AIAdapter'

// --- MockAdapter -------------------------------------------------------------

class MockAdapter implements AIAdapter {
  responses: string[] = []
  callIndex = 0
  constructor(responses: string[]) {
    this.responses = responses
  }
  async chat(_request: ChatRequest): Promise<ChatResponse> {
    const content = this.responses[this.callIndex % this.responses.length]
    this.callIndex++
    return {
      content,
      model: 'mock-model',
      provider: 'mock',
      usage: { promptTokens: 50, completionTokens: 100, totalTokens: 150 },
      durationMs: 42,
    }
  }
  async models(): Promise<AIModel[]> {
    return [{ id: 'mock-model', provider: 'mock' }]
  }
  async health(): Promise<AIHealth> {
    return { healthy: true, provider: 'mock' }
  }
}

// --- Canned AI responses -----------------------------------------------------

const COURSE_OUTLINE = JSON.stringify({
  title: 'Rust Programming Basics',
  description: 'Learn Rust from scratch',
  outline: 'Module 1: Variables, Module 2: Ownership',
})
const COURSE_MODULES = JSON.stringify({
  modules: [
    {
      title: 'Getting Started',
      summary: 'Introduction to Rust',
      lessons: [
        { title: 'Installation', content: 'How to install Rust', duration: 15 },
        { title: 'Hello World', content: 'Your first Rust program', duration: 10 },
      ],
    },
  ],
})

const PRES_OUTLINE = JSON.stringify({
  title: 'Intro to Rust',
  description: 'A short slide deck',
  outline: 'Slide 1, Slide 2, Slide 3',
})
const PRES_SLIDES = JSON.stringify({
  slides: [
    { title: 'Welcome', bullets: ['Intro', 'Agenda'], notes: 'Welcome notes' },
    { title: 'Topics', bullets: ['Variables', 'Ownership'] },
  ],
})

const QUIZ_OUTLINE = JSON.stringify({
  title: 'Rust Quiz',
  description: 'Test your Rust knowledge',
  outline: '5 questions on basics',
})
const QUIZ_QUESTIONS = JSON.stringify({
  questions: [
    {
      question: 'What is ownership in Rust?',
      options: ['A', 'B', 'C', 'D'],
      correctIndex: 0,
      explanation: 'Ownership is Rust memory management',
    },
    {
      question: 'What does `mut` mean?',
      options: ['mutable', 'mute', 'multiply', 'mutex'],
      correctIndex: 0,
      explanation: '`mut` marks a binding as mutable',
    },
  ],
})

const DOC_OUTLINE = JSON.stringify({
  title: 'Rust Reference',
  description: 'A reference document',
  outline: 'Section 1, Section 2',
})
const DOC_SECTIONS = JSON.stringify({
  sections: [
    { title: 'Overview', content: 'Rust is a systems language.' },
    { title: 'Syntax', content: 'Rust uses curly braces.' },
  ],
})

function makeCtx(): WorkflowContext {
  return createWorkflowContext({
    correlationId: 'corr-gen',
    executionId: 'exec-gen',
    // Set a model so the generators use it instead of falling back to the
    // built-in default ('groq-llama-3.3-70b').
    model: 'mock-model',
  })
}

// --- Tests -------------------------------------------------------------------

describe('GenerationModule (integration)', () => {
  let adapter: MockAdapter

  beforeEach(() => {
    adapter = new MockAdapter([])
  })

  it('createGenerationModule wires all 4 generators + orchestrator + module', () => {
    const bundle = createGenerationModule({ aiAdapter: adapter })
    expect(bundle.module).toBeDefined()
    expect(bundle.orchestrator).toBeInstanceOf(GenerationOrchestrator)
    expect(bundle.generators.course).toBeInstanceOf(CourseGenerator)
    expect(bundle.generators.presentation).toBeInstanceOf(PresentationGenerator)
    expect(bundle.generators.quiz).toBeInstanceOf(QuizGenerator)
    expect(bundle.generators.document).toBeInstanceOf(DocumentGenerator)
    expect(bundle.orchestrator.listGenerators().sort()).toEqual([
      'course',
      'document',
      'presentation',
      'quiz',
    ])
  })

  it('CourseGenerator.generate returns GeneratorOutput with content', async () => {
    adapter.responses = [COURSE_OUTLINE, COURSE_MODULES]
    const gen = new CourseGenerator(adapter)
    const input: GeneratorInput = {
      topic: 'Rust Programming',
      contentType: 'course',
      modules: 1,
    }
    const out = await gen.generate(input, makeCtx())
    expect(out.ok).toBe(true)
    expect(out.content.length).toBeGreaterThan(0)
    expect(out.title).toBe('Rust Programming Basics')
    expect(out.outline).toContain('Module 1')
    expect(Array.isArray(out.modules)).toBe(true)
    expect((out.modules as unknown[]).length).toBe(1)
    expect(out.artifacts.length).toBe(2) // course + markdown
    expect(out.tokensUsed?.totalTokens).toBe(300) // 150 + 150
    expect(out.cost).toBeGreaterThan(0)
    expect(out.provider).toBe('mock')
    expect(out.model).toBe('mock-model')
  })

  it('PresentationGenerator.generate returns output with slides', async () => {
    adapter.responses = [PRES_OUTLINE, PRES_SLIDES]
    const gen = new PresentationGenerator(adapter)
    const input: GeneratorInput = {
      topic: 'Intro to Rust',
      contentType: 'presentation',
      modules: 2,
    }
    const out = await gen.generate(input, makeCtx())
    expect(out.ok).toBe(true)
    expect(out.content.length).toBeGreaterThan(0)
    expect(out.title).toBe('Intro to Rust')
    expect(Array.isArray(out.modules)).toBe(true)
    expect((out.modules as unknown[]).length).toBe(2)
    expect(out.artifacts.length).toBe(2) // presentation + markdown
  })

  it('QuizGenerator.generate returns output with questions', async () => {
    adapter.responses = [QUIZ_OUTLINE, QUIZ_QUESTIONS]
    const gen = new QuizGenerator(adapter)
    const input: GeneratorInput = {
      topic: 'Rust Quiz',
      contentType: 'quiz',
      modules: 2,
    }
    const out = await gen.generate(input, makeCtx())
    expect(out.ok).toBe(true)
    expect(out.content.length).toBeGreaterThan(0)
    expect(out.title).toBe('Rust Quiz')
    expect(Array.isArray(out.modules)).toBe(true)
    expect((out.modules as unknown[]).length).toBe(2)
    expect(out.artifacts.length).toBe(2) // quiz + markdown
  })

  it('DocumentGenerator.generate returns output with sections', async () => {
    adapter.responses = [DOC_OUTLINE, DOC_SECTIONS]
    const gen = new DocumentGenerator(adapter)
    const input: GeneratorInput = {
      topic: 'Rust Reference',
      contentType: 'document',
      modules: 2,
    }
    const out = await gen.generate(input, makeCtx())
    expect(out.ok).toBe(true)
    expect(out.content.length).toBeGreaterThan(0)
    expect(out.title).toBe('Rust Reference')
    expect(Array.isArray(out.modules)).toBe(true)
    expect((out.modules as unknown[]).length).toBe(2)
    expect(out.artifacts.length).toBe(2) // document + markdown
  })

  it('GenerationOrchestrator dispatches by contentType', async () => {
    // Use the orchestrator built by the factory — it has all 4 generators.
    adapter.responses = [COURSE_OUTLINE, COURSE_MODULES]
    const bundle = createGenerationModule({ aiAdapter: adapter })
    const input: GeneratorInput = {
      topic: 'Rust',
      contentType: 'course',
      modules: 1,
    }
    const out = await bundle.orchestrator.generate(input, makeCtx())
    expect(out.ok).toBe(true)
    expect(out.content.length).toBeGreaterThan(0)
  })

  it('GenerationOrchestrator dispatch returns failed output for unknown contentType', async () => {
    const bundle = createGenerationModule({ aiAdapter: adapter })
    // The contentType field is typed, so we cast to bypass the type system
    // for this negative test only.
    const input = {
      topic: 'X',
      contentType: 'unknown-type' as unknown as 'course',
    } as GeneratorInput
    const out = await bundle.orchestrator.generate(input, makeCtx())
    expect(out.ok).toBe(false)
    expect(out.error).toContain('no generator registered for content type')
  })

  it('GenerationOrchestrator.listGenerators returns all 4 types', () => {
    const bundle = createGenerationModule({ aiAdapter: adapter })
    const types = bundle.orchestrator.listGenerators().sort()
    expect(types).toEqual(['course', 'document', 'presentation', 'quiz'])
  })

  it('GenerationPipeline.dryRun returns estimated tokens WITHOUT calling AI', async () => {
    adapter.responses = [COURSE_OUTLINE, COURSE_MODULES]
    const gen = new CourseGenerator(adapter)
    const pipeline = new GenerationPipeline(gen)
    const input: GeneratorInput = {
      topic: 'Rust',
      contentType: 'course',
      modules: 5,
    }
    const result = await pipeline.dryRun(input, makeCtx())
    expect(result.canExecute).toBe(true)
    expect(result.estimatedTokens.totalTokens).toBeGreaterThan(0)
    expect(result.estimatedTokens.promptTokens).toBeGreaterThan(0)
    expect(result.estimatedTokens.completionTokens).toBeGreaterThan(0)
    expect(result.estimatedCost).toBeGreaterThan(0)
    expect(result.estimatedDurationMs).toBeGreaterThan(0)
    expect(result.stepsPlanned).toEqual([
      'prepare',
      'generate',
      'validate',
      'finalize',
    ])
    expect(result.providerSelection.generate).toBe('course-generator')
    // No AI calls.
    expect(adapter.callIndex).toBe(0)
  })

  it('GenerationPipeline.dryRun returns canExecute=false for unsupported contentType', async () => {
    const gen = new CourseGenerator(adapter)
    const pipeline = new GenerationPipeline(gen)
    const input = {
      topic: 'X',
      contentType: 'presentation' as unknown as 'course',
    } as GeneratorInput
    const result = await pipeline.dryRun(input, makeCtx())
    expect(result.canExecute).toBe(false)
    expect(result.warnings.length).toBeGreaterThan(0)
    expect(result.stepsPlanned).toEqual([])
  })
})
