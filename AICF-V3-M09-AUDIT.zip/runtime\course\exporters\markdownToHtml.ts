// =============================================================================
// AICF V3 — Markdown to HTML transformer (Epic 6 — Exporters)
// =============================================================================
// A small, dependency-free Markdown -> HTML transformer used by every exporter
// that needs to render content (HTML, DOCX, PDF). It supports the subset of
// Markdown that AICF course content uses:
//
//   - ATX headings (# .. ######)
//   - Paragraphs (blank-line separated)
//   - Unordered lists (- or * markers)
//   - Ordered lists (1. markers)
//   - Fenced code blocks (``` optional-language)
//   - Inline code (`code`)
//   - Bold (**text**) and italic (*text*)
//   - Links ([text](url))
//   - Blockquotes (> text)
//   - Horizontal rules (--- or ***)
//
// The transformer NEVER generates or modifies content — it only re-formats
// the supplied text into HTML. All text is HTML-escaped before formatting
// is applied, so the output is safe to embed in a larger HTML document.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

/**
 * Escape the five significant HTML characters in a string. This is applied to
 * all raw text BEFORE any inline Markdown formatting is applied, so the output
 * is always well-formed HTML.
 */
export function escapeHtml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/**
 * Apply inline Markdown formatting (bold, italic, inline code, links) to a
 * single line of already-escaped HTML text. The order matters: inline code is
 * applied first so that its contents are not re-processed for bold/italic.
 */
function applyInline(escaped: string): string {
  // Inline code: `...`
  let out = escaped.replace(/`([^`]+)`/g, (_m, code: string) => `<code>${code}</code>`)
  // Bold: **...**
  out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
  // Italic: *...*  (avoid matching ** which is bold — already consumed above)
  out = out.replace(/(^|[^*])\*([^*]+)\*(?!\*)/g, '$1<em>$2</em>')
  // Links: [text](url) — url is restricted to a safe subset
  out = out.replace(
    /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    '<a href="$2">$1</a>',
  )
  return out
}

interface ListState {
  /** "ul" | "ol" | null when not inside a list. */
  type: 'ul' | 'ol' | null
  /** Accumulated <li> items for the current list. */
  items: string[]
}

function flushList(list: ListState, out: string[]): void {
  if (list.type === null) return
  const items = list.items.map((it) => `      <li>${applyInline(it)}</li>`).join('\n')
  out.push(`    <${list.type}>`)
  out.push(items)
  out.push(`    </${list.type}>`)
  list.type = null
  list.items = []
}

/**
 * Transform a Markdown string into an HTML fragment (no <html>, <head>, or
 * <body> wrapper — callers wrap the result as needed).
 *
 * The fragment is a sequence of block-level elements (<h1>-<h6>, <p>, <ul>,
 * <ol>, <pre><code>, <blockquote>, <hr>) suitable for embedding in any HTML
 * document.
 */
export function markdownToHtml(markdown: string): string {
  const src = markdown.replace(/\r\n/g, '\n')
  const lines = src.split('\n')
  const out: string[] = []
  const list: ListState = { type: null, items: [] }

  let i = 0
  while (i < lines.length) {
    const line = lines[i]

    // Fenced code block: ``` optional-language ... ```
    const fence = line.match(/^```(\w+)?\s*$/)
    if (fence) {
      flushList(list, out)
      const lang = fence[1] ?? ''
      const codeLines: string[] = []
      i++
      while (i < lines.length && !/^```\s*$/.test(lines[i])) {
        codeLines.push(lines[i])
        i++
      }
      // Consume the closing fence (if present)
      if (i < lines.length) i++
      const codeBody = escapeHtml(codeLines.join('\n'))
      const cls = lang ? ` class="language-${escapeHtml(lang)}"` : ''
      out.push(`    <pre><code${cls}>${codeBody}</code></pre>`)
      continue
    }

    // Heading: # .. ######
    const heading = line.match(/^(#{1,6})\s+(.*)$/)
    if (heading) {
      flushList(list, out)
      const level = heading[1].length
      const text = applyInline(escapeHtml(heading[2].trim()))
      out.push(`    <h${level}>${text}</h${level}>`)
      i++
      continue
    }

    // Horizontal rule: --- or *** (3+ of same char, only dashes/stars)
    if (/^(-{3,}|\*{3,}|_{3,})\s*$/.test(line) && line.trim().length >= 3) {
      flushList(list, out)
      out.push('    <hr />')
      i++
      continue
    }

    // Blockquote: > text (consecutive lines grouped)
    if (/^>\s?/.test(line)) {
      flushList(list, out)
      const quoteLines: string[] = []
      while (i < lines.length && /^>\s?/.test(lines[i])) {
        quoteLines.push(lines[i].replace(/^>\s?/, ''))
        i++
      }
      const inner = applyInline(escapeHtml(quoteLines.join(' ').trim()))
      out.push(`    <blockquote>${inner}</blockquote>`)
      continue
    }

    // Unordered list item: - text  or  * text
    const ulItem = line.match(/^\s*[-*]\s+(.*)$/)
    if (ulItem) {
      if (list.type !== 'ul') {
        flushList(list, out)
        list.type = 'ul'
      }
      list.items.push(escapeHtml(ulItem[1]))
      i++
      continue
    }

    // Ordered list item: 1. text  (any number followed by . or ))
    const olItem = line.match(/^\s*\d+[.)]\s+(.*)$/)
    if (olItem) {
      if (list.type !== 'ol') {
        flushList(list, out)
        list.type = 'ol'
      }
      list.items.push(escapeHtml(olItem[1]))
      i++
      continue
    }

    // Blank line — closes any open list and paragraph grouping
    if (line.trim() === '') {
      flushList(list, out)
      i++
      continue
    }

    // Paragraph: collect consecutive non-blank, non-special lines
    flushList(list, out)
    const paraLines: string[] = []
    while (
      i < lines.length &&
      lines[i].trim() !== '' &&
      !/^#{1,6}\s/.test(lines[i]) &&
      !/^```/.test(lines[i]) &&
      !/^>\s?/.test(lines[i]) &&
      !/^\s*[-*]\s+/.test(lines[i]) &&
      !/^\s*\d+[.)]\s+/.test(lines[i]) &&
      !/^(-{3,}|\*{3,}|_{3,})\s*$/.test(lines[i])
    ) {
      paraLines.push(lines[i])
      i++
    }
    if (paraLines.length > 0) {
      const text = applyInline(escapeHtml(paraLines.join(' ').trim()))
      out.push(`    <p>${text}</p>`)
    }
  }

  // Flush any trailing list
  flushList(list, out)

  return out.join('\n')
}

/**
 * Split a Markdown document into "slides" for the PPTX exporter. A new slide
 * starts at every level-1 or level-2 heading. The heading text becomes the
 * slide title and the body lines (until the next heading) become the slide's
 * bullet points (one bullet per non-blank line, with sub-bullets for list
 * items). Returns an array of { title, bullets, notes } objects.
 */
export interface MarkdownSlide {
  title: string
  bullets: string[]
  notes: string
}

export function markdownToSlides(markdown: string): MarkdownSlide[] {
  const src = markdown.replace(/\r\n/g, '\n')
  const lines = src.split('\n')
  const slides: MarkdownSlide[] = []
  let current: MarkdownSlide | null = null

  const pushCurrent = (): void => {
    if (current && (current.bullets.length > 0 || current.title.length > 0)) {
      slides.push(current)
    }
  }

  for (const line of lines) {
    const heading = line.match(/^(#{1,2})\s+(.*)$/)
    if (heading) {
      pushCurrent()
      current = { title: heading[2].trim(), bullets: [], notes: '' }
      continue
    }
    if (!current) {
      current = { title: 'Untitled Slide', bullets: [], notes: '' }
    }
    if (line.trim() === '') continue
    // Strip list markers and bold/italic markers for cleaner bullet text
    const bullet = line
      .replace(/^\s*[-*]\s+/, '')
      .replace(/^\s*\d+[.)]\s+/, '')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .trim()
    if (bullet.length > 0) {
      current.bullets.push(bullet)
    }
  }
  pushCurrent()

  // Slide notes default to the bullet count for downstream enrichment
  for (const s of slides) {
    s.notes = `${s.bullets.length} bullet point${s.bullets.length === 1 ? '' : 's'}`
  }

  return slides
}
