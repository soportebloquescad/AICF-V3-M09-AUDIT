// =============================================================================
// AICF V3 — Sprint 2 — Context Middleware
// =============================================================================
// Re-exports the buildContext function from RuntimeContextMiddleware
// for consumers who prefer importing from Context.ts.
// =============================================================================

export { buildContext } from './RuntimeContextMiddleware'
