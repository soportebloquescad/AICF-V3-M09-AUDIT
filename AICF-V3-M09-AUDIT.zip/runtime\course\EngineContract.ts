// =============================================================================
// AICF V3 — Epica 7 — Engine Contract
// =============================================================================
// Universal contract that every Epica 8 engine implements. The runtime
// (EngineRegistry, CourseOrchestrator, AIFactory) only depends on this
// interface, never on concrete engines. `unknown` is allowed ONLY at this
// boundary — engines cast internally to their typed contracts.
// =============================================================================

export interface HealthStatus {
  healthy: boolean
  details?: Record<string, unknown>
  error?: string
}

/**
 * Universal engine contract. Every stage engine (CurriculumBuilder,
 * ModulePlanner, LessonWriterEngine, ...) implements this so the
 * orchestrator can drive them uniformly.
 */
export interface EngineContract {
  readonly name: string

  /**
   * Initialize engine state (load models, warm caches, etc.).
   * Called once before the first execute().
   */
  initialize(): Promise<void>

  /**
   * Run the engine. `unknown` is allowed only here at the boundary;
   * each concrete engine casts to its typed input.
   */
  execute(input: unknown): Promise<unknown>

  /**
   * Validate input shape before execute(). Returns false (never throws)
   * so the orchestrator can skip misconfigured engines.
   */
  validate(input: unknown): boolean

  /**
   * Health check — returns provider/model reachability.
   */
  health(): Promise<HealthStatus>

  /**
   * Release resources (caches, file handles, etc.).
   */
  shutdown(): Promise<void>
}

export const ENGINE_VERSION = '3.0.0'
export const RUNTIME_VERSION = 'AICF-V3-RC1'
