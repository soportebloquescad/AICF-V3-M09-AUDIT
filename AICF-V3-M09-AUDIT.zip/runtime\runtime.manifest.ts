// =============================================================================
// AICF V3 — Runtime Manifest (Sprint 19: All 9 Modules Real)
// =============================================================================
// The SINGLE source of truth for which modules the Runtime loads.
// To add a new module:
//   1. Create the module class under src/lib/runtime/modules/<name>/
//   2. Add a case to ModuleFactory.create()
//   3. Add an entry to runtimeManifest.modules below
//
// No other files need to change. RuntimeService, ModuleRegistry, and
// RuntimeBootstrap are NOT modified when adding modules.
//
// Sprint 19 additions:
//   - localization (priority 5)  — i18n, translations, regional formatting
//   - assets (priority 15)       — in-memory asset storage (images/docs/files)
//   - reports (priority 25)      — report generation, listing, and export
//
// All 9 modules are now real implementations — no stubs remain.
//
// Initialization order (by priority, ascending):
//   1. observability (5)         — captures events from all other modules
//   2. localization (5)          — i18n / formatting (used by later modules)
//   3. infrastructure (10)       — M18, LiteLLM + connectors
//   4. workflow (12)             — workflow engine
//   5. content-intelligence (15) — M08, policy + routing
//   6. assets (15)               — asset storage
//   7. generation (20)           — content generation (depends on workflow)
//   8. real-generation (25)      — M21, AI generation (depends on M08 + M18)
//   9. reports (25)              — reporting (depends on localization + assets)
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import { ModuleFactory, type ModuleDeps } from './factories/ModuleFactory'
import type { PluginMetadata } from './contracts/PluginMetadata'
import {
  CONTENT_INTELLIGENCE_METADATA,
} from './modules/m08/ContentIntelligenceRuntimeModule'
import {
  INFRASTRUCTURE_METADATA,
} from './modules/m18/InfrastructureRuntimeModule'
import {
  REAL_GENERATION_METADATA,
} from './modules/m21/RealGenerationRuntimeModule'
import { WORKFLOW_METADATA } from './modules/workflow/WorkflowModule'
import { GENERATION_MODULE_METADATA } from './modules/generation/GenerationModule'
import { OBSERVABILITY_MODULE_METADATA } from './modules/observability/ObservabilityModule'
import { LOCALIZATION_METADATA } from './modules/localization/LocalizationModule'
import { ASSETS_METADATA } from './modules/assets/AssetsModule'
import { REPORTS_METADATA } from './modules/reports/ReportsModule'

/**
 * A single module entry in the runtime manifest.
 */
export interface ManifestModuleEntry {
  /** Unique module ID (matches the RuntimeModule.name). */
  id: string

  /** Whether the module is enabled. Disabled modules are skipped entirely. */
  enabled: boolean

  /**
   * Factory function that creates the module instance.
   * Uses ModuleFactory.create() — never `new ModuleName()` directly.
   */
  factory: (deps?: ModuleDeps) => ReturnType<typeof ModuleFactory.create>

  /** IDs of modules this module depends on. Must be initialized first. */
  dependencies: string[]

  /**
   * Priority (ascending). Lower = initialized first.
   */
  priority: number

  /** Sprint 17: plugin metadata (REQUIRED — capabilities, contracts, mission, etc.). */
  metadata: PluginMetadata
}

/**
 * The runtime manifest.
 *
 * Sprint 19: all 9 modules are real implementations (no stubs).
 * Modules: observability, localization, infrastructure, workflow,
 * content-intelligence, assets, generation, real-generation, reports.
 */
export const runtimeManifest: { modules: ManifestModuleEntry[] } = {
  modules: [
    {
      id: 'observability',
      enabled: true,
      factory: (deps) => ModuleFactory.create('observability', deps),
      dependencies: [],
      priority: 5,
      metadata: OBSERVABILITY_MODULE_METADATA,
    },
    {
      id: 'localization',
      enabled: true,
      factory: (deps) => ModuleFactory.create('localization', deps),
      dependencies: [],
      priority: 5,
      metadata: LOCALIZATION_METADATA,
    },
    {
      id: 'infrastructure',
      enabled: true,
      factory: (deps) => ModuleFactory.create('infrastructure', deps),
      dependencies: [],
      priority: 10,
      metadata: INFRASTRUCTURE_METADATA,
    },
    {
      id: 'workflow',
      enabled: true,
      factory: (deps) => ModuleFactory.create('workflow', deps),
      dependencies: [],
      priority: 12,
      metadata: WORKFLOW_METADATA,
    },
    {
      id: 'content-intelligence',
      enabled: true,
      factory: (deps) => ModuleFactory.create('content-intelligence', deps),
      dependencies: [],
      priority: 15,
      metadata: CONTENT_INTELLIGENCE_METADATA,
    },
    {
      id: 'assets',
      enabled: true,
      factory: (deps) => ModuleFactory.create('assets', deps),
      dependencies: [],
      priority: 15,
      metadata: ASSETS_METADATA,
    },
    {
      id: 'generation',
      enabled: true,
      factory: (deps) => ModuleFactory.create('generation', deps),
      dependencies: ['workflow'],
      priority: 20,
      metadata: GENERATION_MODULE_METADATA,
    },
    {
      id: 'real-generation',
      enabled: true,
      factory: (deps) => ModuleFactory.create('real-generation', deps),
      dependencies: ['content-intelligence', 'infrastructure'],
      priority: 25,
      metadata: REAL_GENERATION_METADATA,
    },
    {
      id: 'reports',
      enabled: true,
      factory: (deps) => ModuleFactory.create('reports', deps),
      dependencies: ['localization', 'assets'],
      priority: 25,
      metadata: REPORTS_METADATA,
    },
  ],
}

/**
 * Resolves the manifest to an ordered list of enabled modules (sorted by
 * priority ascending). Validates dependencies and detects cycles.
 *
 * @throws if a dependency is missing, disabled, or cyclic.
 */
export function resolveManifest(manifest = runtimeManifest): ManifestModuleEntry[] {
  const enabled = manifest.modules.filter((m) => m.enabled)

  // Check that all dependencies are present + enabled
  const enabledIds = new Set(enabled.map((m) => m.id))
  for (const mod of enabled) {
    for (const dep of mod.dependencies) {
      if (!enabledIds.has(dep)) {
        throw new Error(
          `Manifest: module '${mod.id}' depends on '${dep}', but '${dep}' is not enabled or not in the manifest`,
        )
      }
    }
  }

  // Topological sort by priority (stable: ties broken by original order)
  const sorted = [...enabled].sort((a, b) => a.priority - b.priority)

  // Cycle detection (Kahn's algorithm)
  const visited = new Set<string>()
  const visiting = new Set<string>()
  const visit = (id: string, path: string[]) => {
    if (visited.has(id)) return
    if (visiting.has(id)) {
      throw new Error(`Manifest: circular dependency detected: ${[...path, id].join(' → ')}`)
    }
    visiting.add(id)
    const entry = sorted.find((m) => m.id === id)
    if (entry) {
      for (const dep of entry.dependencies) {
        visit(dep, [...path, id])
      }
    }
    visiting.delete(id)
    visited.add(id)
  }
  for (const mod of sorted) {
    visit(mod.id, [])
  }

  return sorted
}
