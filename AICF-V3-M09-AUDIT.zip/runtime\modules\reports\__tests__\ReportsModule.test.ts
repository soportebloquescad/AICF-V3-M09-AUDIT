// =============================================================================
// AICF V3 — Sprint 19 — Reports Module Reference Tests
// =============================================================================
// Verifies that the ReportsModule follows the reference pattern:
//   - Full lifecycle (initialize / isReady / dispose)
//   - Health and metadata accessors (incl. declared dependencies)
//   - Capabilities (generateReport, getReportStatus, listReports,
//     exportReport) return the expected shapes and honor filters
//   - Export to JSON / Markdown / CSV produces valid output
//
// Tests are self-contained — no external services or fixtures required.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import {
  ReportsModule,
  REPORTS_METADATA,
  createReportsModule,
  type ReportRecord,
} from '../ReportsModule'

describe('ReportsModule', () => {
  let testModule: ReportsModule

  beforeEach(() => {
    testModule = createReportsModule()
  })

  describe('lifecycle', () => {
    it('initialize() → isReady() === true', async () => {
      expect(testModule.isReady()).toBe(false)
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      await testModule.initialize()
      const firstStartup = (await testModule.health()).startupTime
      await testModule.initialize()
      const secondStartup = (await testModule.health()).startupTime
      expect(secondStartup).toBe(firstStartup)
    })

    it('dispose() → isReady() === false', async () => {
      await testModule.initialize()
      expect(testModule.isReady()).toBe(true)
      await testModule.dispose()
      expect(testModule.isReady()).toBe(false)
    })

    it('reload() works', async () => {
      await testModule.initialize()
      await testModule.reload()
      expect(testModule.isReady()).toBe(true)
    })
  })

  describe('health and metadata', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('health() returns healthy when initialized', async () => {
      const h = await testModule.health()
      expect(h.ready).toBe(true)
      expect(h.status).toBe('healthy')
      expect(h.version).toBe(REPORTS_METADATA.version)
      expect(h.dependencies).toEqual(['localization', 'assets'])
    })

    it('getMetadata() returns the declared plugin metadata', () => {
      const meta = testModule.getMetadata()
      expect(meta).toEqual(REPORTS_METADATA)
      expect(meta.id).toBe('reports')
      expect(meta.priority).toBe(25)
      expect(meta.dependencies).toEqual(['localization', 'assets'])
      expect(meta.capabilities).toContain('generateReport')
      expect(meta.capabilities).toContain('getReportStatus')
      expect(meta.capabilities).toContain('listReports')
      expect(meta.capabilities).toContain('exportReport')
      expect(meta.events).toEqual(['report.generated', 'report.exported'])
    })

    it('getStatus() returns the expected status shape', () => {
      const s = testModule.getStatus()
      expect(s.name).toBe(REPORTS_METADATA.name)
      expect(s.ready).toBe(true)
      expect(s.version).toBe(REPORTS_METADATA.version)
      expect(s.details?.implemented).toBe(true)
    })
  })

  describe('generateReport and getReportStatus', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('generateReport returns an ID and status completed', async () => {
      const result = await testModule.generateReport('summary', { since: '2024-01-01' })
      expect(typeof result.id).toBe('string')
      expect(result.id.length).toBeGreaterThan(0)
      expect(result.status).toBe('completed')
    })

    it('getReportStatus returns the report', async () => {
      const { id } = await testModule.generateReport('summary', { since: '2024-01-01' })
      const status = await testModule.getReportStatus(id)
      expect(status).not.toBeNull()
      expect(status?.id).toBe(id)
      expect(status?.status).toBe('completed')
      expect(status?.type).toBe('summary')
      expect(status?.createdAt).toBeTruthy()
    })

    it('getReportStatus returns null for an unknown ID', async () => {
      const status = await testModule.getReportStatus('does-not-exist')
      expect(status).toBeNull()
    })

    it('generates a summary report with counts', async () => {
      const { id } = await testModule.generateReport('summary', {})
      const list = await testModule.listReports()
      const record = list.find((r: ReportRecord) => r.id === id)
      expect(record).toBeDefined()
      expect(record?.data.type).toBe('summary')
      expect(record?.data.counts).toBeDefined()
    })

    it('generates an audit report with an empty trail', async () => {
      const { id } = await testModule.generateReport('audit', {})
      const list = await testModule.listReports()
      const record = list.find((r: ReportRecord) => r.id === id)
      expect(record?.data.type).toBe('audit')
      expect(Array.isArray(record?.data.trail)).toBe(true)
      expect(record?.data.trail).toEqual([])
    })

    it('generates a statistics report with basic statistics', async () => {
      const { id } = await testModule.generateReport('statistics', {})
      const list = await testModule.listReports()
      const record = list.find((r: ReportRecord) => r.id === id)
      expect(record?.data.type).toBe('statistics')
      expect(record?.data.statistics).toBeDefined()
    })

    it('echoes params back for unknown report types', async () => {
      const { id } = await testModule.generateReport('custom-type', { foo: 'bar' })
      const list = await testModule.listReports()
      const record = list.find((r: ReportRecord) => r.id === id)
      expect(record?.type).toBe('custom-type')
      expect(record?.data.type).toBe('custom-type')
      expect(record?.data.params).toEqual({ foo: 'bar' })
    })
  })

  describe('listReports', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns all reports when no filter is given', async () => {
      await testModule.generateReport('summary', {})
      await testModule.generateReport('audit', {})
      const list = await testModule.listReports()
      expect(list).toHaveLength(2)
    })

    it('filters by type', async () => {
      await testModule.generateReport('summary', {})
      await testModule.generateReport('audit', {})
      await testModule.generateReport('summary', {})
      const list = await testModule.listReports({ type: 'summary' })
      expect(list).toHaveLength(2)
      expect(list.every((r: ReportRecord) => r.type === 'summary')).toBe(true)
    })

    it('filters by status', async () => {
      await testModule.generateReport('summary', {})
      await testModule.generateReport('audit', {})
      const list = await testModule.listReports({ status: 'completed' })
      expect(list.length).toBeGreaterThanOrEqual(2)
      expect(list.every((r: ReportRecord) => r.status === 'completed')).toBe(true)
    })

    it('returns an empty array when nothing matches the filter', async () => {
      await testModule.generateReport('summary', {})
      const list = await testModule.listReports({ status: 'failed' })
      expect(list).toEqual([])
    })

    it('returns defensive copies', async () => {
      const { id } = await testModule.generateReport('summary', { foo: 'bar' })
      const list = await testModule.listReports()
      const record = list.find((r: ReportRecord) => r.id === id)
      if (record) {
        record.type = 'mutated'
        record.params.foo = 'mutated'
      }
      const after = await testModule.listReports({ type: 'summary' })
      expect(after).toHaveLength(1)
      expect(after[0]?.params.foo).toBe('bar')
    })
  })

  describe('exportReport', () => {
    beforeEach(async () => {
      await testModule.initialize()
    })

    it('returns null for an unknown ID', async () => {
      const result = await testModule.exportReport('does-not-exist', 'json')
      expect(result).toBeNull()
    })

    it('exports to JSON', async () => {
      const { id } = await testModule.generateReport('summary', { range: '7d' })
      const exported = await testModule.exportReport(id, 'json')
      expect(exported).not.toBeNull()
      expect(exported?.mimeType).toBe('application/json')
      // Should be valid JSON
      const parsed = JSON.parse(exported!.content)
      expect(parsed.type).toBe('summary')
      expect(parsed.params).toEqual({ range: '7d' })
    })

    it('exports to Markdown', async () => {
      const { id } = await testModule.generateReport('summary', {})
      const exported = await testModule.exportReport(id, 'markdown')
      expect(exported).not.toBeNull()
      expect(exported?.mimeType).toBe('text/markdown')
      expect(exported?.content.startsWith('# summary Report')).toBe(true)
      expect(exported?.content).toContain('```json')
    })

    it('exports to CSV', async () => {
      const { id } = await testModule.generateReport('summary', {})
      const exported = await testModule.exportReport(id, 'csv')
      expect(exported).not.toBeNull()
      expect(exported?.mimeType).toBe('text/csv')
      // Should have at least one header row and one data row
      const lines = exported!.content.split('\n')
      expect(lines.length).toBeGreaterThanOrEqual(2)
      // The header should mention at least one of the flat keys
      expect(exported?.content).toContain('type')
    })

    it('CSV escapes cells containing commas', async () => {
      const { id } = await testModule.generateReport('custom', {
        note: 'hello, world',
      })
      const exported = await testModule.exportReport(id, 'csv')
      expect(exported).not.toBeNull()
      // Either the cell is quoted, or there are no commas — here we expect a quoted cell.
      expect(exported?.content).toContain('"hello, world"')
    })
  })
})
