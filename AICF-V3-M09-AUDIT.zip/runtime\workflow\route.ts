// =============================================================================
// AICF V3 — POST + GET /api/runtime/workflow (Sprint 13+14)
// =============================================================================
// Workflow Runtime API.
//
// POST: Execute or dry-run a workflow definition.
//   Body: { definition: WorkflowDefinition, inputs: Record<string, unknown>, dryRun?: boolean }
//   Response: WorkflowResult | DryRunResult
//
// GET: List workflow executions (from the state store).
//   Query: ?status=pending|running|paused|completed|failed|cancelled
//   Response: { executions: WorkflowExecution[] }
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getWorkflowModuleBundle } from '@/lib/runtime/modules/workflow/bundle'
import { createWorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

const executeSchema = z.object({
  definition: z.record(z.string(), z.unknown()),
  inputs: z.record(z.string(), z.unknown()).default({}),
  dryRun: z.boolean().default(false),
  correlationId: z.string().optional(),
  userId: z.string().optional(),
})

export async function POST(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow', method: 'POST' })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const parsed = executeSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten() },
      { status: 422 },
    )
  }

  try {
    const bundle = getWorkflowModuleBundle()
    const { definition, inputs, dryRun, correlationId, userId } = parsed.data

    const ctx = createWorkflowContext({
      correlationId: correlationId || `cor-${Date.now().toString(36)}`,
      executionId: `exec-${Date.now().toString(36)}`,
      userId: userId || 'anonymous',
      variables: inputs,
      dryRun,
    })

    if (dryRun) {
      const result = await bundle.module.dryRun(definition as never, inputs, ctx)
      reqLogger.info({ correlationId: ctx.correlationId }, 'Workflow dry-run completed')
      return NextResponse.json(result, { status: 200 })
    }

    const result = await bundle.module.execute(definition as never, inputs, ctx)
    reqLogger.info(
      { correlationId: ctx.correlationId, status: result.status, durationMs: result.durationMs },
      'Workflow executed',
    )
    return NextResponse.json(result, { status: result.status === 'failed' ? 500 : 200 })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Workflow execution failed',
    )
    return NextResponse.json(
      { error: 'Workflow execution failed', message: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow', method: 'GET' })

  try {
    const url = new URL(request.url)
    const status = url.searchParams.get('status') || undefined

    const bundle = getWorkflowModuleBundle()
    const executions = status
      ? await bundle.stateStore.listByStatus(status as never)
      : await bundle.stateStore.listPending()

    reqLogger.info({ count: executions.length, status: status || 'pending' }, 'Listed executions')
    return NextResponse.json({ executions })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to list executions',
    )
    return NextResponse.json({ error: 'Failed to list executions' }, { status: 500 })
  }
}
