// =============================================================================
// AICF V3 — EventSubscriber interface + AuditSubscriber (Sprint 22)
// =============================================================================
// Sprint 21 introduced the EventSubscriber contract. Subscribers receive every
// envelope-wrapped event published via RuntimeEventBus.publishEnvelope.
//
// Sprint 22 (this file):
//   - Replaces the Sprint 21 stub with a real AuditSubscriber backed by
//     the AuditProvider interface from ../audit/AuditProvider.
//   - onEvent() records one AuditEntry per EDA event. Recording is best-effort:
//     errors are caught, logged, and swallowed — the subscriber never throws.
//   - Exports a factory `createAuditSubscriber(auditProvider)` for the
//     observability-singleton wiring.
//
// The EventSubscriber interface stays here (it is the canonical definition
// imported by MetricsSubscriber + DashboardSubscriber).
// =============================================================================

import type { RuntimeEventEnvelope } from '../events/EventMetadata'
import type { AuditProvider } from '../audit/AuditProvider'
import { logger } from '@/lib/ai/logger'

/**
 * Contract every event subscriber must implement. Subscribers receive every
 * envelope-wrapped event published by the runtime pipeline. They MUST NOT
 * throw — failures are logged and swallowed by the bus.
 */
export interface EventSubscriber {
  /** Subscriber name (used for logging + diagnostics). */
  readonly name: string

  /**
   * Called once per published event. Must not throw — wrap any side-effect
   * in try/catch and log on failure.
   */
  onEvent(event: RuntimeEventEnvelope<unknown>): Promise<void>

  /** Returns true once the subscriber has finished initializing. */
  isReady(): boolean
}

/**
 * Audit subscriber — records every EDA event to the audit trail.
 *
 * Each envelope received by `onEvent()` is translated into one AuditEntry:
 *   - requestId: event.metadata.requestId
 *   - action:    event.metadata.pipelineStage (the stage that emitted it)
 *   - module:    event.metadata.pipelineStage (the stage that emitted it)
 *   - details:   { eventId, stageOrder, operation, correlationId, payload }
 *
 * Recording is best-effort: any failure inside `auditProvider.record()` is
 * caught, logged at error level, and swallowed. The subscriber never throws
 * from onEvent() — this protects the EventBus delivery path.
 */
export class AuditSubscriber implements EventSubscriber {
  readonly name = 'audit-subscriber'
  private ready = false

  constructor(private readonly auditProvider: AuditProvider) {}

  /**
   * Initializes the subscriber. Flips the ready flag — no async work is
   * required because the AuditProvider is provided (already constructed).
   */
  async initialize(): Promise<void> {
    this.ready = true
    logger.debug({ subscriber: this.name }, 'AuditSubscriber: initialized')
  }

  isReady(): boolean {
    return this.ready
  }

  async onEvent(event: RuntimeEventEnvelope<unknown>): Promise<void> {
    try {
      const meta = event.metadata
      await this.auditProvider.record({
        requestId: meta.requestId,
        action: meta.pipelineStage,
        module: meta.pipelineStage,
        details: {
          eventId: meta.eventId,
          stageOrder: meta.stageOrder,
          operation: meta.operation,
          correlationId: meta.correlationId,
          payload: event.payload,
        },
      })
    } catch (err) {
      // Best-effort: never throw out of onEvent. The EventBus relies on
      // subscribers being non-fatal so a faulty subscriber can't break the
      // delivery chain for other subscribers.
      logger.error(
        {
          subscriber: this.name,
          eventId: event.metadata.eventId,
          error: err instanceof Error ? err.message : String(err),
        },
        'AuditSubscriber: record() failed (swallowed)',
      )
    }
  }
}

/**
 * Factory: creates an AuditSubscriber bound to the given AuditProvider.
 *
 * @example
 * const sub = createAuditSubscriber(auditProvider)
 * await sub.initialize()
 * bus.onAll((e) => sub.onEvent(extractEnvelope(e)))
 */
export function createAuditSubscriber(auditProvider: AuditProvider): AuditSubscriber {
  return new AuditSubscriber(auditProvider)
}
