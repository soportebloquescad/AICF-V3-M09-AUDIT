// =============================================================================
// AICF V3 — Epica 8 — Slide Builder Engine
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { ModulePlan, Lesson, Presentation, Slide, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export interface SlideBuilderInput {
  title: string
  modules: ModulePlan[]
  lessons: Lesson[]
}

export class SlideBuilder implements EngineContract {
  readonly name = 'slide-builder'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('SlideBuilder: invalid input — expected { title, modules, lessons }')
    }
    const typed = input as SlideBuilderInput
    if (this.opts.aiAdapter) {
      try {
        return await this.buildWithAI(typed)
      } catch (err) {
        logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'SlideBuilder: AI failed, using fallback')
      }
    }
    return this.buildDeterministic(typed)
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    if (typeof obj.title !== 'string') return false
    if (!Array.isArray(obj.modules)) return false
    if (!Array.isArray(obj.lessons)) return false
    return true
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async buildWithAI(input: SlideBuilderInput): Promise<Presentation> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a premium instructional slide designer. Create pedagogically structured slides with SPECIFIC content (no generic placeholders). Each content slide must have: title, a content paragraph explaining the concept, a concrete example, a visual description (diagram/chart/mermaid/image), and instructor notes. Respond as JSON: { "title": string, "description": string, "slides": [{index, title, content, example, bullets[], notes, instructorNotes, layout, lessonId, moduleId, visual: {type, description}}], "theme": string }',
        },
        {
          role: 'user',
          content: `Course: ${input.title}\nModules: ${input.modules.map((m) => `${m.id}: ${m.title}`).join(', ')}\nLessons: ${input.lessons.map((l) => `${l.id} (module:${l.moduleId}): ${l.title}`).join('; ')}\n\nCreate a premium slide deck: title slide, section slides per module, content slides for key lessons (associate each with its lessonId and moduleId), and a closing slide. For each content slide include: content (1-2 sentence explanation), example (concrete real-world example), visual (type + description), instructorNotes (delivery guidance). Mix layouts (title, content, section, two-column, image).`,
        },
      ],
      temperature: 0.5,
      maxTokens: 8192,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const parsed = JSON.parse(resp.content) as { title?: string; description?: string; slides?: Array<Partial<Slide>>; theme?: string }
    return this.assemblePresentation(
      input,
      {
        title: parsed.title ?? input.title,
        description: parsed.description ?? `Slide deck for ${input.title}.`,
        slides: parsed.slides ?? [],
        theme: parsed.theme ?? 'aicf-professional',
      },
      resp.provider as Provider,
      resp.model,
    )
  }

  private buildDeterministic(input: SlideBuilderInput): Presentation {
    const slides: Slide[] = []
    let index = 0
    slides.push({
      id: makeId('slide'),
      index: index++,
      title: input.title,
      bullets: [],
      notes: `Welcome slide for the course "${input.title}". Introduce the course topic, the target audience, and the overall learning journey. Set expectations for what students will achieve by the end.`,
      layout: 'title',
      content: `Welcome to "${input.title}". This course provides a structured learning path designed to build practical competence through progressive modules.`,
      example: `This course on ${input.title} will guide you from foundational concepts to advanced applications, with hands-on exercises and real-world case studies.`,
      instructorNotes: `Begin by introducing yourself and the course objectives. Ask participants about their background and expectations. Allocate 5 minutes for introductions.`,
      visual: { type: 'image', description: `Cover illustration representing ${input.title}` },
    })

    for (const mod of input.modules) {
      slides.push({
        id: makeId('slide'),
        index: index++,
        title: mod.title,
        bullets: [],
        notes: `Section divider slide introducing ${mod.title}. ${mod.summary} Briefly outline what students will learn in this section and how it connects to the overall course objectives.`,
        layout: 'section',
        moduleId: mod.id,
        content: `This section covers ${mod.title}. ${mod.summary}`,
        example: `In ${mod.title}, you will explore ${mod.learningOutcomes.slice(0, 2).join(' and ')}.`,
        instructorNotes: `Transition from the previous module. Highlight how ${mod.title} connects to prior learning. Set the stage with a brief real-world scenario.`,
        visual: { type: 'diagram', description: `Module structure diagram for ${mod.title}` },
      })

      slides.push({
        id: makeId('slide'),
        index: index++,
        title: `${mod.title}: Overview`,
        bullets: [
          `Learning outcomes: ${mod.learningOutcomes.join('; ')}`,
          `Duration: approximately ${mod.durationHours} hours`,
          `Bloom levels targeted: ${mod.bloomLevels.join(', ')}`,
          `Lessons in this module: ${mod.lessonCount}`,
        ],
        notes: `Overview slide for ${mod.title}. Walk through each learning outcome and explain how the module is structured. Emphasize the Bloom levels to set expectations for the depth of engagement required.`,
        layout: 'content',
        moduleId: mod.id,
        content: `Module ${mod.title} targets ${mod.bloomLevels.join(', ')} Bloom levels across ${mod.lessonCount} lessons totaling ${mod.durationHours} hours.`,
        example: `Learning outcome example: "${mod.learningOutcomes[0] ?? 'apply concepts to real scenarios'}" — you will demonstrate this through exercises and case studies.`,
        instructorNotes: `Walk through each learning outcome. Ask participants which outcome is most relevant to their work. Emphasize the Bloom levels to set expectations.`,
        visual: { type: 'chart', description: `Bloom level distribution chart for ${mod.title}` },
      })

      const moduleLessons = input.lessons.filter((l) => l.moduleId === mod.id).slice(0, 2)
      for (const lesson of moduleLessons) {
        slides.push({
          id: makeId('slide'),
          index: index++,
          title: lesson.title,
          bullets: lesson.learningObjectives.slice(0, 4).map((o) => o.length > 80 ? o.slice(0, 77) + '...' : o),
          notes: `Content slide for lesson "${lesson.title}". ${lesson.keyTakeaways.join(' ')} Use specific examples to illustrate each objective. Allow time for questions.`,
          layout: 'content',
          lessonId: lesson.id,
          moduleId: mod.id,
          content: `Lesson "${lesson.title}" focuses on: ${lesson.learningObjectives.slice(0, 2).join('; ')}. Key takeaways include ${lesson.keyTakeaways.slice(0, 2).join(' ')}`,
          example: `Real-world example: In a business context, ${lesson.title.toLowerCase()} manifests when teams apply ${lesson.keyTakeaways.slice(0, 2).join(' and ')} to solve concrete problems.`,
          instructorNotes: `Present the learning objectives clearly. Use the key takeaways as discussion prompts. Allow 10 minutes for Q&A after the content delivery.`,
          visual: { type: 'diagram', description: `Concept diagram illustrating ${lesson.title}` },
        })

        slides.push({
          id: makeId('slide'),
          index: index++,
          title: `${lesson.title}: Key Concepts`,
          bullets: lesson.keyTakeaways.map((t) => t.length > 80 ? t.slice(0, 77) + '...' : t),
          notes: `Key concepts slide for "${lesson.title}". Deep dive into each takeaway. Use the two-column layout to compare and contrast concepts where appropriate.`,
          layout: 'two-column',
          lessonId: lesson.id,
          moduleId: mod.id,
          content: `Key concepts of ${lesson.title}: ${lesson.keyTakeaways.join(' ')}`,
          example: `Example: Compare two approaches to ${lesson.title.toLowerCase()} — traditional vs. modern — highlighting trade-offs in ${lesson.keyTakeaways.slice(0, 2).join(' and ')}.`,
          instructorNotes: `Use the two-column layout to compare concepts. Ask participants which concept they find most challenging and why.`,
          visual: { type: 'mermaid', description: `Comparison flowchart for ${lesson.title} key concepts` },
        })
      }

      slides.push({
        id: makeId('slide'),
        index: index++,
        title: `${mod.title}: Application`,
        bullets: [
          `Apply concepts to realistic ${mod.title.toLowerCase()} scenarios`,
          `Practice with hands-on exercises`,
          `Reflect on common pitfalls and how to avoid them`,
          `Connect module concepts to the broader course`,
        ],
        notes: `Application slide for ${mod.title}. Discuss how the concepts from this module apply in practice. Encourage students to think about their own contexts and how they might use what they have learned.`,
        layout: 'image',
        moduleId: mod.id,
        content: `Application of ${mod.title}: bridge theory to practice through hands-on exercises and real-world scenarios.`,
        example: `Hands-on exercise: Design a ${mod.title.toLowerCase()} solution for a realistic business scenario, applying ${mod.learningOutcomes[0] ?? 'the core concepts'}.`,
        instructorNotes: `Introduce the hands-on exercise. Circulate among participants to provide guidance. Debrief with a group discussion on challenges encountered.`,
        visual: { type: 'image', description: `Application scenario illustration for ${mod.title}` },
      })
    }

    slides.push({
      id: makeId('slide'),
      index: index++,
      title: 'Course Summary',
      bullets: [
        `Recap of ${input.modules.length} modules and their key outcomes`,
        `Integration of concepts across the course`,
        `Next steps for continued learning`,
        `Resources for further exploration`,
      ],
      notes: `Closing slide summarizing the entire course. Recap the journey through each module, highlight the integration of concepts, and provide guidance on next steps. Encourage students to apply their learning in real contexts.`,
      layout: 'content',
      content: `Course summary: ${input.modules.length} modules covering ${input.lessons.length} lessons. Integration of concepts across the entire learning journey.`,
      example: `Next steps: Apply the frameworks learned to a real project within the next 30 days to solidify your understanding.`,
      instructorNotes: `Recap the course journey module by module. Highlight integration points. Provide guidance on continued learning and resources.`,
      visual: { type: 'diagram', description: `Course journey map showing module progression` },
    })

    slides.push({
      id: makeId('slide'),
      index: index++,
      title: 'Thank You',
      bullets: [],
      notes: `Thank you slide. Provide contact information for questions, links to additional resources, and an invitation for feedback. Thank students for their engagement with the course.`,
      layout: 'title',
      content: `Thank you for completing "${input.title}". We hope this course has provided valuable knowledge and practical skills.`,
      example: `Stay connected: Join the alumni community for ongoing discussions, resource sharing, and networking opportunities.`,
      instructorNotes: `Thank participants. Share contact information and additional resources. Invite feedback via the course evaluation form.`,
      visual: { type: 'none', description: 'No visual — closing slide' },
    })

    const parsed = {
      title: input.title,
      description: `A comprehensive slide deck for the course "${input.title}" covering ${input.modules.length} modules with ${slides.length} slides. Each slide includes speaker notes to support delivery.`,
      slides,
      theme: 'aicf-professional',
    }
    return this.assemblePresentation(input, parsed, 'runtime-adapter', 'deterministic-fallback')
  }

  private assemblePresentation(
    input: SlideBuilderInput,
    parsed: { title: string; description: string; slides: Array<Partial<Slide>>; theme: string },
    provider: Provider,
    model: string,
  ): Presentation {
    const now = new Date().toISOString()
    const slides: Slide[] = (parsed.slides ?? []).map((s, i) => ({
      id: s.id ?? makeId('slide'),
      index: s.index ?? i,
      title: s.title ?? `Slide ${i + 1}`,
      bullets: s.bullets ?? [],
      notes: s.notes ?? '',
      layout: s.layout ?? 'content',
      // EPIC 10: preserve premium fields from AI response or deterministic builder
      ...(s.content ? { content: s.content } : {}),
      ...(s.example ? { example: s.example } : {}),
      ...(s.visual ? { visual: s.visual } : {}),
      ...(s.instructorNotes ? { instructorNotes: s.instructorNotes } : {}),
      ...(s.lessonId ? { lessonId: s.lessonId } : {}),
      ...(s.moduleId ? { moduleId: s.moduleId } : {}),
    }))
    return {
      id: makeId('pres'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      title: parsed.title,
      description: parsed.description,
      slides,
      slideCount: slides.length,
      theme: parsed.theme,
      audience: 'course learners',
    }
  }
}
