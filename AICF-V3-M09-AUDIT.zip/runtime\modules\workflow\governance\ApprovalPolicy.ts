// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Approval Policy
// =============================================================================
// Enforces human-in-the-loop approval for steps that declare
// `step.config.requiresApproval === true`. Approvals are stashed in
// `ctx.variables.__approvals` as `Record<stepId, boolean>` (or as a Set of
// approved step ids). The policy denies when approval is required but not
// granted.
//
// Sprint 13+14 spec requirements covered:
//   - name: 'approval-policy'
//   - check(ctx, step): denies when step requires approval AND approval is
//     not present in ctx.variables.__approvals
// =============================================================================

import type {
  WorkflowContext,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import type { IPolicy, PolicyDecision } from '@/lib/runtime/modules/workflow/policies/PolicyMiddleware'

/** Read the approvals map from `ctx.variables.__approvals`. */
function readApprovals(ctx: WorkflowContext): Record<string, boolean> {
  const raw = ctx.variables?.['__approvals']
  if (raw === null || typeof raw !== 'object') return {}
  return raw as Record<string, boolean>
}

/** Read a boolean config flag from step.config. */
function readBool(
  config: Record<string, unknown>,
  key: string,
): boolean {
  const v = config[key]
  return v === true || v === 'true'
}

/**
 * Enforces human-in-the-loop approval for steps that opt into it.
 * Implements `IPolicy`.
 */
export class ApprovalPolicy implements IPolicy {
  readonly name = 'approval-policy'

  async check(
    ctx: WorkflowContext,
    step: WorkflowStepDefinition,
  ): Promise<PolicyDecision> {
    const requiresApproval = readBool(step.config, 'requiresApproval')
    if (!requiresApproval) {
      return { allowed: true, violations: [] }
    }
    const approvals = readApprovals(ctx)
    const approved = approvals[step.id] === true
    if (!approved) {
      return {
        allowed: false,
        violations: [
          `step '${step.id}' requires approval; no approval found in ctx.variables.__approvals`,
        ],
        reason: 'approval required but not granted',
      }
    }
    return { allowed: true, violations: [] }
  }
}
