// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — WorkerRegistry
// =============================================================================
// The WorkerRegistry holds named workers, each bound to a specific pipeline
// stage. Workers implement the `PipelineWorker` interface: an async
// `execute(input)` method that produces a `WorkerResult`, and a `health()`
// method that reports readiness.
//
// The CoursePipeline looks up workers by stage name from the registry and
// invokes them in sequence, passing the previous stage's output as input
// to the next.
// =============================================================================

import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { logger } from '@/lib/ai/logger'

/**
 * Input passed to every worker invocation.
 */
export interface WorkerInput {
  /** Course id this execution belongs to. */
  courseId: string
  /** Unique execution id (matches PipelineState.executionId). */
  executionId: string
  /** Correlation id for distributed tracing. */
  correlationId: string
  /** The original RuntimeRequest that initiated the pipeline. */
  request: RuntimeRequest
  /** Accumulated context from previous stages (their outputs). */
  context: Record<string, unknown>
}

/**
 * Result returned by a worker.
 */
export interface WorkerResult {
  /** Whether the worker succeeded. */
  ok: boolean
  /** Stage name this result belongs to. */
  stage: string
  /** Output produced by the worker (passed to the next stage as input.context[stage]). */
  output: unknown
  /** Error message if `ok === false`. */
  error?: string
  /** Worker execution duration in milliseconds. */
  durationMs: number
}

/**
 * Health status reported by a worker.
 */
export interface WorkerHealth {
  /** Worker name. */
  name: string
  /** Whether the worker is ready to accept work. */
  healthy: boolean
  /** Worker mode (e.g. 'ai', 'deterministic', 'disabled'). */
  mode: string
  /** Last error reported by the worker, if any. */
  lastError?: string
}

/**
 * A pipeline worker. Bound to a single stage; invoked with a WorkerInput
 * and produces a WorkerResult.
 */
export interface PipelineWorker {
  /** Worker name (unique within the registry). */
  name: string
  /** Stage name this worker handles. */
  stage: string
  /** Human-readable description. */
  description: string
  /** Execute the worker. */
  execute(input: WorkerInput): Promise<WorkerResult>
  /** Report health status. */
  health(): WorkerHealth | Promise<WorkerHealth>
}

/**
 * The WorkerRegistry. Holds named workers and looks them up by stage.
 */
export class WorkerRegistry {
  private readonly workers = new Map<string, PipelineWorker>()
  private readonly byStage = new Map<string, PipelineWorker>()

  /**
   * Register a worker. Overwrites any existing worker with the same name.
   */
  register(worker: PipelineWorker): void {
    this.workers.set(worker.name, worker)
    this.byStage.set(worker.stage, worker)
    logger.info(
      { name: worker.name, stage: worker.stage },
      'WorkerRegistry: worker registered',
    )
  }

  /**
   * Get a worker by stage name. Returns null if not registered.
   */
  get(stage: string): PipelineWorker | null {
    return this.byStage.get(stage) ?? null
  }

  /**
   * Get a worker by name. Returns null if not registered.
   */
  getByName(name: string): PipelineWorker | null {
    return this.workers.get(name) ?? null
  }

  /**
   * List all registered workers.
   */
  list(): PipelineWorker[] {
    return Array.from(this.workers.values())
  }

  /**
   * List all registered stage names.
   */
  listStages(): string[] {
    return Array.from(this.byStage.keys())
  }

  /**
   * Returns true if a worker is registered for the given stage.
   */
  has(stage: string): boolean {
    return this.byStage.has(stage)
  }

  /**
   * Return the number of registered workers.
   */
  size(): number {
    return this.workers.size
  }

  /**
   * Collect health status from every registered worker.
   */
  async health(): Promise<WorkerHealth[]> {
    const out: WorkerHealth[] = []
    for (const worker of this.workers.values()) {
      try {
        const h = await worker.health()
        out.push(h)
      } catch (err) {
        out.push({
          name: worker.name,
          healthy: false,
          mode: 'error',
          lastError: err instanceof Error ? err.message : String(err),
        })
      }
    }
    return out
  }
}

/**
 * Singleton WorkerRegistry.
 */
let singleton: WorkerRegistry | null = null

export function getWorkerRegistry(): WorkerRegistry {
  if (!singleton) {
    singleton = new WorkerRegistry()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetWorkerRegistry(): void {
  singleton = null
}
