// =============================================================================
// AICF V3 — Épica 7 — GET /api/runtime/course/health
// =============================================================================
// Thin Route Handler: health check for the Course Factory module.
// Verifies that CourseWorker, CourseJobStore, and CourseArtifactRegistry
// are available. Does NOT modify any protected component.
// =============================================================================

import { NextResponse } from 'next/server'
import { peekRuntimeService } from '@/lib/runtime/runtime-singleton'
import { CourseJobStore } from '@/lib/runtime/course/CourseJobStore'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  const reqLogger = logger.child({ endpoint: '/api/runtime/course/health', method: 'GET' })

  try {
    const service = peekRuntimeService()
    const runtimeHealthy = service !== null

    // Verify CourseJobStore is functional
    let jobStoreHealthy = false
    try {
      const jobs = await CourseJobStore.list()
      jobStoreHealthy = Array.isArray(jobs)
    } catch {
      jobStoreHealthy = false
    }

    // Verify CourseArtifactRegistry is functional
    let registryHealthy = false
    try {
      const size = await CourseArtifactRegistry.size()
      registryHealthy = typeof size === 'number'
    } catch {
      registryHealthy = false
    }

    const allHealthy = runtimeHealthy && jobStoreHealthy && registryHealthy

    reqLogger.info({ runtimeHealthy, jobStoreHealthy, registryHealthy, allHealthy }, 'Course Factory health check')

    return NextResponse.json({
      status: allHealthy ? 'healthy' : 'degraded',
      healthy: allHealthy,
      checks: {
        runtime: { healthy: runtimeHealthy, detail: runtimeHealthy ? 'RuntimeService initialized' : 'RuntimeService not initialized' },
        jobStore: { healthy: jobStoreHealthy, detail: jobStoreHealthy ? 'CourseJobStore operational' : 'CourseJobStore unavailable' },
        artifactRegistry: { healthy: registryHealthy, detail: registryHealthy ? 'CourseArtifactRegistry operational' : 'CourseArtifactRegistry unavailable' },
      },
      module: 'course-factory',
      version: '3.0.0',
      timestamp: new Date().toISOString(),
    }, { status: 200 })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Health check failed',
    )
    return NextResponse.json({
      status: 'unhealthy',
      healthy: false,
      error: err instanceof Error ? err.message : String(err),
      module: 'course-factory',
      timestamp: new Date().toISOString(),
    }, { status: 200 })
  }
}
