// =============================================================================
// AICF V3 — RuntimeBootstrap Tests (Sprint 15: Plugin Architecture)
// =============================================================================
// Tests for the RuntimeBootstrap lifecycle: manifest resolution, module
// creation via factory, initialization order, health checks, event emission,
// and failure isolation.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeBootstrap } from '../RuntimeBootstrap'
import { RuntimeEventBus } from '@/lib/runtime/events/RuntimeEventBus'
import { ModuleRegistry } from '@/lib/runtime/registry/ModuleRegistry'
import type { RuntimeModule, ModuleHealth } from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'

/**
 * Builds minimal PluginMetadata for a test module. Sprint 17 made `metadata`
 * required on ManifestModuleEntry, so every mock entry needs one.
 */
function makeMockMetadata(id: string, deps: string[] = []): PluginMetadata {
  return {
    id,
    name: id,
    description: `mock ${id}`,
    author: 'test',
    version: '1.0.0',
    mission: 'TEST',
    priority: 10,
    dependencies: deps,
    capabilities: [],
    contracts: createVersionedContract('1.0.0', 'compatible'),
  }
}

/**
 * Builds a mock module with full lifecycle.
 */
function makeMockModule(id: string, opts?: { failInit?: boolean; deps?: string[] }): RuntimeModule {
  let initialized = false
  let disposed = false
  const startupTime = new Date().toISOString()
  return {
    name: id,
    version: '1.0.0',
    async initialize() {
      if (opts?.failInit) throw new Error(`${id} init failed`)
      initialized = true
    },
    isReady: () => initialized && !disposed,
    getStatus: () => ({
      name: id,
      ready: initialized && !disposed,
      version: '1.0.0',
      details: { implemented: true },
    }),
    async health(): Promise<ModuleHealth> {
      return {
        ready: initialized && !disposed,
        status: disposed ? 'unhealthy' : initialized ? 'healthy' : 'degraded',
        startupTime,
        dependencies: opts?.deps || [],
        version: '1.0.0',
        lastInitialization: startupTime,
      }
    },
    async dispose() { disposed = true },
    async shutdown() { disposed = true },
    getMetrics: () => ({
      initLatencyMs: 5,
      errorCount: 0,
      lastUsed: null,
      lastError: null,
      operationCount: 0,
    }),
  }
}

describe('RuntimeBootstrap', () => {
  let registry: ModuleRegistry
  let eventBus: RuntimeEventBus

  beforeEach(() => {
    registry = new ModuleRegistry()
    eventBus = new RuntimeEventBus()
  })

  it('should initialize all enabled modules in priority order', async () => {
    const order: string[] = []
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          {
            id: 'c',
            enabled: true,
            factory: () => { order.push('c'); return makeMockModule('c') },
            dependencies: [],
            priority: 30,
            metadata: makeMockMetadata('c'),
          },
          {
            id: 'a',
            enabled: true,
            factory: () => { order.push('a'); return makeMockModule('a') },
            dependencies: [],
            priority: 10,
            metadata: makeMockMetadata('a'),
          },
          {
            id: 'b',
            enabled: true,
            factory: () => { order.push('b'); return makeMockModule('b') },
            dependencies: ['a'],
            priority: 20,
            metadata: makeMockMetadata('b', ['a']),
          },
        ],
      },
    })

    const result = await bootstrap.run()

    expect(result.completed).toBe(true)
    expect(result.initialized).toEqual(['a', 'b', 'c'])
    expect(order).toEqual(['a', 'b', 'c'])
  })

  it('should skip disabled modules', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a'), dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
          { id: 'b', enabled: false, factory: () => makeMockModule('b'), dependencies: [], priority: 20, metadata: makeMockMetadata('b') },
        ],
      },
    })

    const result = await bootstrap.run()

    expect(result.initialized).toEqual(['a'])
    expect(result.skipped).toEqual(['b'])
  })

  it('should continue with other modules if one fails', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a'), dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
          { id: 'b', enabled: true, factory: () => makeMockModule('b', { failInit: true }), dependencies: [], priority: 20, metadata: makeMockMetadata('b') },
          { id: 'c', enabled: true, factory: () => makeMockModule('c'), dependencies: [], priority: 30, metadata: makeMockMetadata('c') },
        ],
      },
    })

    const result = await bootstrap.run()

    expect(result.completed).toBe(true)
    expect(result.initialized).toEqual(['a', 'c'])
    expect(result.failed.length).toBe(1)
    expect(result.failed[0].moduleId).toBe('b')
    expect(result.failed[0].error).toContain('init failed')
  })

  it('should skip a module if its dependency failed', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a', { failInit: true }), dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
          { id: 'b', enabled: true, factory: () => makeMockModule('b'), dependencies: ['a'], priority: 20, metadata: makeMockMetadata('b', ['a']) },
        ],
      },
    })

    const result = await bootstrap.run()

    expect(result.failed.length).toBe(2)
    expect(result.failed[0].moduleId).toBe('a')
    expect(result.failed[1].moduleId).toBe('b')
    expect(result.failed[1].error).toContain('dependencies not satisfied')
  })

  it('should emit lifecycle events', async () => {
    const events: string[] = []
    eventBus.onAll((e) => { events.push(e.type); return })

    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a'), dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
        ],
      },
    })

    await bootstrap.run()

    expect(events).toContain('runtime.bootstrap.start')
    expect(events).toContain('module.loaded')
    expect(events).toContain('module.initializing')
    expect(events).toContain('module.initialized')
    expect(events).toContain('module.registered')
    expect(events).toContain('runtime.bootstrap.complete')
    expect(events).toContain('runtime.ready')
  })

  it('should be idempotent (second run is a no-op)', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a'), dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
        ],
      },
    })

    const result1 = await bootstrap.run()
    const result2 = await bootstrap.run()

    expect(result2).toBe(result1) // same object reference
  })

  it('should register modules in the registry', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'workflow', enabled: true, factory: () => makeMockModule('workflow'), dependencies: [], priority: 10, metadata: makeMockMetadata('workflow') },
        ],
      },
    })

    await bootstrap.run()

    const wf = registry.get('workflow')
    expect(wf).not.toBeNull()
    expect(wf?.isReady()).toBe(true)
  })

  it('should detect circular dependencies', async () => {
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => makeMockModule('a'), dependencies: ['b'], priority: 10, metadata: makeMockMetadata('a', ['b']) },
          { id: 'b', enabled: true, factory: () => makeMockModule('b'), dependencies: ['a'], priority: 20, metadata: makeMockMetadata('b', ['a']) },
        ],
      },
    })

    const result = await bootstrap.run()

    expect(result.completed).toBe(false)
    expect(result.failed.length).toBe(1)
    expect(result.failed[0].error).toContain('circular')
  })

  it('should support graceful shutdown', async () => {
    const mod = makeMockModule('a')
    const bootstrap = new RuntimeBootstrap({
      registry,
      eventBus,
      manifest: {
        modules: [
          { id: 'a', enabled: true, factory: () => mod, dependencies: [], priority: 10, metadata: makeMockMetadata('a') },
        ],
      },
    })

    await bootstrap.run()
    expect(mod.isReady()).toBe(true)

    await bootstrap.shutdown()
    expect(mod.isReady()).toBe(false) // disposed
  })
})
