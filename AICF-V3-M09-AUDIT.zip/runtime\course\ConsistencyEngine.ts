// =============================================================================
// AICF V3 — Épica 6 — Consistency Engine
// =============================================================================
export interface ConsistencyIssue {
  type: 'terminology' | 'style' | 'definition' | 'reference' | 'naming' | 'length' | 'language'
  severity: 'low' | 'medium' | 'high'
  description: string
  location?: string
}

export interface ConsistencyResult {
  score: number
  issues: ConsistencyIssue[]
  recommendations: string[]
}

export class ConsistencyEngine {
  async validate(input: {
    content: string
    terminology?: Record<string, string>
    expectedLanguage?: string
  }): Promise<ConsistencyResult> {
    const issues: ConsistencyIssue[] = []
    const recommendations: string[] = []

    // 1. Terminology check
    if (input.terminology) {
      for (const [term, expected] of Object.entries(input.terminology)) {
        const regex = new RegExp(`\\b${term}\\b`, 'gi')
        const matches = input.content.match(regex)
        if (matches && matches.length > 0) {
          const hasExpected = input.content.toLowerCase().includes(expected.toLowerCase())
          if (!hasExpected) {
            issues.push({ type: 'terminology', severity: 'low', description: `Term "${term}" used but expected translation "${expected}" not found` })
          }
        }
      }
    }

    // 2. Style check — detect mixing formal/informal
    const informalMarkers = /\b(tío|chico|cosa|rollo)\b/gi
    const formalMarkers = /\b(por lo tanto|en consecuencia|asimismo)\b/gi
    const hasInformal = informalMarkers.test(input.content)
    const hasFormal = formalMarkers.test(input.content)
    if (hasInformal && hasFormal) {
      issues.push({ type: 'style', severity: 'medium', description: 'Mixed formal and informal register detected' })
    }

    // 3. Definitions check — look for "X is defined as" patterns
    const defMatches = input.content.matchAll(/(\w[\w\s]+) (?:is|is defined as|means|refers to)\s/gi)
    const defined: string[] = []
    for (const m of defMatches) {
      defined.push(m[1].trim().toLowerCase())
    }
    const uniqueDefs = new Set(defined)
    if (defined.length !== uniqueDefs.size) {
      issues.push({ type: 'definition', severity: 'low', description: 'Some terms defined multiple times with potentially different definitions' })
    }

    // 4. References check — "see Module N" where N > actual modules
    const moduleRefs = input.content.matchAll(/(?:see|see Module|Module)\s+(\d+)/gi)
    const referencedModules = new Set<number>()
    for (const m of moduleRefs) {
      referencedModules.add(Number(m[1]))
    }
    const moduleHeaders = input.content.match(/^##\s+Module\s+(\d+)/gim)
    const actualModules = moduleHeaders ? moduleHeaders.length : 0
    for (const ref of referencedModules) {
      if (ref > actualModules && actualModules > 0) {
        issues.push({ type: 'reference', severity: 'high', description: `Reference to Module ${ref} but only ${actualModules} modules exist` })
      }
    }

    // 5. Naming check — inconsistent module naming
    const moduleTitles = input.content.matchAll(/^##\s+(Module\s+\d+|Módulo\s+\d+|Module:\s*)/gim)
    const namingPatterns = new Set<string>()
    for (const m of moduleTitles) {
      namingPatterns.add(m[1].split(/\s+/)[0].toLowerCase())
    }
    if (namingPatterns.size > 1) {
      issues.push({ type: 'naming', severity: 'medium', description: 'Inconsistent module naming patterns detected' })
    }

    // 6. Length check — inconsistent lesson lengths
    const lessons = input.content.split(/^###\s+/m).filter((s) => s.trim().length > 0)
    if (lessons.length > 2) {
      const lengths = lessons.map((l) => l.split(/\s+/).length)
      const avg = lengths.reduce((a, b) => a + b, 0) / lengths.length
      const outliers = lengths.filter((l) => l < avg * 0.3 || l > avg * 3)
      if (outliers.length > 0) {
        issues.push({ type: 'length', severity: 'medium', description: `${outliers.length} lessons have inconsistent lengths compared to average (${Math.round(avg)} words)` })
      }
    }

    // 7. Language check — detect mixing
    const spanishMarkers = /\b(que|de|en|con|por|para|una|el|la|los|las)\b/gi
    const englishMarkers = /\b(the|and|is|are|was|were|with|for|that|this)\b/gi
    const spanishCount = (input.content.match(spanishMarkers) ?? []).length
    const englishCount = (input.content.match(englishMarkers) ?? []).length
    const total = spanishCount + englishCount
    if (total > 50) {
      const spanishRatio = spanishCount / total
      const englishRatio = englishCount / total
      if (spanishRatio > 0.3 && englishRatio > 0.3) {
        issues.push({ type: 'language', severity: 'high', description: `Mixed language detected: ~${Math.round(spanishRatio * 100)}% Spanish, ~${Math.round(englishRatio * 100)}% English` })
      }
    }

    // Score
    const penalty = issues.reduce((sum, i) => sum + (i.severity === 'high' ? 15 : i.severity === 'medium' ? 8 : 3), 0)
    const score = Math.max(0, 100 - penalty)

    if (issues.length === 0) {
      recommendations.push('Content is consistent across all checked dimensions')
    } else {
      if (issues.some((i) => i.type === 'terminology')) recommendations.push('Review terminology to ensure consistent use of translated terms')
      if (issues.some((i) => i.type === 'style')) recommendations.push('Unify the writing register (formal or informal, not both)')
      if (issues.some((i) => i.type === 'reference')) recommendations.push('Fix broken cross-references to non-existent modules')
      if (issues.some((i) => i.type === 'language')) recommendations.push('Ensure content is in a single language')
    }

    return { score, issues, recommendations }
  }
}
