// =============================================================================
// AICF V3 — Service Container (Sprint 16: Dependency Injection)
// =============================================================================
// The SINGLE point of creation and resolution for dependencies.
// No module is allowed to `new` another module directly — everything goes
// through the ServiceContainer.
//
// Usage:
//   const container = new ServiceContainer()
//   container.register('eventBus', new RuntimeEventBus())
//   container.register('logger', logger)
//   container.register('aiAdapter', new RuntimeAdapter())
//
//   // Modules resolve their deps from the container:
//   const eventBus = container.get<RuntimeEventBus>('eventBus')
//
// The ModuleFactory uses the ServiceContainer to resolve dependencies
// when creating modules.
// =============================================================================

import { logger } from '@/lib/ai/logger'

/**
 * A factory function that creates a service instance (used for lazy registration).
 */
export type ServiceFactory<T = unknown> = (container: ServiceContainer) => T

/**
 * A registered service entry.
 */
interface ServiceEntry {
  /** The instance (if eagerly registered). */
  instance: unknown
  /** The factory (if lazily registered). */
  factory: ServiceFactory | null
  /** Whether the service has been resolved (for lazy singletons). */
  resolved: boolean
  /** Whether this is a singleton (default true). */
  singleton: boolean
}

/**
 * A lightweight dependency injection container.
 * Supports:
 *   - Eager registration (instance)
 *   - Lazy registration (factory)
 *   - Singleton resolution
 *   - Dependency resolution by service ID
 *
 * @example
 * const container = new ServiceContainer()
 * container.register('logger', logger)
 * container.register('eventBus', () => new RuntimeEventBus()) // lazy
 * container.registerFactory('aiAdapter', (c) => new RuntimeAdapter(c.get('eventBus')))
 *
 * const logger = container.get<Logger>('logger')
 * const eventBus = container.get<RuntimeEventBus>('eventBus')
 */
export class ServiceContainer {
  private readonly services = new Map<string, ServiceEntry>()

  /**
   * Registers a service instance (eager).
   */
  register<T>(serviceId: string, instance: T): void {
    this.services.set(serviceId, {
      instance,
      factory: null,
      resolved: true,
      singleton: true,
    })
    logger.debug({ serviceId, type: 'eager' }, 'ServiceContainer: service registered')
  }

  /**
   * Registers a service factory (lazy — created on first get()).
   */
  registerFactory<T>(serviceId: string, factory: ServiceFactory<T>, singleton = true): void {
    this.services.set(serviceId, {
      instance: null,
      factory: factory as ServiceFactory,
      resolved: false,
      singleton,
    })
    logger.debug({ serviceId, type: 'lazy', singleton }, 'ServiceContainer: service factory registered')
  }

  /**
   * Resolves a service by ID. Throws if not registered.
   */
  get<T>(serviceId: string): T {
    const entry = this.services.get(serviceId)
    if (!entry) {
      throw new Error(`ServiceContainer: service '${serviceId}' is not registered`)
    }

    if (entry.singleton) {
      if (!entry.resolved && entry.factory) {
        entry.instance = entry.factory(this)
        entry.resolved = true
        logger.debug({ serviceId }, 'ServiceContainer: service resolved (lazy singleton)')
      }
      return entry.instance as T
    }

    // Non-singleton — always create a new instance via factory
    if (entry.factory) {
      return entry.factory(this) as T
    }

    return entry.instance as T
  }

  /**
   * Returns true if a service is registered.
   */
  has(serviceId: string): boolean {
    return this.services.has(serviceId)
  }

  /**
   * Resolves all dependencies for a module by service ID.
   * Returns a bag of { serviceId → instance }.
   *
   * @example
   * const deps = container.resolveDependencies(['eventBus', 'logger', 'aiAdapter'])
   * // deps = { eventBus: ..., logger: ..., aiAdapter: ... }
   */
  resolveDependencies(serviceIds: string[]): Record<string, unknown> {
    const result: Record<string, unknown> = {}
    for (const id of serviceIds) {
      if (this.has(id)) {
        result[id] = this.get(id)
      }
    }
    return result
  }

  /**
   * Lists all registered service IDs.
   */
  list(): string[] {
    return Array.from(this.services.keys())
  }

  /**
   * Clears all registered services (for tests).
   */
  clear(): void {
    this.services.clear()
  }
}
