// =============================================================================
// AICF V3 — Business Registry Barrel (Épica 2 — AI Factory Core, B5 + B6)
// =============================================================================
// Re-exports the two Business-layer registries:
//   - BusinessModuleRegistry      (B5: indexes BusinessModuleBase instances)
//   - BusinessCapabilityRegistry  (B6: indexes Capability descriptors)
//
// Both are in-memory + per-instance (no global singletons).
// =============================================================================

export { BusinessModuleRegistry } from './BusinessModuleRegistry'
export { BusinessCapabilityRegistry } from './CapabilityRegistry'
