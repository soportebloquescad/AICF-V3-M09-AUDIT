// =============================================================================
// AICF V3 — M08 Content Intelligence — DecisionPlan Contract
// =============================================================================
// The decision plan is the immutable output of the ContentIntelligenceEngine.
// It captures every choice made by the 9-stage pipeline (provider, model,
// temperature, cache policy, retry policy, fallback strategy, audit trail).
//
// Downstream stages (PromptBuilder, ExecutionStage, AuditStage) read from the
// DecisionPlan — they never re-derive these values. This keeps routing,
// policy, and budget decisions centralized in one auditable artifact.
// =============================================================================

/**
 * Priority of a decision. Higher priority requests are routed to faster
 * providers; lower priority requests can use cheaper / background providers.
 */
export type DecisionPriority = 'critical' | 'high' | 'normal' | 'low' | 'background'

/**
 * Cache policy attached to every decision. The execution layer consults
 * these fields to decide whether to read from / write to the prompt cache.
 */
export interface CachePolicy {
  /** Whether to consult the cache before executing. */
  checkCache: boolean
  /** Whether to store the result in the cache after executing. */
  setCache: boolean
  /** Time-to-live for cached entries, in seconds. */
  ttlSeconds: number
  /** Cache namespace (used to partition the cache by tenant / product). */
  namespace: string
}

/**
 * Retry policy for the execution layer. Defines how many attempts to make
 * and how to back off between them.
 */
export interface RetryPolicy {
  /** Maximum number of attempts (including the first). */
  maxAttempts: number
  /** Base delay between attempts, in milliseconds. */
  baseDelayMs: number
  /** Multiplier applied to the delay after each attempt (exponential backoff). */
  backoffMultiplier: number
  /** Whether to retry against the same provider or switch on each retry. */
  retrySameProvider: boolean
}

/**
 * Fallback strategy used when the primary provider fails or is unavailable.
 */
export interface FallbackStrategy {
  /** Whether fallback is enabled. */
  enabled: boolean
  /** Fallback provider name. */
  provider: string
  /** Fallback model id. */
  model: string
  /** Trigger condition: 'error' | 'timeout' | 'unavailable' | 'always'. */
  triggerOn: 'error' | 'timeout' | 'unavailable' | 'always'
}

/**
 * Audit trail attached to every decision. Records the inputs and reasoning
 * used by each pipeline stage so the decision can be reconstructed later.
 */
export interface DecisionAudit {
  /** The policy mode that was applied (fast / balanced / premium / ...). */
  policyMode: string
  /** The detected request intent. */
  intent: string
  /** Human-readable reason for the provider choice. */
  providerReason: string
  /** Human-readable reason for the model choice. */
  modelReason: string
  /** Estimated cost in USD for the request (input + output). */
  estimatedCost: number
  /** Estimated total token consumption (input + output). */
  estimatedTokens: number
  /** ISO timestamp when the decision was made. */
  timestamp: string
  /** Per-stage execution records (stage name -> duration / notes). */
  stages: Array<{ stage: string; durationMs: number; notes?: string }>
}

/**
 * The DecisionPlan — the immutable output of the ContentIntelligenceEngine.
 * Every downstream stage reads routing, policy, and budget decisions from here.
 */
export interface DecisionPlan {
  /** Request ID this plan was generated for. */
  requestId: string
  /** Correlation ID for distributed tracing. */
  correlationId: string
  /** Selected provider name (e.g. 'groq', 'gemini', 'openrouter', 'litellm'). */
  provider: string
  /** Selected model id (e.g. 'groq-llama-3.3-70b'). */
  model: string
  /** Sampling temperature to use. */
  temperature: number
  /** Nucleus sampling probability (top-p). */
  topP: number
  /** Maximum output tokens to generate. */
  maxTokens: number
  /** Stop sequences (optional). */
  stop: string[]
  /** Priority of the request. */
  priority: DecisionPriority
  /** Cache policy applied to this decision. */
  cachePolicy: CachePolicy
  /** Retry policy applied to this decision. */
  retryPolicy: RetryPolicy
  /** Fallback strategy if the primary provider fails. */
  fallbackStrategy: FallbackStrategy
  /** Audit trail explaining the decision. */
  audit: DecisionAudit
}

/**
 * Default cache policy used when none is provided.
 */
export const DEFAULT_CACHE_POLICY: CachePolicy = {
  checkCache: true,
  setCache: true,
  ttlSeconds: 300,
  namespace: 'default',
}

/**
 * Default retry policy used when none is provided.
 */
export const DEFAULT_RETRY_POLICY: RetryPolicy = {
  maxAttempts: 3,
  baseDelayMs: 500,
  backoffMultiplier: 2,
  retrySameProvider: true,
}

/**
 * Default fallback strategy (disabled by default — providers handle their
 * own internal retries).
 */
export const DEFAULT_FALLBACK_STRATEGY: FallbackStrategy = {
  enabled: false,
  provider: 'litellm',
  model: 'litellm-auto',
  triggerOn: 'error',
}

/**
 * Factory: creates a DecisionPlan with sensible defaults.
 *
 * Defaults:
 *   - temperature: 0.7
 *   - topP: 1
 *   - maxTokens: 4096
 *   - priority: 'normal'
 *   - stop: []
 *   - cachePolicy: DEFAULT_CACHE_POLICY
 *   - retryPolicy: DEFAULT_RETRY_POLICY
 *   - fallbackStrategy: DEFAULT_FALLBACK_STRATEGY
 */
export function createDecisionPlan(
  overrides: Partial<DecisionPlan> & Pick<DecisionPlan, 'requestId' | 'correlationId' | 'provider' | 'model'>,
): DecisionPlan {
  return {
    temperature: 0.7,
    topP: 1,
    maxTokens: 4096,
    stop: [],
    priority: 'normal',
    cachePolicy: { ...DEFAULT_CACHE_POLICY },
    retryPolicy: { ...DEFAULT_RETRY_POLICY },
    fallbackStrategy: { ...DEFAULT_FALLBACK_STRATEGY },
    audit: {
      policyMode: 'balanced',
      intent: 'unknown',
      providerReason: 'default',
      modelReason: 'default',
      estimatedCost: 0,
      estimatedTokens: 0,
      timestamp: new Date().toISOString(),
      stages: [],
    },
    ...overrides,
  }
}
