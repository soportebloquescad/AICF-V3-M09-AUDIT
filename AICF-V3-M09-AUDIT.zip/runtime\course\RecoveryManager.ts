// =============================================================================
// AICF V3 — Epica 8 — Recovery Manager
// =============================================================================
// Manages course-level checkpoints for resume/retry operations. Complements
// the RecoverySystem (which handles per-operation retry/fallback) by
// providing coarse-grained course-level state persistence.
// =============================================================================
import type { CourseResult, StageResult } from './CourseContracts'
import { auditTrail } from './AuditTrail'
import { recoverySystem, type RecoveryConfig } from './RecoverySystem'
import { logger } from '@/lib/ai/logger'

export interface CourseCheckpoint {
  checkpointId: string
  courseId: string
  correlationId: string
  stage: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  stagesCompleted: string[]
  stagesRemaining: string[]
  savedAt: string
  payload: {
    partialResult: CourseResult | null
    stageResults: StageResult[]
  }
}

export interface RetryStageResult {
  success: boolean
  stage: string
  attempts: number
  message: string
  checkpointId?: string
}

export interface ResumeResult {
  success: boolean
  courseId: string
  resumedFrom: string | null
  stagesRemaining: string[]
  message: string
}

class RecoveryManagerImpl {
  private readonly checkpoints = new Map<string, CourseCheckpoint>()
  private readonly courseLatest = new Map<string, string>()

  saveCheckpoint(input: {
    courseId: string
    correlationId: string
    stage: string
    status: CourseCheckpoint['status']
    stagesCompleted: string[]
    stagesRemaining: string[]
    partialResult: CourseResult | null
    stageResults: StageResult[]
  }): CourseCheckpoint {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    const checkpointId = `cp-${ts}-${rand}`
    const checkpoint: CourseCheckpoint = {
      checkpointId,
      courseId: input.courseId,
      correlationId: input.correlationId,
      stage: input.stage,
      status: input.status,
      stagesCompleted: [...input.stagesCompleted],
      stagesRemaining: [...input.stagesRemaining],
      savedAt: new Date().toISOString(),
      payload: {
        partialResult: input.partialResult,
        stageResults: [...input.stageResults],
      },
    }
    this.checkpoints.set(checkpointId, checkpoint)
    this.courseLatest.set(input.courseId, checkpointId)

    auditTrail.record({
      correlationId: input.correlationId,
      courseId: input.courseId,
      stage: input.stage,
      action: 'recovery.checkpoint',
      actor: 'recovery-manager',
      detail: `Checkpoint saved at stage ${input.stage} (${input.status})`,
    })
    logger.info({ checkpointId, courseId: input.courseId, stage: input.stage }, 'RecoveryManager: checkpoint saved')
    return checkpoint
  }

  loadCheckpoint(checkpointId: string): CourseCheckpoint | null {
    return this.checkpoints.get(checkpointId) ?? null
  }

  getLatestCheckpoint(courseId: string): CourseCheckpoint | null {
    const cpId = this.courseLatest.get(courseId)
    if (!cpId) return null
    return this.checkpoints.get(cpId) ?? null
  }

  listCheckpoints(courseId: string): CourseCheckpoint[] {
    return Array.from(this.checkpoints.values())
      .filter((c) => c.courseId === courseId)
      .sort((a, b) => a.savedAt.localeCompare(b.savedAt))
  }

  resume(courseId: string): ResumeResult {
    const checkpoint = this.getLatestCheckpoint(courseId)
    if (!checkpoint) {
      return { success: false, courseId, resumedFrom: null, stagesRemaining: [], message: `No checkpoint found for course ${courseId}` }
    }
    if (checkpoint.status === 'completed') {
      return { success: true, courseId, resumedFrom: checkpoint.stage, stagesRemaining: [], message: `Course already completed at stage ${checkpoint.stage}` }
    }
    auditTrail.record({
      correlationId: checkpoint.correlationId,
      courseId,
      stage: checkpoint.stage,
      action: 'recovery.resume',
      actor: 'recovery-manager',
      detail: `Resuming from stage ${checkpoint.stage} with ${checkpoint.stagesRemaining.length} stages remaining`,
    })
    return {
      success: true,
      courseId,
      resumedFrom: checkpoint.stage,
      stagesRemaining: checkpoint.stagesRemaining,
      message: `Resuming from stage ${checkpoint.stage}; ${checkpoint.stagesRemaining.length} stages remaining`,
    }
  }

  async retryStage(
    courseId: string,
    stage: string,
    operation: () => Promise<unknown>,
    config: Partial<RecoveryConfig> = {},
  ): Promise<RetryStageResult> {
    const checkpoint = this.getLatestCheckpoint(courseId)
    if (!checkpoint) {
      return { success: false, stage, attempts: 0, message: `No checkpoint found for course ${courseId}` }
    }
    const result = await recoverySystem.withRetry(operation, config)
    auditTrail.record({
      correlationId: checkpoint.correlationId,
      courseId,
      stage,
      action: 'stage.retry',
      actor: 'recovery-manager',
      detail: result.success
        ? `Stage ${stage} succeeded after ${result.attempts} attempts`
        : `Stage ${stage} failed after ${result.attempts} attempts: ${result.lastError ?? 'unknown error'}`,
      severity: result.success ? 'info' : 'error',
    })
    return {
      success: result.success,
      stage,
      attempts: result.attempts,
      message: result.success
        ? `Stage ${stage} succeeded after ${result.attempts} attempts`
        : `Stage ${stage} failed after ${result.attempts} attempts: ${result.lastError ?? 'unknown error'}`,
      checkpointId: checkpoint.checkpointId,
    }
  }

  rollbackTo(courseId: string, stage: string): CourseCheckpoint | null {
    const all = this.listCheckpoints(courseId)
    const target = all.filter((c) => c.stage === stage).pop() ?? null
    if (!target) return null
    // Drop all checkpoints after the target
    const targetIdx = all.indexOf(target)
    for (let i = targetIdx + 1; i < all.length; i++) {
      this.checkpoints.delete(all[i]!.checkpointId)
    }
    this.courseLatest.set(courseId, target.checkpointId)
    auditTrail.record({
      correlationId: target.correlationId,
      courseId,
      stage,
      action: 'recovery.resume',
      actor: 'recovery-manager',
      detail: `Rolled back to stage ${stage}`,
    })
    return target
  }

  clear(courseId?: string): void {
    if (courseId) {
      const cps = this.listCheckpoints(courseId)
      for (const cp of cps) {
        this.checkpoints.delete(cp.checkpointId)
      }
      this.courseLatest.delete(courseId)
    } else {
      this.checkpoints.clear()
      this.courseLatest.clear()
    }
  }

  size(): number {
    return this.checkpoints.size
  }
}

export const recoveryManager = new RecoveryManagerImpl()
