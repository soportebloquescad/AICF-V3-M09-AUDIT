// =============================================================================
// AICF V3 — Sprint 8 RC54 — AssessmentEnginePro
// =============================================================================
// Extends existing AssessmentEngine with certificate generation.
// REUSES: AssessmentEngine (existing), CourseResult, QualityReport.
// =============================================================================

import type { CourseResult } from '../course/CourseContracts'
import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import { AssessmentEngine } from '../assessment/AssessmentEngine'
import type { PremiumAssessment } from '../assessment/AssessmentEngine'
import { logger } from '@/lib/ai/logger'

export interface CertificateData {
  id: string
  courseTitle: string
  studentName: string
  completionDate: string
  score: number
  provider: string
  model: string
  certificateHtml: string
}

export interface AssessmentProResult extends PremiumAssessment {
  certificate: CertificateData
  formativeQuizzes: number
  summativeExam: boolean
  finalProject: { title: string; description: string; deliverables: string[]; rubricCriteria: string[] }
}

export class AssessmentEnginePro {
  private readonly base: AssessmentEngine
  private readonly log = logger.child({ component: 'AssessmentEnginePro' })

  constructor() {
    this.base = new AssessmentEngine()
  }

  generate(course: CourseResult, studentNameOrTheme?: string | ThemePreset, maybeStudentName?: string): AssessmentProResult {
    // Backward-compatible overload: generate(course, studentName?) OR
    // generate(course, theme, studentName?). When a ThemePreset is passed as
    // the second argument, the certificate uses the theme's CSS variables.
    let studentName = 'Course Graduate'
    let theme: ThemePreset | undefined
    if (typeof studentNameOrTheme === 'string') {
      studentName = studentNameOrTheme
    } else if (studentNameOrTheme && typeof studentNameOrTheme === 'object') {
      theme = studentNameOrTheme
      if (typeof maybeStudentName === 'string') studentName = maybeStudentName
    }
    this.log.info({ courseId: course.id, theme: theme?.name ?? 'default' }, 'AssessmentEnginePro: generating')

    const baseResult = this.base.generate(course)
    const certificate = this.generateCertificate(course, studentName, theme)
    const finalProject = this.generateFinalProject(course)

    return {
      ...baseResult,
      certificate,
      formativeQuizzes: course.quizzes.length,
      summativeExam: true,
      finalProject,
    }
  }

  private generateCertificate(course: CourseResult, studentName: string, theme?: ThemePreset): CertificateData {
    const score = course.qualityReport?.overallScore ?? 0
    const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
    const themeCss = theme ? getThemeEngine().renderBaseCss(theme) : `
    body { margin: 0; padding: 2rem; font-family: Georgia, 'Times New Roman', serif; background: #f8fafc; }
    `

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Certificate of Completion — ${course.title}</title>
  <style>
    ${themeCss}
    .cert { max-width: 800px; margin: 0 auto; background: var(--color-surface, white); border: 8px double var(--color-primary, #2563eb); padding: 3rem; text-align: center; position: relative; }
    .cert::before { content: '🏆'; font-size: 4rem; position: absolute; top: 1rem; left: 50%; transform: translateX(-50%); }
    .cert h1 { color: var(--color-primary, #2563eb); font-size: 2rem; margin-top: 3rem; }
    .cert .student { font-size: 1.8rem; font-weight: bold; margin: 1rem 0; color: var(--color-text, #1e293b); border-bottom: 2px solid var(--color-primary, #2563eb); display: inline-block; padding: 0 2rem 0.5rem; }
    .cert .course { font-size: 1.3rem; color: var(--color-text-muted, #475569); margin: 1rem 0; }
    .cert .meta { font-size: 0.9rem; color: var(--color-text-muted, #94a3b8); margin-top: 2rem; }
    .cert .score { font-size: 1.1rem; color: var(--color-success, #16a34a); font-weight: bold; }
    .cert .seal { position: absolute; bottom: 1rem; right: 1rem; width: 80px; height: 80px; border: 3px solid var(--color-primary, #2563eb); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; color: var(--color-primary, #2563eb); font-weight: bold; text-align: center; }
  </style>
</head>
<body>
  <div class="cert">
    <h1>Certificate of Completion</h1>
    <p>This certifies that</p>
    <div class="student">${studentName}</div>
    <p>has successfully completed</p>
    <div class="course">${course.title}</div>
    <p>with a quality score of</p>
    <div class="score">${score}/100</div>
    <div class="meta">
      Completed: ${date}<br>
      Provider: ${course.provider} | Model: ${course.model}<br>
      Certificate ID: cert-${course.id}
    </div>
    <div class="seal">AICF V3<br>Certified</div>
  </div>
</body>
</html>`

    return {
      id: `cert-${course.id}`,
      courseTitle: course.title,
      studentName,
      completionDate: date,
      score,
      provider: course.provider,
      model: course.model,
      certificateHtml: html,
    }
  }

  private generateFinalProject(course: CourseResult): { title: string; description: string; deliverables: string[]; rubricCriteria: string[] } {
    return {
      title: `Final Project: Apply ${course.topic}`,
      description: `Create a comprehensive project demonstrating mastery of ${course.topic}. Integrate concepts from all ${course.modules.length} modules into a real-world application or analysis.`,
      deliverables: [
        'Project report (1000+ words) with problem statement, approach, and results',
        'Presentation deck (10-15 slides) summarizing key findings',
        'Working prototype, demo, or detailed analysis document',
        'Self-reflection document (300+ words) on learning journey',
      ],
      rubricCriteria: [
        'Content accuracy and depth (25%)',
        'Application of course concepts (25%)',
        'Creativity and originality (20%)',
        'Presentation quality (15%)',
        'Documentation and reflection (15%)',
      ],
    }
  }
}
