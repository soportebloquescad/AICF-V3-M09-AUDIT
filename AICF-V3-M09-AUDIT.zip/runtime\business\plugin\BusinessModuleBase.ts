// =============================================================================
// AICF V3 — Business Module Base (Épica 2 — AI Factory Core)
// =============================================================================
// Abstract base class that every Business-layer module extends. It implements
// the full RuntimeModule lifecycle (initialize / isReady / getStatus / health
// / dispose / shutdown / getMetrics) plus a `markUsed()` + `recordError()`
// helper pair that subclasses call inside `executeJob()`.
//
// Subclasses only need to implement:
//   - readonly name + version
//   - getMetadata(): PluginMetadata
//   - getCapabilities(): Capability[]
//   - executeJob(jobType, input, ctx): Promise<ExecutionResult>
//
// Everything else (lifecycle bookkeeping, metrics counters, health reports)
// is handled here so module authors don't reinvent it per module.
//
// No `any`. `unknown` is used for the recordError() parameter type.
// =============================================================================

import type {
  RuntimeModule,
  RuntimeStatus,
  ModuleHealth,
  ModuleMetrics,
} from '@/lib/runtime/contracts/RuntimeModule'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import type { Capability } from '../contracts/Capability'
import type { ExecutionResult } from '../contracts/ExecutionResult'
import type { BusinessContext } from '../contracts/BusinessContext'

/**
 * Abstract base class for every Business-layer module.
 *
 * Subclasses MUST implement `name`, `version`, `getMetadata()`,
 * `getCapabilities()`, and `executeJob()`. Everything else is provided.
 */
export abstract class BusinessModuleBase implements RuntimeModule {
  abstract readonly name: string
  abstract readonly version: string

  /** True once initialize() has run; flipped back to false on dispose(). */
  protected initialized = false
  /** True once dispose() or shutdown() has run. */
  protected disposed = false

  private startupTime = ''
  private lastInitialization = ''
  private lastError: string | null = null
  private initLatencyMs = 0

  /** Cumulative operation count since startup. Incremented by markUsed(). */
  protected operationCount = 0
  /** Cumulative error count since startup. Incremented by recordError(). */
  protected errorCount = 0
  /** ISO timestamp of the last markUsed() call, or null if never used. */
  protected lastUsed: string | null = null

  // ---------------------------------------------------------------------------
  // Abstract surface — subclasses implement these.
  // ---------------------------------------------------------------------------

  /** Returns the module's plugin metadata. */
  abstract getMetadata(): PluginMetadata

  /** Returns the capabilities this module exposes. */
  abstract getCapabilities(): Capability[]

  /**
   * Executes a single job. Subclasses MUST NOT throw — they should catch
   * internal errors and return `createFailedResult(err.message)` instead.
   * The registry trusts this contract.
   */
  abstract executeJob(
    jobType: string,
    input: Record<string, unknown>,
    ctx: BusinessContext,
  ): Promise<ExecutionResult>

  // ---------------------------------------------------------------------------
  // Lifecycle — provided by the base class.
  // ---------------------------------------------------------------------------

  /**
   * Initializes the module. Idempotent — second call is a no-op. Records
   * startup time + initialization latency for health/metrics.
   */
  async initialize(): Promise<void> {
    if (this.initialized) return
    const start = Date.now()
    this.startupTime = new Date().toISOString()
    this.lastInitialization = this.startupTime
    this.initialized = true
    this.initLatencyMs = Date.now() - start
  }

  /** True iff the module has been initialized and not yet disposed. */
  isReady(): boolean {
    return this.initialized && !this.disposed
  }

  /** Returns the runtime status (used by ModuleRegistry.getStatus()). */
  getStatus(): RuntimeStatus {
    return {
      name: this.name,
      ready: this.isReady(),
      version: this.version,
      details: {
        implemented: true,
        capabilities: this.getCapabilities().map((c) => c.name),
      },
    }
  }

  /** Returns a structured health report. */
  async health(): Promise<ModuleHealth> {
    return {
      ready: this.isReady(),
      status: this.disposed ? 'unhealthy' : this.initialized ? 'healthy' : 'degraded',
      startupTime: this.startupTime,
      dependencies: [],
      version: this.version,
      lastInitialization: this.lastInitialization,
      lastError: this.lastError || undefined,
      metrics: this.getMetrics(),
    }
  }

  /** Returns the per-module metrics snapshot. */
  getMetrics(): ModuleMetrics {
    return {
      initLatencyMs: this.initLatencyMs,
      errorCount: this.errorCount,
      lastUsed: this.lastUsed,
      lastError: this.lastError,
      operationCount: this.operationCount,
    }
  }

  /** Releases resources. Idempotent. */
  async dispose(): Promise<void> {
    this.disposed = true
  }

  /** Graceful shutdown. Idempotent. Mirrors dispose() in the base class. */
  async shutdown(): Promise<void> {
    this.disposed = true
  }

  // ---------------------------------------------------------------------------
  // Protected helpers — used by subclasses inside executeJob().
  // ---------------------------------------------------------------------------

  /**
   * Increments the operation count + records the last-used timestamp.
   * Subclasses should call this at the entry of executeJob() (before any
   * work begins) so metrics reflect every attempt, successful or not.
   */
  protected markUsed(): void {
    this.operationCount += 1
    this.lastUsed = new Date().toISOString()
  }

  /**
   * Records an error: increments the error count + captures the message.
   * Subclasses should call this in their executeJob() catch block.
   */
  protected recordError(err: unknown): void {
    this.errorCount += 1
    this.lastError = err instanceof Error ? err.message : String(err)
  }
}
