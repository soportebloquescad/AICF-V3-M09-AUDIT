// =============================================================================
// AICF V3 — Assessment Writer Agent
// =============================================================================
// Writes multiple-choice quiz questions that assess the learning
// objectives. Reads `context.lessons` (and optionally `context.design`
// for Bloom alignment) to scope the assessment. Produces 5-10 questions
// per call, each with four options, the correct index, and an
// explanation.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, readContext } from './agentUtils'

export interface AssessmentWriterDeps {
  aiAdapter: AIAdapter | null
}

interface AssessmentItem {
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

interface AssessmentsPayload {
  assessments: AssessmentItem[]
}

interface LessonShape {
  title: string
  content?: string
}

export class AssessmentWriter implements Agent {
  public readonly name = 'assessment-writer'

  constructor(private readonly deps: AssessmentWriterDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const lessons = collectLessons(input)
      const targetCount = clampCount(lessons.length * 2, 5, 10)
      const ai = this.deps.aiAdapter
      const aiResult = await callAI(ai, buildPrompt(input, lessons, targetCount), {
        systemPrompt:
          'You are an assessment designer. Respond with valid JSON only.',
        temperature: 0.4,
        maxTokens: 2200,
      })

      let assessments: AssessmentItem[]
      if (aiResult.ok && aiResult.content) {
        const parsed = extractJSON<{ assessments?: unknown[] }>(aiResult.content)
        assessments = coerceAssessments(parsed)
        if (assessments.length === 0) {
          assessments = fallbackAssessments(input, lessons, targetCount)
        }
      } else {
        assessments = fallbackAssessments(input, lessons, targetCount)
      }

      return {
        agentName: this.name,
        result: { assessments },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function collectLessons(input: AgentInput): LessonShape[] {
  const lessons = readContext<LessonShape[]>(input.context, 'lessons')
  if (Array.isArray(lessons) && lessons.length > 0) {
    return lessons.filter((l) => l && typeof l.title === 'string').slice(0, 12)
  }
  return [{ title: `${input.topic} - Foundations` }]
}

function clampCount(value: number, min: number, max: number): number {
  if (Number.isNaN(value)) return min
  return Math.max(min, Math.min(max, value))
}

function buildPrompt(input: AgentInput, lessons: LessonShape[], targetCount: number): string {
  const titles = lessons.map((l) => `- ${l.title}`).join('\n')
  return [
    `Write ${targetCount} multiple-choice assessment items for the course on "${input.topic}".`,
    `Audience: ${input.audience}. Level: ${input.level}. Locale: ${input.locale}.`,
    `Cover these lessons:`,
    titles,
    ``,
    `Return JSON with this exact shape:`,
    `{`,
    `  "assessments": [`,
    `    {`,
    `      "question": string,`,
    `      "options": [string, string, string, string],   // exactly 4 options`,
    `      "correctIndex": number,                         // 0-3`,
    `      "explanation": string`,
    `    }`,
    `  ]`,
    `}`,
  ].join('\n')
}

function coerceAssessments(parsed: { assessments?: unknown[] } | null): AssessmentItem[] {
  if (!parsed || !Array.isArray(parsed.assessments)) return []
  const out: AssessmentItem[] = []
  for (const raw of parsed.assessments) {
    if (!raw || typeof raw !== 'object') continue
    const r = raw as Record<string, unknown>
    const question = r.question
    const options = r.options
    const correctIndex = r.correctIndex
    const explanation = r.explanation
    if (
      typeof question === 'string' &&
      question.length > 0 &&
      Array.isArray(options) &&
      options.length === 4 &&
      options.every((o) => typeof o === 'string' && o.length > 0) &&
      typeof correctIndex === 'number' &&
      Number.isInteger(correctIndex) &&
      correctIndex >= 0 &&
      correctIndex < 4 &&
      typeof explanation === 'string' &&
      explanation.length > 0
    ) {
      out.push({
        question,
        options: options as string[],
        correctIndex,
        explanation,
      })
    }
  }
  return out
}

function fallbackAssessments(
  input: AgentInput,
  lessons: LessonShape[],
  targetCount: number,
): AssessmentItem[] {
  const topic = input.topic
  const items: AssessmentItem[] = []
  const pool = lessons.length > 0 ? lessons : [{ title: topic }]
  let i = 0
  while (items.length < targetCount) {
    const lesson = pool[i % pool.length]
    items.push(buildItem(topic, lesson.title, items.length))
    i += 1
  }
  return items
}

function buildItem(topic: string, lessonTitle: string, ordinal: number): AssessmentItem {
  // Four parallel item templates so the fallback produces variety.
  switch (ordinal % 4) {
    case 0:
      return {
        question: `Which statement best describes the central concept of "${lessonTitle}" within ${topic}?`,
        options: [
          `A foundational concept that combines a clear definition with applied techniques.`,
          `An unrelated tangent with no connection to ${topic}.`,
          `A purely historical note with no current relevance.`,
          `A typo in the lesson title.`,
        ],
        correctIndex: 0,
        explanation: `The central concept is a foundational element that combines definition and application. The other options are distractors with no pedagogical basis.`,
      }
    case 1:
      return {
        question: `When applying the ideas from "${lessonTitle}", what is the recommended first step?`,
        options: [
          `Skip directly to the final answer without analysis.`,
          `Identify the relevant inputs and select the appropriate technique.`,
          `Ignore constraints and proceed regardless of context.`,
          `Memorize the lesson without understanding.`,
        ],
        correctIndex: 1,
        explanation: `Structured analysis begins by identifying inputs and selecting the technique. Skipping analysis leads to errors and poor transfer.`,
      }
    case 2:
      return {
        question: `Which of the following is a common pitfall when working with "${lessonTitle}"?`,
        options: [
          `Validating results against expected outcomes.`,
          `Documenting assumptions before applying a technique.`,
          `Treating related but distinct concepts as interchangeable.`,
          `Reviewing worked examples before practicing.`,
        ],
        correctIndex: 2,
        explanation: `Confusing related concepts is a frequent source of error. The other options are good practices, not pitfalls.`,
      }
    default:
      return {
        question: `How does "${lessonTitle}" relate to the broader study of ${topic}?`,
        options: [
          `It is entirely isolated from the rest of ${topic}.`,
          `It is a foundational element that connects to adjacent topics within ${topic}.`,
          `It replaces all prior material in the course.`,
          `It is only relevant for advanced researchers, not practitioners.`,
        ],
        correctIndex: 1,
        explanation: `Each lesson is a foundational element that connects to adjacent topics. This integration is what builds competence over time.`,
      }
  }
}
