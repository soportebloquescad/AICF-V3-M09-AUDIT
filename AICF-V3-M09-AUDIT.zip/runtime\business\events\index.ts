// =============================================================================
// AICF V3 — Business Events Barrel (Épica 2 — AI Factory Core)
// =============================================================================
// Re-exports the BusinessEvent type + factory.
// =============================================================================

export type { BusinessEvent, BusinessEventType } from './BusinessEvents'
export { createBusinessEvent } from './BusinessEvents'
