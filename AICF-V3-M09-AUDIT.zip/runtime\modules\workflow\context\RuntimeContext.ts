// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Runtime Context Holder
// =============================================================================
// Re-exports `WorkflowContext` from contracts and provides a module-level
// "current context" holder for observability: the logger, metrics
// aggregator, and audit log can read the active execution context without
// having to thread it through every function signature.
//
// Sprint 13+14 spec requirements covered:
//   - Single module-level holder for the *currently executing* workflow
//     context (one per process at a time; concurrent executions set their
//     own context inside `withContext` and restore the previous one on
//     exit)
//   - `withContext` async wrapper: sets the context for the duration of
//     `fn`, restores the previous context (or clears it) on success /
//     error / cancellation — no leak across executions
//
// IMPORTANT: this is a process-local convenience holder, NOT a concurrency
// primitive. If you run multiple executions concurrently in the same
// process, use `withContext` (which saves/restores the previous context)
// rather than calling `setContext` / `clearContext` directly.
// =============================================================================

import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'

// Re-export the contract surface for module-local convenience.
export type {
  WorkflowContext,
  CreateWorkflowContextOptions,
} from '@/lib/runtime/contracts/workflow'
export { createWorkflowContext, updateContextCost } from '@/lib/runtime/contracts/workflow'

/**
 * Module-level holder for the currently-executing workflow context.
 * Backed by a single mutable slot; access is synchronous.
 *
 * The holder is intentionally minimal — it tracks at most one "current"
 * context. Concurrent executions should each wrap their work in
 * `withContext`, which saves and restores the prior context.
 */
export class RuntimeContextHolder {
  private static current: WorkflowContext | null = null

  /** Set the current workflow context. Overwrites any prior context. */
  static setContext(ctx: WorkflowContext): void {
    RuntimeContextHolder.current = ctx
  }

  /** Return the current workflow context, or `null` if none is set. */
  static getContext(): WorkflowContext | null {
    return RuntimeContextHolder.current
  }

  /** Clear the current workflow context. Safe to call when none is set. */
  static clearContext(): void {
    RuntimeContextHolder.current = null
  }

  /**
   * Run `fn` with `ctx` as the current context. The previous context is
   * saved and restored on exit (success, error, or any rejection), so
   * nested `withContext` calls behave like a stack.
   *
   * @param ctx The context to install while `fn` runs.
   * @param fn  The async function to execute under `ctx`.
   * @returns   Whatever `fn` resolves to.
   */
  static async withContext<T>(
    ctx: WorkflowContext,
    fn: () => Promise<T>,
  ): Promise<T> {
    const previous = RuntimeContextHolder.current
    RuntimeContextHolder.current = ctx
    try {
      return await fn()
    } finally {
      RuntimeContextHolder.current = previous
    }
  }
}

/**
 * Module-level convenience: the singleton holder instance. Consumers may
 * import either the class (`RuntimeContextHolder`) or this instance
 * (`runtimeContext`) — both share the same backing slot.
 */
export const runtimeContext = RuntimeContextHolder
