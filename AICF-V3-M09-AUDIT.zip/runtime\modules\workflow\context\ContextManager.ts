// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Context Manager
// =============================================================================
// Builds, mutates, and snapshots `WorkflowContext` instances for workflow
// executions. Wraps the contract factories (`createWorkflowContext`,
// `updateContextCost`) with higher-level operations the orchestrator and
// state store consume:
//
//   - `createContext(opts)`            — fresh context from options
//   - `updateVariables(ctx, newVars)`  — immutable merge of variables
//   - `snapshot(ctx)`                  — serialize for checkpointing
//   - `restore(snapshot)`              — rebuild a context from a snapshot
//
// Sprint 13+14 spec requirements covered:
//   - Context checkpointing for pause / resume / replay
//   - Immutable variable updates (each step sees a new context revision)
//   - Snapshot is JSON-serializable so it can be persisted in a state store
//     without a custom reviver
// =============================================================================

import type {
  WorkflowContext,
  CreateWorkflowContextOptions,
} from '@/lib/runtime/contracts/workflow'
import { createWorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/**
 * Manages the lifecycle of `WorkflowContext` instances for workflow
 * executions. Stateless across executions; safe to call concurrently.
 */
export class ContextManager {
  /**
   * Create a fresh `WorkflowContext` for a new execution. Delegates to the
   * contract `createWorkflowContext` factory.
   */
  createContext(opts: CreateWorkflowContextOptions): WorkflowContext {
    return createWorkflowContext(opts)
  }

  /**
   * Return a NEW context with `newVars` shallow-merged into the existing
   * `variables` bag. The input `ctx` is NOT mutated, so callers can keep
   * an audit trail of every context revision.
   *
   * Values in `newVars` override existing keys with the same name.
   */
  updateVariables(
    ctx: WorkflowContext,
    newVars: Record<string, unknown>,
  ): WorkflowContext {
    return {
      ...ctx,
      variables: { ...ctx.variables, ...newVars },
    }
  }

  /**
   * Serialize a context into a plain JSON-serializable object for
   * checkpointing. The snapshot captures every field of `WorkflowContext`
   * (including the nested `tokens` and `variables` maps).
   *
   * The snapshot shape is intentionally a strict subset / projection of
   * `WorkflowContext` — never contains class instances, functions, or
   * non-enumerable properties.
   */
  snapshot(ctx: WorkflowContext): Record<string, unknown> {
    return {
      correlationId: ctx.correlationId,
      executionId: ctx.executionId,
      locale: ctx.locale,
      cost: ctx.cost,
      tokens: { ...ctx.tokens },
      startedAt: ctx.startedAt,
      variables: this.deepClone(ctx.variables),
      dryRun: ctx.dryRun,
      ...(ctx.userId !== undefined ? { userId: ctx.userId } : {}),
      ...(ctx.workspaceId !== undefined
        ? { workspaceId: ctx.workspaceId }
        : {}),
      ...(ctx.projectId !== undefined ? { projectId: ctx.projectId } : {}),
      ...(ctx.model !== undefined ? { model: ctx.model } : {}),
      ...(ctx.provider !== undefined ? { provider: ctx.provider } : {}),
      ...(ctx.endedAt !== undefined ? { endedAt: ctx.endedAt } : {}),
      ...(ctx.durationMs !== undefined ? { durationMs: ctx.durationMs } : {}),
      ...(ctx.metadata !== undefined
        ? { metadata: this.deepClone(ctx.metadata) }
        : {}),
    }
  }

  /**
   * Rebuild a `WorkflowContext` from a previously-captured snapshot.
   * Performs structural validation: missing required fields are logged
   * and filled with sensible defaults so a corrupt checkpoint never
   * crashes the engine.
   *
   * @param snapshot Output of `snapshot(ctx)` or an equivalent plain object.
   */
  restore(snapshot: Record<string, unknown>): WorkflowContext {
    const s = snapshot as Partial<WorkflowContext> & {
      correlationId?: unknown
      executionId?: unknown
      locale?: unknown
      cost?: unknown
      tokens?: unknown
      startedAt?: unknown
      variables?: unknown
      dryRun?: unknown
    }

    const correlationId =
      typeof s.correlationId === 'string' ? s.correlationId : ''
    const executionId = typeof s.executionId === 'string' ? s.executionId : ''

    if (!correlationId || !executionId) {
      logger.warn(
        { correlationId, executionId },
        'context snapshot is missing required identity fields; restoring with defaults',
      )
    }

    const tokens =
      this.isTokenUsage(s.tokens) && typeof s.tokens === 'object' && s.tokens
        ? {
            promptTokens: s.tokens.promptTokens,
            completionTokens: s.tokens.completionTokens,
            totalTokens: s.tokens.totalTokens,
          }
        : { promptTokens: 0, completionTokens: 0, totalTokens: 0 }

    const ctx: WorkflowContext = {
      correlationId,
      executionId,
      locale: typeof s.locale === 'string' ? s.locale : 'en',
      cost: typeof s.cost === 'number' ? s.cost : 0,
      tokens,
      startedAt: typeof s.startedAt === 'number' ? s.startedAt : Date.now(),
      variables: this.isPlainObject(s.variables) ? { ...s.variables } : {},
      dryRun: typeof s.dryRun === 'boolean' ? s.dryRun : false,
    }

    // Optional fields (restore only if present).
    if (typeof s.userId === 'string') ctx.userId = s.userId
    if (typeof s.workspaceId === 'string') ctx.workspaceId = s.workspaceId
    if (typeof s.projectId === 'string') ctx.projectId = s.projectId
    if (typeof s.model === 'string') ctx.model = s.model
    if (typeof s.provider === 'string') ctx.provider = s.provider
    if (typeof s.endedAt === 'number') ctx.endedAt = s.endedAt
    if (typeof s.durationMs === 'number') ctx.durationMs = s.durationMs
    if (this.isPlainObject(s.metadata)) ctx.metadata = { ...s.metadata }

    return ctx
  }

  /**
   * Deep-clone a JSON-serializable value. Falls back to a shallow clone for
   * non-plain values (class instances). Handles arrays, plain objects, and
   * primitives.
   */
  private deepClone<T>(value: T): T {
    if (value === null || typeof value !== 'object') return value
    if (Array.isArray(value)) {
      return (value as unknown[]).map((v) => this.deepClone(v)) as unknown as T
    }
    if (this.isPlainObject(value)) {
      const out: Record<string, unknown> = {}
      for (const [k, v] of Object.entries(value)) {
        out[k] = this.deepClone(v)
      }
      return out as unknown as T
    }
    // Non-plain object: return as-is (don't try to clone class instances).
    return value
  }

  /** Plain-object guard. */
  private isPlainObject(
    value: unknown,
  ): value is Record<string, unknown> {
    if (typeof value !== 'object' || value === null) return false
    if (Array.isArray(value)) return false
    const proto = Object.getPrototypeOf(value)
    return proto === Object.prototype || proto === null
  }

  /** TokenUsage structural guard. */
  private isTokenUsage(
    value: unknown,
  ): value is { promptTokens: number; completionTokens: number; totalTokens: number } {
    if (typeof value !== 'object' || value === null) return false
    const v = value as Record<string, unknown>
    return (
      typeof v.promptTokens === 'number' &&
      typeof v.completionTokens === 'number' &&
      typeof v.totalTokens === 'number'
    )
  }
}
