// =============================================================================
// AICF V3 — Epica 7 — Recovery System
// =============================================================================
// Retry with exponential backoff, fallback chains, and per-provider
// circuit breakers.
// =============================================================================

import { logger } from '@/lib/ai/logger'

export type RecoveryErrorCode = 'TIMEOUT' | 'RATE_LIMIT' | 'NETWORK' | 'AUTH' | 'MODEL_NOT_FOUND' | 'UNKNOWN'

export interface RecoveryConfig {
  maxRetries: number
  baseDelayMs: number
  maxDelayMs: number
  backoffMultiplier: number
  jitter: boolean
  retryableErrors: RecoveryErrorCode[]
}

export const DEFAULT_RECOVERY_CONFIG: RecoveryConfig = {
  maxRetries: 3,
  baseDelayMs: 500,
  maxDelayMs: 30_000,
  backoffMultiplier: 2,
  jitter: true,
  retryableErrors: ['TIMEOUT', 'RATE_LIMIT', 'NETWORK'],
}

export interface RecoveryResult<T> {
  success: boolean
  value: T | null
  attempts: number
  totalDelayMs: number
  lastError?: string
  providerUsed?: string
  fellBack: boolean
}

export type CircuitState = 'closed' | 'open' | 'half-open'

export interface CircuitBreakerStatus {
  provider: string
  state: CircuitState
  failureCount: number
  lastFailureAt?: string
  openedAt?: string
}

class CircuitBreaker {
  private failureCount = 0
  private state: CircuitState = 'closed'
  private lastFailureAt?: string
  private openedAt?: string
  private readonly failureThreshold: number
  private readonly resetTimeoutMs: number

  constructor(
    private readonly provider: string,
    opts: { failureThreshold: number; resetTimeoutMs: number },
  ) {
    this.failureThreshold = opts.failureThreshold
    this.resetTimeoutMs = opts.resetTimeoutMs
  }

  canExecute(): boolean {
    if (this.state === 'closed') return true
    if (this.state === 'open') {
      if (this.openedAt && Date.now() - new Date(this.openedAt).getTime() > this.resetTimeoutMs) {
        this.state = 'half-open'
        logger.info({ provider: this.provider }, 'CircuitBreaker: open → half-open')
        return true
      }
      return false
    }
    // half-open: allow one trial
    return true
  }

  recordSuccess(): void {
    if (this.state === 'half-open') {
      this.state = 'closed'
      this.failureCount = 0
      this.openedAt = undefined
      logger.info({ provider: this.provider }, 'CircuitBreaker: half-open → closed')
    } else if (this.state === 'closed') {
      this.failureCount = 0
    }
  }

  recordFailure(): void {
    this.failureCount++
    this.lastFailureAt = new Date().toISOString()
    if (this.state === 'half-open') {
      this.state = 'open'
      this.openedAt = new Date().toISOString()
      logger.warn({ provider: this.provider }, 'CircuitBreaker: half-open → open')
    } else if (this.failureCount >= this.failureThreshold) {
      this.state = 'open'
      this.openedAt = new Date().toISOString()
      logger.warn({ provider: this.provider, failures: this.failureCount }, 'CircuitBreaker: closed → open')
    }
  }

  status(): CircuitBreakerStatus {
    return {
      provider: this.provider,
      state: this.state,
      failureCount: this.failureCount,
      lastFailureAt: this.lastFailureAt,
      openedAt: this.openedAt,
    }
  }

  reset(): void {
    this.state = 'closed'
    this.failureCount = 0
    this.lastFailureAt = undefined
    this.openedAt = undefined
  }
}

class RecoverySystemImpl {
  private readonly breakers = new Map<string, CircuitBreaker>()
  private readonly defaultConfig: RecoveryConfig = DEFAULT_RECOVERY_CONFIG

  withRetry<T>(
    operation: () => Promise<T>,
    config: Partial<RecoveryConfig> = {},
  ): Promise<RecoveryResult<T>> {
    const cfg = { ...this.defaultConfig, ...config }
    return this.executeWithRetry(operation, cfg, 0, 0)
  }

  async withFallback<T>(
    primary: { provider: string; operation: () => Promise<T> },
    fallbacks: Array<{ provider: string; operation: () => Promise<T> }>,
    config: Partial<RecoveryConfig> = {},
  ): Promise<RecoveryResult<T>> {
    const cfg = { ...this.defaultConfig, ...config }
    const all = [primary, ...fallbacks]
    let totalDelayMs = 0
    let attempts = 0
    let lastError: string | undefined

    for (const candidate of all) {
      attempts++
      const breaker = this.getOrCreateBreaker(candidate.provider)
      if (!breaker.canExecute()) {
        lastError = `Circuit open for provider ${candidate.provider}`
        continue
      }
      const inner = await this.executeWithRetry(candidate.operation, cfg, 0, 0)
      totalDelayMs += inner.totalDelayMs
      if (inner.success) {
        breaker.recordSuccess()
        return {
          success: true,
          value: inner.value,
          attempts,
          totalDelayMs,
          providerUsed: candidate.provider,
          fellBack: candidate.provider !== primary.provider,
        }
      }
      breaker.recordFailure()
      lastError = inner.lastError
    }
    return {
      success: false,
      value: null,
      attempts,
      totalDelayMs,
      lastError,
      fellBack: false,
    }
  }

  getCircuitStatus(provider: string): CircuitBreakerStatus | null {
    return this.breakers.get(provider)?.status() ?? null
  }

  getAllCircuits(): CircuitBreakerStatus[] {
    return Array.from(this.breakers.values()).map((b) => b.status())
  }

  resetCircuit(provider: string): boolean {
    const breaker = this.breakers.get(provider)
    if (!breaker) return false
    breaker.reset()
    return true
  }

  resetAllCircuits(): void {
    for (const breaker of this.breakers.values()) {
      breaker.reset()
    }
  }

  private async executeWithRetry<T>(
    operation: () => Promise<T>,
    cfg: RecoveryConfig,
    attempt: number,
    totalDelayMs: number,
  ): Promise<RecoveryResult<T>> {
    try {
      const value = await operation()
      return { success: true, value, attempts: attempt + 1, totalDelayMs, fellBack: false }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      const code = this.classifyError(err)
      const isLastAttempt = attempt >= cfg.maxRetries
      const isRetryable = cfg.retryableErrors.includes(code)
      if (isLastAttempt || !isRetryable) {
        return {
          success: false,
          value: null,
          attempts: attempt + 1,
          totalDelayMs,
          lastError: message,
          fellBack: false,
        }
      }
      const delay = this.computeDelay(cfg, attempt)
      logger.warn({ attempt: attempt + 1, delayMs: delay, code }, 'RecoverySystem: retrying after delay')
      await this.sleep(delay)
      return this.executeWithRetry(operation, cfg, attempt + 1, totalDelayMs + delay)
    }
  }

  private computeDelay(cfg: RecoveryConfig, attempt: number): number {
    const base = Math.min(cfg.baseDelayMs * Math.pow(cfg.backoffMultiplier, attempt), cfg.maxDelayMs)
    if (!cfg.jitter) return base
    return Math.round(base * (0.5 + Math.random() * 0.5))
  }

  private classifyError(err: unknown): RecoveryErrorCode {
    if (err && typeof err === 'object' && 'code' in err) {
      const code = (err as { code: unknown }).code
      if (code === 'TIMEOUT' || code === 'RATE_LIMIT' || code === 'NETWORK' || code === 'AUTH' || code === 'MODEL_NOT_FOUND') {
        return code
      }
    }
    const message = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase()
    if (message.includes('timeout') || message.includes('timed out')) return 'TIMEOUT'
    if (message.includes('rate limit') || message.includes('429') || message.includes('too many')) return 'RATE_LIMIT'
    if (message.includes('network') || message.includes('econnreset') || message.includes('enotfound') || message.includes('unreachable')) return 'NETWORK'
    return 'UNKNOWN'
  }

  private getOrCreateBreaker(provider: string): CircuitBreaker {
    let breaker = this.breakers.get(provider)
    if (!breaker) {
      breaker = new CircuitBreaker(provider, { failureThreshold: 5, resetTimeoutMs: 60_000 })
      this.breakers.set(provider, breaker)
    }
    return breaker
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }
}

export const recoverySystem = new RecoverySystemImpl()
export { CircuitBreaker }
