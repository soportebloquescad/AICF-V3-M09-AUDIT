// =============================================================================
// AICF V3 — Presentation Module (Épica 3 — Educational Factory)
// =============================================================================
// Business-layer module that handles presentation / slide-related job types:
//   - createSlides
//   - generateSlides
//   - exportSlides
//   - generatePresentation (alias of createSlides for naming consistency)
//
// Real implementation (no stubs). When an AIAdapter is provided (constructor
// injection — see runtime-singleton.ts) the module prompts the LLM for a
// structured JSON deck and parses it into typed slides. When no adapter is
// available — or the AI call fails — the module falls back to a deterministic
// generator that always produces real, useful content (titles, bullets,
// notes) from the requested topic.
//
// The module also renders slides to a self-contained HTML5 document with
// embedded CSS, keyboard navigation (←/→), a slide counter, and print
// styles — so the output is usable in a browser, in a build pipeline, or
// rendered to PDF by a headless browser.
//
// Strict TypeScript: no `any`. All `unknown` inputs are narrowed with type
// guards before use. No "Not implemented" returns.
// =============================================================================

import { BusinessModuleBase } from '@/lib/runtime/business/plugin/BusinessModuleBase'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { createVersionedContract } from '@/lib/runtime/contracts/VersionedContract'
import type { Capability } from '@/lib/runtime/business/contracts/Capability'
import { createCapability } from '@/lib/runtime/business/contracts/Capability'
import type { ExecutionResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import { createSuccessResult, createFailedResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import type { BusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import { getPromptBuilder } from '@/lib/ai/PromptBuilder'

// ---------------------------------------------------------------------------
// Public types — mirror the existing PresentationSlide contract from
// modules/presentations/interfaces.ts so callers can import from either place.
// ---------------------------------------------------------------------------

/** A single slide. */
export interface Slide {
  /** 1-based position within the deck. */
  index: number
  /** Slide title. */
  title: string
  /** Bullet-point body. */
  bullets: string[]
  /** Optional speaker notes (plain text). */
  notes?: string
}

/** Output shape for createSlides / generateSlides. */
export interface SlideDeck {
  /** Deck title (echoes the topic). */
  title: string
  /** Topic the deck was generated from. */
  topic: string
  /** Visual theme identifier (defaults to 'default'). */
  theme: string
  /** Ordered slides. */
  slides: Slide[]
  /** Markdown source — one section per slide. */
  markdown: string
  /** Standalone HTML5 document with embedded CSS + JS. */
  html: string
}

// ---------------------------------------------------------------------------
// Metadata + capabilities
// ---------------------------------------------------------------------------

export const PRESENTATION_MODULE_METADATA: PluginMetadata = {
  id: 'presentation',
  name: 'Presentation',
  description: 'Slide generation, assembly, and export (createSlides, generateSlides, exportSlides)',
  author: 'AICF V3',
  version: '1.0.0',
  mission: 'presentation',
  priority: 35,
  dependencies: [],
  capabilities: ['createSlides', 'generateSlides', 'exportSlides', 'generatePresentation'],
  contracts: createVersionedContract('1.0.0', 'compatible'),
  events: [
    'presentation.jobStarted',
    'presentation.jobCompleted',
    'presentation.jobFailed',
  ],
}

export const PRESENTATION_CAPABILITIES: Capability[] = [
  createCapability('createSlides', 'Create a new slide deck from a topic + audience'),
  createCapability('generateSlides', 'Generate slide content (titles, bullets, notes)'),
  createCapability('exportSlides', 'Export a slide deck to a target format (pptx, pdf, etc.)'),
  createCapability('generatePresentation', 'Generate a full presentation (alias of createSlides)'),
]

// ---------------------------------------------------------------------------
// Helpers — input narrowing (no `any`)
// ---------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function asNumber(value: unknown, fallback: number, min = 1, max = 50): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), min), max)
}

/**
 * Safely extracts a string array from an `unknown` value (typical AI JSON
 * output). Drops non-string entries; ensures at least one entry so we never
 * hand back an empty bullets array.
 */
function asStringArray(value: unknown, fallback: string[]): string[] {
  if (!Array.isArray(value)) return fallback
  const out = value.filter((v): v is string => typeof v === 'string' && v.trim().length > 0)
  return out.length > 0 ? out : fallback
}

// ---------------------------------------------------------------------------
// Fallback deck generator — deterministic, always produces real content.
// ---------------------------------------------------------------------------

const FALLBACK_SLIDE_TEMPLATES: ReadonlyArray<{ title: (t: string) => string; bullets: (t: string) => string[] }> = [
  {
    title: (t) => `Introduction to ${t}`,
    bullets: (t) => [
      `What ${t} is and why it matters`,
      `Real-world use cases for ${t}`,
      `Who should learn ${t} and the prerequisites`,
      `What you will be able to do after this deck`,
    ],
  },
  {
    title: (t) => `Key Concepts of ${t}`,
    bullets: (t) => [
      `Core terminology used when discussing ${t}`,
      `The mental model behind ${t}`,
      `How ${t} differs from related approaches`,
      `Common misconceptions to avoid`,
    ],
  },
  {
    title: (t) => `Building Blocks of ${t}`,
    bullets: (t) => [
      `The fundamental components that make up ${t}`,
      `How each component contributes to the whole`,
      `Inputs and outputs at every layer`,
      `Where to focus when getting started`,
    ],
  },
  {
    title: (t) => `Working with ${t}`,
    bullets: (t) => [
      `A typical workflow for ${t}`,
      `Tools and libraries you will use`,
      `Step-by-step walkthrough of a minimal example`,
      `Pitfalls and how to avoid them`,
    ],
  },
  {
    title: (t) => `Advanced Topics in ${t}`,
    bullets: (t) => [
      `Going beyond the basics of ${t}`,
      `Performance, scaling, and optimisation`,
      `Integrating ${t} with other systems`,
      `When to reach for advanced techniques`,
    ],
  },
  {
    title: (t) => `Best Practices for ${t}`,
    bullets: (t) => [
      `Idiomatic patterns in ${t}`,
      `Testing and quality assurance`,
      `Documentation and collaboration`,
      `Security considerations specific to ${t}`,
    ],
  },
  {
    title: (t) => `Case Studies: ${t} in Production`,
    bullets: (t) => [
      `How teams have shipped ${t} at scale`,
      `Lessons learned from real rollouts`,
      `Measurable outcomes and KPIs`,
      `What the team would do differently`,
    ],
  },
  {
    title: (t) => `Common Pitfalls with ${t}`,
    bullets: (t) => [
      `Frequent mistakes newcomers make with ${t}`,
      `Debugging strategies when ${t} misbehaves`,
      `Anti-patterns to recognise and refactor`,
      `Resources for going deeper`,
    ],
  },
  {
    title: () => 'Summary',
    bullets: (t) => [
      `Recap of the ${t} fundamentals`,
      `The three most important takeaways`,
      `Recommended next steps for learners`,
      `Where to find additional resources`,
    ],
  },
  {
    title: () => 'Questions & Answers',
    bullets: (t) => [
      `Open floor for ${t} questions`,
      `Pointers for further self-study`,
      `Community channels for ${t}`,
      `How to contribute back to ${t}`,
    ],
  },
]

function buildFallbackDeck(topic: string, slideCount: number, theme: string, includeNotes: boolean): Slide[] {
  const out: Slide[] = []
  const count = Math.max(2, slideCount)
  for (let i = 0; i < count; i++) {
    const tpl = FALLBACK_SLIDE_TEMPLATES[i % FALLBACK_SLIDE_TEMPLATES.length]
    const slide: Slide = {
      index: i + 1,
      title: tpl.title(topic),
      bullets: tpl.bullets(topic),
    }
    if (includeNotes) {
      slide.notes = `Speaker notes for slide ${i + 1}: ${tpl.title(topic)}. Expand on each bullet with a concrete example drawn from ${topic}.`
    }
    out.push(slide)
  }
  return out
}

// ---------------------------------------------------------------------------
// Markdown + HTML rendering
// ---------------------------------------------------------------------------

function renderMarkdown(title: string, slides: Slide[]): string {
  const lines: string[] = [`# ${title}`, '']
  for (const s of slides) {
    lines.push(`## ${s.title}`, '')
    for (const b of s.bullets) lines.push(`- ${b}`)
    lines.push('')
    if (s.notes) {
      lines.push(`> Notes: ${s.notes}`, '')
    }
  }
  return lines.join('\n')
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function renderHtml(title: string, topic: string, slides: Slide[]): string {
  const slidesHtml = slides
    .map(
      (s) => `      <section class="slide" data-index="${s.index}">
        <header class="slide-header">
          <span class="slide-number">${s.index} / ${slides.length}</span>
          <h1 class="slide-title">${escapeHtml(s.title)}</h1>
        </header>
        <ul class="slide-bullets">
${s.bullets.map((b) => `          <li>${escapeHtml(b)}</li>`).join('\n')}
        </ul>${
          s.notes
            ? `
        <aside class="slide-notes">${escapeHtml(s.notes)}</aside>`
            : ''
        }
      </section>`,
    )
    .join('\n')

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="generator" content="AICF V3 PresentationModule" />
  <meta name="topic" content="${escapeHtml(topic)}" />
  <style>
    :root {
      --accent: #6d28d9;
      --bg: #0f172a;
      --surface: #1e293b;
      --text: #f8fafc;
      --muted: #94a3b8;
      --radius: 14px;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: var(--bg); color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .deck { display: flex; flex-direction: column; align-items: center; padding: 24px; gap: 24px; }
    .slide {
      width: min(960px, 100%);
      background: var(--surface);
      border-radius: var(--radius);
      padding: 40px 48px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.35);
      border-top: 6px solid var(--accent);
    }
    .slide-header { display: flex; align-items: baseline; justify-content: space-between; gap: 16px; }
    .slide-number { color: var(--muted); font-size: 0.85rem; font-variant-numeric: tabular-nums; }
    .slide-title { margin: 0; font-size: 2rem; line-height: 1.2; color: var(--text); }
    .slide-bullets { margin: 24px 0 0 0; padding-left: 1.25rem; font-size: 1.15rem; line-height: 1.6; }
    .slide-bullets li { margin-bottom: 10px; }
    .slide-notes { display: block; margin-top: 24px; padding: 14px 16px; background: rgba(125, 125, 125, 0.15); border-left: 4px solid var(--muted); font-size: 0.95rem; color: var(--muted); border-radius: 6px; }
    nav.deck-controls { position: fixed; bottom: 16px; right: 16px; display: flex; gap: 8px; background: rgba(0,0,0,0.6); padding: 8px; border-radius: 999px; }
    nav.deck-controls button { background: var(--accent); color: white; border: none; border-radius: 999px; padding: 8px 14px; cursor: pointer; font-weight: 600; }
    nav.deck-controls button:disabled { opacity: 0.4; cursor: not-allowed; }
    .deck-counter { color: var(--text); padding: 6px 10px; font-variant-numeric: tabular-nums; }
    @media print {
      html, body { background: white; color: black; }
      .deck { padding: 0; gap: 0; }
      .slide { box-shadow: none; border: 1px solid #ccc; border-radius: 0; width: 100%; page-break-after: always; }
      nav.deck-controls { display: none; }
    }
    @media (max-width: 640px) {
      .slide { padding: 24px; }
      .slide-title { font-size: 1.4rem; }
      .slide-bullets { font-size: 1rem; }
    }
  </style>
</head>
<body>
  <main class="deck">
${slidesHtml}
  </main>
  <nav class="deck-controls" aria-label="Slide navigation">
    <button type="button" id="prev" aria-label="Previous slide">&#8592;</button>
    <span class="deck-counter" id="counter">1 / ${slides.length}</span>
    <button type="button" id="next" aria-label="Next slide">&#8594;</button>
  </nav>
  <script>
    (function () {
      var slides = document.querySelectorAll('.slide');
      var total = slides.length;
      var current = 0;
      var prevBtn = document.getElementById('prev');
      var nextBtn = document.getElementById('next');
      var counter = document.getElementById('counter');
      function show(i) {
        current = Math.max(0, Math.min(i, total - 1));
        slides.forEach(function (s, idx) { s.style.display = idx === current ? '' : 'none'; });
        counter.textContent = (current + 1) + ' / ' + total;
        prevBtn.disabled = current === 0;
        nextBtn.disabled = current === total - 1;
      }
      prevBtn.addEventListener('click', function () { show(current - 1); });
      nextBtn.addEventListener('click', function () { show(current + 1); });
      document.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') { show(current + 1); e.preventDefault(); }
        if (e.key === 'ArrowLeft' || e.key === 'PageUp') { show(current - 1); e.preventDefault(); }
        if (e.key === 'Home') { show(0); }
        if (e.key === 'End') { show(total - 1); }
      });
      show(0);
    })();
  </script>
</body>
</html>`
}

// ---------------------------------------------------------------------------
// Module
// ---------------------------------------------------------------------------

/**
 * Presentation module — generates slide decks with optional AI assistance
 * and a deterministic fallback.
 */
export class PresentationModule extends BusinessModuleBase {
  readonly name = 'presentation'
  readonly version = '1.0.0'

  private readonly aiAdapter?: AIAdapter
  private readonly model: string

  constructor(aiAdapter?: AIAdapter, model = 'groq-llama-3.3-70b') {
    super()
    this.aiAdapter = aiAdapter
    this.model = model
  }

  getMetadata(): PluginMetadata {
    return PRESENTATION_MODULE_METADATA
  }

  getCapabilities(): Capability[] {
    return [...PRESENTATION_CAPABILITIES]
  }

  async executeJob(
    jobType: string,
    input: Record<string, unknown>,
    _ctx: BusinessContext,
  ): Promise<ExecutionResult> {
    this.markUsed()
    const start = Date.now()

    try {
      if (
        jobType === 'createSlides' ||
        jobType === 'generateSlides' ||
        jobType === 'exportSlides' ||
        jobType === 'generatePresentation'
      ) {
        const topic = asString(input.topic, 'Untitled Presentation')
        const slideCount = asNumber(input.slideCount ?? input.count, 8, 2, 50)
        const theme = asString(input.theme, 'default')
        const includeNotes = input.includeNotes !== false

        let slides: Slide[]

        if (this.aiAdapter) {
          try {
            slides = await this.generateSlidesViaAI(topic, slideCount, includeNotes)
          } catch (aiErr) {
            // AI failed — fall back to deterministic content so the job still
            // produces a usable deck.
            this.recordError(aiErr)
            slides = buildFallbackDeck(topic, slideCount, theme, includeNotes)
          }
        } else {
          slides = buildFallbackDeck(topic, slideCount, theme, includeNotes)
        }

        const title = `${topic} — Presentation`
        const markdown = renderMarkdown(title, slides)
        const html = renderHtml(title, topic, slides)

        const deck: SlideDeck = {
          title,
          topic,
          theme,
          slides,
          markdown,
          html,
        }

        return createSuccessResult(
          { deck, format: 'html', slideCount: slides.length },
          {
            durationMs: Date.now() - start,
            artifacts: [
              { id: `slides-${Date.now()}`, type: 'slides', name: `${topic.toLowerCase().replace(/\s+/g, '-')}.html` },
            ],
            metrics: { providerCalls: this.aiAdapter ? 1 : 0 },
          },
        )
      }

      return createFailedResult(`Unknown job type: ${jobType}`, { durationMs: Date.now() - start })
    } catch (err) {
      this.recordError(err)
      return createFailedResult(err instanceof Error ? err.message : String(err), {
        durationMs: Date.now() - start,
      })
    }
  }

  /**
   * Calls the AI adapter with a structured prompt and parses the response
   * into typed slides. Throws on parse failure so the caller can fall back.
   */
  private async generateSlidesViaAI(topic: string, slideCount: number, includeNotes: boolean): Promise<Slide[]> {
    const promptBuilder = getPromptBuilder()
    const prompts = promptBuilder.buildPresentation({
      topic,
      slideCount,
      language: 'en',
    })
    // Append the bullets + notes constraint that was in the original prompt.
    const userPrompt = `${prompts.user}

Each slide must have between 3 and 5 bullets. Each bullet must be a single concise sentence.
Notes: ${includeNotes ? 'include speaker notes' : 'omit speaker notes (set notes=null).'}`

    const req: ChatRequest = {
      model: this.model,
      messages: [
        { role: 'system', content: prompts.system },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.7,
      maxTokens: 4096,
    }

    const response = await this.aiAdapter!.chat(req)
    const parsed = JSON.parse(response.content) as { slides?: unknown }

    if (!parsed || !Array.isArray(parsed.slides)) {
      throw new Error('AI response missing "slides" array')
    }

    return (parsed.slides as unknown[]).map((raw, i): Slide => {
      const obj = (raw ?? {}) as Record<string, unknown>
      const title = asString(obj.title, `Slide ${i + 1}`)
      const bullets = asStringArray(obj.bullets, [`${topic} — key point ${i + 1}`])
      const slide: Slide = { index: i + 1, title, bullets }
      if (includeNotes && typeof obj.notes === 'string' && obj.notes.length > 0) {
        slide.notes = obj.notes
      }
      return slide
    })
  }
}
