// =============================================================================
// AICF V3 — ServiceContainer Tests (Sprint 16)
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { ServiceContainer } from '../ServiceContainer'

describe('ServiceContainer', () => {
  let container: ServiceContainer

  beforeEach(() => {
    container = new ServiceContainer()
  })

  it('should register and get an eager instance', () => {
    const logger = { info: () => {} }
    container.register('logger', logger)
    expect(container.has('logger')).toBe(true)
    expect(container.get<unknown>('logger')).toBe(logger)
  })

  it('should throw when getting an unregistered service', () => {
    expect(() => container.get('unknown')).toThrow(/not registered/)
  })

  it('should register and resolve a lazy factory', () => {
    let created = false
    container.registerFactory('eventBus', () => {
      created = true
      return { emit: () => {} }
    })
    expect(created).toBe(false) // not yet created
    const bus = container.get<{ emit: () => void }>('eventBus')
    expect(created).toBe(true)
    expect(bus).toBeDefined()
    expect(typeof bus.emit).toBe('function')
  })

  it('should resolve lazy singleton only once', () => {
    let count = 0
    container.registerFactory('counter', () => ({ value: ++count }))
    const c1 = container.get<{ value: number }>('counter')
    const c2 = container.get<{ value: number }>('counter')
    expect(c1).toBe(c2) // same instance
    expect(count).toBe(1)
  })

  it('should resolve non-singleton factory each time', () => {
    let count = 0
    container.registerFactory('counter', () => ({ value: ++count }), false)
    const c1 = container.get<{ value: number }>('counter')
    const c2 = container.get<{ value: number }>('counter')
    expect(c1).not.toBe(c2) // different instances
    expect(count).toBe(2)
  })

  it('should resolve dependencies by service IDs', () => {
    container.register('logger', { info: () => {} })
    container.register('eventBus', { emit: () => {} })
    const deps = container.resolveDependencies(['logger', 'eventBus', 'unknown'])
    expect(deps.logger).toBeDefined()
    expect(deps.eventBus).toBeDefined()
    expect(deps.unknown).toBeUndefined() // not registered, skipped
  })

  it('should list all registered service IDs', () => {
    container.register('a', 1)
    container.register('b', 2)
    container.registerFactory('c', () => 3)
    const ids = container.list()
    expect(ids).toContain('a')
    expect(ids).toContain('b')
    expect(ids).toContain('c')
    expect(ids.length).toBe(3)
  })

  it('should clear all services', () => {
    container.register('a', 1)
    container.clear()
    expect(container.has('a')).toBe(false)
    expect(container.list().length).toBe(0)
  })

  it('should support factory that resolves other services', () => {
    container.register('config', { model: 'gpt-4o' })
    container.registerFactory('adapter', (c) => {
      const config = c.get<{ model: string }>('config')
      return { model: config.model, chat: () => 'response' }
    })
    const adapter = container.get<{ model: string; chat: () => string }>('adapter')
    expect(adapter.model).toBe('gpt-4o')
    expect(adapter.chat()).toBe('response')
  })
})
