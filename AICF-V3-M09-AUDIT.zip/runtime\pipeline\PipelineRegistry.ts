// =============================================================================
// AICF V3 — Pipeline Registry (Sprint 2 Production Runtime)
// =============================================================================
// Builds the default pipeline with REAL stage implementations for ALL 10
// stages: Validate, Policy, Routing, PromptBuilder, Execution,
// PostProcessing, Audit, Cache, Metrics, Response.
//
// Sprint 21: PipelineConfig accepts an optional `eventBus`. When provided,
// the Validate stage emits ValidationStarted/Completed events through the
// bus (best-effort — never throws).
//
// Sprint 2 Production Runtime: the Audit, Cache, Metrics, and Response
// stages are real implementations (no longer pass-throughs). They use:
//   - AuditProvider (observability-singleton) — append-only audit log
//   - RuntimeResponseCache (cache/RuntimeResponseCache) — in-memory LRU
//   - MetricsRegistry (observability-singleton) — per-module call metrics
// The Validate stage performs real request validation (operation present,
// messages required for chat).
// =============================================================================

import type { PipelineStage } from './PipelineStage'
import { createPipelineStage } from './PipelineStage'
import { Pipeline } from './Pipeline'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import {
  createPolicyStage,
  createRoutingStage,
  createPromptBuilderStage,
  createExecutionStage,
  createPostProcessingStage,
  type FallbackGenerateFn,
} from '../stages'
import type { ContentIntelligenceModule, RealGenerationModule, InfrastructureModule } from '../contracts/ModuleInterfaces'
import { RuntimeEventBus } from '../events/RuntimeEventBus'
import type { RuntimeEventType } from '../events/RuntimeEvents'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import { getRuntimeResponseCache, computeCacheKey } from '../cache/RuntimeResponseCache'
import { logger } from '@/lib/ai/logger'

// --- Infrastructure stages (real implementations) -------------------------

/**
 * Validate stage — emits ValidationStarted/Completed events AND performs
 * real request validation (operation present, messages non-empty for chat).
 * On validation failure, sets ctx.response.ok=false + errorCode.
 *
 * The model is NOT hard-required here — the ExecutionStage has a sensible
 * default ('groq-llama-3.3-70b'). This keeps the pipeline lenient for
 * callers that omit the model while still catching structural errors.
 */
function makeValidateStage(eventBus?: RuntimeEventBus): PipelineStage {
  return createPipelineStage('Validate', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const requestId = ctx.request.requestId
    const correlationId = ctx.request.correlationId
    const operation = ctx.request.operation
    const started = Date.now()

    if (eventBus) {
      try {
        const meta = createEventMetadata({
          correlationId,
          requestId,
          operation,
          pipelineStage: 'Validate',
          stageOrder: 2,
        })
        await eventBus.publishEnvelope(createEnvelope(meta, { requestId, operation }), 'ValidationStarted')
      } catch (err) {
        logger.debug(
          { error: err instanceof Error ? err.message : String(err) },
          'Validate stage: failed to emit ValidationStarted (best-effort)',
        )
      }
    }

    // --- Real validation logic ---
    const errors: string[] = []
    if (!operation) {
      errors.push('operation is required')
    }
    if (operation === 'chat') {
      if (!ctx.request.messages || ctx.request.messages.length === 0) {
        errors.push('messages array is required for chat operation')
      }
    }

    const valid = errors.length === 0

    if (eventBus) {
      try {
        const meta = createEventMetadata({
          correlationId,
          requestId,
          operation,
          pipelineStage: 'Validate',
          stageOrder: 3,
          durationMs: Date.now() - started,
        })
        const payload: Record<string, unknown> = { requestId, valid }
        if (errors.length > 0) payload.errors = errors
        await eventBus.publishEnvelope(
          createEnvelope(meta, payload),
          'ValidationCompleted' as RuntimeEventType,
        )
      } catch (err) {
        logger.debug(
          { error: err instanceof Error ? err.message : String(err) },
          'Validate stage: failed to emit ValidationCompleted (best-effort)',
        )
      }
    }

    if (!valid) {
      const next = cloneRuntimeContext(ctx)
      next.response = {
        ...next.response,
        ok: false,
        error: `Validate: ${errors.join('; ')}`,
        errorCode: 'VALIDATION_ERROR',
      }
      return next
    }

    return ctx
  })
}

/**
 * Audit stage — records the request in the AuditProvider (best-effort).
 * Imports the audit singleton lazily so the pipeline doesn't hard-depend on
 * observability wiring at module load time.
 *
 * Audit failures are swallowed — they never break the pipeline.
 */
async function auditStage(ctx: RuntimeContext): Promise<RuntimeContext> {
  try {
    const { getAuditProvider } = await import('../observability-singleton')
    const audit = getAuditProvider()
    await audit.record({
      requestId: ctx.request.requestId,
      action: 'request.received',
      module: 'pipeline.audit',
      details: {
        operation: ctx.request.operation,
        model: ctx.request.model ?? null,
        messageCount: ctx.request.messages?.length ?? 0,
        correlationId: ctx.request.correlationId,
        traceId: ctx.traceId,
      },
    })
  } catch (err) {
    logger.debug(
      { error: err instanceof Error ? err.message : String(err) },
      'Audit stage: best-effort recording failed (continuing)',
    )
  }
  return ctx
}

/**
 * Cache stage — checks the in-memory LRU cache for an identical prior
 * request. On a hit, short-circuits the pipeline by populating the
 * response from the cached snapshot. On a miss, records the request key
 * so the Response stage can store the final response.
 *
 * Cache is OPT-IN for chat: only chat operations with messages are cached.
 * Status/models/workflow operations are NEVER cached (they're cheap or
 * side-effectful).
 */
async function cacheStage(ctx: RuntimeContext): Promise<RuntimeContext> {
  const next = cloneRuntimeContext(ctx)

  // Only chat operations with messages are cacheable.
  if (ctx.request.operation !== 'chat' || !ctx.request.messages || ctx.request.messages.length === 0) {
    return next
  }

  const cache = getRuntimeResponseCache()
  const key = computeCacheKey({
    operation: ctx.request.operation,
    model: ctx.request.model,
    messages: ctx.request.messages,
    parameters: ctx.request.parameters ?? null,
  })

  // Stash the key on the context (via a clone) so the Response stage can
  // store the final response under the same key. We piggyback on the
  // stageResults map to avoid adding a new context field.
  next.stageResults.set('__cacheKey', { ok: true, durationMs: 0, key })

  const cached = cache.get(key)
  if (cached) {
    logger.info(
      { requestId: ctx.request.requestId, cacheKey: key.slice(0, 32) },
      'Cache stage: HIT — short-circuiting pipeline',
    )
    // Mark the response as cached + populate content from the snapshot.
    next.response = {
      ...next.response,
      ok: cached.ok,
      content: cached.content,
      model: cached.model,
      provider: cached.provider,
      usage: cached.usage,
      cached: true,
    }
    next.cached = true
    next.metrics.cacheHit = true
  } else {
    next.metrics.cacheHit = false
  }

  return next
}

/**
 * Metrics stage — records per-module + per-request metrics in the
 * MetricsRegistry. Best-effort: failures are swallowed.
 *
 * Records under module 'pipeline' so /api/runtime/metrics can report
 * aggregate pipeline latency + token usage.
 */
async function metricsStage(ctx: RuntimeContext): Promise<RuntimeContext> {
  const next = cloneRuntimeContext(ctx)
  // Aggregate metrics from the context.
  next.metrics.provider = next.provider
  next.metrics.model = next.model
  next.metrics.cacheHit = next.cached
  // tokens and cost are set by PostProcessing stage

  // Best-effort: record in the MetricsRegistry.
  try {
    const { getMetricsRegistry } = await import('../observability-singleton')
    const registry = getMetricsRegistry()
    const durationMs = Date.now() - next.startedAt
    registry.recordCall('pipeline', durationMs, next.response.ok ? undefined : next.response.error)
  } catch (err) {
    logger.debug(
      { error: err instanceof Error ? err.message : String(err) },
      'Metrics stage: best-effort recording failed (continuing)',
    )
  }

  return next
}

/**
 * Response stage — finalizes the RuntimeResponse. Stores the response in
 * the cache (when cacheable + not already a cache hit). Sets the cached
 * flag + models + workflowResult on the response.
 */
async function responseStage(ctx: RuntimeContext): Promise<RuntimeContext> {
  const next = cloneRuntimeContext(ctx)
  next.response.cached = next.cached
  if (next.models) {
    next.response.models = next.models
  }
  if (next.workflowResult) {
    next.response.result = next.workflowResult
  }

  // --- Cache store (only on successful chat responses that weren't hits) ---
  if (
    next.response.ok &&
    !next.cached &&
    next.content &&
    ctx.request.operation === 'chat'
  ) {
    const cacheKeyEntry = next.stageResults.get('__cacheKey')
    if (cacheKeyEntry && typeof cacheKeyEntry === 'object' && 'key' in cacheKeyEntry) {
      try {
        const cache = getRuntimeResponseCache()
        cache.set(String(cacheKeyEntry.key), next.response)
      } catch (err) {
        logger.debug(
          { error: err instanceof Error ? err.message : String(err) },
          'Response stage: best-effort cache store failed (continuing)',
        )
      }
    }
  }

  return next
}

/**
 * Configuration for building the default pipeline.
 */
export interface PipelineConfig {
  /** Content Intelligence module (M08). If null, Policy and Routing use defaults. */
  ciModule?: ContentIntelligenceModule | null

  /** Real Generation module (M21). If null, Execution tries M18 or fallback. */
  genModule?: RealGenerationModule | null

  /** Infrastructure module (M18). If null, Execution tries fallback. */
  infraModule?: InfrastructureModule | null

  /** Fallback generate function (typically LiteLLMAdapter.chat). */
  fallback: FallbackGenerateFn

  /** Sprint 21: optional EventBus. When set, stages emit EDA events. */
  eventBus?: RuntimeEventBus
}

/**
 * Builds the default pipeline with real stages.
 * @param config - Module dependencies injected via DI.
 */
export function buildDefaultPipeline(config: PipelineConfig): PipelineStage[] {
  const ciModule = config.ciModule || null
  const genModule = config.genModule || null
  const infraModule = config.infraModule || null
  const eventBus = config.eventBus

  logger.info(
    {
      ciReady: Boolean(ciModule),
      genReady: Boolean(genModule),
      infraReady: Boolean(infraModule),
      hasEventBus: Boolean(eventBus),
    },
    'Building default pipeline with real stages',
  )

  return [
    makeValidateStage(eventBus),
    createPolicyStage(ciModule, eventBus),
    createRoutingStage(ciModule, eventBus),
    createPromptBuilderStage(),
    createExecutionStage({ genModule, infraModule, fallback: config.fallback, eventBus }),
    createPostProcessingStage(eventBus),
    createPipelineStage('Audit', auditStage),
    createPipelineStage('Cache', cacheStage),
    createPipelineStage('Metrics', metricsStage),
    createPipelineStage('Response', responseStage),
  ]
}

/**
 * The legacy default pipeline (for backward compatibility — uses
 * pass-through stages without real module integration).
 * @deprecated Use buildDefaultPipeline(config) instead.
 */
export const DEFAULT_PIPELINE_STAGES: PipelineStage[] = buildDefaultPipeline({
  fallback: async () => ({ content: '', model: '', provider: 'litellm', usage: null, durationMs: 0 }),
  eventBus: new RuntimeEventBus(),
})

/**
 * Registry of named pipelines.
 */
export class PipelineRegistry {
  private readonly pipelines = new Map<string, Pipeline>()

  constructor(stages?: PipelineStage[]) {
    // Register the default pipeline
    this.register('default', new Pipeline(stages || DEFAULT_PIPELINE_STAGES))
  }

  /**
   * Registers a pipeline by name.
   */
  register(name: string, pipeline: Pipeline): void {
    this.pipelines.set(name, pipeline)
  }

  /**
   * Gets a pipeline by name. Falls back to 'default'.
   */
  get(name: string = 'default'): Pipeline {
    return this.pipelines.get(name) || this.pipelines.get('default')!
  }

  /**
   * Lists all registered pipeline names.
   */
  list(): string[] {
    return Array.from(this.pipelines.keys())
  }
}
