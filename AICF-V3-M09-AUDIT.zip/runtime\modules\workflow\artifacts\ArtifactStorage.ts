// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — In-Memory Artifact Storage
// =============================================================================
// Concrete `IArtifactStorage` implementation backed by in-memory `Map`s.
// Maintains two indexes:
//   - artifacts:    id        -> WorkflowArtifact
//   - executionIdx: executionId -> Set<artifactId>
//
// All read paths (`load`, `listByExecution`, `listByStep`, `getLineage`,
// `getChildren`) return DEEP CLONES so callers cannot mutate persisted state
// by holding onto a returned reference. Writes deep-clone on the way in too.
//
// Sprint 13+14 spec requirements covered:
//   - CRUD over artifacts keyed by id
//   - Lookup by execution and by step (UI drill-down)
//   - `getLineage` returns the provenance graph for an artifact
//   - `getChildren` finds derived artifacts (lineage.parentArtifact === id)
// =============================================================================

import type {
  WorkflowArtifact,
  ArtifactLineage,
} from '@/lib/runtime/contracts/workflow'
import type { IArtifactStorage } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Deep-clone a JSON-serializable value. Uses `structuredClone` when
 * available; falls back to `JSON.parse(JSON.stringify(...))`.
 */
function deepClone<T>(value: T): T {
  if (
    typeof globalThis !== 'undefined' &&
    typeof (globalThis as { structuredClone?: unknown }).structuredClone ===
      'function'
  ) {
    try {
      return (globalThis as { structuredClone: (v: T) => T }).structuredClone(
        value,
      )
    } catch {
      // fall through to JSON path
    }
  }
  return JSON.parse(JSON.stringify(value)) as T
}

/**
 * In-memory `IArtifactStorage`. Safe to call from concurrent callers; the
 * `id` is the unit of isolation.
 *
 * One storage instance can be shared across many executions. The store does
 * NOT enforce any cross-artifact transactions — callers that need those must
 * layer them on top.
 */
export class InMemoryArtifactStorage implements IArtifactStorage {
  /** Artifacts keyed by id (deep-cloned on save). */
  private readonly artifacts = new Map<string, WorkflowArtifact>()
  /** Execution -> set of artifact ids (denormalized lookup index). */
  private readonly executionIdx = new Map<string, Set<string>>()

  // ----- IArtifactStorage --------------------------------------------------

  /** Persist an artifact. Idempotent on `id`. Deep-clones the input. */
  async save(artifact: WorkflowArtifact): Promise<void> {
    const clone = deepClone(artifact)
    this.artifacts.set(artifact.id, clone)
    let set = this.executionIdx.get(artifact.executionId)
    if (!set) {
      set = new Set<string>()
      this.executionIdx.set(artifact.executionId, set)
    }
    set.add(artifact.id)
    logger.debug(
      { artifactId: artifact.id, executionId: artifact.executionId },
      'ArtifactStorage: artifact saved',
    )
  }

  /** Load an artifact by id, or null if not found. Returns a deep clone. */
  async load(id: string): Promise<WorkflowArtifact | null> {
    const found = this.artifacts.get(id)
    return found ? deepClone(found) : null
  }

  /** Delete an artifact by id. No-op if not found. */
  async delete(id: string): Promise<void> {
    const found = this.artifacts.get(id)
    if (!found) return
    this.artifacts.delete(id)
    const set = this.executionIdx.get(found.executionId)
    if (set) {
      set.delete(id)
      if (set.size === 0) {
        this.executionIdx.delete(found.executionId)
      }
    }
    logger.debug(
      { artifactId: id, executionId: found.executionId },
      'ArtifactStorage: artifact deleted',
    )
  }

  /** List all artifacts produced by an execution. Returns deep clones. */
  async listByExecution(executionId: string): Promise<WorkflowArtifact[]> {
    const ids = this.executionIdx.get(executionId)
    if (!ids) return []
    const out: WorkflowArtifact[] = []
    for (const id of ids) {
      const a = this.artifacts.get(id)
      if (a) out.push(deepClone(a))
    }
    return out
  }

  /** List all artifacts produced by a specific step within an execution. */
  async listByStep(
    executionId: string,
    stepId: string,
  ): Promise<WorkflowArtifact[]> {
    const all = await this.listByExecution(executionId)
    return all.filter((a) => a.stepId === stepId)
  }

  /** Return the provenance graph for an artifact, or null if not found. */
  async getLineage(id: string): Promise<ArtifactLineage | null> {
    const found = this.artifacts.get(id)
    return found ? deepClone(found.lineage) : null
  }

  // ----- Extended (Batch D) ------------------------------------------------

  /**
   * Find all artifacts whose `lineage.parentArtifact === id`. Returns deep
   * clones. Returns an empty array if the parent artifact has no children
   * or is unknown.
   */
  async getChildren(id: string): Promise<WorkflowArtifact[]> {
    const out: WorkflowArtifact[] = []
    for (const a of this.artifacts.values()) {
      if (a.lineage.parentArtifact === id) {
        out.push(deepClone(a))
      }
    }
    return out
  }

  // ----- Diagnostics (not part of the interface) --------------------------

  /** Number of artifacts currently stored. */
  get size(): number {
    return this.artifacts.size
  }

  /** Number of distinct executions with at least one artifact. */
  get executionCount(): number {
    return this.executionIdx.size
  }
}
