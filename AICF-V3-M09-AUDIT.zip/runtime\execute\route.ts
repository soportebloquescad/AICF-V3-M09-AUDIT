// =============================================================================
// AICF V3 — Sprint 2.2 — POST /api/runtime/execute (with Correlation ID)
// =============================================================================
// Executes a Runtime request through the M09 pipeline.
// Reads x-correlation-id from request headers; generates one if absent.
// Returns x-correlation-id in response headers.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getRuntimeService, getRuntimeInitError } from '@/lib/runtime/runtime-singleton'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { RuntimeError } from '@/lib/runtime/errors/RuntimeError'
import { createCorrelationId, extractCorrelationIdFromHeaders, CORRELATION_ID_HEADER } from '@/lib/runtime/middleware/CorrelationId'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

const executeSchema = z.object({
  operation: z.enum(['chat', 'models', 'status', 'generate']),
  model: z.string().optional(),
  messages: z.array(z.object({
    role: z.enum(['system', 'user', 'assistant']),
    content: z.string(),
  })).optional(),
  parameters: z.record(z.string(), z.unknown()).optional(),
  requestId: z.string().optional(),
  correlationId: z.string().optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
})

export async function POST(request: NextRequest) {
  const correlationId = extractCorrelationIdFromHeaders(request.headers) ?? createCorrelationId()
  const reqLogger = logger.child({ endpoint: '/api/runtime/execute', method: 'POST', correlationId })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON body', correlationId },
      { status: 400, headers: { [CORRELATION_ID_HEADER]: correlationId } },
    )
  }

  const parsed = executeSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten(), correlationId },
      { status: 422, headers: { [CORRELATION_ID_HEADER]: correlationId } },
    )
  }

  try {
    const service = await getRuntimeService()

    if (!service) {
      const initError = getRuntimeInitError()
      return NextResponse.json(
        { error: 'Runtime not available', code: 'RUNTIME_INIT_FAILED', details: initError ? { initError } : undefined, correlationId },
        { status: 503, headers: { [CORRELATION_ID_HEADER]: correlationId } },
      )
    }

    const runtimeRequest = createRuntimeRequest({
      operation: parsed.data.operation,
      model: parsed.data.model,
      messages: parsed.data.messages as import('@/lib/ai/AIAdapter').ChatMessage[] | undefined,
      parameters: parsed.data.parameters,
      requestId: parsed.data.requestId,
      correlationId: parsed.data.correlationId || correlationId,
      metadata: parsed.data.metadata,
    })

    const timeoutMs = 30_000
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new RuntimeError('Runtime operation timed out', 'TIMEOUT', undefined, 504)), timeoutMs)
    })

    const response = await Promise.race([
      service.execute(runtimeRequest),
      timeoutPromise,
    ])

    reqLogger.info(
      { requestId: response.requestId, ok: response.ok, durationMs: response.durationMs, operation: parsed.data.operation },
      'Runtime execute completed',
    )

    return NextResponse.json(
      response,
      { status: response.ok ? 200 : 500, headers: { [CORRELATION_ID_HEADER]: correlationId } },
    )
  } catch (err) {
    if (err instanceof RuntimeError) {
      reqLogger.warn(
        { code: err.code, module: err.module, message: err.message },
        'Runtime execute failed (RuntimeError)',
      )
      return NextResponse.json(
        { error: err.message, code: err.code, module: err.module, correlationId },
        { status: err.statusCode, headers: { [CORRELATION_ID_HEADER]: correlationId } },
      )
    }

    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Runtime execute failed (unexpected)',
    )
    return NextResponse.json(
      { error: 'Runtime execution failed', message: err instanceof Error ? err.message : String(err), correlationId },
      { status: 500, headers: { [CORRELATION_ID_HEADER]: correlationId } },
    )
  }
}
