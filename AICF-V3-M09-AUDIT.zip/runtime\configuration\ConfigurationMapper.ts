// =============================================================================
// AICF V3 — Sprint 10 — ConfigurationMapper
// =============================================================================
import type { CourseConfiguration } from './CourseConfiguration'
import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import { getCountryEngine, type LocaleContext } from '../locale/CountryEngine'

export interface ResolvedConfiguration {
  config: CourseConfiguration
  theme: ThemePreset
  locales: LocaleContext[]
}

export class ConfigurationMapper {
  resolve(config: CourseConfiguration): ResolvedConfiguration {
    const themeEngine = getThemeEngine()
    const countryEngine = getCountryEngine()
    const theme = themeEngine.getTheme(config.visual.theme)
    const locales = countryEngine.buildContexts(config.geographic.countries)
    return { config, theme, locales }
  }
}

let singleton: ConfigurationMapper | null = null
export function getConfigurationMapper(): ConfigurationMapper {
  if (!singleton) singleton = new ConfigurationMapper()
  return singleton
}
export function resetConfigurationMapper(): void { singleton = null }
