// =============================================================================
// AICF V3 — Runtime Response Contract
// =============================================================================
// The payload that exits the Runtime pipeline. Typed — no `any`.
// =============================================================================

import type { ChatUsage, AIModel } from '@/lib/ai/AIAdapter'

/**
 * The result of a Runtime operation.
 */
export interface RuntimeResponse {
  /** Whether the operation succeeded. */
  ok: boolean

  /** The request that produced this response. */
  requestId: string

  /** Correlation ID for tracing. */
  correlationId: string

  /** Chat content (for chat operations). */
  content?: string

  /** Model used. */
  model?: string

  /** Provider that handled the request. */
  provider?: string

  /** Token usage. */
  usage?: ChatUsage | null

  /** Total duration in milliseconds. */
  durationMs: number

  /** List of models (for models operation). */
  models?: AIModel[]

  /** Workflow result (for workflow operations). */
  result?: Record<string, unknown>

  /** Error message (if ok === false). */
  error?: string

  /** Error code (if ok === false). */
  errorCode?: string

  /** Whether the response was served from cache. */
  cached?: boolean

  /** Pipeline stages executed. */
  stages?: string[]
}

/**
 * Factory: creates a successful RuntimeResponse.
 */
export function createRuntimeResponse(requestId: string, correlationId: string): RuntimeResponse {
  return {
    ok: true,
    requestId,
    correlationId,
    durationMs: 0,
  }
}

/**
 * Factory: creates an error RuntimeResponse.
 */
export function createRuntimeErrorResponse(
  requestId: string,
  correlationId: string,
  error: string,
  errorCode?: string,
): RuntimeResponse {
  return {
    ok: false,
    requestId,
    correlationId,
    durationMs: 0,
    error,
    errorCode,
  }
}
