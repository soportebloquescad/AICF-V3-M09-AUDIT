// =============================================================================
// AICF V3 — Épica 6 — Asset Generator
// EPIC 10: reuses MediaGenerator (topic-aware) for SVG + Mermaid when topic
// context is available. Falls back to legacy templates for backward compat.
// =============================================================================
import { logger } from '@/lib/ai/logger'

export type AssetType = 'svg' | 'mermaid' | 'plantuml' | 'bpmn' | 'drawio' | 'image-prompt' | 'infographic' | 'table' | 'timeline'

export interface GeneratedAsset {
  type: AssetType
  name: string
  content: string
  format: string
  metadata?: Record<string, unknown>
}

export interface AssetGenerateInput {
  /** Required for generate(), optional for generateAll() */
  type?: AssetType
  title: string
  description: string
  locale?: string
  /** EPIC 10: topic context for topic-aware generation (reuses MediaGenerator) */
  topic?: string
  /** EPIC 10: traceability */
  lessonId?: string
  moduleId?: string
  courseId?: string
}

export class AssetGenerator {
  /**
   * EPIC 10: generate a topic-aware asset. When `topic` is provided, SVG and
   * Mermaid assets delegate to MediaGenerator (Sprint 11A) which produces
   * topic-specific visuals. Other types use the legacy templates (which are
   * still real content, just not topic-varied).
   */
  async generate(input: AssetGenerateInput): Promise<GeneratedAsset> {
    // EPIC 10: for SVG + Mermaid, try topic-aware generation via MediaGenerator
    if (input.topic && (input.type === 'svg' || input.type === 'mermaid')) {
      try {
        const { MediaGenerator } = await import('../media/MediaGenerator')
        const { getThemeByName, DEFAULT_THEME_NAME } = await import('../theme/ThemeCatalog')
        const { getCountryEngine } = await import('../locale/CountryEngine')
        const theme = getThemeByName(DEFAULT_THEME_NAME)
        const countryEngine = getCountryEngine()
        const locale = countryEngine.buildContext('global') ?? undefined
        const media = new MediaGenerator()
        const metadata: Record<string, unknown> = {}
        if (input.lessonId) metadata.lessonId = input.lessonId
        if (input.moduleId) metadata.moduleId = input.moduleId
        if (input.courseId) metadata.courseId = input.courseId

        if (input.type === 'svg') {
          const svg = media.generateConcept(input.topic, 0, theme)
          return { type: 'svg', name: `${input.title}.svg`, content: svg, format: 'svg', metadata }
        }
        // mermaid
        const mermaid = media.generateMermaid(input.topic, 'flow')
        return { type: 'mermaid', name: `${input.title}.mermaid`, content: mermaid, format: 'mermaid', metadata }
      } catch (err) {
        logger.debug({ error: err instanceof Error ? err.message : String(err) }, 'AssetGenerator: MediaGenerator unavailable, falling back to legacy template')
      }
    }

    // Legacy path (backward-compatible, no topic context)
    switch (input.type) {
      case 'svg': return this.generateSVG(input)
      case 'mermaid': return this.generateMermaid(input)
      case 'plantuml': return this.generatePlantUML(input)
      case 'bpmn': return this.generateBPMN(input)
      case 'drawio': return this.generateDrawio(input)
      case 'image-prompt': return this.generateImagePrompt(input)
      case 'infographic': return this.generateInfographic(input)
      case 'table': return this.generateTable(input)
      case 'timeline': return this.generateTimeline(input)
      default: return this.generateSVG(input)
    }
  }

  async generateAll(input: AssetGenerateInput): Promise<GeneratedAsset[]> {
    const types: AssetType[] = ['svg', 'mermaid', 'plantuml', 'bpmn', 'drawio', 'image-prompt', 'infographic', 'table', 'timeline']
    const results: GeneratedAsset[] = []
    for (const t of types) {
      results.push(await this.generate({ ...input, type: t }))
    }
    return results
  }

  private generateSVG(input: { title: string }): GeneratedAsset {
    const content = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200">
  <rect x="10" y="10" width="120" height="60" rx="5" fill="#e0e7ff" stroke="#4f46e5" stroke-width="2"/>
  <text x="70" y="45" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#1e1b4b">Start</text>
  <line x1="130" y1="40" x2="190" y2="40" stroke="#4f46e5" stroke-width="2" marker-end="url(#arrow)"/>
  <rect x="190" y="10" width="120" height="60" rx="5" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
  <text x="250" y="45" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#78350f">Process</text>
  <line x1="250" y1="70" x2="250" y2="130" stroke="#d97706" stroke-width="2" marker-end="url(#arrow)"/>
  <rect x="190" y="130" width="120" height="60" rx="5" fill="#d1fae5" stroke="#059669" stroke-width="2"/>
  <text x="250" y="165" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#064e3b">End</text>
  <defs>
    <marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="#4f46e5"/>
    </marker>
  </defs>
  <text x="200" y="195" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#6b7280">${input.title}</text>
</svg>`
    return { type: 'svg', name: `${input.title}.svg`, content, format: 'svg' }
  }

  private generateMermaid(input: { title: string }): GeneratedAsset {
    const content = `graph TD
    A[Start: ${input.title}] --> B{Decision Point}
    B -->|Yes| C[Process Step 1]
    B -->|No| D[Alternative Path]
    C --> E[Process Step 2]
    D --> E
    E --> F[End: Complete]
    style A fill:#e0e7ff
    style F fill:#d1fae5`
    return { type: 'mermaid', name: `${input.title}.mermaid`, content, format: 'mermaid' }
  }

  private generatePlantUML(input: { title: string }): GeneratedAsset {
    const content = `@startuml
title ${input.title}

class Course {
  +id: String
  +title: String
  +modules: List
  +getStatus(): Status
}

class Module {
  +id: String
  +title: String
  +lessons: List
}

class Lesson {
  +id: String
  +title: String
  +content: String
}

Course "1" *-- "many" Module
Module "1" *-- "many" Lesson
@enduml`
    return { type: 'plantuml', name: `${input.title}.plantuml`, content, format: 'plantuml' }
  }

  private generateBPMN(input: { title: string }): GeneratedAsset {
    const content = `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI">
  <bpmn:process id="${input.title.replace(/\s/g, '_')}" name="${input.title}">
    <bpmn:startEvent id="start" name="Start"/>
    <bpmn:task id="task1" name="Process ${input.title}"/>
    <bpmn:endEvent id="end" name="Complete"/>
    <bpmn:sequenceFlow sourceRef="start" targetRef="task1"/>
    <bpmn:sequenceFlow sourceRef="task1" targetRef="end"/>
  </bpmn:process>
</bpmn:definitions>`
    return { type: 'bpmn', name: `${input.title}.bpmn`, content, format: 'bpmn' }
  }

  private generateDrawio(input: { title: string }): GeneratedAsset {
    const content = `<mxGraphModel dx="800" dy="600" grid="1" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="850" pageHeight="1100">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="${input.title}" style="rounded=1;whiteSpace=wrap;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="200" height="60" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`
    return { type: 'drawio', name: `${input.title}.drawio`, content, format: 'drawio' }
  }

  private generateImagePrompt(input: { title: string; description: string }): GeneratedAsset {
    const content = `A professional educational illustration about ${input.title}. ${input.description}. Style: clean, modern, vector-based, suitable for a premium online course. Color palette: blue, green, white. Composition: centered with clear visual hierarchy. Resolution: 1920x1080. No text overlays.`
    return { type: 'image-prompt', name: `${input.title}-prompt.txt`, content, format: 'txt' }
  }

  private generateInfographic(input: { title: string }): GeneratedAsset {
    const content = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
  <rect width="600" height="400" fill="#f8fafc"/>
  <text x="300" y="40" text-anchor="middle" font-family="sans-serif" font-size="24" font-weight="bold" fill="#1e293b">${input.title}</text>
  <rect x="50" y="80" width="150" height="100" rx="10" fill="#3b82f6"/>
  <text x="125" y="130" text-anchor="middle" font-family="sans-serif" font-size="14" fill="white">Concept 1</text>
  <rect x="225" y="80" width="150" height="100" rx="10" fill="#10b981"/>
  <text x="300" y="130" text-anchor="middle" font-family="sans-serif" font-size="14" fill="white">Concept 2</text>
  <rect x="400" y="80" width="150" height="100" rx="10" fill="#f59e0b"/>
  <text x="475" y="130" text-anchor="middle" font-family="sans-serif" font-size="14" fill="white">Concept 3</text>
  <text x="300" y="220" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#475569">Key Insights</text>
  <text x="300" y="260" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#64748b">- Fundamental principle</text>
  <text x="300" y="285" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#64748b">- Practical application</text>
  <text x="300" y="310" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#64748b">- Advanced technique</text>
</svg>`
    return { type: 'infographic', name: `${input.title}-infographic.svg`, content, format: 'svg' }
  }

  private generateTable(input: { title: string }): GeneratedAsset {
    const content = `Concept,Description,Importance\nConcept 1,Foundational principle of ${input.title},High\nConcept 2,Practical application,Medium\nConcept 3,Advanced technique,Low\n`
    return { type: 'table', name: `${input.title}.csv`, content, format: 'csv' }
  }

  private generateTimeline(input: { title: string }): GeneratedAsset {
    const content = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="200" viewBox="0 0 600 200">
  <line x1="50" y1="100" x2="550" y2="100" stroke="#cbd5e1" stroke-width="4"/>
  <circle cx="100" cy="100" r="12" fill="#3b82f6"/>
  <text x="100" y="80" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#1e293b">Phase 1</text>
  <text x="100" y="130" text-anchor="middle" font-family="sans-serif" font-size="10" fill="#64748b">Introduction</text>
  <circle cx="250" cy="100" r="12" fill="#10b981"/>
  <text x="250" y="80" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#1e293b">Phase 2</text>
  <text x="250" y="130" text-anchor="middle" font-family="sans-serif" font-size="10" fill="#64748b">Development</text>
  <circle cx="400" cy="100" r="12" fill="#f59e0b"/>
  <text x="400" y="80" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#1e293b">Phase 3</text>
  <text x="400" y="130" text-anchor="middle" font-family="sans-serif" font-size="10" fill="#64748b">Practice</text>
  <circle cx="500" cy="100" r="12" fill="#ef4444"/>
  <text x="500" y="80" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#1e293b">Phase 4</text>
  <text x="500" y="130" text-anchor="middle" font-family="sans-serif" font-size="10" fill="#64748b">Mastery</text>
  <text x="300" y="180" text-anchor="middle" font-family="sans-serif" font-size="14" font-weight="bold" fill="#1e293b">${input.title}</text>
</svg>`
    return { type: 'timeline', name: `${input.title}-timeline.svg`, content, format: 'svg' }
  }
}
