// =============================================================================
// AICF V3 — Runtime Bootstrap (Sprint 15: Plugin Architecture + Lifecycle)
// =============================================================================
// Reads the runtime manifest, creates each module via ModuleFactory,
// initializes them in priority order, runs health checks, registers them in
// ModuleRegistry, and emits lifecycle events via RuntimeEventBus.
//
// Bootstrap is invoked ONCE in the runtime lifecycle. It is idempotent —
// calling bootstrap() twice is a no-op after the first successful run.
//
// If a module fails to initialize, the error is logged but bootstrap
// continues with the remaining modules. The failed module is NOT registered.
// =============================================================================

import type { RuntimeModule, ModuleHealth } from '../contracts/RuntimeModule'
import { createDefaultModuleMetrics, createUninitializedHealth } from '../contracts/RuntimeModule'
import type { RuntimeModuleCategory } from '../contracts/RuntimeModule'
import { runtimeManifest, resolveManifest, type ManifestModuleEntry } from '../runtime.manifest'
import type { ModuleDeps } from '../factories/ModuleFactory'
import { RuntimeEventBus } from '../events/RuntimeEventBus'
import type { ModuleRegistry } from '../registry/ModuleRegistry'
import { logger } from '@/lib/ai/logger'

/**
 * The result of a bootstrap run.
 */
export interface BootstrapResult {
  /** Whether the bootstrap completed (even with module failures). */
  completed: boolean

  /** ISO timestamp when bootstrap started. */
  startedAt: string

  /** ISO timestamp when bootstrap completed. */
  completedAt: string

  /** Total duration in milliseconds. */
  durationMs: number

  /** Modules that were successfully initialized + registered. */
  initialized: string[]

  /** Modules that failed to initialize (with errors). */
  failed: Array<{ moduleId: string; error: string }>

  /** Modules that were skipped (disabled in manifest). */
  skipped: string[]
}

/**
 * Maps a manifest module ID to a RuntimeModuleCategory for the registry.
 * The manifest uses friendly IDs ('workflow', 'generation', 'observability');
 * the registry uses canonical categories.
 */
function moduleIdToCategory(moduleId: string): RuntimeModuleCategory {
  switch (moduleId) {
    case 'workflow': return 'workflow'
    case 'generation': return 'generation'
    case 'observability': return 'observability'
    // Legacy modules — not created by bootstrap, but supported for completeness.
    case 'content-intelligence': return 'content-intelligence'
    case 'real-generation': return 'real-generation'
    case 'infrastructure': return 'infrastructure'
    case 'localization': return 'localization'
    case 'assets': return 'assets'
    case 'reports': return 'reports'
    default: return 'workflow' // fallback
  }
}

/**
 * The Runtime Bootstrap — reads the manifest, creates + initializes + registers
 * all enabled modules in priority order.
 *
 * @example
 * const bootstrap = new RuntimeBootstrap({ registry, eventBus, deps: { aiAdapter } })
 * const result = await bootstrap.run()
 */
export class RuntimeBootstrap {
  private ran = false
  private result: BootstrapResult | null = null
  private readonly eventBus: RuntimeEventBus
  private readonly registry: ModuleRegistry
  private readonly deps: ModuleDeps
  private readonly manifest: { modules: ManifestModuleEntry[] }

  constructor(opts: {
    registry: ModuleRegistry
    eventBus?: RuntimeEventBus
    deps?: ModuleDeps
    manifest?: { modules: ManifestModuleEntry[] }
  }) {
    this.registry = opts.registry
    this.eventBus = opts.eventBus || new RuntimeEventBus()
    this.deps = opts.deps || {}
    this.manifest = opts.manifest || runtimeManifest
  }

  /**
   * Returns the event bus (for subscribing to lifecycle events).
   */
  getEventBus(): RuntimeEventBus {
    return this.eventBus
  }

  /**
   * Returns the bootstrap result (or null if not yet run).
   */
  getResult(): BootstrapResult | null {
    return this.result
  }

  /**
   * Returns whether bootstrap has run.
   */
  hasRun(): boolean {
    return this.ran
  }

  /**
   * Runs the bootstrap. Idempotent — safe to call multiple times.
   */
  async run(): Promise<BootstrapResult> {
    if (this.ran) {
      return this.result!
    }

    const startedAt = new Date().toISOString()
    const startMs = Date.now()
    logger.info('RuntimeBootstrap: starting')

    await this.eventBus.emitEvent('runtime.bootstrap.start', {
      data: { moduleCount: this.manifest.modules.length },
    })

    const initialized: string[] = []
    const failed: Array<{ moduleId: string; error: string }> = []
    const skipped: string[] = []

    // Track disabled modules (before resolveManifest filters them out)
    for (const entry of this.manifest.modules) {
      if (!entry.enabled) {
        skipped.push(entry.id)
        logger.info({ moduleId: entry.id }, 'RuntimeBootstrap: skipping disabled module')
      }
    }

    // Resolve the manifest (sort by priority + cycle detection)
    let ordered: ManifestModuleEntry[]
    try {
      ordered = resolveManifest(this.manifest)
    } catch (err) {
      const error = err instanceof Error ? err.message : String(err)
      logger.error({ error }, 'RuntimeBootstrap: manifest resolution failed')
      await this.eventBus.emitEvent('runtime.bootstrap.failed', { error })
      this.result = {
        completed: false,
        startedAt,
        completedAt: new Date().toISOString(),
        durationMs: Date.now() - startMs,
        initialized: [],
        failed: [{ moduleId: 'manifest', error }],
        skipped,
      }
      this.ran = true
      return this.result
    }

    // Track which modules were successfully initialized (for dependency checks)
    const initializedSet = new Set<string>()

    for (const entry of ordered) {
      // (Disabled modules were already tracked above — resolveManifest filters them out.)

      // Check dependencies
      const depsOk = entry.dependencies.every((d) => initializedSet.has(d))
      if (!depsOk) {
        const missing = entry.dependencies.filter((d) => !initializedSet.has(d))
        const error = `dependencies not satisfied: ${missing.join(', ')}`
        failed.push({ moduleId: entry.id, error })
        logger.error({ moduleId: entry.id, missing }, 'RuntimeBootstrap: skipping module — dependencies not met')
        await this.eventBus.emitEvent('module.failed', { moduleId: entry.id, error })
        continue
      }

      // Emit module.loaded
      await this.eventBus.emitEvent('module.loaded', { moduleId: entry.id })

      // Emit module.initializing
      await this.eventBus.emitEvent('module.initializing', { moduleId: entry.id })

      try {
        // Create via factory
        const moduleInstance = entry.factory(this.deps)

        // Initialize
        const initStart = Date.now()
        if (moduleInstance.initialize) {
          await moduleInstance.initialize()
        }
        const initLatencyMs = Date.now() - initStart

        // Health check (optional — if the module implements health())
        let health: ModuleHealth | null = null
        if (moduleInstance.health) {
          try {
            health = await moduleInstance.health()
          } catch (err) {
            logger.warn(
              { moduleId: entry.id, error: err instanceof Error ? err.message : String(err) },
              'RuntimeBootstrap: health check failed (non-fatal)',
            )
          }
        }

        // Register in the registry
        const category = moduleIdToCategory(entry.id)
        // Sprint 17: every module MUST declare metadata. Modules without
        // metadata are rejected — the register() path (no metadata) is gone.
        if (!entry.metadata) {
          throw new Error(
            `RuntimeBootstrap: module '${entry.id}' has no metadata — all modules must declare metadata`,
          )
        }
        this.registry.registerWithMetadata(category, moduleInstance, entry.metadata)
        // Sprint 17: also register discovery info (version, priority, tags,
        // health) on the CapabilityRegistry so lookup queries can answer.
        this.registry.getCapabilityRegistry().registerModuleInfo(entry.metadata.id, {
          version: entry.metadata.version,
          priority: entry.metadata.priority,
          tags: [],
          health: 'healthy',
        })
        await this.eventBus.emitEvent('ModuleRegistered', {
          moduleId: entry.id,
          capabilities: entry.metadata.capabilities,
        })
        await this.eventBus.emitEvent('module.registered', { moduleId: entry.id })
        await this.eventBus.emitEvent('ModuleReady', { moduleId: entry.id })

        // Emit module.initialized
        await this.eventBus.emitEvent('module.initialized', {
          moduleId: entry.id,
          data: { initLatencyMs, healthStatus: health?.status || 'healthy' },
        })

        initialized.push(entry.id)
        initializedSet.add(entry.id)

        logger.info(
          { moduleId: entry.id, initLatencyMs, healthStatus: health?.status || 'healthy' },
          'RuntimeBootstrap: module initialized',
        )
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err)
        failed.push({ moduleId: entry.id, error })
        await this.eventBus.emitEvent('module.failed', { moduleId: entry.id, error })
        logger.error(
          { moduleId: entry.id, error },
          'RuntimeBootstrap: module initialization failed (continuing with remaining modules)',
        )
      }
    }

    const completedAt = new Date().toISOString()
    const durationMs = Date.now() - startMs

    this.result = {
      completed: true,
      startedAt,
      completedAt,
      durationMs,
      initialized,
      failed,
      skipped,
    }
    this.ran = true

    await this.eventBus.emitEvent('runtime.bootstrap.complete', {
      data: { initialized: initialized.length, failed: failed.length, skipped: skipped.length, durationMs },
    })

    if (failed.length === 0) {
      await this.eventBus.emitEvent('runtime.ready', {
        data: { moduleCount: initialized.length },
      })
    }

    logger.info(
      { initialized, failed: failed.map((f) => f.moduleId), skipped, durationMs },
      'RuntimeBootstrap: complete',
    )

    return this.result
  }

  /**
   * Gracefully shuts down all initialized modules (in reverse order).
   */
  async shutdown(): Promise<void> {
    if (!this.result) return

    const reverseOrder = [...this.result.initialized].reverse()
    for (const moduleId of reverseOrder) {
      try {
        const category = moduleIdToCategory(moduleId)
        const mod = this.registry.get(category)
        if (mod?.shutdown) {
          await mod.shutdown()
          await this.eventBus.emitEvent('module.disposed', { moduleId })
        }
      } catch (err) {
        logger.warn(
          { moduleId, error: err instanceof Error ? err.message : String(err) },
          'RuntimeBootstrap: shutdown error (non-fatal)',
        )
      }
    }

    await this.eventBus.emitEvent('runtime.shutdown')
    logger.info('RuntimeBootstrap: shutdown complete')
  }
}
