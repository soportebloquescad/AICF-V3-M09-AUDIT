// =============================================================================
// AICF V3 — POST /api/runtime/workflow/[id]/dryrun (Sprint 13+14)
// =============================================================================
// Performs a dry-run of an existing execution's workflow definition.
// Returns estimated tokens, cost, duration WITHOUT calling AI.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getWorkflowModuleBundle } from '@/lib/runtime/modules/workflow/bundle'
import { createWorkflowContext } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const dryRunSchema = z.object({
  definition: z.record(z.string(), z.unknown()),
  inputs: z.record(z.string(), z.unknown()).default({}),
  correlationId: z.string().optional(),
  userId: z.string().optional(),
})

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: '/api/runtime/workflow/[id]/dryrun', method: 'POST', executionId: id })

  let body: unknown
  try {
    body = await request.json()
  } catch {
    body = {}
  }

  const parsed = dryRunSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parsed.error.flatten() },
      { status: 422 },
    )
  }

  try {
    const bundle = getWorkflowModuleBundle()
    const { definition, inputs, correlationId, userId } = parsed.data

    const ctx = createWorkflowContext({
      correlationId: correlationId || `cor-dryrun-${Date.now().toString(36)}`,
      executionId: id,
      userId: userId || 'anonymous',
      variables: inputs,
      dryRun: true,
    })

    const result = await bundle.module.dryRun(definition as never, inputs, ctx)

    reqLogger.info(
      {
        executionId: id,
        canExecute: result.canExecute,
        estimatedCost: result.estimatedCost,
        stepsPlanned: result.stepsPlanned.length,
      },
      'Dry-run completed',
    )
    return NextResponse.json(result)
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Dry-run failed',
    )
    return NextResponse.json({ error: 'Dry-run failed' }, { status: 500 })
  }
}
