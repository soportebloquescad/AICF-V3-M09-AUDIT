// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — EventBus Tests
// =============================================================================
// Tests for the InMemoryEventBus implementation. Verifies typed
// publish/subscribe, subscribeAll, history filtering, history cap, and
// error isolation between subscribers. No external dependencies.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { InMemoryEventBus } from '../events/EventBus'
import type { WorkflowEvent } from '@/lib/runtime/contracts/workflow'

/** Build a minimal event for testing. */
function makeEvent(
  type: string,
  executionId?: string,
  data: Record<string, unknown> = {},
): WorkflowEvent {
  const event: WorkflowEvent = {
    type: type as WorkflowEvent['type'],
    timestamp: Date.now(),
    level: 'info',
    data,
  }
  if (executionId !== undefined) event.executionId = executionId
  return event
}

describe('InMemoryEventBus', () => {
  let bus: InMemoryEventBus

  beforeEach(() => {
    bus = new InMemoryEventBus()
  })

  it('publish + subscribe: handler receives the event', async () => {
    const received: WorkflowEvent[] = []
    bus.subscribe('workflow.started', (e) => {
      received.push(e)
    })
    const event = makeEvent('workflow.started', 'exec-1', { workflowId: 'wf-1' })
    await bus.publish(event)
    expect(received.length).toBe(1)
    expect(received[0]).toBe(event)
  })

  it('multiple subscribers per event type all receive the event', async () => {
    const seen1: WorkflowEvent[] = []
    const seen2: WorkflowEvent[] = []
    bus.subscribe('step.completed', (e) => { seen1.push(e) })
    bus.subscribe('step.completed', (e) => { seen2.push(e) })
    const event = makeEvent('step.completed', 'exec-1')
    await bus.publish(event)
    expect(seen1.length).toBe(1)
    expect(seen2.length).toBe(1)
  })

  it('subscribeAll receives every event regardless of type', async () => {
    const all: WorkflowEvent[] = []
    bus.subscribeAll((e) => { all.push(e) })
    await bus.publish(makeEvent('workflow.started', 'exec-1'))
    await bus.publish(makeEvent('step.completed', 'exec-1'))
    await bus.publish(makeEvent('workflow.completed', 'exec-1'))
    expect(all.length).toBe(3)
    expect(all.map((e) => e.type)).toEqual([
      'workflow.started',
      'step.completed',
      'workflow.completed',
    ])
  })

  it('unsubscribe (returned fn) removes the handler', async () => {
    const received: WorkflowEvent[] = []
    const unsubscribe = bus.subscribe('workflow.started', (e) => {
      received.push(e)
    })
    await bus.publish(makeEvent('workflow.started', 'exec-1'))
    expect(received.length).toBe(1)
    unsubscribe()
    await bus.publish(makeEvent('workflow.started', 'exec-2'))
    expect(received.length).toBe(1)
  })

  it('getHistory filters by executionId', async () => {
    await bus.publish(makeEvent('workflow.started', 'exec-1'))
    await bus.publish(makeEvent('step.completed', 'exec-1'))
    await bus.publish(makeEvent('workflow.started', 'exec-2'))
    const exec1 = await bus.getHistory('exec-1')
    const exec2 = await bus.getHistory('exec-2')
    const all = await bus.getHistory()
    expect(exec1.length).toBe(2)
    expect(exec2.length).toBe(1)
    expect(all.length).toBe(3)
  })

  it('clear wipes history but keeps handlers subscribed', async () => {
    const received: WorkflowEvent[] = []
    bus.subscribe('workflow.started', (e) => { received.push(e) })
    await bus.publish(makeEvent('workflow.started', 'exec-1'))
    expect((await bus.getHistory()).length).toBe(1)
    bus.clear()
    expect((await bus.getHistory()).length).toBe(0)
    // Handler still subscribed.
    await bus.publish(makeEvent('workflow.started', 'exec-2'))
    expect(received.length).toBe(2)
  })

  it('handler errors are swallowed and do not crash publish', async () => {
    const receivedAfter: WorkflowEvent[] = []
    bus.subscribe('workflow.started', () => {
      throw new Error('boom')
    })
    // Same-type subscriber that should still receive the event.
    bus.subscribe('workflow.started', (e) => {
      receivedAfter.push(e)
    })
    // subscribeAll subscriber that should still receive the event.
    const allSeen: WorkflowEvent[] = []
    bus.subscribeAll((e) => { allSeen.push(e) })

    await expect(bus.publish(makeEvent('workflow.started', 'exec-1'))).resolves.toBeUndefined()
    expect(receivedAfter.length).toBe(1)
    expect(allSeen.length).toBe(1)
  })

  it('history is capped at 1000 events (FIFO eviction)', async () => {
    for (let i = 0; i < 1100; i += 1) {
      await bus.publish(makeEvent('workflow.started', `exec-${i}`))
    }
    const history = await bus.getHistory()
    expect(history.length).toBe(1000)
    // The first 100 events should be evicted; the oldest remaining is exec-100.
    expect(history[0].executionId).toBe('exec-100')
    expect(history[history.length - 1].executionId).toBe('exec-1099')
  })
})
