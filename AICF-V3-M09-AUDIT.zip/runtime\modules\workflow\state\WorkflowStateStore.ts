// =============================================================================
// AICF V3 — Sprint 13+14 — In-Memory Workflow State Store (Batch C2)
// =============================================================================
// Concrete `IWorkflowStateStore` implementation backed by in-memory `Map`s.
// The store is **durable-ready**: every `save` deep-clones the input so the
// caller's in-memory reference cannot be mutated by subsequent reads, and
// every `load` returns a deep clone so callers cannot mutate persisted state.
// Swapping this for a Postgres / Redis-backed implementation only requires
// reimplementing the same surface against a real DB driver — the contract
// is identical.
//
// Sprint 13+14 spec requirements covered:
//   - CRUD over executions keyed by id (deep-cloned on save AND load)
//   - `listPending` / `listByStatus` for the scheduler and dashboard
//   - Checkpoint persistence (separate map keyed by executionId)
//   - `updateStepExecution` for fine-grained step writes (no full-envelope
//     rewrite)
//   - Full-state serialization via `toJSON` / `fromJSON` / `export` / `import`
//     so the store can be snapshotted to a file or DB blob and restored
//
// Design notes:
//   - `executions` and `checkpoints` are stored in SEPARATE maps. The
//     `WorkflowExecution.checkpoints` array on the envelope is a
//     denormalized view; the canonical checkpoint store is the separate
//     map. Callers (e.g. `ExecutionCheckpointManager`) are expected to
//     keep both in sync.
//   - Deep cloning uses `structuredClone` when available (Node 17+) and
//     falls back to `JSON.parse(JSON.stringify(...))`. The execution
//     envelope is JSON-serializable by contract, so the fallback is safe.
//   - All async methods are async to match the `IWorkflowStateStore`
//     contract — a real DB-backed implementation will be genuinely async.
// =============================================================================

import type {
  WorkflowExecution,
  ExecutionStatus,
  Checkpoint,
  StepExecution,
} from '@/lib/runtime/contracts/workflow'
import type { IWorkflowStateStore } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/** Schema version for the serialized state payload. */
const STATE_SCHEMA_VERSION = '1.0.0'

/** Statuses considered "pending" (non-terminal) by `listPending`. */
const PENDING_STATUSES: ReadonlySet<ExecutionStatus> = new Set([
  'pending',
  'running',
  'paused',
  'compensating',
])

/**
 * Serialized shape of the full state store. Used by `toJSON` / `export`.
 * Both maps are serialized as arrays of `[key, value]` pairs so the
 * payload is plain JSON (no Map reviver required).
 */
export interface WorkflowStateStoreSnapshot {
  /** Schema version — bump if the shape changes. */
  version: string
  /** Epoch ms when the snapshot was taken. */
  exportedAt: number
  /** `[executionId, WorkflowExecution][]` */
  executions: Array<[string, WorkflowExecution]>
  /** `[executionId, Checkpoint[]][]` */
  checkpoints: Array<[string, Checkpoint[]]>
}

/**
 * Deep-clone a JSON-serializable value. Uses `structuredClone` when
 * available; falls back to `JSON.parse(JSON.stringify(...))` for older
 * runtimes. The execution envelope is JSON-serializable by contract, so
 * the fallback is always safe for our data.
 */
function deepClone<T>(value: T): T {
  if (typeof globalThis !== 'undefined' && typeof (globalThis as { structuredClone?: unknown }).structuredClone === 'function') {
    try {
      return (globalThis as { structuredClone: (v: T) => T }).structuredClone(value)
    } catch (err) {
      // structuredClone can throw on non-cloneable values (functions,
      // symbols). Our data is plain JSON, so this should never happen —
      // but we fall back to JSON to be safe.
      logger.debug(
        { err: err instanceof Error ? err.message : 'structuredClone failed' },
        'WorkflowStateStore: structuredClone failed, falling back to JSON',
      )
    }
  }
  return JSON.parse(JSON.stringify(value)) as T
}

/**
 * In-memory, durable-ready `IWorkflowStateStore`. Safe to call from
 * concurrent callers; `executionId` is the unit of isolation.
 *
 * One store instance can be shared across many executions. The store does
 * NOT enforce write ordering across executions — callers that need
 * cross-execution transactions must layer that on top.
 */
export class InMemoryWorkflowStateStore implements IWorkflowStateStore {
  /** Execution envelopes keyed by executionId (deep-cloned on save). */
  private readonly executions = new Map<string, WorkflowExecution>()
  /** Checkpoints keyed by executionId, in save order (deep-cloned on save). */
  private readonly checkpoints = new Map<string, Checkpoint[]>()

  // ----- IWorkflowStateStore ------------------------------------------------

  /**
   * Persist (or update) an execution envelope. Deep-clones the input so
   * the caller's reference cannot mutate persisted state.
   */
  async saveExecution(execution: WorkflowExecution): Promise<void> {
    const clone = deepClone(execution)
    clone.updatedAt = Date.now()
    this.executions.set(execution.executionId, clone)
    logger.debug(
      { executionId: execution.executionId, status: execution.status },
      'WorkflowStateStore: execution saved',
    )
  }

  /**
   * Load an execution by id, or `null` if not found. Returns a deep clone
   * so callers cannot mutate persisted state.
   */
  async loadExecution(executionId: string): Promise<WorkflowExecution | null> {
    const found = this.executions.get(executionId)
    if (!found) return null
    return deepClone(found)
  }

  /**
   * List executions in non-terminal states (`pending`, `running`,
   * `paused`, `compensating`). Returns deep clones.
   */
  async listPending(): Promise<WorkflowExecution[]> {
    const out: WorkflowExecution[] = []
    for (const exec of this.executions.values()) {
      if (PENDING_STATUSES.has(exec.status)) {
        out.push(deepClone(exec))
      }
    }
    return out
  }

  /**
   * List executions matching a specific status. Returns deep clones.
   */
  async listByStatus(status: ExecutionStatus): Promise<WorkflowExecution[]> {
    const out: WorkflowExecution[] = []
    for (const exec of this.executions.values()) {
      if (exec.status === status) {
        out.push(deepClone(exec))
      }
    }
    return out
  }

  /**
   * Delete an execution and its checkpoints. No-op if not found.
   */
  async deleteExecution(executionId: string): Promise<void> {
    const hadExec = this.executions.delete(executionId)
    const hadCheckpoints = this.checkpoints.delete(executionId)
    if (hadExec || hadCheckpoints) {
      logger.debug(
        { executionId, hadExec, hadCheckpoints },
        'WorkflowStateStore: execution deleted',
      )
    }
  }

  /**
   * Persist a checkpoint for an execution. Deep-clones the checkpoint.
   * Does NOT mutate the execution envelope's `checkpoints` array — callers
   * that want the envelope's denormalized view in sync must call
   * `saveExecution` themselves (or use `ExecutionCheckpointManager`).
   */
  async saveCheckpoint(
    executionId: string,
    checkpoint: Checkpoint,
  ): Promise<void> {
    const clone = deepClone(checkpoint)
    const list = this.checkpoints.get(executionId)
    if (list) {
      list.push(clone)
    } else {
      this.checkpoints.set(executionId, [clone])
    }
    logger.debug(
      { executionId, checkpointId: checkpoint.id, stepId: checkpoint.stepId },
      'WorkflowStateStore: checkpoint saved',
    )
  }

  /**
   * Load all checkpoints for an execution, in save order. Returns deep
   * clones. Returns an empty array if the execution has no checkpoints
   * (or is unknown).
   */
  async loadCheckpoints(executionId: string): Promise<Checkpoint[]> {
    const list = this.checkpoints.get(executionId)
    if (!list) return []
    return list.map((c) => deepClone(c))
  }

  /**
   * Update a single step's execution record within an execution
   * envelope, without rewriting the rest of the envelope. Deep-clones
   * the step record. No-op (logged at warn) if the execution is unknown.
   * If the step id does not yet exist on the envelope, it is added.
   */
  async updateStepExecution(
    executionId: string,
    stepId: string,
    stepExec: StepExecution,
  ): Promise<void> {
    const exec = this.executions.get(executionId)
    if (!exec) {
      logger.warn(
        { executionId, stepId },
        'WorkflowStateStore: updateStepExecution — execution not found',
      )
      return
    }
    exec.steps[stepId] = deepClone(stepExec)
    exec.updatedAt = Date.now()
    logger.debug(
      { executionId, stepId, status: stepExec.status },
      'WorkflowStateStore: step execution updated',
    )
  }

  // ----- Serialization ------------------------------------------------------

  /**
   * Return a serializable snapshot of the full store state. The snapshot
   * is a plain object (no `Map`s) so it can be `JSON.stringify`'d
   * directly. Both maps are serialized as `[key, value][]` arrays.
   */
  toJSON(): WorkflowStateStoreSnapshot {
    return {
      version: STATE_SCHEMA_VERSION,
      exportedAt: Date.now(),
      executions: Array.from(this.executions.entries()).map(
        ([id, exec]) => [id, deepClone(exec)] as [string, WorkflowExecution],
      ),
      checkpoints: Array.from(this.checkpoints.entries()).map(
        ([id, list]) => [id, list.map((c) => deepClone(c))] as [string, Checkpoint[]],
      ),
    }
  }

  /**
   * Restore the store from a snapshot. Replaces ALL current state. The
   * snapshot is deep-cloned so the caller's reference cannot mutate
   * persisted state. Unknown snapshot versions are rejected.
   */
  fromJSON(data: WorkflowStateStoreSnapshot): void {
    if (!data || typeof data !== 'object') {
      throw new Error('WorkflowStateStore.fromJSON: expected a snapshot object')
    }
    if (data.version !== STATE_SCHEMA_VERSION) {
      throw new Error(
        `WorkflowStateStore.fromJSON: unsupported snapshot version '${data.version}' (expected '${STATE_SCHEMA_VERSION}')`,
      )
    }
    this.executions.clear()
    this.checkpoints.clear()
    for (const [id, exec] of data.executions) {
      this.executions.set(id, deepClone(exec))
    }
    for (const [id, list] of data.checkpoints) {
      this.checkpoints.set(id, list.map((c) => deepClone(c)))
    }
    logger.debug(
      {
        executionCount: this.executions.size,
        checkpointKeys: this.checkpoints.size,
      },
      'WorkflowStateStore: state restored from snapshot',
    )
  }

  /**
   * Return the full store state as a JSON string. Convenience wrapper
   * around `toJSON()` + `JSON.stringify`.
   */
  export(): string {
    return JSON.stringify(this.toJSON())
  }

  /**
   * Restore the full store state from a JSON string. Replaces ALL
   * current state. Throws on invalid JSON or unknown schema version.
   */
  import(json: string): void {
    const parsed = JSON.parse(json) as WorkflowStateStoreSnapshot
    this.fromJSON(parsed)
  }

  // ----- Diagnostics (not part of the interface) ----------------------------

  /** Number of executions currently stored. */
  get size(): number {
    return this.executions.size
  }

  /** Number of executions with at least one checkpoint. */
  get checkpointKeyCount(): number {
    return this.checkpoints.size
  }
}
