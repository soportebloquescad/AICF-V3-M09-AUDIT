// =============================================================================
// AICF V3 — Sprint 2 — Runtime Adapter (runtime-layer)
// =============================================================================
// Adapter at the runtime layer that bridges between the Runtime pipeline
// and the AI layer. This is NOT the BFF-layer RuntimeAdapter in src/lib/ai/.
// This adapter wraps an AIAdapter for use within the runtime pipeline.
// =============================================================================

import type { AIAdapter, ChatRequest, ChatResponse, AIModel, AIHealth } from '@/lib/ai/AIAdapter'

export interface RuntimeAdapterConfig {
  aiAdapter: AIAdapter
  fallback?: AIAdapter
}

export class RuntimeAdapter {
  private readonly aiAdapter: AIAdapter
  private readonly fallback: AIAdapter | null

  constructor(config: RuntimeAdapterConfig) {
    this.aiAdapter = config.aiAdapter
    this.fallback = config.fallback ?? null
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    try {
      return await this.aiAdapter.chat(request)
    } catch (err) {
      if (this.fallback) {
        return await this.fallback.chat(request)
      }
      throw err
    }
  }

  async models(): Promise<AIModel[]> {
    try {
      return await this.aiAdapter.models()
    } catch {
      if (this.fallback) {
        return await this.fallback.models()
      }
      return []
    }
  }

  async health(): Promise<AIHealth> {
    return await this.aiAdapter.health()
  }
}
