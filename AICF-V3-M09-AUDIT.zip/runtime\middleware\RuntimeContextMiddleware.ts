// =============================================================================
// AICF V3 — Runtime Context Middleware
// =============================================================================
// Creates and enriches the RuntimeContext before pipeline execution.
//
// Épica 1 — Stabilization: the `ensureCorrelationId` + `ensureRequestId`
// helpers from the (deleted) `./CorrelationId` module are inlined here so
// this file is self-contained. The standalone CorrelationId.ts was only
// consumed by this file (verified via grep).
// =============================================================================

import type { RuntimeRequest } from '../contracts/RuntimeRequest'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { createRuntimeContext } from '../contracts/RuntimeContext'
import { ensureRequestId, ensureCorrelationId } from './CorrelationId'
import { logger } from '@/lib/ai/logger'

/**
 * Builds a RuntimeContext from a (possibly partial) request.
 * Ensures requestId and correlationId are present.
 * Creates a child logger with tracing context.
 */
export function buildContext(request: RuntimeRequest): RuntimeContext {
  // Ensure tracing IDs (Sprint 4: uses createCorrelationId/createRequestId)
  request.requestId = ensureRequestId(request)
  request.correlationId = ensureCorrelationId(request)

  // Build context (this sets traceId from metadata or defaults to correlationId)
  const ctx = createRuntimeContext(request)

  // Create child logger with full tracing context (requestId, correlationId, traceId)
  logger.child({
    requestId: request.requestId,
    correlationId: request.correlationId,
    traceId: ctx.traceId,
  })

  logger.info(
    {
      requestId: request.requestId,
      correlationId: request.correlationId,
      traceId: ctx.traceId,
      operation: request.operation,
    },
    'RuntimeContext built',
  )

  return ctx
}
