// =============================================================================
// AICF V3 — Sprint 3: RuntimeService Job Management Tests
// =============================================================================
// Tests the Sprint 3 additive job-management API on RuntimeService:
//   - executeJob() records jobs in the in-memory tracker
//   - getStatus(jobId) returns tracked job metadata
//   - listJobs() returns jobs (optionally filtered by status)
//   - cancelJob(jobId) requests cooperative cancellation
//
// These tests are additive: existing RuntimeService behavior (execute(),
// initialize(), getModuleStatus(), getRuntimeHealth()) is unchanged and
// covered by the existing RuntimeService.test.ts suite.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { RuntimeService, _resetGlobalBootstrap } from '../RuntimeService'
import { createJobRequest } from '@/lib/runtime/business/contracts/JobRequest'
import type { JobResponse } from '@/lib/runtime/business/contracts/JobResponse'
import type { BusinessContext } from '@/lib/runtime/business/contracts/BusinessContext'
import type { ExecutionResult } from '@/lib/runtime/business/contracts/ExecutionResult'
import type { Capability } from '@/lib/runtime/business/contracts/Capability'
import { createCapability } from '@/lib/runtime/business/contracts/Capability'
import type { PluginMetadata } from '@/lib/runtime/contracts/PluginMetadata'
import { BusinessModuleBase } from '@/lib/runtime/business/plugin/BusinessModuleBase'
import { createSuccessResult, createFailedResult } from '@/lib/runtime/business/contracts/ExecutionResult'

// -----------------------------------------------------------------------------
// Test fixtures
// -----------------------------------------------------------------------------

/**
 * A minimal BusinessModule that records executeJob calls and can be configured
 * to succeed/fail/sleep. Used to drive executeJob() through the real
 * RuntimeService path.
 */
class TestJobModule extends BusinessModuleBase {
  readonly name: string
  readonly version = '1.0.0'
  private ready = false
  private readonly behavior: 'success' | 'fail' | 'sleep'
  private readonly sleepMs: number
  private readonly caps: Capability[]
  callCount = 0

  constructor(opts: {
    behavior?: 'success' | 'fail' | 'sleep'
    sleepMs?: number
    name?: string
    capabilities?: string[]
  } = {}) {
    super()
    this.name = opts.name ?? 'test-job-module'
    this.behavior = opts.behavior ?? 'success'
    this.sleepMs = opts.sleepMs ?? 0
    const capNames = opts.capabilities ?? ['createCourse', 'createSlides']
    this.caps = capNames.map((n) => createCapability(n, `Test capability ${n}`))
  }

  async initialize(): Promise<void> {
    this.ready = true
  }

  isReady(): boolean {
    return this.ready
  }

  getMetadata(): PluginMetadata {
    return {
      id: this.name,
      name: this.name,
      description: `Test module (${this.name})`,
      author: 'sprint3-tests',
      version: this.version,
      mission: 'test',
      priority: 100,
      dependencies: [],
      capabilities: this.caps.map((c) => c.name),
      contracts: { schemaVersion: '1.0.0', contractVersion: '1.0.0', runtimeVersion: '3.0.0', compatibility: 'compatible' as const },
      events: [],
    }
  }

  getCapabilities(): Capability[] {
    return this.caps
  }

  async executeJob(
    jobType: string,
    input: Record<string, unknown>,
    _ctx: BusinessContext,
  ): Promise<ExecutionResult> {
    this.callCount++
    this.markUsed()
    if (this.behavior === 'sleep') {
      await new Promise((r) => setTimeout(r, this.sleepMs))
    }
    if (this.behavior === 'fail') {
      this.recordError(new Error('Test module configured to fail'))
      return createFailedResult('Test module configured to fail')
    }
    return createSuccessResult(
      { jobType, echoed: input, message: 'test success' },
      { metrics: { tokensUsed: 100, cost: 0.001, providerCalls: 1 } },
    )
  }
}

// -----------------------------------------------------------------------------
// Tests
// -----------------------------------------------------------------------------

describe('RuntimeService Sprint 3 — Job Management', () => {
  beforeEach(() => {
    _resetGlobalBootstrap()
  })

  it('executeJob() tracks the job as running then completed', async () => {
    const service = new RuntimeService()
    const testModule = new TestJobModule({ behavior: 'success' })
    service.getBusinessModuleRegistry().register(testModule)

    const request = createJobRequest('createCourse', { topic: 'Test' }, {
      correlationId: 'corr-test-1',
      requestId: 'req-test-1',
    })

    const response: JobResponse = await service.executeJob(request)

    expect(response.status).toBe('completed')
    expect(response.jobId).toBe(request.jobId)

    // getStatus should return the tracked job with final status
    const status = service.getStatus(request.jobId)
    expect(status).not.toBeNull()
    expect(status!.jobId).toBe(request.jobId)
    expect(status!.jobType).toBe('createCourse')
    expect(status!.status).toBe('completed')
    expect(status!.correlationId).toBe('corr-test-1')
    expect(status!.requestId).toBe('req-test-1')
    expect(status!.startedAt).toBeDefined()
    expect(status!.completedAt).toBeDefined()
    expect(typeof status!.durationMs).toBe('number')
  })

  it('executeJob() tracks failed jobs when no module handles the job type', async () => {
    const service = new RuntimeService()
    // No module registered for 'createQuiz'

    const request = createJobRequest('createQuiz', { topic: 'Quiz' })
    const response = await service.executeJob(request)

    expect(response.status).toBe('failed')
    expect(response.error).toContain('No module registered')

    const status = service.getStatus(request.jobId)
    expect(status).not.toBeNull()
    expect(status!.status).toBe('failed')
    expect(status!.error).toContain('No module registered')
  })

  it('executeJob() tracks failed jobs when module init fails', async () => {
    const service = new RuntimeService()
    class InitFailModule extends TestJobModule {
      async initialize(): Promise<void> {
        throw new Error('init boom')
      }
    }
    service.getBusinessModuleRegistry().register(new InitFailModule({ behavior: 'success' }))

    const request = createJobRequest('createCourse', { topic: 'X' })
    const response = await service.executeJob(request)

    expect(response.status).toBe('failed')
    expect(response.error).toContain('failed to initialize')

    const status = service.getStatus(request.jobId)
    expect(status!.status).toBe('failed')
    expect(status!.error).toContain('failed to initialize')
  })

  it('listJobs() returns all tracked jobs in reverse-chronological order', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    const req1 = createJobRequest('createCourse', { n: 1 })
    const req2 = createJobRequest('createCourse', { n: 2 })
    const req3 = createJobRequest('createSlides', { n: 3 })

    await service.executeJob(req1)
    await service.executeJob(req2)
    await service.executeJob(req3)

    const all = service.listJobs()
    expect(all.length).toBe(3)
    // Most recent first (req3 was executed last)
    expect(all[0]!.jobId).toBe(req3.jobId)
    expect(all[2]!.jobId).toBe(req1.jobId)
  })

  it('listJobs() filters by status', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    // 2 will succeed
    await service.executeJob(createJobRequest('createCourse', { n: 1 }))
    await service.executeJob(createJobRequest('createCourse', { n: 2 }))
    // 1 will fail (no module for createQuiz)
    await service.executeJob(createJobRequest('createQuiz', { n: 3 }))

    const completed = service.listJobs('completed')
    expect(completed.length).toBe(2)
    expect(completed.every((j) => j.status === 'completed')).toBe(true)

    const failed = service.listJobs('failed')
    expect(failed.length).toBe(1)
    expect(failed[0]!.status).toBe('failed')

    const running = service.listJobs('running')
    expect(running.length).toBe(0)
  })

  it('listJobs() respects the limit parameter', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    for (let i = 0; i < 5; i++) {
      await service.executeJob(createJobRequest('createCourse', { i }))
    }

    const limited = service.listJobs(undefined, 3)
    expect(limited.length).toBe(3)
  })

  it('getStatus() returns null for unknown job IDs', () => {
    const service = new RuntimeService()
    const status = service.getStatus('nonexistent-job-id')
    expect(status).toBeNull()
  })

  it('cancelJob() records cancellation request and marks job as cancelled on completion', async () => {
    const service = new RuntimeService()
    // Use a module with a long sleep so the cancel happens while it's running.
    // We use a deferred promise to control timing precisely.
    const sleepingModule = new TestJobModule({ behavior: 'sleep', sleepMs: 200 })
    service.getBusinessModuleRegistry().register(sleepingModule)

    const request = createJobRequest('createCourse', { slow: true })
    // Kick off execution but don't await yet — the module sleeps 200ms.
    const execPromise = service.executeJob(request)

    // Give the tracker a tick to record the job as 'running'.
    await new Promise((r) => setTimeout(r, 10))

    // Now the job should be tracked as 'running'. Request cancellation.
    const cancelled = service.cancelJob(request.jobId)
    expect(cancelled).toBe(true)

    // Wait for the module to finish sleeping + the job to complete.
    const response = await execPromise
    // The tracker marks the job 'cancelled' because cancelRequested was set
    // while it was running.
    expect(response.status).toBe('cancelled')

    const status = service.getStatus(request.jobId)
    expect(status!.status).toBe('cancelled')
    expect(status!.cancelRequested).toBe(true)
  })

  it('cancelJob() returns false for unknown job IDs', () => {
    const service = new RuntimeService()
    expect(service.cancelJob('nonexistent')).toBe(false)
  })

  it('cancelJob() returns false for already-completed jobs', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    const request = createJobRequest('createCourse', { done: true })
    await service.executeJob(request)

    expect(service.cancelJob(request.jobId)).toBe(false)
  })

  it('executeJob() preserves correlationId and requestId in tracked job', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    const request = createJobRequest('createCourse', { x: 1 }, {
      correlationId: 'my-corr-id',
      requestId: 'my-req-id',
      userId: 'user-123',
      projectId: 'proj-456',
    })

    await service.executeJob(request)

    const status = service.getStatus(request.jobId)
    expect(status!.correlationId).toBe('my-corr-id')
    expect(status!.requestId).toBe('my-req-id')
  })

  it('job tracker is bounded (does not grow unboundedly)', async () => {
    const service = new RuntimeService()
    service.getBusinessModuleRegistry().register(new TestJobModule({ behavior: 'success' }))

    for (let i = 0; i < 10; i++) {
      await service.executeJob(createJobRequest('createCourse', { i }))
    }

    const all = service.listJobs()
    expect(all.length).toBe(10)
    expect(all.length).toBeLessThanOrEqual(1000)
  })

  it('executeJob() routes to the correct module by jobType capability', async () => {
    const service = new RuntimeService()
    const courseModule = new TestJobModule({ behavior: 'success', capabilities: ['createCourse', 'createSlides'] })
    service.getBusinessModuleRegistry().register(courseModule)

    const req1 = createJobRequest('createCourse', { topic: 'A' })
    const resp1 = await service.executeJob(req1)
    expect(resp1.status).toBe('completed')
    expect(courseModule.callCount).toBe(1)

    const req2 = createJobRequest('createSlides', { topic: 'B' })
    const resp2 = await service.executeJob(req2)
    expect(resp2.status).toBe('completed')
    expect(courseModule.callCount).toBe(2)

    const req3 = createJobRequest('createQuiz', { topic: 'C' })
    const resp3 = await service.executeJob(req3)
    expect(resp3.status).toBe('failed')
  })
})
