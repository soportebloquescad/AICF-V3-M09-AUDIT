// =============================================================================
// AICF V3 — Sprint 13+14 — Batch I — ArtifactRegistry + Storage Tests
// =============================================================================
// Tests for ArtifactRegistry and InMemoryArtifactStorage. Verifies save +
// load, listByExecution / listByStep, lineage queries (getLineage,
// getChildren, getParent, getFullLineage), and linkChild.
// =============================================================================
import { describe, it, expect, beforeEach } from 'bun:test'
import { ArtifactRegistry } from '../artifacts/ArtifactRegistry'
import { InMemoryArtifactStorage } from '../artifacts/ArtifactStorage'
import { createArtifact } from '@/lib/runtime/contracts/workflow'
import type { WorkflowArtifact } from '@/lib/runtime/contracts/workflow'

/** Build a minimal artifact with optional parent. */
async function makeArtifact(
  id: string,
  opts: { exec?: string; step?: string; parent?: string; type?: WorkflowArtifact['type'] } = {},
): Promise<WorkflowArtifact> {
  const exec = opts.exec ?? 'exec-1'
  const step = opts.step ?? 'step-1'
  return createArtifact(
    exec,
    step,
    `artifact-${id}`,
    opts.type ?? 'text',
    `content-${id}`,
    opts.parent !== undefined
      ? {
          parentArtifact: opts.parent,
          generator: step,
          workflowExecution: exec,
          children: [],
        }
      : { generator: step, workflowExecution: exec, children: [] },
    { id },
  )
}

describe('ArtifactRegistry + InMemoryArtifactStorage', () => {
  let storage: InMemoryArtifactStorage
  let registry: ArtifactRegistry

  beforeEach(() => {
    storage = new InMemoryArtifactStorage()
    registry = new ArtifactRegistry(storage)
  })

  it('save + load artifact (via registry.register / registry.get)', async () => {
    const art = await makeArtifact('a-1')
    await registry.register(art)
    const loaded = await registry.get('a-1')
    expect(loaded).not.toBeNull()
    expect(loaded?.id).toBe('a-1')
    expect(loaded?.content).toBe('content-a-1')
  })

  it('listByExecution returns all artifacts for an execution', async () => {
    await registry.register(await makeArtifact('a-1', { exec: 'e-1' }))
    await registry.register(await makeArtifact('a-2', { exec: 'e-1' }))
    await registry.register(await makeArtifact('a-3', { exec: 'e-2' }))
    const e1 = await registry.listByExecution('e-1')
    const e2 = await registry.listByExecution('e-2')
    expect(e1.map((a) => a.id).sort()).toEqual(['a-1', 'a-2'])
    expect(e2.map((a) => a.id)).toEqual(['a-3'])
  })

  it('listByStep filters by step within an execution', async () => {
    await registry.register(
      await makeArtifact('a-1', { exec: 'e-1', step: 'outline' }),
    )
    await registry.register(
      await makeArtifact('a-2', { exec: 'e-1', step: 'modules' }),
    )
    await registry.register(
      await makeArtifact('a-3', { exec: 'e-1', step: 'outline' }),
    )
    const outline = await storage.listByStep('e-1', 'outline')
    const modules = await storage.listByStep('e-1', 'modules')
    expect(outline.map((a) => a.id).sort()).toEqual(['a-1', 'a-3'])
    expect(modules.map((a) => a.id)).toEqual(['a-2'])
  })

  it('getLineage returns the provenance graph for an artifact', async () => {
    const parent = await makeArtifact('parent')
    const child = await makeArtifact('child', { parent: 'parent' })
    await registry.register(parent)
    await registry.register(child)
    const lineage = await registry.getLineage('child')
    expect(lineage).not.toBeNull()
    expect(lineage?.parentArtifact).toBe('parent')
    expect(lineage?.children).toEqual([])
  })

  it('getChildren returns all artifacts whose parentArtifact === id', async () => {
    const parent = await makeArtifact('parent')
    const child1 = await makeArtifact('c-1', { parent: 'parent' })
    const child2 = await makeArtifact('c-2', { parent: 'parent' })
    const unrelated = await makeArtifact('c-3', { parent: 'other' })
    await registry.register(parent)
    await registry.register(child1)
    await registry.register(child2)
    await registry.register(unrelated)
    const children = await registry.getChildren('parent')
    expect(children.map((c) => c.id).sort()).toEqual(['c-1', 'c-2'])
  })

  it('getParent loads the parent artifact via lineage.parentArtifact', async () => {
    const parent = await makeArtifact('parent')
    const child = await makeArtifact('child', { parent: 'parent' })
    await registry.register(parent)
    await registry.register(child)
    const p = await registry.getParent('child')
    expect(p).not.toBeNull()
    expect(p?.id).toBe('parent')
    // An artifact without a parent returns null.
    expect(await registry.getParent('parent')).toBeNull()
  })

  it('getFullLineage walks up the parent chain (parent, grandparent, ...)', async () => {
    const grand = await makeArtifact('grand')
    const parent = await makeArtifact('parent', { parent: 'grand' })
    const child = await makeArtifact('child', { parent: 'parent' })
    await registry.register(grand)
    await registry.register(parent)
    await registry.register(child)
    const lineage = await registry.getFullLineage('child')
    expect(lineage.map((a) => a.id)).toEqual(['parent', 'grand'])
    // The starting artifact is NOT included.
    expect(lineage.find((a) => a.id === 'child')).toBeUndefined()
  })

  it('linkChild updates the parent children array (idempotent)', async () => {
    const parent = await makeArtifact('parent')
    const child = await makeArtifact('child')
    await registry.register(parent)
    await registry.register(child)
    await registry.linkChild('parent', 'child')
    const p1 = await registry.get('parent')
    expect(p1?.lineage.children).toEqual(['child'])
    // Calling again is a no-op (idempotent).
    await registry.linkChild('parent', 'child')
    const p2 = await registry.get('parent')
    expect(p2?.lineage.children).toEqual(['child'])
    // Linking a second, distinct child.
    const child2 = await makeArtifact('child-2')
    await registry.register(child2)
    await registry.linkChild('parent', 'child-2')
    const p3 = await registry.get('parent')
    expect(p3?.lineage.children).toEqual(['child', 'child-2'])
  })
})
