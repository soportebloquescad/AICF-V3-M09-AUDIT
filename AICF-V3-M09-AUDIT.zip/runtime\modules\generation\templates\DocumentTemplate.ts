// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Document Template
// =============================================================================
// Template loader for the "document" content category. Wraps the declarative
// `document.workflow.json` definition (authored under the workflow module)
// as an `ITemplate`, providing self-describing metadata, lazy loading from
// disk (with a minimal fallback when the JSON file is missing), and input
// validation for the document-generation surface.
//
// Sprint 13+14 spec requirements covered:
//   - Self-describing `name` / `version` / `description`
//   - `load()` returns a fully-formed `WorkflowDefinition` ready to execute
//   - `validate(inputs)` lets callers check inputs before invoking the engine
//   - Robust disk loading via `fs.readFileSync` with a minimal default
//     workflow fallback (keeps the module bootable in test/CI environments
//     where the JSON file may not yet be present)
// =============================================================================

import { readFileSync } from 'fs'
import { resolve as resolvePath } from 'path'

import type { ITemplate } from '@/lib/runtime/interfaces'
import type {
  WorkflowDefinition,
  WorkflowMetadata,
  WorkflowStepDefinition,
} from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Relative path to the document workflow JSON definition. */
const TEMPLATE_PATH = resolvePath(
  __dirname,
  '..',
  '..',
  'workflow',
  'templates',
  'document.workflow.json',
)

/**
 * Document workflow template. Loads `document.workflow.json` from the
 * workflow module's templates directory and exposes it via the `ITemplate`
 * contract.
 */
export class DocumentTemplate implements ITemplate {
  public readonly name = 'document'
  public readonly version = '1.0.0'
  public readonly description =
    'Generates a complete document with outline and Markdown sections from a topic.'

  /**
   * Load the document workflow definition. Reads the JSON template from
   * disk; on any read/parse failure, falls back to a minimal but valid
   * default workflow so callers can still proceed (with a logged warning).
   */
  public async load(): Promise<WorkflowDefinition> {
    try {
      const raw = readFileSync(TEMPLATE_PATH, 'utf-8')
      const parsed = JSON.parse(raw) as WorkflowDefinition
      return parsed
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.warn(
        { template: this.name, path: TEMPLATE_PATH, error: message },
        'DocumentTemplate: falling back to default workflow',
      )
      return defaultDocumentWorkflow()
    }
  }

  /**
   * Validate caller-supplied inputs. The document template requires a
   * non-empty `topic` string.
   */
  public validate(inputs: Record<string, unknown>): {
    valid: boolean
    errors: string[]
  } {
    const errors: string[] = []
    const topic = inputs['topic']
    if (typeof topic !== 'string' || topic.trim().length === 0) {
      errors.push('input "topic" is required and must be a non-empty string')
    }
    if (
      inputs['sections'] !== undefined &&
      typeof inputs['sections'] !== 'number'
    ) {
      errors.push('input "sections", when provided, must be a number')
    }
    return { valid: errors.length === 0, errors }
  }
}

/**
 * Build a minimal but valid `WorkflowDefinition` for the document template.
 * Used only as a fallback when the JSON file cannot be read or parsed.
 */
function defaultDocumentWorkflow(): WorkflowDefinition {
  const now = Date.now()
  const metadata: WorkflowMetadata = {
    id: 'document-generation',
    name: 'Document Generation Workflow (fallback)',
    version: '1.0.0',
    description:
      'Minimal fallback document generation workflow (used when JSON template is unavailable).',
    author: 'AICF V3 generation module',
    createdAt: now,
    updatedAt: now,
    tags: ['document', 'report', 'generation', 'fallback'],
    category: 'document',
  }
  const generateStep: WorkflowStepDefinition = {
    id: 'generate-document',
    name: 'Generate Document',
    type: 'generate',
    provider: 'document-generator',
    config: {},
    inputs: { topic: '$.inputs.topic' },
    outputs: { document: 'document' },
    dependsOn: [],
    retries: 1,
    timeout: 120_000,
  }
  return {
    metadata,
    version: '1.0.0',
    inputs: {
      topic: {
        name: 'topic',
        type: 'string',
        required: true,
        description: 'The document topic',
      },
    },
    outputs: {
      document: {
        name: 'document',
        type: 'object',
        description: 'The generated document',
        fromStep: 'generate-document',
      },
    },
    steps: [generateStep],
    checkpoints: [],
    policies: {
      maxRetries: 3,
      timeoutMs: 120_000,
      maxCost: 0.5,
      maxTokens: 50_000,
    },
  }
}
