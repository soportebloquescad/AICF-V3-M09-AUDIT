// =============================================================================
// AICF V3 — Post Processing Stage (Sprint 21: emits AuditStarted/AuditCompleted)
// =============================================================================
// Normalizes the response: ensures usage, provider, model, metadata,
// duration, and cost are correctly set in the context.
//
// Sprint 21: when an EventBus is provided (optional 1st arg), the stage
// emits:
//   - AuditStarted  (before normalizing)
//   - AuditCompleted (after normalizing)
// Emission is best-effort — wrapped in try/catch, never throws, never blocks
// the pipeline.
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'
import { cloneRuntimeContext } from '../contracts/RuntimeContext'
import type { RuntimeEventBus } from '../events/RuntimeEventBus'
import { createEventMetadata, createEnvelope } from '../events/EventMetadata'
import { logger } from '@/lib/ai/logger'

/** Estimated cost per 1K tokens (USD). Used when actual cost is unknown. */
const ESTIMATED_COSTS: Record<string, { prompt: number; completion: number }> = {
  'groq-llama-3.3-70b': { prompt: 0.00059, completion: 0.00079 },
  'gpt-4o': { prompt: 0.0025, completion: 0.01 },
  'gpt-4o-mini': { prompt: 0.00015, completion: 0.0006 },
  'claude-3.5-sonnet': { prompt: 0.003, completion: 0.015 },
  'gemini-1.5-pro': { prompt: 0.00125, completion: 0.005 },
}

/**
 * Best-effort: emits an envelope-wrapped EDA event. Wraps in try/catch so
 * emission failures never propagate to the pipeline.
 */
async function emitBestEffort(
  eventBus: RuntimeEventBus | undefined,
  type: 'AuditStarted' | 'AuditCompleted',
  opts: {
    correlationId: string
    requestId: string
    operation: string
    stageOrder: number
    durationMs?: number
    payload: Record<string, unknown>
  },
): Promise<void> {
  if (!eventBus) return
  try {
    const meta = createEventMetadata({
      correlationId: opts.correlationId,
      requestId: opts.requestId,
      operation: opts.operation,
      pipelineStage: 'PostProcessing',
      stageOrder: opts.stageOrder,
      durationMs: opts.durationMs,
    })
    await eventBus.publishEnvelope(createEnvelope(meta, opts.payload), type)
  } catch (err) {
    logger.debug(
      { type, error: err instanceof Error ? err.message : String(err) },
      'PostProcessing stage: event emission failed (best-effort)',
    )
  }
}

/**
 * Creates the PostProcessing stage.
 * Normalizes context fields after execution.
 * @param eventBus - Optional. When set, emits AuditStarted/AuditCompleted events.
 */
export function createPostProcessingStage(eventBus?: RuntimeEventBus): PipelineStage {
  return createPipelineStage('PostProcessing', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const requestId = ctx.request.requestId
    const correlationId = ctx.request.correlationId
    const operation = ctx.request.operation

    await emitBestEffort(eventBus, 'AuditStarted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 10,
      payload: { requestId, operation },
    })

    const started = Date.now()

    const next = cloneRuntimeContext(ctx)

    // Normalize content
    if (next.content) {
      next.response.content = next.content
    }

    // Normalize provider and model
    next.response.provider = next.provider || undefined
    next.response.model = next.model || undefined

    // Normalize usage
    if (next.usage) {
      next.response.usage = next.usage

      // Update metrics
      next.metrics.tokensPrompt = next.usage.promptTokens
      next.metrics.tokensCompletion = next.usage.completionTokens
      next.metrics.tokensTotal = next.usage.totalTokens
    }

    // Estimate cost if usage is available
    if (next.usage && next.model) {
      const costRate = ESTIMATED_COSTS[next.model]
      if (costRate) {
        next.metrics.cost =
          (next.usage.promptTokens / 1000) * costRate.prompt +
          (next.usage.completionTokens / 1000) * costRate.completion
      }
    }

    // Update provider/model in metrics
    next.metrics.provider = next.provider
    next.metrics.model = next.model

    logger.debug(
      {
        requestId: next.request.requestId,
        provider: next.provider,
        model: next.model,
        tokens: next.usage?.totalTokens,
        cost: next.metrics.cost,
      },
      'PostProcessing: response normalized',
    )

    await emitBestEffort(eventBus, 'AuditCompleted', {
      correlationId,
      requestId,
      operation,
      stageOrder: 11,
      durationMs: Date.now() - started,
      payload: {
        requestId,
        module: 'post-processing',
        tokensTotal: next.usage?.totalTokens ?? 0,
      },
    })

    return next
  })
}
