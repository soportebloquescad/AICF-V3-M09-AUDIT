// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — ArtifactPackage (Universal)
// =============================================================================
// The universal container for a generated artifact.
//
// Every artifact-generating module produces an ArtifactPackage. It carries:
//   - The main content (markdown)
//   - Structured sections
//   - Attached files (with MIME types)
//   - Metadata + checksum
//
// Specific artifact results (CourseResult, etc.) EXTEND this interface —
// they add type-specific structured fields (e.g. CourseResult adds `modules`).
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

/**
 * A single section within an artifact package.
 */
export interface ArtifactSection {
  /** Section title. */
  title: string
  /** Section content (markdown). */
  content: string
  /** Section type (e.g. 'intro', 'lesson', 'exercise', 'summary', 'appendix'). */
  type: string
}

/**
 * A file attached to an artifact package.
 */
export interface ArtifactFile {
  /** File name (including extension). */
  name: string
  /** File content (text or base64-encoded binary). */
  content: string
  /** MIME type (e.g. 'text/markdown', 'application/pdf', 'image/png'). */
  mimeType: string
}

/**
 * The universal container for a generated artifact.
 *
 * Produced by artifact-generating modules. Specific artifact results
 * (CourseResult, EbookResult, etc.) extend this interface.
 */
export interface ArtifactPackage {
  /** Unique package identifier. */
  id: string

  /** Artifact type (matches the ArtifactRequest.type). */
  type: string

  /** Human-readable title. */
  title: string

  /** Human-readable description. */
  description: string

  /** Main content (markdown). */
  content: string

  /** Structured sections of the artifact. */
  sections: ArtifactSection[]

  /** Attached files. */
  files: ArtifactFile[]

  /** Arbitrary metadata (source, generation params, etc.). */
  metadata: Record<string, unknown>

  /** Checksum (SHA-256 or similar) for integrity verification. */
  checksum: string
}

/**
 * Factory: creates an ArtifactPackage with sensible defaults.
 *
 * @example
 * const pkg = createArtifactPackage({ id, type: 'course', title: 'Intro to Rust', content: '...' })
 */
export function createArtifactPackage(
  partial: Partial<ArtifactPackage> & Pick<ArtifactPackage, 'id' | 'type' | 'title'>,
): ArtifactPackage {
  return {
    description: '',
    content: '',
    sections: [],
    files: [],
    metadata: {},
    checksum: '',
    ...partial,
  }
}
