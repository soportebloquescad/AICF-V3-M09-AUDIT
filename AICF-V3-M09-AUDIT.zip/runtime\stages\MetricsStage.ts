// =============================================================================
// AICF V3 — Sprint 2 — Metrics Stage
// =============================================================================
// Collects metrics from the context (latency, tokens, cost).
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'

export function createMetricsStage(): PipelineStage {
  return createPipelineStage('Metrics', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    const now = Date.now()
    ctx.metrics.pipelineTimeMs = now - (ctx.metrics.pipelineTimeMs || now)
    ctx.response.stages = [...(ctx.response.stages ?? []), 'Metrics']
    return ctx
  })
}
