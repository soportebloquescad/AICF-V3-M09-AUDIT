// =============================================================================
// AICF V3 — Shared Barrel (Épica 2 — AI Factory Core, B7 + B8 + B9)
// =============================================================================
// Re-exports the shared DTOs (B7), validators (B8), and builders (B9).
// =============================================================================

export type {
  TopicInput,
  LevelInput,
  ModuleCountInput,
  LanguageInput,
  FormatInput,
  AudienceInput,
  ArtifactOutput,
  CourseOutput,
  SlidesOutput,
  QuizOutput,
  DocumentOutput,
} from './dtos'

export type { ValidationResult } from './validators'
export {
  validateTopicInput,
  validateLevelInput,
  validateModuleCountInput,
  validateFormatInput,
} from './validators'

export { buildJobRequest, buildBusinessContext, type BuildJobRequestOptions } from './builders'
