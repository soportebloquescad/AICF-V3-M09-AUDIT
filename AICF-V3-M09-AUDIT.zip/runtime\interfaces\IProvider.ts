// =============================================================================
// AICF V3 — Sprint 13+14 — Provider Interface
// =============================================================================
// A provider is the lowest-level runtime building block: it implements one or
// more `ProviderCapability` operations (chat / generate / validate / transform
// / conditional) and is invoked by an IStepExecutor.
//
// Sprint 13+14 spec requirements covered:
//   - Uniform capability surface across heterogeneous providers
//   - `getManifest()` for self-description (registry, UI, audit)
//   - `isReady()` for health-checked provider pools
//   - Reuses `StepExecutionResult` so provider output flows unchanged through
//     the executor into the execution envelope
// =============================================================================

import type { WorkflowContext } from '@/lib/runtime/contracts/workflow'
import type { StepExecutionResult } from './IStepExecutor'

/** Capability a provider can implement. */
export type ProviderCapability =
  | 'chat'
  | 'generate'
  | 'validate'
  | 'transform'
  | 'conditional'

/** Self-describing provider manifest. Used by the registry and UI. */
export interface ProviderManifest {
  /** Provider name (matches `IProvider.name`). */
  name: string
  /** Semver version of the provider implementation. */
  version: string
  /** Capabilities advertised by this provider. */
  capabilities: ProviderCapability[]
  /** Provider-specific configuration (safe to surface; never secrets). */
  config: Record<string, unknown>
  /** Short human-readable description. */
  description: string
}

/**
 * Provider contract. Implementations MUST be safe to call concurrently across
 * distinct executions; per-execution state belongs in `WorkflowContext`, not
 * the provider.
 */
export interface IProvider {
  /** Provider name (unique within the registry). */
  readonly name: string
  /** Capabilities advertised by this provider. */
  readonly capabilities: ProviderCapability[]
  /** Initialize the provider (e.g. open connections, warm caches). */
  initialize(): Promise<void>
  /** Execute a capability against an input payload. */
  execute(
    capability: ProviderCapability,
    input: Record<string, unknown>,
    ctx: WorkflowContext,
  ): Promise<StepExecutionResult>
  /** Whether the provider is initialized and ready to serve requests. */
  isReady(): boolean
  /** Return the provider manifest. */
  getManifest(): ProviderManifest
}
