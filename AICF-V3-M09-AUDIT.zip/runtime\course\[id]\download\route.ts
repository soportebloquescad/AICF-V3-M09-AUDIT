// =============================================================================
// AICF V3 — Épica 7 — GET /api/runtime/course/[id]/download
// =============================================================================
// Thin Route Handler: downloads the ZIP artifact for a course.
// Looks up the ZIP artifact via CourseArtifactRegistry and streams it.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: `/api/runtime/course/${id}/download`, method: 'GET' })

  try {
    const artifacts = await CourseArtifactRegistry.listByProject(id)
    const zipArtifact = artifacts.find((a) => a.type === 'zip')

    if (!zipArtifact) {
      return NextResponse.json(
        { error: 'ZIP not found. The course may not be fully generated yet.', courseId: id },
        { status: 404 },
      )
    }

    reqLogger.info({ courseId: id, artifactId: zipArtifact.artifactId, sizeBytes: zipArtifact.sizeBytes }, 'Downloading ZIP')

    return new NextResponse(new Uint8Array(zipArtifact.content), {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${id}.zip"`,
        'Content-Length': String(zipArtifact.sizeBytes),
      },
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to download ZIP',
    )
    return NextResponse.json(
      { error: 'Failed to download ZIP' },
      { status: 500 },
    )
  }
}
