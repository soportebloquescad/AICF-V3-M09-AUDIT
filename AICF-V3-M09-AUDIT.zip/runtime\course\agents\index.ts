// =============================================================================
// AICF V3 — Course Agents Barrel
// =============================================================================
// Re-exports all 10 course-generation agents plus the shared utilities.
// The AgentCoordinator imports from this barrel to instantiate agents.
// =============================================================================

export { ResearchAgent } from './ResearchAgent'
export type { ResearchAgentDeps } from './ResearchAgent'

export { InstructionalDesigner } from './InstructionalDesigner'
export type { InstructionalDesignerDeps } from './InstructionalDesigner'

export { CurriculumArchitect } from './CurriculumArchitect'
export type { CurriculumArchitectDeps } from './CurriculumArchitect'

export { LessonWriter } from './LessonWriter'
export type { LessonWriterDeps } from './LessonWriter'

export { ExerciseWriter } from './ExerciseWriter'
export type { ExerciseWriterDeps } from './ExerciseWriter'

export { AssessmentWriter } from './AssessmentWriter'
export type { AssessmentWriterDeps } from './AssessmentWriter'

export { SlideGenerator } from './SlideGenerator'
export type { SlideGeneratorDeps } from './SlideGenerator'

export { DocumentGenerator } from './DocumentGenerator'
export type { DocumentGeneratorDeps } from './DocumentGenerator'

export { QualityAgent } from './QualityAgent'
export type { QualityAgentDeps } from './QualityAgent'

export { PublisherAgent } from './PublisherAgent'
export type { PublisherAgentDeps } from './PublisherAgent'

export {
  callAI,
  extractJSON,
  normalizeLevel,
  readContext,
  elapsedMs,
  errorToString,
  clamp,
  pickBloomLevels,
  BLOOM_VERBS,
  BLOOM_LEVELS_ORDER,
} from './agentUtils'
export type {
  CallAIOptions,
  CallAIResult,
  BloomLevel,
} from './agentUtils'
