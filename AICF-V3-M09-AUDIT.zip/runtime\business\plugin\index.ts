// =============================================================================
// AICF V3 — Business Plugin SDK Barrel (Épica 2 — AI Factory Core)
// =============================================================================
// Re-exports the abstract base class + the defineModule() factory.
// =============================================================================

export { BusinessModuleBase } from './BusinessModuleBase'
export { defineModule, type DefineModuleConfig } from './PluginSDK'
