// =============================================================================
// AICF V3 — Epica 8 — Lesson Writer Engine (500+ words per lesson)
// =============================================================================
import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type { EngineContract, HealthStatus } from './EngineContract'
import { ENGINE_VERSION, RUNTIME_VERSION } from './EngineContract'
import type { Lesson, LessonPlan, KnowledgePack, Provider } from './CourseContracts'
import { logger } from '@/lib/ai/logger'

function makeId(prefix: string): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${prefix}-${ts}-${rand}`
}

export interface LessonWriterEngineInput {
  lessonPlans: LessonPlan[]
  knowledgePack: KnowledgePack
}

export class LessonWriterEngine implements EngineContract {
  readonly name = 'lesson-writer'
  private healthy = false

  constructor(private readonly opts: { aiAdapter: AIAdapter | null }) {}

  async initialize(): Promise<void> {
    this.healthy = true
  }

  async execute(input: unknown): Promise<unknown> {
    if (!this.validate(input)) {
      throw new Error('LessonWriterEngine: invalid input — expected { lessonPlans, knowledgePack }')
    }
    const typed = input as LessonWriterEngineInput
    const lessons: Lesson[] = []
    for (const plan of typed.lessonPlans) {
      if (this.opts.aiAdapter) {
        try {
          lessons.push(await this.writeWithAI(plan, typed.knowledgePack))
          continue
        } catch (err) {
          logger.warn({ error: err instanceof Error ? err.message : String(err) }, 'LessonWriterEngine: AI failed, using fallback')
        }
      }
      lessons.push(this.writeDeterministic(plan, typed.knowledgePack))
    }
    return lessons
  }

  validate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false
    const obj = input as Record<string, unknown>
    if (!Array.isArray(obj.lessonPlans) || obj.lessonPlans.length === 0) return false
    if (typeof obj.knowledgePack !== 'object' || obj.knowledgePack === null) return false
    return true
  }

  async health(): Promise<HealthStatus> {
    if (this.opts.aiAdapter) {
      try {
        const h = await this.opts.aiAdapter.health()
        return { healthy: h.healthy, details: { provider: h.provider } }
      } catch (err) {
        return { healthy: false, error: err instanceof Error ? err.message : String(err) }
      }
    }
    return { healthy: this.healthy, details: { mode: 'deterministic-fallback' } }
  }

  async shutdown(): Promise<void> {
    this.healthy = false
  }

  private async writeWithAI(plan: LessonPlan, knowledgePack: KnowledgePack): Promise<Lesson> {
    const req: ChatRequest = {
      model: 'default',
      messages: [
        {
          role: 'system',
          content: `You are a premium lesson writer producing clear, pedagogically sound Markdown lessons aligned with Bloom's taxonomy. Use H2 headings (##) for sections, include learning objectives, multiple body sections with SPECIFIC examples (no generic placeholders), a visual reference section describing a diagram/chart/mermaid that illustrates the concepts, and a hands-on exercise WITH solution. Minimum 600 words.`,
        },
        {
          role: 'user',
          content: `Write a ${plan.length} lesson titled "${plan.title}" for module "${plan.moduleTitle}" (moduleId: ${plan.moduleId}).\nBloom level: ${plan.bloomLevel}\nLearning objectives: ${plan.learningObjectives.join('; ')}\nKey concepts: ${plan.keyConcepts.join(', ')}\nKnowledge context: ${knowledgePack.summary}\nKey facts: ${knowledgePack.keyFacts.slice(0, 3).join('; ')}\n\nReturn Markdown with sections: Learning Objectives, Introduction, Key Concepts (with subsections and concrete examples), Practical Application (with a real-world scenario), Visual Reference (describe a diagram/chart/mermaid that illustrates the key concepts), Hands-on Exercise (with step-by-step instructions AND a solution section), Summary, Key Takeaways. Make all content SPECIFIC to the topic — no generic filler.`,
        },
      ],
      temperature: 0.6,
      maxTokens: 6144,
    }
    const resp = await this.opts.aiAdapter!.chat(req)
    const wordCount = resp.content.split(/\s+/).filter(Boolean).length
    return this.assembleLesson(plan, resp.content, wordCount, resp.provider as Provider, resp.model)
  }

  private writeDeterministic(plan: LessonPlan, knowledgePack: KnowledgePack): Lesson {
    const content = this.buildMarkdown(plan, knowledgePack)
    const wordCount = content.split(/\s+/).filter(Boolean).length
    return this.assembleLesson(plan, content, wordCount, 'runtime-adapter', 'deterministic-fallback')
  }

  private buildMarkdown(plan: LessonPlan, knowledgePack: KnowledgePack): string {
    const lines: string[] = []
    lines.push(`# ${plan.title}`)
    lines.push('')
    lines.push('## Learning Objectives')
    lines.push('')
    for (const obj of plan.learningObjectives) {
      lines.push(`- ${obj}`)
    }
    lines.push('')
    lines.push('## Introduction')
    lines.push('')
    lines.push(`This lesson, part of ${plan.moduleTitle}, introduces you to ${plan.title.toLowerCase()}. Building on the foundational understanding developed in earlier lessons, this session explores ${plan.keyConcepts.join(', ')} in depth. By the end of this lesson, you will be able to apply these concepts confidently in real-world scenarios.`)
    lines.push('')
    lines.push(`The lesson targets the ${plan.bloomLevel} level of Bloom's taxonomy, meaning you will not only recall information but also ${this.bloomAction(plan.bloomLevel)} what you have learned. The content is structured to support ${plan.length === 'short' ? 'a focused, intensive study session' : plan.length === 'long' ? 'an extended, in-depth exploration' : 'a balanced study session'} of approximately ${plan.durationMinutes} minutes.`)
    lines.push('')
    lines.push('## Key Concepts')
    lines.push('')
    for (let i = 0; i < plan.keyConcepts.length; i++) {
      const concept = plan.keyConcepts[i] ?? `concept ${i + 1}`
      lines.push(`### ${concept.charAt(0).toUpperCase() + concept.slice(1)}`)
      lines.push('')
      lines.push(`The concept of ${concept} is central to understanding ${plan.title.toLowerCase()}. ${this.expandConcept(concept, plan, knowledgePack)} By mastering ${concept}, you will be better equipped to handle the practical challenges introduced in subsequent sections.`)
      lines.push('')
      lines.push(`Consider how ${concept} relates to the broader topic of ${plan.moduleTitle}. The connection may not be immediately obvious, but as you work through the examples and exercises, the relationship will become clearer. ${knowledgePack.keyFacts[i % knowledgePack.keyFacts.length] ?? 'Research supports the importance of this concept.'}`)
      lines.push('')
    }
    lines.push('## Practical Application')
    lines.push('')
    lines.push(`Putting theory into practice is essential for deep learning. In this section, we apply the concepts covered above to a concrete scenario related to ${plan.moduleTitle.toLowerCase()}. Imagine you are working on a project where ${plan.keyConcepts[0] ?? 'these concepts'} must be applied to achieve a specific outcome.`)
    lines.push('')
    lines.push(`The first step is to identify the relevant ${plan.keyConcepts[0] ?? 'factors'} in your scenario. Next, analyze how ${plan.keyConcepts[1] ?? 'other factors'} interact with these. Finally, synthesize your analysis into an actionable plan. This three-step approach — identify, analyze, synthesize — is a powerful framework applicable across many domains.`)
    lines.push('')
    lines.push('## Common Pitfalls')
    lines.push('')
    lines.push('As you apply these concepts, be aware of common mistakes that learners make:')
    lines.push('')
    lines.push(`1. **Oversimplification**: Reducing ${plan.keyConcepts[0] ?? 'complex ideas'} to simple rules without considering context. Always evaluate the specific situation before applying general principles.`)
    lines.push(`2. **Premature application**: Trying to use ${plan.keyConcepts[1] ?? 'advanced techniques'} before fully understanding the foundations. Take time to master each concept before moving on.`)
    lines.push(`3. **Ignoring trade-offs**: Every decision involves trade-offs. When applying ${plan.keyConcepts[2] ?? 'these concepts'}, consider what you gain and what you give up with each approach.`)
    lines.push('')
    lines.push('## Visual Reference')
    lines.push('')
    lines.push(`The following diagram illustrates the relationship between the key concepts of ${plan.title}:`)
    lines.push('')
    lines.push('```mermaid')
    lines.push(`flowchart TD`)
    lines.push(`    A[${plan.keyConcepts[0] ?? 'Concept A'}] --> B[${plan.keyConcepts[1] ?? 'Concept B'}]`)
    lines.push(`    B --> C[${plan.keyConcepts[2] ?? 'Concept C'}]`)
    lines.push(`    C --> D[Practical Application]`)
    lines.push(`    D --> E[Outcome]`)
    lines.push('```')
    lines.push('')
    lines.push(`This flowchart shows how ${plan.keyConcepts[0] ?? 'the first concept'} leads to ${plan.keyConcepts[1] ?? 'the second'}, which in turn enables ${plan.keyConcepts[2] ?? 'the third'}, culminating in practical application and measurable outcomes.`)
    lines.push('')
    lines.push('## Hands-on Exercise')
    lines.push('')
    lines.push(`**Exercise**: Apply the concepts of ${plan.title} to a real-world scenario related to ${plan.moduleTitle.toLowerCase()}.`)
    lines.push('')
    lines.push('**Instructions**:')
    lines.push(`1. Identify a concrete situation where ${plan.keyConcepts[0] ?? 'the key concept'} is relevant`)
    lines.push(`2. Analyze how ${plan.keyConcepts[1] ?? 'the second concept'} affects the situation`)
    lines.push(`3. Propose a solution using the three-step framework (identify, analyze, synthesize)`)
    lines.push(`4. Evaluate potential trade-offs of your proposed solution`)
    lines.push(`5. Document your reasoning and expected outcomes`)
    lines.push('')
    lines.push('**Solution**:')
    lines.push(`A well-structured solution would: (a) clearly identify the ${plan.keyConcepts[0] ?? 'core issue'} in context, (b) analyze the interaction of ${plan.keyConcepts.slice(1, 3).join(' and ')} on the outcome, (c) synthesize a solution that addresses the identified issue while acknowledging trade-offs, and (d) provide measurable success criteria. The solution demonstrates ${plan.bloomLevel}-level mastery by not just recalling facts but ${this.bloomAction(plan.bloomLevel)} the concepts in a novel context.`)
    lines.push('')
    lines.push('## Summary')
    lines.push('')
    lines.push(`In this lesson, we explored ${plan.title.toLowerCase()} within the context of ${plan.moduleTitle}. We covered ${plan.keyConcepts.length} key concepts, examined their practical applications, and identified common pitfalls to avoid. The lesson aimed to develop your ability to ${this.bloomAction(plan.bloomLevel)} these concepts in real scenarios.`)
    lines.push('')
    lines.push('## Key Takeaways')
    lines.push('')
    for (const concept of plan.keyConcepts) {
      lines.push(`- ${concept.charAt(0).toUpperCase() + concept.slice(1)} is a foundational element that requires both theoretical understanding and practical application.`)
    }
    lines.push(`- The three-step framework (identify, analyze, synthesize) provides a structured approach to problem-solving.`)
    lines.push(`- Awareness of common pitfalls helps you avoid mistakes and develop expertise more quickly.`)
    lines.push(`- Continuous practice and reflection are essential for mastery.`)
    lines.push('')
    return lines.join('\n')
  }

  private bloomAction(bloom: string): string {
    const map: Record<string, string> = {
      Remember: 'recall and recognize',
      Understand: 'explain and interpret',
      Apply: 'implement and use',
      Analyze: 'deconstruct and compare',
      Evaluate: 'judge and critique',
      Create: 'design and produce',
    }
    return map[bloom] ?? 'work with'
  }

  private expandConcept(concept: string, plan: LessonPlan, knowledgePack: KnowledgePack): string {
    const fact = knowledgePack.keyFacts.find((f) => f.toLowerCase().includes(concept.toLowerCase())) ?? knowledgePack.keyFacts[0] ?? `This concept plays a key role in ${plan.moduleTitle}.`
    return `${fact.charAt(0).toUpperCase() + fact.slice(1)} Understanding ${concept} requires attention to both its theoretical underpinnings and its practical manifestations.`
  }

  private assembleLesson(
    plan: LessonPlan,
    content: string,
    wordCount: number,
    provider: Provider,
    model: string,
  ): Lesson {
    const now = new Date().toISOString()
    return {
      id: makeId('lesson'),
      version: ENGINE_VERSION,
      createdAt: now,
      updatedAt: now,
      generatorVersion: ENGINE_VERSION,
      provider,
      model,
      runtimeVersion: RUNTIME_VERSION,
      lessonPlanId: plan.id,
      moduleId: plan.moduleId,
      moduleTitle: plan.moduleTitle,
      lessonIndex: plan.lessonIndex,
      title: plan.title,
      content,
      wordCount,
      learningObjectives: plan.learningObjectives,
      keyTakeaways: [
        `Mastery of ${plan.keyConcepts[0] ?? 'key concepts'} is essential`,
        `The three-step framework supports structured problem-solving`,
        `Awareness of pitfalls accelerates learning`,
      ],
      durationMinutes: plan.durationMinutes,
      bloomLevel: plan.bloomLevel,
    }
  }
}
