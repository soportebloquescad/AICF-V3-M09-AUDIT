// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — ArtifactRepository (universal)
// =============================================================================
// The universal in-memory repository for generated artifact packages.
//
// Stores ArtifactPackage instances keyed by ID. Supports save, load, list,
// delete, findByType, findByStatus.
//
// ALIAS: This class is also exported as `CourseRepository` for backward
// compatibility with code that referenced a course-specific repository.
// The alias points to the SAME class — there is only one implementation.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// It does NOT touch src/lib/db/repositories/CourseRepository.ts (the Prisma
// DB layer) — that file has a different responsibility (DB records) and
// remains untouched.
// =============================================================================

import type { ArtifactPackage } from '../contracts/ArtifactPackage'
import { logger } from '@/lib/ai/logger'

/**
 * The status of a stored artifact.
 */
export type ArtifactStatus = 'pending' | 'generating' | 'completed' | 'failed'

/**
 * A stored artifact entry — the package plus its status and timestamps.
 */
export interface ArtifactEntry {
  /** The artifact package. */
  package: ArtifactPackage
  /** The artifact's current status. */
  status: ArtifactStatus
  /** ISO timestamp when the entry was created. */
  createdAt: string
  /** ISO timestamp when the entry was last updated. */
  updatedAt: string
}

/**
 * The universal in-memory repository for artifact packages.
 *
 * Stores packages keyed by ID. Supports querying by type and status.
 *
 * This is the SINGLE implementation. `CourseRepository` is an alias that
 * points to this class — there is no separate course repository.
 *
 * Usage:
 *   const repo = new ArtifactRepository()
 *   repo.save(pkg, 'completed')
 *   const loaded = repo.load(pkg.id)
 *   const courses = repo.findByType('course')
 */
export class ArtifactRepository {
  private readonly entries = new Map<string, ArtifactEntry>()
  private readonly log = logger.child({ component: 'ArtifactRepository' })

  /**
   * Saves (or updates) an artifact package.
   *
   * @param pkg    - The artifact package to store.
   * @param status - The artifact status (defaults to 'completed').
   */
  save(pkg: ArtifactPackage, status: ArtifactStatus = 'completed'): void {
    const now = new Date().toISOString()
    const existing = this.entries.get(pkg.id)
    this.entries.set(pkg.id, {
      package: pkg,
      status,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    })
    this.log.info({ artifactId: pkg.id, type: pkg.type, status }, 'ArtifactRepository: saved')
  }

  /**
   * Loads an artifact package by ID.
   * @returns The package, or null if not found.
   */
  load(id: string): ArtifactPackage | null {
    return this.entries.get(id)?.package ?? null
  }

  /**
   * Loads a full artifact entry (with status + timestamps) by ID.
   * @returns The entry, or null if not found.
   */
  loadEntry(id: string): ArtifactEntry | null {
    return this.entries.get(id) ?? null
  }

  /**
   * Lists all stored artifact packages.
   */
  list(): ArtifactPackage[] {
    return Array.from(this.entries.values()).map((e) => e.package)
  }

  /**
   * Lists all stored artifact entries (with status + timestamps).
   */
  listEntries(): ArtifactEntry[] {
    return Array.from(this.entries.values())
  }

  /**
   * Deletes an artifact by ID.
   * @returns true if the artifact was found and removed.
   */
  delete(id: string): boolean {
    const removed = this.entries.delete(id)
    if (removed) {
      this.log.info({ artifactId: id }, 'ArtifactRepository: deleted')
    }
    return removed
  }

  /**
   * Finds all artifacts of a given type.
   *
   * @param type - The artifact type (e.g. 'course', 'ebook', 'presentation').
   */
  findByType(type: string): ArtifactPackage[] {
    return Array.from(this.entries.values())
      .filter((e) => e.package.type === type)
      .map((e) => e.package)
  }

  /**
   * Finds all artifacts with a given status.
   *
   * @param status - The artifact status (e.g. 'completed', 'failed').
   */
  findByStatus(status: ArtifactStatus): ArtifactPackage[] {
    return Array.from(this.entries.values())
      .filter((e) => e.status === status)
      .map((e) => e.package)
  }

  /**
   * Returns whether an artifact with the given ID exists.
   */
  has(id: string): boolean {
    return this.entries.has(id)
  }

  /**
   * Returns the number of stored artifacts.
   */
  size(): number {
    return this.entries.size
  }

  /**
   * Clears all stored artifacts.
   */
  clear(): void {
    this.entries.clear()
    this.log.info('ArtifactRepository: cleared')
  }
}

/**
 * Backward-compatibility alias.
 *
 * `CourseRepository` is the SAME class as `ArtifactRepository`. Code that
 * referenced a course-specific repository can use this alias without any
 * changes. There is only ONE implementation.
 */
export const CourseRepository = ArtifactRepository
