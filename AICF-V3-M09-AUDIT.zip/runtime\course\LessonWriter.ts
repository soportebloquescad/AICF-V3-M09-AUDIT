// =============================================================================
// AICF V3 — Épica 6 — Lesson Writer
// =============================================================================
import { ContentGenerator, type GeneratedContent } from './ContentGenerator'

export class LessonWriter {
  constructor(private readonly opts: { contentGenerator: ContentGenerator }) {}

  async writeLesson(input: {
    topic: string
    moduleTitle: string
    lessonTitle: string
    level: string
    bloomLevel: string
    length: string
    locale: string
    terminology?: Record<string, string>
  }): Promise<GeneratedContent> {
    return this.opts.contentGenerator.generateLesson(input)
  }

  async writeLessons(input: {
    topic: string
    modules: Array<{ title: string; lessons: Array<{ title: string }> }>
    level: string
    locale: string
  }): Promise<GeneratedContent[]> {
    const results: GeneratedContent[] = []
    for (const mod of input.modules) {
      for (const lesson of mod.lessons) {
        results.push(await this.writeLesson({
          topic: input.topic,
          moduleTitle: mod.title,
          lessonTitle: lesson.title,
          level: input.level,
          bloomLevel: 'Understand',
          length: 'standard',
          locale: input.locale,
        }))
      }
    }
    return results
  }
}
