// =============================================================================
// AICF V3 — Pipeline Stage
// =============================================================================
// A single stage in the Runtime pipeline. Each stage receives a
// RuntimeContext and returns it (possibly modified).
// Stages must never throw — they record errors in context.errors.
// =============================================================================

import type { RuntimeContext } from '../contracts/RuntimeContext'

/**
 * A function that processes a RuntimeContext.
 * Must return the same context (mutated or not).
 */
export type PipelineStageFn = (ctx: RuntimeContext) => Promise<RuntimeContext>

/**
 * A named pipeline stage.
 */
export interface PipelineStage {
  /** Stage name (e.g., "Validate", "Policy"). */
  name: string

  /** The function that processes the context. */
  execute: PipelineStageFn
}

/**
 * Factory: creates a PipelineStage from a name and function.
 */
export function createPipelineStage(name: string, execute: PipelineStageFn): PipelineStage {
  return Object.freeze({ name, execute })
}
