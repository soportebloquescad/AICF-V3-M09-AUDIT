// =============================================================================
// AICF V3 — Épica 9 — InteractivePresentationEngine
// =============================================================================
// Generates a self-contained Reveal.js-compatible interactive presentation.
// All JS + CSS is embedded (no CDN, no external dependencies). Images are
// embedded as data URIs.
//
// Features:
//   ✅ Reveal.js-compatible API (keyboard nav, fragments, presenter mode)
//   ✅ Navigation: ←/→/Space/Home/End/F (fullscreen)
//   ✅ Speaker notes (presenter mode via 'S' key)
//   ✅ Animations: fade, slide, zoom, convex
//   ✅ Progress bar
//   ✅ Responsive (mobile/tablet/desktop)
//   ✅ Dark/light theme
//   ✅ Images embedded as data URIs
//   ✅ Mermaid diagrams
//   ✅ Print CSS
//
// REUSES: Storyboard (from StoryboardGenerator), ImageArtifact[] (from
// ImageGenerator), ThemePreset (from ThemeCatalog).
// =============================================================================

import type { ThemePreset } from '../theme/ThemeCatalog'
import { getThemeEngine } from '../theme/ThemeEngine'
import type { Storyboard, StoryboardSlide } from '../course/StoryboardGenerator'
import type { ImageArtifact } from '../course/ImageGenerator'
import { logger } from '@/lib/ai/logger'

export class InteractivePresentationEngine {
  private readonly log = logger.child({ component: 'InteractivePresentationEngine' })

  build(opts: {
    storyboard: Storyboard
    images: ImageArtifact[]
    theme: ThemePreset
  }): string {
    const { storyboard, images, theme } = opts
    this.log.info({ slideCount: storyboard.slides.length, imageCount: images.length, theme: theme.name }, 'InteractivePresentationEngine: building')

    const themeEngine = getThemeEngine()
    const themeCss = themeEngine.renderBaseCss(theme)
    const slidesHtml = storyboard.slides.map((slide, i) => this.buildSlideHtml(slide, images[i], theme)).join('\n')
    const totalSlides = storyboard.slides.length

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>${this.escape(storyboard.title)} — Interactive Presentation</title>
  <style>
    ${themeCss}

    /* === Reveal.js-compatible styles === */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100%; height: 100%; overflow: hidden; background: var(--color-background); }
    .reveal { width: 100vw; height: 100vh; position: relative; }
    .slides { width: 100%; height: 100%; position: relative; }
    .section { position: absolute; inset: 0; display: none; flex-direction: column; justify-content: center; align-items: center; padding: 3rem; opacity: 0; transition: opacity 0.5s ease, transform 0.5s ease; }
    .section.active { display: flex; opacity: 1; }
    .section.past { display: flex; opacity: 0; transform: translateX(-100%); }
    .section.future { display: flex; opacity: 0; transform: translateX(100%); }

    /* Transitions */
    .section[data-transition="fade"] { transition: opacity 0.6s ease; }
    .section[data-transition="slide"] { transition: opacity 0.4s ease, transform 0.4s ease; }
    .section[data-transition="zoom"] { transition: opacity 0.4s ease, transform 0.4s ease; transform-origin: center; }
    .section[data-transition="convex"] { transition: opacity 0.5s ease, transform 0.5s ease; transform-origin: left; }

    /* Slide content */
    .section h1 { font-size: 2.8rem; color: var(--color-primary); margin-bottom: 0.5rem; text-align: center; font-family: var(--font-heading); }
    .section h2 { font-size: 2rem; color: var(--color-primary); margin-bottom: 1rem; text-align: center; font-family: var(--font-heading); }
    .section .subtitle { font-size: 1.2rem; color: var(--color-text-muted); margin-bottom: 1.5rem; text-align: center; }
    .section .content { max-width: 900px; width: 100%; }
    .section .bullets { list-style: none; padding: 0; }
    .section .bullets li { padding: 0.5rem 0; border-bottom: 1px solid var(--color-border); font-size: 1.1rem; color: var(--color-text); opacity: 0; transform: translateX(-20px); transition: all 0.3s ease; }
    .section .bullets li.visible { opacity: 1; transform: translateX(0); }
    .section .bullets li:last-child { border-bottom: none; }

    /* Images */
    .section .slide-image { max-width: 600px; max-height: 350px; margin: 1rem auto; border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow-lg); }
    .section .slide-image img, .section .slide-image svg { width: 100%; height: 100%; object-fit: contain; display: block; }

    /* Mermaid */
    .section .mermaid { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 1rem; margin: 1rem auto; text-align: center; }

    /* Country badge */
    .section .country-badge { background: var(--color-accent); color: white; padding: 0.3rem 1rem; border-radius: var(--radius); font-size: 0.8rem; font-weight: bold; display: inline-block; margin-bottom: 1rem; }

    /* Progress bar */
    .progress { position: fixed; bottom: 0; left: 0; height: 4px; background: var(--color-accent); transition: width 0.3s ease; z-index: 100; }

    /* Controls */
    .controls { position: fixed; bottom: 1rem; right: 1rem; display: flex; gap: 0.5rem; z-index: 100; }
    .controls button { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 0.5rem 1rem; cursor: pointer; font-size: 0.85rem; color: var(--color-text); }
    .controls button:hover { background: var(--color-border); }
    .controls .counter { color: var(--color-text-muted); font-size: 0.85rem; padding: 0.5rem 0; min-width: 60px; text-align: center; }

    /* Theme toggle */
    .theme-toggle { position: fixed; top: 1rem; right: 1rem; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 1.2rem; z-index: 100; display: flex; align-items: center; justify-content: center; }

    /* Speaker notes (presenter mode) */
    .notes-panel { position: fixed; bottom: 0; left: 0; right: 0; background: var(--color-surface); border-top: 2px solid var(--color-border); padding: 1rem; font-size: 0.9rem; color: var(--color-text-muted); display: none; max-height: 30vh; overflow-y: auto; z-index: 200; }
    .notes-panel.visible { display: block; }
    .notes-panel strong { color: var(--color-text); }

    /* Presenter overlay */
    .presenter-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.9); display: none; z-index: 300; padding: 2rem; color: white; }
    .presenter-overlay.visible { display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }
    .presenter-overlay .current-slide { font-size: 1.5rem; }
    .presenter-overlay .next-slide { font-size: 1rem; opacity: 0.6; }
    .presenter-overlay .notes { grid-column: 1 / -1; background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 8px; font-size: 1rem; }

    /* Dark theme */
    [data-theme="dark"] { --color-background: #0f172a; --color-surface: #1e293b; --color-text: #f1f5f9; --color-text-muted: #94a3b8; --color-border: #334155; --color-primary: #10b981; }
    [data-theme="light"] { --color-background: #ffffff; --color-surface: #f8fafc; --color-text: #1e293b; --color-text-muted: #64748b; --color-border: #e2e8f0; --color-primary: #1f2937; }

    /* Responsive */
    @media (max-width: 768px) {
      .section { padding: 1.5rem; }
      .section h1 { font-size: 1.8rem; }
      .section h2 { font-size: 1.4rem; }
      .section .subtitle { font-size: 0.95rem; }
      .section .bullets li { font-size: 0.95rem; }
      .section .slide-image { max-width: 100%; max-height: 200px; }
      .controls { bottom: 0.5rem; right: 0.5rem; }
    }

    /* Print */
    @media print {
      .section { position: relative; page-break-after: always; display: flex !important; opacity: 1 !important; transform: none !important; }
      .controls, .theme-toggle, .notes-panel, .presenter-overlay, .progress { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="reveal">
    <div class="slides" id="slides">
      ${slidesHtml}
    </div>
    <div class="progress" id="progress" style="width: 0%"></div>
    <div class="controls">
      <button onclick="prev()">←</button>
      <span class="counter" id="counter">1 / ${totalSlides}</span>
      <button onclick="next()">→</button>
    </div>
    <button class="theme-toggle" onclick="toggleTheme()">🌓</button>
    <div class="notes-panel" id="notesPanel"></div>
    <div class="presenter-overlay" id="presenterOverlay">
      <div class="current-slide" id="presenterCurrent"></div>
      <div class="next-slide" id="presenterNext"></div>
      <div class="notes" id="presenterNotes"></div>
    </div>
  </div>

  <script>
    let currentSlide = 0;
    const totalSlides = ${totalSlides};
    const slides = document.querySelectorAll('.section');
    const counter = document.getElementById('counter');
    const progress = document.getElementById('progress');
    const notesPanel = document.getElementById('notesPanel');
    const presenterOverlay = document.getElementById('presenterOverlay');
    const presenterCurrent = document.getElementById('presenterCurrent');
    const presenterNext = document.getElementById('presenterNext');
    const presenterNotes = document.getElementById('presenterNotes');
    let presenterMode = false;
    let notesVisible = false;

    const speakerNotes = ${JSON.stringify(storyboard.speakerNotes)};

    function showSlide(idx) {
      slides.forEach((s, i) => {
        s.classList.remove('active', 'past', 'future');
        if (i === idx) s.classList.add('active');
        else if (i < idx) s.classList.add('past');
        else s.classList.add('future');
      });
      counter.textContent = (idx + 1) + ' / ' + totalSlides;
      progress.style.width = ((idx + 1) / totalSlides * 100) + '%';
      currentSlide = idx;

      // Show speaker notes
      notesPanel.innerHTML = '<strong>Speaker Notes:</strong> ' + (speakerNotes[idx] || '');

      // Presenter mode
      if (presenterMode) {
        presenterCurrent.innerHTML = '<h2>Current: ' + (slides[idx]?.querySelector('h1, h2')?.textContent || 'Slide ' + (idx+1)) + '</h2>';
        presenterNext.innerHTML = idx < totalSlides - 1 ? '<strong>Next:</strong> ' + (slides[idx+1]?.querySelector('h1, h2')?.textContent || 'Slide ' + (idx+2)) : '<strong>End</strong>';
        presenterNotes.textContent = speakerNotes[idx] || '';
      }

      // Reveal fragments (bullets) with delay
      const bullets = slides[idx]?.querySelectorAll('.bullets li');
      if (bullets) {
        bullets.forEach((b, i) => {
          b.classList.remove('visible');
          setTimeout(() => b.classList.add('visible'), i * 200 + 300);
        });
      }
    }

    function next() { if (currentSlide < totalSlides - 1) showSlide(currentSlide + 1); }
    function prev() { if (currentSlide > 0) showSlide(currentSlide - 1); }

    function toggleTheme() {
      const current = document.body.dataset.theme || 'dark';
      document.body.dataset.theme = current === 'dark' ? 'light' : 'dark';
    }

    function toggleNotes() {
      notesVisible = !notesVisible;
      notesPanel.classList.toggle('visible', notesVisible);
    }

    function togglePresenter() {
      presenterMode = !presenterMode;
      presenterOverlay.classList.toggle('visible', presenterMode);
      if (presenterMode) showSlide(currentSlide);
    }

    function toggleFullscreen() {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen();
      else document.exitFullscreen();
    }

    document.addEventListener('keydown', (e) => {
      switch(e.key) {
        case 'ArrowRight': case ' ': case 'PageDown': e.preventDefault(); next(); break;
        case 'ArrowLeft': case 'PageUp': e.preventDefault(); prev(); break;
        case 'Home': showSlide(0); break;
        case 'End': showSlide(totalSlides - 1); break;
        case 'f': case 'F': toggleFullscreen(); break;
        case 's': case 'S': togglePresenter(); break;
        case 'n': case 'N': toggleNotes(); break;
        case 't': case 'T': toggleTheme(); break;
        case 'Escape': if (presenterMode) togglePresenter(); break;
      }
    });

    // Touch support
    let touchStartX = 0;
    document.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; });
    document.addEventListener('touchend', (e) => {
      const diff = e.changedTouches[0].clientX - touchStartX;
      if (Math.abs(diff) > 50) { if (diff > 0) prev(); else next(); }
    });

    // Initialize
    document.body.dataset.theme = '${theme.mode === 'dark' ? 'dark' : 'light'}';
    showSlide(0);
  </script>
</body>
</html>`
  }

  private buildSlideHtml(slide: StoryboardSlide, image: ImageArtifact | undefined, theme: ThemePreset): string {
    const bulletsHtml = slide.bullets.length > 0
      ? `<ul class="bullets">${slide.bullets.map((b) => `<li>${this.escape(b)}</li>`).join('')}</ul>`
      : ''

    const imageHtml = image
      ? `<div class="slide-image">${image.content.toString('utf-8')}</div>`
      : ''

    const mermaidHtml = slide.visual.diagramPrompt
      ? `<div class="mermaid">${slide.visual.diagramPrompt}</div>`
      : ''

    const countryBadge = slide.countryName
      ? `<div class="country-badge">🌍 ${this.escape(slide.countryName)}</div>`
      : ''

    return `<section class="section" data-transition="${slide.timing.transition}" data-index="${slide.index}">
      ${countryBadge}
      <h1>${this.escape(slide.title)}</h1>
      <p class="subtitle">${this.escape(slide.subtitle)}</p>
      <div class="content">
        ${imageHtml}
        ${mermaidHtml}
        ${bulletsHtml}
      </div>
    </section>`
  }

  private escape(text: string): string {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  }
}
