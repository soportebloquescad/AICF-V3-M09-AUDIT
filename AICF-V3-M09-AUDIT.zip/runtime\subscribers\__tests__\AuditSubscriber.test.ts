// =============================================================================
// AICF V3 — AuditSubscriber Tests (Sprint 22: PR 2 — Observability subscribers)
// =============================================================================
// Verifies:
//   - onEvent() records exactly one AuditEntry to the AuditProvider
//   - The recorded entry maps envelope fields correctly:
//       requestId ← metadata.requestId
//       action    ← metadata.pipelineStage
//       module    ← metadata.pipelineStage
//       details   ← { eventId, stageOrder, operation, correlationId, payload }
//   - onEvent() never throws — AuditProvider errors are caught + swallowed
//   - isReady() returns false before initialize(), true after
//   - createAuditSubscriber() returns an AuditSubscriber instance
//
// No `any`. Uses the real InMemoryAuditProvider + a custom throwing fake to
// validate the best-effort contract. Uses `testModule` not `module` per
// project conventions.
// =============================================================================

import { describe, it, expect, beforeEach } from 'bun:test'
import { AuditSubscriber, createAuditSubscriber } from '../AuditSubscriber'
import { InMemoryAuditProvider, type AuditProvider, type AuditEntry } from '../../audit/AuditProvider'
import { createEventMetadata, createEnvelope, type RuntimeEventEnvelope } from '../../events/EventMetadata'

/**
 * Helper: builds an envelope with sensible defaults for tests.
 * `testModule` is the pipeline stage that emitted the event.
 */
function makeEnvelope(
  overrides: Partial<{
    requestId: string
    correlationId: string
    operation: string
    pipelineStage: string
    stageOrder: number
    durationMs: number
    payload: Record<string, unknown>
  }> = {},
): RuntimeEventEnvelope<Record<string, unknown>> {
  const meta = createEventMetadata({
    correlationId: overrides.correlationId ?? 'cor-1',
    requestId: overrides.requestId ?? 'req-1',
    operation: overrides.operation ?? 'chat',
    pipelineStage: overrides.pipelineStage ?? 'Policy',
    stageOrder: overrides.stageOrder ?? 4,
    durationMs: overrides.durationMs,
  })
  return createEnvelope(meta, overrides.payload ?? { allowed: true })
}

/**
 * Fake AuditProvider that always throws from record() — used to verify the
 * subscriber's best-effort contract (never throws out of onEvent).
 */
class ThrowingAuditProvider implements AuditProvider {
  async record(): Promise<AuditEntry> {
    throw new Error('synthetic record() failure')
  }
  async query(): Promise<AuditEntry[]> {
    return []
  }
  count(): number {
    return 0
  }
}

/**
 * Fake AuditProvider that records every call's arguments — used to verify
 * the exact shape of the entry passed to record().
 */
class RecordingAuditProvider implements AuditProvider {
  readonly recorded: Array<Omit<AuditEntry, 'id' | 'timestamp'>> = []

  async record(entry: Omit<AuditEntry, 'id' | 'timestamp'>): Promise<AuditEntry> {
    this.recorded.push(entry)
    return {
      ...entry,
      id: `audit-${this.recorded.length}`,
      timestamp: new Date().toISOString(),
    }
  }
  async query(): Promise<AuditEntry[]> {
    return []
  }
  count(): number {
    return this.recorded.length
  }
}

describe('AuditSubscriber (Sprint 22: PR 2)', () => {
  let auditProvider: InMemoryAuditProvider

  beforeEach(() => {
    auditProvider = new InMemoryAuditProvider()
  })

  // -------------------------------------------------------------------------
  // isReady()
  // -------------------------------------------------------------------------
  describe('isReady()', () => {
    it('returns false before initialize()', () => {
      const sub = new AuditSubscriber(auditProvider)
      expect(sub.isReady()).toBe(false)
    })

    it('returns true after initialize()', async () => {
      const sub = new AuditSubscriber(auditProvider)
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })

    it('initialize() is idempotent', async () => {
      const sub = new AuditSubscriber(auditProvider)
      await sub.initialize()
      await sub.initialize()
      expect(sub.isReady()).toBe(true)
    })
  })

  // -------------------------------------------------------------------------
  // onEvent() — recording behavior
  // -------------------------------------------------------------------------
  describe('onEvent() records to AuditProvider', () => {
    it('records one AuditEntry per event', async () => {
      const sub = new AuditSubscriber(auditProvider)
      await sub.initialize()

      await sub.onEvent(makeEnvelope())
      expect(auditProvider.count()).toBe(1)

      await sub.onEvent(makeEnvelope({ requestId: 'req-2' }))
      expect(auditProvider.count()).toBe(2)
    })

    it('maps metadata.requestId → entry.requestId', async () => {
      const sub = new AuditSubscriber(auditProvider)
      await sub.initialize()
      await sub.onEvent(makeEnvelope({ requestId: 'req-abc' }))

      const entries = await auditProvider.query({ requestId: 'req-abc' })
      expect(entries.length).toBe(1)
      expect(entries[0].requestId).toBe('req-abc')
    })

    it('maps metadata.pipelineStage → entry.action AND entry.module', async () => {
      const sub = new AuditSubscriber(auditProvider)
      await sub.initialize()
      const testModule = 'Routing'
      await sub.onEvent(makeEnvelope({ pipelineStage: testModule }))

      const entries = await auditProvider.query({ module: testModule })
      expect(entries.length).toBe(1)
      expect(entries[0].action).toBe(testModule)
      expect(entries[0].module).toBe(testModule)
    })

    it('packs details with { eventId, stageOrder, operation, correlationId, payload }', async () => {
      const recorder = new RecordingAuditProvider()
      const sub = new AuditSubscriber(recorder)
      await sub.initialize()

      const payload = { allowed: true, reason: 'policy-ok' }
      await sub.onEvent(
        makeEnvelope({
          requestId: 'req-9',
          correlationId: 'cor-9',
          operation: 'generate',
          pipelineStage: 'Policy',
          stageOrder: 4,
          payload,
        }),
      )

      expect(recorder.recorded.length).toBe(1)
      const entry = recorder.recorded[0]
      expect(entry.requestId).toBe('req-9')
      expect(entry.action).toBe('Policy')
      expect(entry.module).toBe('Policy')
      const details = entry.details as Record<string, unknown>
      expect(typeof details.eventId).toBe('string')
      expect(details.eventId).toMatch(/^[0-9a-f-]+$/i)
      expect(details.stageOrder).toBe(4)
      expect(details.operation).toBe('generate')
      expect(details.correlationId).toBe('cor-9')
      expect(details.payload).toEqual(payload)
    })

    it('forwards the payload reference unchanged', async () => {
      const recorder = new RecordingAuditProvider()
      const sub = new AuditSubscriber(recorder)
      await sub.initialize()

      const payload = { ok: true, count: 3 }
      await sub.onEvent(makeEnvelope({ payload }))
      const details = recorder.recorded[0].details as Record<string, unknown>
      expect(details.payload).toBe(payload)
    })
  })

  // -------------------------------------------------------------------------
  // onEvent() — error handling (best-effort, never throws)
  // -------------------------------------------------------------------------
  describe('onEvent() error handling', () => {
    it('swallows errors from auditProvider.record() — does NOT throw', async () => {
      const throwingProvider = new ThrowingAuditProvider()
      const sub = new AuditSubscriber(throwingProvider)
      await sub.initialize()

      // The promise should resolve, not reject — best-effort contract.
      await expect(sub.onEvent(makeEnvelope())).resolves.toBeUndefined()
    })

    it('continues processing subsequent events after a failure', async () => {
      // Use a provider that throws on the first call, succeeds on subsequent
      // calls. We can't easily flip behavior on the InMemory provider, so
      // use a stateful fake.
      let callCount = 0
      const flakyProvider: AuditProvider = {
        async record(entry) {
          callCount++
          if (callCount === 1) throw new Error('first call fails')
          return { ...entry, id: `id-${callCount}`, timestamp: new Date().toISOString() }
        },
        async query() {
          return []
        },
        count() {
          return Math.max(0, callCount - 1)
        },
      }

      const sub = new AuditSubscriber(flakyProvider)
      await sub.initialize()

      await sub.onEvent(makeEnvelope()) // throws internally, swallowed
      await sub.onEvent(makeEnvelope({ requestId: 'req-2' })) // succeeds
      await sub.onEvent(makeEnvelope({ requestId: 'req-3' })) // succeeds

      // Two successful records after the initial failure.
      expect(callCount).toBe(3)
    })

    it('does not propagate errors from onEvent to the caller', async () => {
      const throwingProvider = new ThrowingAuditProvider()
      const sub = new AuditSubscriber(throwingProvider)
      await sub.initialize()

      // Try/catch wrapper to verify the promise resolves cleanly.
      let threw = false
      try {
        await sub.onEvent(makeEnvelope())
      } catch {
        threw = true
      }
      expect(threw).toBe(false)
    })
  })

  // -------------------------------------------------------------------------
  // createAuditSubscriber() factory
  // -------------------------------------------------------------------------
  describe('createAuditSubscriber() factory', () => {
    it('returns an AuditSubscriber instance', () => {
      const sub = createAuditSubscriber(auditProvider)
      expect(sub).toBeInstanceOf(AuditSubscriber)
    })

    it('binds to the provided auditProvider', async () => {
      const sub = createAuditSubscriber(auditProvider)
      await sub.initialize()
      await sub.onEvent(makeEnvelope())
      expect(auditProvider.count()).toBe(1)
    })

    it('factory result name is "audit-subscriber"', () => {
      const sub = createAuditSubscriber(auditProvider)
      expect(sub.name).toBe('audit-subscriber')
    })
  })
})
