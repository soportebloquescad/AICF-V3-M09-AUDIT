// =============================================================================
// AICF V3 — Research Agent
// =============================================================================
// Researches the course topic to surface key facts and a summary that
// downstream agents use to ground their outputs. When the AI adapter is
// unavailable, produces a deterministic research brief with 6+ key facts
// drawn from the topic and audience.
// =============================================================================

import type { AIAdapter } from '@/lib/ai/AIAdapter'
import type { Agent, AgentInput, AgentOutput } from '../AgentCoordinator'
import { callAI, elapsedMs, errorToString, extractJSON, normalizeLevel } from './agentUtils'

export interface ResearchAgentDeps {
  aiAdapter: AIAdapter | null
}

interface ResearchPayload {
  topic: string
  keyFacts: string[]
  summary: string
  confidence: number
}

export class ResearchAgent implements Agent {
  public readonly name = 'research-agent'

  constructor(private readonly deps: ResearchAgentDeps) {}

  async execute(input: AgentInput): Promise<AgentOutput> {
    const start = Date.now()
    try {
      const ai = this.deps.aiAdapter
      const aiResult = await callAI(ai, buildPrompt(input), {
        systemPrompt:
          'You are an expert instructional researcher. Respond with valid JSON only, no prose.',
        temperature: 0.3,
        maxTokens: 1200,
      })

      let research: ResearchPayload
      if (aiResult.ok && aiResult.content) {
        const parsed = extractJSON<Partial<ResearchPayload>>(aiResult.content)
        if (parsed && Array.isArray(parsed.keyFacts) && parsed.keyFacts.length >= 3) {
          research = {
            topic: typeof parsed.topic === 'string' ? parsed.topic : input.topic,
            keyFacts: parsed.keyFacts.filter((f): f is string => typeof f === 'string'),
            summary:
              typeof parsed.summary === 'string' && parsed.summary.length > 0
                ? parsed.summary
                : fallbackSummary(input),
            confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 0.85,
          }
        } else {
          research = fallbackResearch(input)
        }
      } else {
        research = fallbackResearch(input)
      }

      return {
        agentName: this.name,
        result: { research },
        durationMs: elapsedMs(start),
        success: true,
      }
    } catch (err) {
      return {
        agentName: this.name,
        result: {},
        durationMs: elapsedMs(start),
        success: false,
        error: errorToString(err),
      }
    }
  }
}

function buildPrompt(input: AgentInput): string {
  return [
    `Research the topic "${input.topic}" for a course aimed at ${input.audience} at the ${input.level} level.`,
    `Locale: ${input.locale}.`,
    ``,
    `Return JSON with this exact shape and nothing else:`,
    `{`,
    `  "topic": string,`,
    `  "keyFacts": string[],   // at least 6 concise, accurate facts`,
    `  "summary": string,      // 3-5 sentence overview`,
    `  "confidence": number    // 0.0 to 1.0`,
    `}`,
  ].join('\n')
}

function fallbackSummary(input: AgentInput): string {
  const level = normalizeLevel(input.level)
  return `${input.topic} is a subject that combines conceptual foundations with applied practice. For ${input.audience} working at the ${level} level, the most valuable entry points are the core principles, common workflows, and measurable outcomes that define the field. This course builds a structured path from fundamentals to applied competence, with explicit checkpoints for mastery.`
}

function fallbackResearch(input: AgentInput): ResearchPayload {
  const topic = input.topic
  return {
    topic,
    keyFacts: [
      `${topic} is a discipline grounded in both theoretical frameworks and applied practice.`,
      `The historical evolution of ${topic} has shaped contemporary methods, terminology, and standards.`,
      `Core principles of ${topic} include conceptual models, procedural techniques, and measurable outcomes.`,
      `Practitioners of ${topic} rely on established workflows and continuous skill refinement.`,
      `Common challenges in ${topic} involve balancing rigor against practical constraints such as time, cost, and resources.`,
      `Emerging trends in ${topic} reflect technological progress and evolving industry expectations.`,
      `${topic} connects to adjacent fields through shared concepts, tools, and professional practices.`,
    ],
    summary: fallbackSummary(input),
    confidence: 0.7,
  }
}
