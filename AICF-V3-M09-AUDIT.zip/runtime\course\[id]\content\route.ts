// =============================================================================
// AICF V3 — Épica 7 — GET /api/runtime/course/[id]/content
// =============================================================================
// Thin Route Handler: returns generated content artifacts from
// CourseArtifactRegistry. Supports ?type= filter and ?format= filter.
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import { CourseArtifactRegistry } from '@/lib/runtime/course/CourseArtifactRegistry'
import { logger } from '@/lib/ai/logger'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const reqLogger = logger.child({ endpoint: `/api/runtime/course/${id}/content`, method: 'GET' })

  const typeFilter = request.nextUrl.searchParams.get('type')
  const formatFilter = request.nextUrl.searchParams.get('format')
  const artifactId = request.nextUrl.searchParams.get('artifactId')

  try {
    let artifacts = await CourseArtifactRegistry.listByProject(id)

    // Filter by type if requested
    if (typeFilter) {
      artifacts = artifacts.filter((a) => a.type === typeFilter)
    }

    // Filter by format if requested
    if (formatFilter) {
      artifacts = artifacts.filter((a) => a.format === formatFilter)
    }

    // Return a single artifact's content if artifactId is specified
    if (artifactId) {
      const artifact = artifacts.find((a) => a.artifactId === artifactId)
      if (!artifact) {
        return NextResponse.json({ error: 'Artifact not found' }, { status: 404 })
      }
      const content = artifact.content.toString('utf-8')
      return new NextResponse(content, {
        status: 200,
        headers: {
          'Content-Type': artifact.format === 'html' ? 'text/html' : artifact.format === 'json' ? 'application/json' : 'text/plain',
          'Content-Disposition': `inline; filename="${artifact.name}"`,
        },
      })
    }

    if (artifacts.length === 0) {
      return NextResponse.json(
        { error: 'No content found for this course', courseId: id },
        { status: 404 },
      )
    }

    reqLogger.info({ courseId: id, artifactCount: artifacts.length, typeFilter, formatFilter }, 'Content retrieved')

    return NextResponse.json({
      courseId: id,
      artifactCount: artifacts.length,
      artifacts: artifacts.map((a) => ({
        artifactId: a.artifactId,
        type: a.type,
        format: a.format,
        name: a.name,
        sizeBytes: a.sizeBytes,
        sha256: a.sha256,
        createdAt: a.createdAt,
        preview: a.content.toString('utf-8').slice(0, 500),
        contentUrl: `/api/runtime/course/${id}/content?artifactId=${a.artifactId}`,
      })),
    })
  } catch (err) {
    reqLogger.error(
      { error: err instanceof Error ? err.message : String(err) },
      'Failed to get content',
    )
    return NextResponse.json(
      { error: 'Failed to get content' },
      { status: 500 },
    )
  }
}
