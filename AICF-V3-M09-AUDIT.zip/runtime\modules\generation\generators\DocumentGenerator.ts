// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Document Generator
// =============================================================================
// Concrete `IGenerator` implementation for the "document" content category.
// Produces a finished document (title + description + outline + Markdown
// sections) by orchestrating two AI adapter calls — one for the outline and
// one for the section bodies. Mirrors the prompt strategy of the legacy
// `CourseWorker` pattern, specialized for long-form documents, and emits
// `WorkflowArtifact` entries ready for the artifact store.
//
// Sprint 13+14 spec requirements covered:
//   - Implements `IGenerator` (uniform generator contract)
//   - `generatorType = 'document'` (registry dispatch key)
//   - `canHandle('document')` returns true
//   - Returns `GeneratorOutput` with content, modules (sections), outline,
//     title, description, artifacts, and provider/model/token attribution
//   - Emits typed `WorkflowArtifact`s via `createArtifact`
// =============================================================================

import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type {
  GeneratorInput,
  GeneratorOutput,
  GeneratorType,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  TokenUsage,
  WorkflowArtifact,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { createArtifact } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Per-token cost estimate (platform currency units). */
const COST_PER_TOKEN = 0.000_002

/** Default model when neither the input nor context specify one. */
const DEFAULT_MODEL = 'groq-llama-3.3-70b'

/**
 * Resolve the model to use for this generation. Falls back through
 * `ctx.model`, a string `metadata.model`, then the default. Returns a
 * string in all cases.
 */
function resolveModel(
  ctx: WorkflowContext,
  input: GeneratorInput,
  fallback: string,
): string {
  if (typeof ctx.model === 'string' && ctx.model.length > 0) return ctx.model
  const metaModel = input.metadata?.['model']
  if (typeof metaModel === 'string' && metaModel.length > 0) return metaModel
  return fallback
}

/** Section shape produced by the generator. */
interface DocumentSection {
  id: string
  title: string
  content: string
}

/** Outline payload returned by the first AI call. */
interface OutlinePayload {
  title: string
  description: string
  outline: string
}

/** Sections payload returned by the second AI call. */
interface SectionsPayload {
  sections: Array<{
    title?: string
    content?: string
  }>
}

/**
 * Document generator. Uses a two-step prompt strategy (outline → sections)
 * to produce a complete Markdown document from a topic.
 */
export class DocumentGenerator implements IGenerator {
  public readonly name = 'document-generator'
  public readonly generatorType: GeneratorType = 'document'
  private readonly adapter: AIAdapter

  constructor(aiAdapter: AIAdapter) {
    this.adapter = aiAdapter
  }

  public canHandle(contentType: string): boolean {
    return contentType === 'document'
  }

  /**
   * Generate a complete Markdown document from `input.topic`. Emits a
   * primary document artifact plus a markdown rendering of the same content.
   */
  public async generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const startMs = Date.now()
    const model = resolveModel(ctx, input, DEFAULT_MODEL)
    const topic = input.topic
    const sectionCount = input.modules ?? 5

    logger.info(
      {
        generator: this.name,
        executionId: ctx.executionId,
        topic,
        sectionCount,
        model,
      },
      'DocumentGenerator: starting',
    )

    try {
      // --- Stage 1: outline ------------------------------------------------
      const outlineResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert technical writer. Generate a structured document outline. Respond in valid JSON only.',
          },
          { role: 'user', content: buildOutlinePrompt(input, sectionCount) },
        ],
        temperature: 0.7,
        maxTokens: 1024,
      } satisfies ChatRequest)

      const outline = parseOutline(outlineResponse.content, topic)

      // --- Stage 2: sections ----------------------------------------------
      const sectionsResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert technical writer. Generate each document section\'s body content as Markdown. Respond in valid JSON only.',
          },
          { role: 'user', content: buildSectionsPrompt(input, outline.title, sectionCount) },
        ],
        temperature: 0.7,
        maxTokens: 4096,
      } satisfies ChatRequest)

      const sections = parseSections(sectionsResponse.content)

      // --- Aggregate token usage ------------------------------------------
      const tokensUsed = addUsage(
        usageFromResponse(outlineResponse.usage),
        usageFromResponse(sectionsResponse.usage),
      )
      const cost = tokensUsed.totalTokens * COST_PER_TOKEN

      // --- Assemble content body ------------------------------------------
      const content = renderDocumentMarkdown(topic, outline, sections)
      const artifacts = await buildDocumentArtifacts(
        ctx.executionId,
        this.name,
        outline,
        sections,
        content,
        {
          model,
          provider: sectionsResponse.provider || outlineResponse.provider,
        },
      )

      logger.info(
        {
          generator: this.name,
          executionId: ctx.executionId,
          durationMs: Date.now() - startMs,
          sectionCount: sections.length,
          tokens: tokensUsed.totalTokens,
        },
        'DocumentGenerator: completed',
      )

      return {
        ok: true,
        content,
        modules: sections,
        outline: outline.outline,
        title: outline.title,
        description: outline.description,
        artifacts,
        tokensUsed,
        cost,
        provider: sectionsResponse.provider || outlineResponse.provider,
        model,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.error(
        { generator: this.name, executionId: ctx.executionId, error: message },
        'DocumentGenerator: failed',
      )
      return {
        ok: false,
        content: '',
        artifacts: [],
        error: message,
        model,
      }
    }
  }
}

// =============================================================================
// Prompt builders
// =============================================================================

function buildOutlinePrompt(input: GeneratorInput, sectionCount: number): string {
  return `Generate a document outline for: "${input.topic}"
Audience: ${input.audience ?? 'general'}
Level: ${input.level ?? 'general'}
Language: ${input.language ?? 'English'}
Target section count: ${sectionCount}

Respond in JSON format:
{
  "title": "Document Title",
  "description": "Document description (2-3 sentences)",
  "outline": "Brief outline of the document structure"
}`
}

function buildSectionsPrompt(
  input: GeneratorInput,
  docTitle: string,
  sectionCount: number,
): string {
  return `Generate ${sectionCount} sections for the document: "${docTitle}"
Topic: ${input.topic}
Level: ${input.level ?? 'general'}
Language: ${input.language ?? 'English'}

Each section's content MUST be a Markdown string. Respond in JSON format:
{
  "sections": [
    {
      "title": "Section Title",
      "content": "## Heading\\n\\nMarkdown body..."
    }
  ]
}`
}

// =============================================================================
// JSON parsing helpers (graceful fallback on malformed JSON)
// =============================================================================

function parseOutline(raw: string, topic: string): OutlinePayload {
  try {
    const parsed = JSON.parse(raw) as Partial<OutlinePayload>
    return {
      title: typeof parsed.title === 'string' && parsed.title.length > 0
        ? parsed.title
        : topic,
      description: typeof parsed.description === 'string' ? parsed.description : '',
      outline: typeof parsed.outline === 'string' ? parsed.outline : raw,
    }
  } catch {
    return {
      title: topic,
      description: raw.slice(0, 200),
      outline: raw,
    }
  }
}

function parseSections(raw: string): DocumentSection[] {
  try {
    const parsed = JSON.parse(raw) as Partial<SectionsPayload>
    const rawSections = parsed.sections ?? []
    return rawSections.map(
      (s, index): DocumentSection => ({
        id: `section-${index + 1}`,
        title: typeof s.title === 'string' && s.title.length > 0
          ? s.title
          : `Section ${index + 1}`,
        content: typeof s.content === 'string' ? s.content : '',
      }),
    )
  } catch {
    return [
      {
        id: 'section-1',
        title: 'Generated Content',
        content: raw.slice(0, 1000),
      },
    ]
  }
}

// =============================================================================
// Markdown rendering
// =============================================================================

function renderDocumentMarkdown(
  topic: string,
  outline: OutlinePayload,
  sections: DocumentSection[],
): string {
  const lines: string[] = []
  lines.push(`# ${outline.title}`)
  lines.push('')
  lines.push(`> ${outline.description}`)
  lines.push('')
  lines.push(`**Topic:** ${topic}`)
  lines.push('')
  lines.push('## Outline')
  lines.push('')
  lines.push(outline.outline)
  lines.push('')
  for (const s of sections) {
    lines.push(`## ${s.title}`)
    lines.push('')
    lines.push(s.content)
    lines.push('')
  }
  return lines.join('\n')
}

// =============================================================================
// Artifact construction
// =============================================================================

async function buildDocumentArtifacts(
  executionId: string,
  generatorName: string,
  outline: OutlinePayload,
  sections: DocumentSection[],
  markdown: string,
  attribution: { model: string; provider: string },
): Promise<WorkflowArtifact[]> {
  const json = JSON.stringify(
    {
      title: outline.title,
      description: outline.description,
      outline: outline.outline,
      sections,
    },
    null,
    2,
  )

  const [docArtifact, markdownArtifact] = await Promise.all([
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (document)`,
      'document',
      json,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (markdown)`,
      'markdown',
      markdown,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
  ])

  return [docArtifact, markdownArtifact]
}

// =============================================================================
// Token usage helpers
// =============================================================================

function usageFromResponse(usage: {
  promptTokens: number
  completionTokens: number
  totalTokens: number
} | null): TokenUsage {
  if (!usage) {
    return { promptTokens: 0, completionTokens: 0, totalTokens: 0 }
  }
  return {
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
    totalTokens: usage.totalTokens,
  }
}

function addUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    promptTokens: a.promptTokens + b.promptTokens,
    completionTokens: a.completionTokens + b.completionTokens,
    totalTokens: a.totalTokens + b.totalTokens,
  }
}
