// =============================================================================
// AICF V3 — Course Schemas (Zod)
// =============================================================================
// Request and response validation schemas for course generation endpoints.
// Prepared for future use (not yet wired to a route handler).
// =============================================================================

import { z } from 'zod'

/**
 * Validates a course generation request.
 */
export const courseRequestSchema = z.object({
  topic: z.string().min(1).max(512),
  audience: z.string().max(256).optional(),
  level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  language: z.string().max(64).optional(),
  modules: z.number().int().min(1).max(50).optional(),
})

export type CourseRequestBody = z.infer<typeof courseRequestSchema>

/**
 * Validates a course module within a response.
 */
export const courseModuleSchema = z.object({
  title: z.string(),
  summary: z.string(),
  lessons: z.array(
    z.object({
      title: z.string(),
      content: z.string(),
    }),
  ),
})

/**
 * Validates a course generation response.
 */
export const courseResponseSchema = z.object({
  title: z.string(),
  description: z.string(),
  modules: z.array(courseModuleSchema),
  model: z.string(),
  provider: z.string(),
  durationMs: z.number(),
})

export type CourseResponseBody = z.infer<typeof courseResponseSchema>
