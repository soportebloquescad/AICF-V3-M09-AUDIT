// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow Contracts Barrel
// =============================================================================
// Re-exports every type, interface, and factory declared by the six workflow
// contract modules. Consumers should import from this barrel only:
//
//   import {
//     type WorkflowDefinition,
//     type WorkflowExecution,
//     createPendingExecution,
//     type WorkflowResult,
//     createCompletedResult,
//   } from '@/lib/runtime/contracts/workflow'
//
// Sprint 13+14 spec: the barrel is the single public surface for workflow
// contracts. Internal modules should never deep-import the underlying files.
// =============================================================================

// --- WorkflowDefinition.ts -------------------------------------------------
export type {
  WorkflowMetadata,
  CompensationAction,
  WorkflowStepType,
  WorkflowStepDefinition,
  WorkflowInput,
  WorkflowOutput,
  WorkflowPolicies,
  WorkflowDefinition,
} from './WorkflowDefinition'

// --- WorkflowExecution.ts --------------------------------------------------
export type {
  ExecutionStatus,
  StepExecutionStatus,
  StepExecution,
  Checkpoint,
  WorkflowExecution,
} from './WorkflowExecution'
export { createPendingExecution } from './WorkflowExecution'

// --- WorkflowResult.ts -----------------------------------------------------
export type {
  TokenUsage,
  WorkflowMetrics,
  WorkflowArtifactRef,
  WorkflowResult,
  DryRunResult,
} from './WorkflowResult'
export {
  createCompletedResult,
  createFailedResult,
  createCancelledResult,
} from './WorkflowResult'

// --- WorkflowArtifact.ts ---------------------------------------------------
export type {
  ArtifactType,
  ArtifactLineage,
  WorkflowArtifact,
} from './WorkflowArtifact'
export { createArtifact } from './WorkflowArtifact'

// --- WorkflowEvent.ts ------------------------------------------------------
export type {
  WorkflowEventType,
  WorkflowEventLevel,
  WorkflowEvent,
  CreateEventOptions,
} from './WorkflowEvent'
export { createEvent, isWorkflowEvent } from './WorkflowEvent'

// --- WorkflowContext.ts ----------------------------------------------------
export type {
  CreateWorkflowContextOptions,
  WorkflowContext,
} from './WorkflowContext'
export { createWorkflowContext, updateContextCost } from './WorkflowContext'
