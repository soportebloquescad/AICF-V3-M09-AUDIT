// =============================================================================
// AICF V3 — Sprint 2 — Pipeline Stage Type
// =============================================================================
// Re-exports the PipelineStage interface and factory from PipelineStage.ts
// for consumers who prefer importing from `Stage.ts`.
// =============================================================================

export type { PipelineStage, PipelineStageFn } from './PipelineStage'
export { createPipelineStage } from './PipelineStage'
