// =============================================================================
// AICF V3 — Sprint 13+14 — Generation Module — Presentation Generator
// =============================================================================
// Concrete `IGenerator` implementation for the "presentation" content
// category. Produces a finished slide deck (title + description + outline +
// slides with bullets and speaker notes) by orchestrating two AI adapter
// calls — one for the outline and one for the slides. Mirrors the prompt
// strategy of the legacy `CourseWorker` pattern, specialized for slide
// decks, and emits `WorkflowArtifact` entries ready for the artifact store.
//
// Sprint 13+14 spec requirements covered:
//   - Implements `IGenerator` (uniform generator contract)
//   - `generatorType = 'presentation'` (registry dispatch key)
//   - `canHandle('presentation')` returns true
//   - Returns `GeneratorOutput` with content, modules (slides), outline,
//     title, description, artifacts, and provider/model/token attribution
//   - Emits typed `WorkflowArtifact`s via `createArtifact`
// =============================================================================

import type { AIAdapter, ChatRequest } from '@/lib/ai/AIAdapter'
import type {
  GeneratorInput,
  GeneratorOutput,
  GeneratorType,
  IGenerator,
} from '@/lib/runtime/interfaces'
import type {
  TokenUsage,
  WorkflowArtifact,
  WorkflowContext,
} from '@/lib/runtime/contracts/workflow'
import { createArtifact } from '@/lib/runtime/contracts/workflow'
import { logger } from '@/lib/ai/logger'

/** Per-token cost estimate (platform currency units). */
const COST_PER_TOKEN = 0.000_002

/** Default model when neither the input nor context specify one. */
const DEFAULT_MODEL = 'groq-llama-3.3-70b'

/**
 * Resolve the model to use for this generation. Falls back through
 * `ctx.model`, a string `metadata.model`, then the default. Returns a
 * string in all cases.
 */
function resolveModel(
  ctx: WorkflowContext,
  input: GeneratorInput,
  fallback: string,
): string {
  if (typeof ctx.model === 'string' && ctx.model.length > 0) return ctx.model
  const metaModel = input.metadata?.['model']
  if (typeof metaModel === 'string' && metaModel.length > 0) return metaModel
  return fallback
}

/** Slide shape produced by the generator. */
interface Slide {
  id: string
  title: string
  bullets: string[]
  notes?: string
}

/** Outline payload returned by the first AI call. */
interface OutlinePayload {
  title: string
  description: string
  outline: string
}

/** Slides payload returned by the second AI call. */
interface SlidesPayload {
  slides: Array<{
    title?: string
    bullets?: unknown
    notes?: string
  }>
}

/**
 * Presentation generator. Uses a two-step prompt strategy (outline → slides)
 * to produce a complete slide deck from a topic.
 */
export class PresentationGenerator implements IGenerator {
  public readonly name = 'presentation-generator'
  public readonly generatorType: GeneratorType = 'presentation'
  private readonly adapter: AIAdapter

  constructor(aiAdapter: AIAdapter) {
    this.adapter = aiAdapter
  }

  public canHandle(contentType: string): boolean {
    return contentType === 'presentation'
  }

  /**
   * Generate a complete slide deck from `input.topic`. Emits a primary
   * presentation artifact plus a markdown rendering of the same content.
   */
  public async generate(
    input: GeneratorInput,
    ctx: WorkflowContext,
  ): Promise<GeneratorOutput> {
    const startMs = Date.now()
    const model = resolveModel(ctx, input, DEFAULT_MODEL)
    const topic = input.topic
    const slideCount = input.modules ?? 10

    logger.info(
      {
        generator: this.name,
        executionId: ctx.executionId,
        topic,
        slideCount,
        model,
      },
      'PresentationGenerator: starting',
    )

    try {
      // --- Stage 1: outline ------------------------------------------------
      const outlineResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert presentation designer. Generate a structured slide deck outline. Respond in valid JSON only.',
          },
          { role: 'user', content: buildOutlinePrompt(input, slideCount) },
        ],
        temperature: 0.7,
        maxTokens: 1024,
      } satisfies ChatRequest)

      const outline = parseOutline(outlineResponse.content, topic)

      // --- Stage 2: slides -------------------------------------------------
      const slidesResponse = await this.adapter.chat({
        model,
        messages: [
          {
            role: 'system',
            content:
              'You are an expert presentation designer. Generate slides as a JSON array where each slide has a title, an array of bullet points, and optional speaker notes. Respond in valid JSON only.',
          },
          { role: 'user', content: buildSlidesPrompt(input, outline.title, slideCount) },
        ],
        temperature: 0.7,
        maxTokens: 4096,
      } satisfies ChatRequest)

      const slides = parseSlides(slidesResponse.content)

      // --- Aggregate token usage ------------------------------------------
      const tokensUsed = addUsage(
        usageFromResponse(outlineResponse.usage),
        usageFromResponse(slidesResponse.usage),
      )
      const cost = tokensUsed.totalTokens * COST_PER_TOKEN

      // --- Assemble content body ------------------------------------------
      const content = renderPresentationMarkdown(topic, outline, slides)
      const artifacts = await buildPresentationArtifacts(
        ctx.executionId,
        this.name,
        outline,
        slides,
        content,
        {
          model,
          provider: slidesResponse.provider || outlineResponse.provider,
        },
      )

      logger.info(
        {
          generator: this.name,
          executionId: ctx.executionId,
          durationMs: Date.now() - startMs,
          slideCount: slides.length,
          tokens: tokensUsed.totalTokens,
        },
        'PresentationGenerator: completed',
      )

      return {
        ok: true,
        content,
        modules: slides,
        outline: outline.outline,
        title: outline.title,
        description: outline.description,
        artifacts,
        tokensUsed,
        cost,
        provider: slidesResponse.provider || outlineResponse.provider,
        model,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logger.error(
        { generator: this.name, executionId: ctx.executionId, error: message },
        'PresentationGenerator: failed',
      )
      return {
        ok: false,
        content: '',
        artifacts: [],
        error: message,
        model,
      }
    }
  }
}

// =============================================================================
// Prompt builders
// =============================================================================

function buildOutlinePrompt(input: GeneratorInput, slideCount: number): string {
  return `Generate a presentation outline for: "${input.topic}"
Audience: ${input.audience ?? 'general'}
Level: ${input.level ?? 'general'}
Language: ${input.language ?? 'English'}
Target slide count: ${slideCount}

Respond in JSON format:
{
  "title": "Presentation Title",
  "description": "Presentation description (2-3 sentences)",
  "outline": "Brief outline of the deck structure"
}`
}

function buildSlidesPrompt(
  input: GeneratorInput,
  deckTitle: string,
  slideCount: number,
): string {
  return `Generate ${slideCount} slides for the presentation: "${deckTitle}"
Topic: ${input.topic}
Level: ${input.level ?? 'general'}
Language: ${input.language ?? 'English'}

Each slide MUST have a bullets array. Respond in JSON format:
{
  "slides": [
    {
      "title": "Slide Title",
      "bullets": ["Bullet 1", "Bullet 2", "Bullet 3"],
      "notes": "Optional speaker notes"
    }
  ]
}`
}

// =============================================================================
// JSON parsing helpers (graceful fallback on malformed JSON)
// =============================================================================

function parseOutline(raw: string, topic: string): OutlinePayload {
  try {
    const parsed = JSON.parse(raw) as Partial<OutlinePayload>
    return {
      title: typeof parsed.title === 'string' && parsed.title.length > 0
        ? parsed.title
        : topic,
      description: typeof parsed.description === 'string' ? parsed.description : '',
      outline: typeof parsed.outline === 'string' ? parsed.outline : raw,
    }
  } catch {
    return {
      title: topic,
      description: raw.slice(0, 200),
      outline: raw,
    }
  }
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value
    .filter((v): v is string => typeof v === 'string' && v.length > 0)
    .map((v) => v)
}

function parseSlides(raw: string): Slide[] {
  try {
    const parsed = JSON.parse(raw) as Partial<SlidesPayload>
    const rawSlides = parsed.slides ?? []
    return rawSlides.map(
      (s, index): Slide => {
        const slide: Slide = {
          id: `slide-${index + 1}`,
          title: typeof s.title === 'string' && s.title.length > 0
            ? s.title
            : `Slide ${index + 1}`,
          bullets: asStringArray(s.bullets),
        }
        if (typeof s.notes === 'string' && s.notes.length > 0) {
          slide.notes = s.notes
        }
        return slide
      },
    )
  } catch {
    return [
      {
        id: 'slide-1',
        title: 'Generated Slide',
        bullets: [raw.slice(0, 500)],
      },
    ]
  }
}

// =============================================================================
// Markdown rendering
// =============================================================================

function renderPresentationMarkdown(
  topic: string,
  outline: OutlinePayload,
  slides: Slide[],
): string {
  const lines: string[] = []
  lines.push(`# ${outline.title}`)
  lines.push('')
  lines.push(`> ${outline.description}`)
  lines.push('')
  lines.push(`**Topic:** ${topic}`)
  lines.push('')
  lines.push('## Outline')
  lines.push('')
  lines.push(outline.outline)
  lines.push('')
  for (const s of slides) {
    lines.push(`## ${s.title}`)
    lines.push('')
    for (const b of s.bullets) {
      lines.push(`- ${b}`)
    }
    if (s.notes !== undefined && s.notes.length > 0) {
      lines.push('')
      lines.push(`_Notes: ${s.notes}_`)
    }
    lines.push('')
  }
  return lines.join('\n')
}

// =============================================================================
// Artifact construction
// =============================================================================

async function buildPresentationArtifacts(
  executionId: string,
  generatorName: string,
  outline: OutlinePayload,
  slides: Slide[],
  markdown: string,
  attribution: { model: string; provider: string },
): Promise<WorkflowArtifact[]> {
  const json = JSON.stringify(
    {
      title: outline.title,
      description: outline.description,
      outline: outline.outline,
      slides,
    },
    null,
    2,
  )

  const [presArtifact, markdownArtifact] = await Promise.all([
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (presentation)`,
      'presentation',
      json,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
    createArtifact(
      executionId,
      generatorName,
      `${outline.title} (markdown)`,
      'markdown',
      markdown,
      {
        generator: generatorName,
        workflowExecution: executionId,
        children: [],
        model: attribution.model,
        provider: attribution.provider,
      },
    ),
  ])

  return [presArtifact, markdownArtifact]
}

// =============================================================================
// Token usage helpers
// =============================================================================

function usageFromResponse(usage: {
  promptTokens: number
  completionTokens: number
  totalTokens: number
} | null): TokenUsage {
  if (!usage) {
    return { promptTokens: 0, completionTokens: 0, totalTokens: 0 }
  }
  return {
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
    totalTokens: usage.totalTokens,
  }
}

function addUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    promptTokens: a.promptTokens + b.promptTokens,
    completionTokens: a.completionTokens + b.completionTokens,
    totalTokens: a.totalTokens + b.totalTokens,
  }
}
