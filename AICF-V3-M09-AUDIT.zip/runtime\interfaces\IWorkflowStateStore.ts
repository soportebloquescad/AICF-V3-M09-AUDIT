// =============================================================================
// AICF V3 — Sprint 13+14 — Workflow State Store Interface
// =============================================================================
// Durable persistence for `WorkflowExecution` envelopes, checkpoints, and
// per-step execution records. The engine writes here on every state
// transition; the API server reads here for status / resume / replay.
//
// Sprint 13+14 spec requirements covered:
//   - CRUD over executions keyed by id
//   - `listPending` / `listByStatus` for the scheduler and the UI dashboard
//   - Checkpoint persistence for pause / resume / replay
//   - `updateStepExecution` for fine-grained step-state writes (avoids
//     rewriting the whole envelope on every step transition)
// =============================================================================

import type {
  WorkflowExecution,
  ExecutionStatus,
  Checkpoint,
  StepExecution,
} from '@/lib/runtime/contracts/workflow'

/**
 * Durable state store contract. Implementations MUST be transactional with
 * respect to a single execution: writes to one execution id are atomic, but
 * cross-execution transactions are not required.
 */
export interface IWorkflowStateStore {
  /** Persist (or update) an execution envelope. */
  saveExecution(execution: WorkflowExecution): Promise<void>
  /** Load an execution by id, or null if not found. */
  loadExecution(executionId: string): Promise<WorkflowExecution | null>
  /** List executions in non-terminal states (pending / running / paused / compensating). */
  listPending(): Promise<WorkflowExecution[]>
  /** List executions in a specific status (e.g. for the dashboard). */
  listByStatus(status: ExecutionStatus): Promise<WorkflowExecution[]>
  /** Delete an execution and its checkpoints. No-op if not found. */
  deleteExecution(executionId: string): Promise<void>
  /** Persist a checkpoint for an execution. */
  saveCheckpoint(executionId: string, checkpoint: Checkpoint): Promise<void>
  /** Load all checkpoints for an execution, in save order. */
  loadCheckpoints(executionId: string): Promise<Checkpoint[]>
  /** Update a single step's execution record within an execution envelope. */
  updateStepExecution(
    executionId: string,
    stepId: string,
    stepExec: StepExecution,
  ): Promise<void>
}
