// =============================================================================
// AICF V3 — Sprint 13+14 — Batch D — Capability Registry
// =============================================================================
// Registers providers by capability. Maintains a two-level map:
//   capability -> providerName -> IProvider
//
// Sprint 13+14 spec requirements covered:
//   - `registerProvider(provider)` — registers under all provider.capabilities
//   - `getProvider(capability, name?)` — returns provider by capability
//     (+ optional name; defaults to the first registered provider for the
//     capability)
//   - `listProviders(capability)` — all providers for a capability
//   - `listCapabilities()` — every capability with at least one provider
//   - `hasCapability(capability)` — boolean membership check
// =============================================================================

import type { IProvider, ProviderCapability } from '@/lib/runtime/interfaces'
import { logger } from '@/lib/ai/logger'

/**
 * Capability-indexed provider registry. One instance can hold providers
 * for every capability; the same provider may be registered under multiple
 * capabilities (per its `capabilities` list).
 */
export class CapabilityRegistry {
  /** Map<capability, Map<providerName, IProvider>>. */
  private readonly byCapability = new Map<
    ProviderCapability,
    Map<string, IProvider>
  >()

  /**
   * Register a provider under every capability it advertises. Re-registering
   * a provider with the same name under the same capability is a no-op
   * (the new instance replaces the old one).
   */
  registerProvider(provider: IProvider): void {
    for (const cap of provider.capabilities) {
      let inner = this.byCapability.get(cap)
      if (!inner) {
        inner = new Map<string, IProvider>()
        this.byCapability.set(cap, inner)
      }
      inner.set(provider.name, provider)
    }
    logger.debug(
      {
        provider: provider.name,
        capabilities: provider.capabilities,
      },
      'CapabilityRegistry: provider registered',
    )
  }

  /**
   * Get a provider by capability. When `name` is omitted, returns the
   * first registered provider for that capability (insertion order);
   * returns null when the capability is unknown or has no providers.
   */
  getProvider(
    capability: ProviderCapability,
    name?: string,
  ): IProvider | null {
    const inner = this.byCapability.get(capability)
    if (!inner) return null
    if (name !== undefined) {
      return inner.get(name) ?? null
    }
    // Return the first-registered provider for this capability.
    for (const p of inner.values()) return p
    return null
  }

  /** All providers registered under a capability (insertion order). */
  listProviders(capability: ProviderCapability): IProvider[] {
    const inner = this.byCapability.get(capability)
    if (!inner) return []
    return Array.from(inner.values())
  }

  /** Every capability that has at least one registered provider. */
  listCapabilities(): string[] {
    return Array.from(this.byCapability.keys())
  }

  /** Whether any provider is registered for the given capability. */
  hasCapability(capability: ProviderCapability): boolean {
    const inner = this.byCapability.get(capability)
    return inner !== undefined && inner.size > 0
  }
}
