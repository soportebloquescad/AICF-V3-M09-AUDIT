// =============================================================================
// AICF V3 — Sprint Cierre Fase 0 — ResearchPlan
// =============================================================================
// The research plan produced before artifact generation.
//
// Before generating an artifact (course, ebook, document), the Runtime
// optionally performs a research phase to gather sources and key facts.
// The ResearchPlan captures the result of that phase.
//
// BFF FROZEN: this file does NOT import or modify anything in src/lib/ai/.
// =============================================================================

/**
 * The depth of research to perform.
 */
export type ResearchDepth = 'light' | 'standard' | 'deep'

/**
 * A research plan produced before artifact generation.
 *
 * Captures:
 *   - The topic being researched
 *   - The depth of research
 *   - The sources consulted (URLs or references)
 *   - Key facts extracted from the sources
 *   - A synthesized summary
 */
export interface ResearchPlan {
  /** The topic being researched. */
  topic: string

  /** The depth of research performed. */
  depth: ResearchDepth

  /** Sources consulted (URLs, citations, or references). */
  sources: string[]

  /** Key facts extracted from the sources. */
  keyFacts: string[]

  /** Synthesized summary of the research (markdown). */
  summary: string
}

/**
 * Factory: creates an empty ResearchPlan.
 *
 * @example
 * const plan = createResearchPlan({ topic: 'Intro to Rust', depth: 'standard' })
 */
export function createResearchPlan(
  partial: Partial<ResearchPlan> & Pick<ResearchPlan, 'topic'>,
): ResearchPlan {
  return {
    depth: 'standard',
    sources: [],
    keyFacts: [],
    summary: '',
    ...partial,
  }
}
