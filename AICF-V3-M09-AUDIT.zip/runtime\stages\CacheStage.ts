// =============================================================================
// AICF V3 — Sprint 2 — Cache Stage
// =============================================================================
// Checks if the response is already cached. If cached, short-circuits.
// Currently a pass-through (cache logic deferred to Content Intelligence).
// =============================================================================

import type { PipelineStage } from '../pipeline/PipelineStage'
import { createPipelineStage } from '../pipeline/PipelineStage'
import type { RuntimeContext } from '../contracts/RuntimeContext'

export function createCacheStage(): PipelineStage {
  return createPipelineStage('Cache', async (ctx: RuntimeContext): Promise<RuntimeContext> => {
    ctx.response.stages = [...(ctx.response.stages ?? []), 'Cache']
    if (ctx.response.cached) {
      ctx.response.stages = [...(ctx.response.stages ?? []), 'Cache HIT']
    }
    return ctx
  })
}
