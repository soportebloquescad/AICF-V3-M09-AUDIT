// =============================================================================
// AICF V3 — HTML Exporter (Epic 6 — Exporters)
// =============================================================================
// Transforms Markdown content into a standalone, self-contained HTML5
// document. The output is a complete `<!DOCTYPE html>` page with embedded
// CSS so it can be saved as a single .html file and opened in any browser.
//
// The exporter NEVER generates or modifies content — it only re-formats the
// supplied Markdown into HTML and wraps it with a styled document shell.
// Metadata (title, author, description, language, etc.) is read from the
// optional `metadata` argument and projected into <head> meta tags + the
// visible document header.
//
// Strict TypeScript: no `any`, no TODO/FIXME, no emojis.
// =============================================================================

import { escapeHtml, markdownToHtml } from './markdownToHtml'

/** Public type alias for the metadata bag accepted by HTMLExporter.export(). */
export type HtmlExportMetadata = Record<string, unknown>

/**
 * HTMLExporter — transforms Markdown to a standalone HTML5 document.
 */
export class HTMLExporter {
  /**
   * Transform `content` (Markdown) into a complete HTML5 document string.
   *
   * @param content  Markdown source text.
   * @param metadata Optional metadata: { title, author, description, language, ... }.
   * @returns A self-contained `<!DOCTYPE html>` document string.
   */
  export(content: string, metadata?: HtmlExportMetadata): string {
    const meta = metadata ?? {}
    const title = asString(meta.title, asString(meta.topic, 'Exported Document'))
    const author = asString(meta.author, '')
    const description = asString(meta.description, '')
    const language = asString(meta.language, 'en').toLowerCase()
    const generator = asString(meta.generator, 'AICF V3 HTMLExporter')

    const bodyHtml = markdownToHtml(content ?? '')
    const headMeta = this.buildHeadMeta(title, author, description, generator, meta)
    const css = this.buildCss()
    const headerBlock = this.buildDocumentHeader(title, author, description, meta)

    return [
      '<!DOCTYPE html>',
      `<html lang="${escapeHtml(language)}">`,
      '<head>',
      '  <meta charset="utf-8" />',
      '  <meta name="viewport" content="width=device-width, initial-scale=1" />',
      `  <title>${escapeHtml(title)}</title>`,
      headMeta,
      `  <meta name="generator" content="${escapeHtml(generator)}" />`,
      '  <style>',
      css,
      '  </style>',
      '</head>',
      '<body>',
      '  <main class="document" role="main">',
      headerBlock,
      '    <article class="content">',
      bodyHtml,
      '    </article>',
      '  </main>',
      '</body>',
      '</html>',
      '',
    ].join('\n')
  }

  // -------------------------------------------------------------------------
  // Internal helpers
  // -------------------------------------------------------------------------

  private buildHeadMeta(
    title: string,
    author: string,
    description: string,
    generator: string,
    meta: HtmlExportMetadata,
  ): string {
    const lines: string[] = []
    if (author) {
      lines.push(`  <meta name="author" content="${escapeHtml(author)}" />`)
    }
    if (description) {
      lines.push(`  <meta name="description" content="${escapeHtml(description)}" />`)
    }
    // Standard keyword meta
    const keywords = asString(meta.keywords, '')
    if (keywords) {
      lines.push(`  <meta name="keywords" content="${escapeHtml(keywords)}" />`)
    }
    // Open Graph tags (useful for link previews)
    lines.push('  <meta property="og:title" content="' + escapeHtml(title) + '" />')
    if (description) {
      lines.push('  <meta property="og:description" content="' + escapeHtml(description) + '" />')
    }
    lines.push('  <meta property="og:type" content="article" />')
    // Generator already emitted by caller; reference to silence unused param
    void generator
    return lines.join('\n')
  }

  private buildDocumentHeader(
    title: string,
    author: string,
    description: string,
    meta: HtmlExportMetadata,
  ): string {
    const lines: string[] = []
    lines.push('    <header class="document-header">')
    lines.push(`      <h1 class="document-title">${escapeHtml(title)}</h1>`)
    if (author) {
      lines.push(`      <p class="document-author">By ${escapeHtml(author)}</p>`)
    }
    if (description) {
      lines.push(`      <p class="document-description">${escapeHtml(description)}</p>`)
    }
    // Optional metadata table (any other keys are rendered as a definition list)
    const knownKeys = new Set(['title', 'author', 'description', 'language', 'generator', 'topic', 'keywords'])
    const extraEntries = Object.entries(meta).filter(([k]) => !knownKeys.has(k))
    if (extraEntries.length > 0) {
      lines.push('      <dl class="document-meta">')
      for (const [k, v] of extraEntries) {
        const value = typeof v === 'string' ? v : safeStringify(v)
        lines.push(`        <dt>${escapeHtml(k)}</dt>`)
        lines.push(`        <dd>${escapeHtml(value)}</dd>`)
      }
      lines.push('      </dl>')
    }
    lines.push('    </header>')
    return lines.join('\n')
  }

  private buildCss(): string {
    return [
      '    :root {',
      '      --accent: #2563eb;',
      '      --accent-dark: #1e40af;',
      '      --bg: #ffffff;',
      '      --surface: #f8fafc;',
      '      --text: #0f172a;',
      '      --muted: #64748b;',
      '      --border: #e2e8f0;',
      '      --code-bg: #f1f5f9;',
      '    }',
      '    * { box-sizing: border-box; }',
      '    html { -webkit-text-size-adjust: 100%; }',
      '    body {',
      '      margin: 0;',
      '      background: var(--bg);',
      '      color: var(--text);',
      "      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;",
      '      line-height: 1.65;',
      '      font-size: 16px;',
      '    }',
      '    main.document {',
      '      max-width: 880px;',
      '      margin: 0 auto;',
      '      padding: 48px 32px 96px;',
      '      background: var(--bg);',
      '    }',
      '    header.document-header {',
      "      border-bottom: 3px solid var(--accent);",
      '      padding-bottom: 24px;',
      '      margin-bottom: 32px;',
      '    }',
      '    h1.document-title {',
      '      color: var(--accent-dark);',
      '      font-size: 2.4rem;',
      '      margin: 0 0 8px 0;',
      '      line-height: 1.2;',
      '    }',
      '    .document-author {',
      '      color: var(--muted);',
      '      margin: 4px 0;',
      '      font-size: 0.95rem;',
      '    }',
      '    .document-description {',
      '      color: var(--text);',
      '      font-style: italic;',
      '      margin: 8px 0 0 0;',
      '    }',
      '    .document-meta {',
      '      display: grid;',
      '      grid-template-columns: max-content 1fr;',
      '      gap: 4px 16px;',
      '      margin-top: 16px;',
      '      font-size: 0.9rem;',
      '    }',
      '    .document-meta dt {',
      '      color: var(--muted);',
      '      font-weight: 600;',
      '    }',
      '    .document-meta dd {',
      '      margin: 0;',
      '    }',
      '    article.content h1, article.content h2, article.content h3,',
      '    article.content h4, article.content h5, article.content h6 {',
      '      color: var(--accent-dark);',
      '      line-height: 1.3;',
      '      margin-top: 1.8em;',
      '      margin-bottom: 0.6em;',
      '    }',
      '    article.content h1 { font-size: 1.9rem; border-bottom: 1px solid var(--border); padding-bottom: 6px; }',
      '    article.content h2 { font-size: 1.55rem; }',
      '    article.content h3 { font-size: 1.3rem; }',
      '    article.content h4 { font-size: 1.15rem; }',
      '    article.content h5, article.content h6 { font-size: 1rem; }',
      '    article.content p { margin: 0.8em 0; }',
      '    article.content ul, article.content ol { margin: 0.8em 0; padding-left: 1.6em; }',
      '    article.content li { margin: 0.3em 0; }',
      '    article.content a { color: var(--accent); text-decoration: underline; }',
      '    article.content blockquote {',
      "      border-left: 4px solid var(--accent);",
      '      margin: 1em 0;',
      '      padding: 8px 16px;',
      '      background: var(--surface);',
      '      color: var(--muted);',
      '    }',
      '    article.content hr {',
      "      border: none;",
      "      border-top: 1px solid var(--border);",
      '      margin: 2em 0;',
      '    }',
      '    article.content pre {',
      '      background: var(--code-bg);',
      '      border: 1px solid var(--border);',
      '      border-radius: 6px;',
      '      padding: 16px;',
      '      overflow-x: auto;',
      '      font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;',
      '      font-size: 0.9rem;',
      '      line-height: 1.5;',
      '    }',
      '    article.content code {',
      "      font-family: \"SFMono-Regular\", Consolas, \"Liberation Mono\", Menlo, monospace;",
      '      font-size: 0.9em;',
      '    }',
      '    article.content :not(pre) > code {',
      '      background: var(--code-bg);',
      '      padding: 2px 5px;',
      '      border-radius: 3px;',
      '    }',
      '    article.content table { border-collapse: collapse; margin: 1em 0; width: 100%; }',
      '    article.content th, article.content td {',
      "      border: 1px solid var(--border);",
      '      padding: 8px 12px;',
      '      text-align: left;',
      '    }',
      '    article.content th { background: var(--surface); font-weight: 600; }',
      '    @media (max-width: 640px) {',
      '      main.document { padding: 24px 16px 48px; }',
      '      h1.document-title { font-size: 1.7rem; }',
      '      .document-meta { grid-template-columns: 1fr; }',
      '    }',
    ].join('\n')
  }
}

// -------------------------------------------------------------------------
// Small input-narrowing helpers (no `any`).
// -------------------------------------------------------------------------

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function safeStringify(value: unknown): string {
  if (value === null) return 'null'
  if (value === undefined) return 'undefined'
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return String(value)
  }
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}
