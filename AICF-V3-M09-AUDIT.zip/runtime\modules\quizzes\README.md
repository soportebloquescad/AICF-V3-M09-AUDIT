# Quizzes Module — Business-layer quiz generation and grading

Real Business-layer module (Épica 3 — Educational Factory). Extends
`BusinessModuleBase` and exposes three capabilities:

- `createQuiz` — Create a new quiz from a topic + question count + difficulty.
- `generateQuiz` — Generate multiple-choice questions with answer options.
- `gradeQuiz` — Grade a submitted quiz against an answer key.

## Status

IMPLEMENTED. `executeJob()` produces real multiple-choice quizzes via two
paths:

1. **AI mode** (when an `AIAdapter` is injected via the constructor): prompts
   the LLM for structured JSON questions, parses them into typed questions.
2. **Fallback mode** (no adapter, or AI call fails): a deterministic generator
   produces 10 distinct question templates about the topic.

Output includes a standalone HTML5 quiz with embedded CSS and JavaScript for
self-scoring (the learner selects answers and clicks "Submit answers"; the
page computes the score and shows per-question explanations). Markdown source
is also returned.

## Metadata

| Field | Value |
| --- | --- |
| id | `quiz` |
| version | `1.0.0` |
| mission | `quiz` |
| priority | 35 |
| dependencies | (none) |
| capabilities | `createQuiz`, `generateQuiz`, `gradeQuiz` |

## Lifecycle

Inherited from `BusinessModuleBase`.

## Constructor

```typescript
new QuizModule(aiAdapter?, model?)
```

- `aiAdapter` — optional `AIAdapter` from `@/lib/ai/AIAdapter`. When omitted,
  the module always uses the deterministic fallback.
- `model` — model id passed to the adapter (default `groq-llama-3.3-70b`).

## Grading

`gradeQuiz` accepts an `input` with the shape:

```ts
{
  questions: GradedQuizQuestion[]; // the answer key
  answers: Record<string, number>; // questionId → selected option index
  passingScore?: number;           // default 70
}
```

Returns a `QuizGrade` with `total`, `correct`, `score` (0–100), `passed`
(boolean), and a per-question `results` array.
