// =============================================================================
// AICF V3 — Runtime Event Bus (Sprint 17: simplified — in-memory only)
// Sprint 21: adds publishEnvelope() + telemetry + idempotency
// =============================================================================
// A lightweight pub/sub event bus for Runtime lifecycle events.
// Decoupled from the workflow module's EventBus — this one is specifically for
// bootstrap/module lifecycle events.
//
// Sprint 17 changes (BACKWARD-INCOMPATIBLE per spec):
//   - Removed the `history` array + `maxHistory` constructor param
//   - Removed `getHistory()` and `clearHistory()`
//   - `clear()` no longer touches history
//   - The bus is now purely in-memory with no persistence — replaceable by
//     Redis/NATS/Kafka later without changing the emit/on interface.
//
// Sprint 21 additions (BACKWARD-COMPATIBLE):
//   - publishEnvelope(envelope, type): publishes an envelope-wrapped EDA
//     event. Performs idempotency check, measures publish time, updates
//     telemetry, then delegates to the existing emit() path with the
//     envelope as the event's `data` field.
//   - Idempotency: an internal Set<string> tracks seen eventIds. Repeated
//     publishEnvelope() calls for the same eventId are skipped (but counted
//     in eventsDeduplicated).
//   - Telemetry counters: eventsPublished, eventsFailed,
//     eventsDeduplicated, eventsPerStage (Map<string, number>),
//     averagePublishTimeMs (rolling average over publishEnvelope calls).
//   - getTelemetry() returns a snapshot; resetTelemetry() clears counters.
//
// Verified safe: no caller in src/ calls getHistory()/clearHistory() on
// RuntimeEventBus. The workflow module's `bundle.eventBus.getHistory()` calls
// use the separate `modules/workflow/events/EventBus.ts` InMemoryEventBus,
// which retains its own history.
// =============================================================================

import type { RuntimeEvent, RuntimeEventType } from './RuntimeEvents'
import { createRuntimeEvent } from './RuntimeEvents'
import type { RuntimeEventEnvelope } from './EventMetadata'
import { logger } from '@/lib/ai/logger'

// Re-export for callers that import from the bus module.
export type { RuntimeEvent, RuntimeEventType } from './RuntimeEvents'
export { createRuntimeEvent } from './RuntimeEvents'

type EventHandler = (event: RuntimeEvent) => void | Promise<void>

/**
 * Telemetry snapshot returned by getTelemetry().
 */
export interface RuntimeEventBusTelemetry {
  eventsPublished: number
  eventsFailed: number
  eventsDeduplicated: number
  eventsPerStage: Record<string, number>
  averagePublishTimeMs: number
}

/**
 * Runtime Event Bus — pub/sub for module lifecycle events.
 *
 * @example
 * const bus = new RuntimeEventBus()
 * bus.on('module.initialized', (e) => console.log(`${e.moduleId} ready`))
 * bus.emit(createRuntimeEvent('module.initialized', { moduleId: 'workflow' }))
 */
export class RuntimeEventBus {
  private readonly handlers = new Map<RuntimeEventType, Set<EventHandler>>()
  private readonly allHandlers = new Set<EventHandler>()

  // --- Sprint 21: idempotency + telemetry -------------------------------
  private readonly seenEventIds = new Set<string>()
  private eventsPublished = 0
  private eventsFailed = 0
  private eventsDeduplicated = 0
  private readonly eventsPerStage = new Map<string, number>()
  private publishTimeTotalMs = 0
  private publishTimeSamples = 0

  /**
   * Emits an event to all subscribers. Handler errors are caught and logged
   * (they don't stop delivery to other handlers).
   */
  async emit(event: RuntimeEvent): Promise<void> {
    // Notify type-specific handlers
    const typeHandlers = this.handlers.get(event.type)
    if (typeHandlers) {
      for (const handler of typeHandlers) {
        try {
          await handler(event)
        } catch (err) {
          logger.error(
            { error: err instanceof Error ? err.message : String(err), eventType: event.type },
            'RuntimeEventBus: handler error (swallowed)',
          )
        }
      }
    }

    // Notify all-handlers
    for (const handler of this.allHandlers) {
      try {
        await handler(event)
      } catch (err) {
        logger.error(
          { error: err instanceof Error ? err.message : String(err), eventType: event.type },
          'RuntimeEventBus: all-handler error (swallowed)',
        )
      }
    }
  }

  /**
   * Convenience: creates and emits an event in one call.
   * Supports all Sprint 16 event fields (requestId, operation, health,
   * capabilities, durationMs, stages, status) plus the Sprint Foundation-Core
   * EDA lifecycle fields (valid, errors, allowed, provider, model, module,
   * success, numeric status).
   */
  async emitEvent(
    type: RuntimeEventType,
    opts?: {
      moduleId?: string
      error?: string
      data?: Record<string, unknown>
      requestId?: string
      operation?: string
      health?: 'healthy' | 'degraded' | 'unhealthy'
      capabilities?: string[]
      durationMs?: number
      stages?: string[]
      status?: 'completed' | 'failed' | number
      // Sprint Foundation-Core EDA lifecycle fields
      valid?: boolean
      errors?: string[]
      allowed?: boolean
      provider?: string
      model?: string
      module?: string
      success?: boolean
    },
  ): Promise<void> {
    await this.emit(createRuntimeEvent(type, opts))
  }

  /**
   * Subscribes to a specific event type. Returns an unsubscribe function.
   */
  on(eventType: RuntimeEventType, handler: EventHandler): () => void {
    let set = this.handlers.get(eventType)
    if (!set) {
      set = new Set()
      this.handlers.set(eventType, set)
    }
    set.add(handler)
    return () => {
      set?.delete(handler)
    }
  }

  /**
   * Subscribes to ALL events. Returns an unsubscribe function.
   */
  onAll(handler: EventHandler): () => void {
    this.allHandlers.add(handler)
    return () => {
      this.allHandlers.delete(handler)
    }
  }

  /**
   * Removes all handlers.
   */
  clear(): void {
    this.handlers.clear()
    this.allHandlers.clear()
  }

  // -------------------------------------------------------------------------
  // Sprint 21: envelope publishing + telemetry + idempotency
  // -------------------------------------------------------------------------

  /**
   * Publishes an envelope-wrapped EDA event.
   *
   * Pipeline:
   *   1. Idempotency: if envelope.metadata.eventId was seen before, skip
   *      delivery but increment eventsDeduplicated.
   *   2. Measure publish time (start).
   *   3. Update telemetry counters (eventsPublished, eventsPerStage).
   *   4. Delegate to emit() with the envelope as the event's `data` field.
   *   5. On emit() throwing, increment eventsFailed (the throw is then
   *      re-thrown so the caller can react — though emit() swallows handler
   *      errors itself).
   *   6. Record publish time in the rolling average.
   *
   * Best-effort: this method itself never throws on idempotency skip —
   * idempotent skips return normally. Actual emit() failures are counted
   * and re-thrown.
   */
  async publishEnvelope(
    envelope: RuntimeEventEnvelope<unknown>,
    type: RuntimeEventType,
  ): Promise<void> {
    const eventId = envelope.metadata.eventId

    // Idempotency: skip duplicates.
    if (this.seenEventIds.has(eventId)) {
      this.eventsDeduplicated++
      logger.debug(
        { eventId, type, deduplicated: this.eventsDeduplicated },
        'RuntimeEventBus: duplicate event skipped (idempotency)',
      )
      return
    }
    this.seenEventIds.add(eventId)

    const start = Date.now()
    try {
      // Update telemetry before delivery so partial failures still record.
      this.eventsPublished++
      const stage = envelope.metadata.pipelineStage
      this.eventsPerStage.set(stage, (this.eventsPerStage.get(stage) || 0) + 1)

      // Delegate to the existing emit() path. The envelope is attached as
      // the event's `data` field so legacy subscribers (using on()/onAll())
      // also receive the structured payload.
      await this.emit(
        createRuntimeEvent(type, {
          requestId: envelope.metadata.requestId,
          operation: envelope.metadata.operation,
          durationMs: envelope.metadata.durationMs,
          data: { envelope },
        }),
      )
    } catch (err) {
      this.eventsFailed++
      logger.error(
        {
          eventId,
          type,
          error: err instanceof Error ? err.message : String(err),
        },
        'RuntimeEventBus: publishEnvelope failed',
      )
      throw err
    } finally {
      const elapsed = Date.now() - start
      this.publishTimeTotalMs += elapsed
      this.publishTimeSamples++
    }
  }

  /**
   * Returns a snapshot of telemetry counters.
   */
  getTelemetry(): RuntimeEventBusTelemetry {
    const eventsPerStage: Record<string, number> = {}
    for (const [stage, count] of this.eventsPerStage.entries()) {
      eventsPerStage[stage] = count
    }
    const averagePublishTimeMs =
      this.publishTimeSamples === 0 ? 0 : this.publishTimeTotalMs / this.publishTimeSamples
    return {
      eventsPublished: this.eventsPublished,
      eventsFailed: this.eventsFailed,
      eventsDeduplicated: this.eventsDeduplicated,
      eventsPerStage,
      averagePublishTimeMs,
    }
  }

  /**
   * Resets all telemetry counters (including the idempotency set).
   * Does NOT clear handlers — use clear() for that.
   */
  resetTelemetry(): void {
    this.seenEventIds.clear()
    this.eventsPublished = 0
    this.eventsFailed = 0
    this.eventsDeduplicated = 0
    this.eventsPerStage.clear()
    this.publishTimeTotalMs = 0
    this.publishTimeSamples = 0
  }
}
