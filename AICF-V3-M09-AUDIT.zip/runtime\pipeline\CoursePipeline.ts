// =============================================================================
// AICF V3 — Sprint 2.5 Infrastructure — CoursePipeline
// =============================================================================
// The CoursePipeline is the top-level orchestrator for course generation.
// It ties together the Content Intelligence layer (M08), the AIFactory
// (17-stage Epica 8 generation), the Sprint 2.5 infrastructure (state,
// checkpoints, artifacts, manifest, export), and produces a single
// CoursePipelineResult.
//
// Pipeline flow:
//   1. decide() via getContentEngine().decide()         (M08 integration)
//   2. generateCourse() via getAIFactory(null)          (17-stage AIFactory)
//   3. mapStages() — map 17 AIFactory stages to 7 business stages
//   4. save() checkpoints via CheckpointEngine
//   5. register() artifacts via getGlobalArtifactRegistry()
//   6. buildCourseManifest() — assemble the manifest
//   7. exportZip() via ExportManager
//   8. register() ZIP + manifest as artifacts
//
// The pipeline uses a globalThis singleton for ArtifactRegistry (so the
// download endpoint can find artifacts across hot-reloads).
// =============================================================================

import type { RuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import { createRuntimeRequest } from '@/lib/runtime/contracts/RuntimeRequest'
import type { DecisionPlan } from '@/lib/runtime/modules/m08/DecisionPlan'
import type { CourseResult, StageResult } from '@/lib/runtime/course/CourseContracts'
import { getAIFactory, type GenerateCourseInput } from '@/lib/runtime/course/AIFactory'
import { getContentEngine } from '@/lib/content-intelligence/ContentEngine'
import {
  PipelineState,
  createPipelineState,
} from './PipelineState'
import {
  CheckpointEngine,
  getCheckpointEngine,
} from '../checkpoint/CheckpointEngine'
import {
  ArtifactRegistry,
  type RegisteredArtifact,
  getGlobalArtifactRegistry,
} from '../artifacts/ArtifactRegistry'
import {
  buildCourseManifest,
  manifestToJson,
  type CourseManifest,
} from '../manifest/CourseManifest'
import {
  ExportManager,
  type ExportResult,
  getExportManager,
} from '../export/ExportManager'
import { getGlobalCourseMetrics } from '../metrics/CourseMetrics'
import { logger } from '@/lib/ai/logger'

/**
 * The 7 business-level pipeline stages.
 */
export const COURSE_PIPELINE_STAGES = [
  'research',
  'curriculum',
  'lessons',
  'quiz',
  'slides',
  'qa',
  'export',
] as const

export type CoursePipelineStage = typeof COURSE_PIPELINE_STAGES[number]

/**
 * The 17 AIFactory stages, in execution order.
 */
const AIFACTORY_STAGES = [
  'research',
  'curriculum',
  'modules',
  'lesson-planning',
  'lesson-writing',
  'exercises',
  'quizzes',
  'assessments',
  'case-studies',
  'checklists',
  'templates',
  'slides',
  'guides',
  'quality',
  'validation',
  'publish',
  'zip',
] as const

/**
 * Result of a CoursePipeline run.
 */
export interface CoursePipelineResult {
  /** Course id (from CourseResult). */
  courseId: string
  /** Execution id (from PipelineState). */
  executionId: string
  /** Whether the pipeline succeeded end-to-end. */
  success: boolean
  /** The full CourseResult from AIFactory. */
  courseResult: CourseResult
  /** The final pipeline state. */
  state: PipelineState
  /** The course manifest. */
  manifest: CourseManifest
  /** The ZIP export result (null if export was skipped). */
  zipExport: ExportResult | null
  /** All artifacts registered for this course. */
  artifacts: RegisteredArtifact[]
  /** Error message if `success === false`. */
  error?: string
}

/**
 * The CoursePipeline. Orchestrates M08 + AIFactory + Sprint 2.5 infra.
 */
export class CoursePipeline {
  private readonly checkpointEngine: CheckpointEngine
  private readonly artifactRegistry: ArtifactRegistry
  private readonly exportManager: ExportManager

  constructor(
    checkpointEngine?: CheckpointEngine,
    artifactRegistry?: ArtifactRegistry,
    exportManager?: ExportManager,
  ) {
    this.checkpointEngine = checkpointEngine ?? getCheckpointEngine()
    this.artifactRegistry = artifactRegistry ?? getGlobalArtifactRegistry()
    this.exportManager = exportManager ?? getExportManager()
  }

  /**
   * Run the full pipeline for the given input.
   */
  async run(input: GenerateCourseInput): Promise<CoursePipelineResult> {
    const executionId = this.makeId('exec')
    const state = createPipelineState(executionId, '', [...COURSE_PIPELINE_STAGES])
    state.start()
    logger.info(
      { executionId, topic: input.topic, mode: input.mode ?? 'balanced' },
      'CoursePipeline: starting',
    )

    let plan: DecisionPlan | null = null
    let courseResult: CourseResult | null = null

    try {
      // --- Stage 1: research (M08 decide + AIFactory research) ----------------
      state.startStage('research')
      const request = this.buildRequest(executionId, input)
      state.courseId = request.requestId
      plan = await getContentEngine().decide(request)
      logger.info(
        { executionId, mode: plan.audit.policyMode, provider: plan.provider, model: plan.model },
        'CoursePipeline: M08 decision made',
      )

      // Delegate to AIFactory for the actual 17-stage generation.
      const factory = getAIFactory(null)
      courseResult = await factory.generateCourse(input)
      logger.info(
        { executionId, courseId: courseResult.id, status: courseResult.status },
        'CoursePipeline: AIFactory.generateCourse complete',
      )

      // Save checkpoint after research.
      this.checkpointEngine.save({
        executionId,
        courseId: courseResult.id,
        stage: 'research',
        output: { courseResultId: courseResult.id },
        context: { plan, courseResultId: courseResult.id },
      })
      state.completeStage('research')

      // --- Stage 2: curriculum (mapped from AIFactory stages) ----------------
      state.startStage('curriculum')
      this.saveStageCheckpoint(executionId, courseResult, 'curriculum')
      state.completeStage('curriculum')

      // --- Stage 3: lessons (mapped from AIFactory lesson-writing) -----------
      state.startStage('lessons')
      this.saveStageCheckpoint(executionId, courseResult, 'lessons')
      state.completeStage('lessons')

      // --- Stage 4: quiz (mapped from AIFactory quizzes + assessments) -------
      state.startStage('quiz')
      this.saveStageCheckpoint(executionId, courseResult, 'quiz')
      state.completeStage('quiz')

      // --- Stage 5: slides (mapped from AIFactory slides) --------------------
      state.startStage('slides')
      this.saveStageCheckpoint(executionId, courseResult, 'slides')
      state.completeStage('slides')

      // --- Stage 6: qa (mapped from AIFactory quality + validation) ----------
      state.startStage('qa')
      this.saveStageCheckpoint(executionId, courseResult, 'qa')
      state.completeStage('qa')

      // --- Stage 7: export ---------------------------------------------------
      state.startStage('export')

      // Register individual content artifacts (lessons, quizzes, slides, etc.).
      const contentArtifacts = this.registerContentArtifacts(courseResult)

      // Build the manifest.
      const manifest = buildCourseManifest({
        courseResult,
        request,
        artifacts: contentArtifacts,
      })

      // Export the ZIP.
      const zipExport = await this.exportManager.exportZip(
        courseResult.id,
        courseResult,
        contentArtifacts,
        manifestToJson(manifest),
      )

      // Register the ZIP + manifest as artifacts too.
      const zipArtifact = this.artifactRegistry.register({
        courseId: courseResult.id,
        type: 'zip',
        name: `${courseResult.id}.zip`,
        content: zipExport.content as Buffer,
        producedBy: 'export',
      })
      const manifestArtifact = this.artifactRegistry.register({
        courseId: courseResult.id,
        type: 'json',
        name: 'manifest.json',
        content: manifestToJson(manifest),
        producedBy: 'export',
      })

      const allArtifacts = [...contentArtifacts, zipArtifact, manifestArtifact]
      state.completeStage('export')

      state.complete()

      // --- Record metrics (Sprint 5 RC32) ---
      try {
        const metrics = getGlobalCourseMetrics()
        metrics.record({
          courseId: courseResult.id,
          title: courseResult.title,
          topic: courseResult.topic,
          provider: plan?.provider ?? courseResult.provider ?? 'deterministic',
          model: plan?.model ?? courseResult.model ?? 'fallback',
          mode: plan?.audit.policyMode ?? 'balanced',
          qualityScore: courseResult.qualityReport?.overallScore ?? 0,
          wordCount: courseResult.totalWordCount,
          moduleCount: courseResult.modules.length,
          lessonCount: courseResult.lessons.length,
          durationMs: state.totalDurationMs,
          zipSizeBytes: zipExport.sizeBytes,
          tokens: courseResult.totalCost > 0 ? Math.round(courseResult.totalCost * 1000) : 0,
          createdAt: courseResult.createdAt,
        })
      } catch {
        // Metrics recording is non-fatal
      }

      logger.info(
        {
          executionId,
          courseId: courseResult.id,
          correlationId: plan?.correlationId,
          provider: plan?.provider,
          model: plan?.model,
          durationMs: state.totalDurationMs,
          qualityScore: courseResult.qualityReport?.overallScore ?? 0,
          artifactCount: allArtifacts.length,
          zipSize: zipExport.sizeBytes,
        },
        'CoursePipeline: completed',
      )

      return {
        courseId: courseResult.id,
        executionId,
        success: true,
        courseResult,
        state,
        manifest,
        zipExport,
        artifacts: allArtifacts,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      state.fail(message)
      logger.error(
        { executionId, error: message },
        'CoursePipeline: failed',
      )
      return {
        courseId: courseResult?.id ?? '',
        executionId,
        success: false,
        courseResult: courseResult ?? this.emptyResult(input),
        state,
        manifest: this.emptyManifest(input),
        zipExport: null,
        artifacts: [],
        error: message,
      }
    }
  }

  /**
   * Map the 17 AIFactory stages to the 7 business stages. Returns a map
   * from business stage to the AIFactory stage results that contribute to it.
   */
  mapStages(stageResults: StageResult[]): Record<CoursePipelineStage, StageResult[]> {
    const map: Record<CoursePipelineStage, StageResult[]> = {
      research: [],
      curriculum: [],
      lessons: [],
      quiz: [],
      slides: [],
      qa: [],
      export: [],
    }
    for (const sr of stageResults) {
      const business = this.aifactoryToBusiness(sr.stage)
      if (business) map[business].push(sr)
    }
    return map
  }

  private aifactoryToBusiness(stage: string): CoursePipelineStage | null {
    switch (stage) {
      case 'research':
        return 'research'
      case 'curriculum':
      case 'modules':
      case 'lesson-planning':
        return 'curriculum'
      case 'lesson-writing':
      case 'exercises':
      case 'templates':
        return 'lessons'
      case 'quizzes':
      case 'assessments':
      case 'case-studies':
      case 'checklists':
        return 'quiz'
      case 'slides':
        return 'slides'
      case 'guides':
        return 'lessons'
      case 'quality':
      case 'validation':
      case 'publish':
        return 'qa'
      case 'zip':
        return 'export'
      default:
        return null
    }
  }

  private buildRequest(executionId: string, input: GenerateCourseInput): RuntimeRequest {
    return createRuntimeRequest({
      operation: 'generate',
      metadata: {
        mode: input.mode ?? 'balanced',
        executionId,
        topic: input.topic,
      },
    })
  }

  private saveStageCheckpoint(
    executionId: string,
    courseResult: CourseResult,
    businessStage: CoursePipelineStage,
  ): void {
    const aifactoryStages = this.businessToAifactory(businessStage)
    const stageResults = courseResult.stages.filter((s) => aifactoryStages.includes(s.stage))
    this.checkpointEngine.save({
      executionId,
      courseId: courseResult.id,
      stage: businessStage,
      output: stageResults.map((s) => ({ stage: s.stage, status: s.status, durationMs: s.durationMs })),
      context: { courseResultId: courseResult.id },
    })
  }

  private businessToAifactory(business: CoursePipelineStage): string[] {
    switch (business) {
      case 'research':
        return ['research']
      case 'curriculum':
        return ['curriculum', 'modules', 'lesson-planning']
      case 'lessons':
        return ['lesson-writing', 'exercises', 'templates', 'guides']
      case 'quiz':
        return ['quizzes', 'assessments', 'case-studies', 'checklists']
      case 'slides':
        return ['slides']
      case 'qa':
        return ['quality', 'validation', 'publish']
      case 'export':
        return ['zip']
      default:
        return []
    }
  }

  private registerContentArtifacts(courseResult: CourseResult): RegisteredArtifact[] {
    const artifacts: RegisteredArtifact[] = []
    const courseId = courseResult.id

    // Course JSON
    artifacts.push(this.artifactRegistry.register({
      courseId,
      type: 'json',
      name: 'course.json',
      content: JSON.stringify(courseResult, this.bufferReplacer, 2),
      producedBy: 'lessons',
    }))

    // Lessons (markdown)
    for (const lesson of courseResult.lessons) {
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'markdown',
        name: `lessons/${lesson.id}.md`,
        content: lesson.content,
        producedBy: 'lessons',
      }))
    }

    // Quizzes
    for (const quiz of courseResult.quizzes) {
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'quiz',
        name: `quizzes/${quiz.id}.json`,
        content: JSON.stringify(quiz, null, 2),
        producedBy: 'quiz',
      }))
    }

    // Assessments
    for (const a of courseResult.assessments) {
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'json',
        name: `assessments/${a.id}.json`,
        content: JSON.stringify(a, null, 2),
        producedBy: 'quiz',
      }))
    }

    // Slides
    if (courseResult.presentation) {
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'slides',
        name: `slides/${courseResult.presentation.id}.json`,
        content: JSON.stringify(courseResult.presentation, null, 2),
        producedBy: 'slides',
      }))
    }

    // Guides
    for (const g of courseResult.guides) {
      const body = g.sections.map((s) => `# ${s.title}\n\n${s.content}`).join('\n\n')
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'markdown',
        name: `guides/${g.id}-${g.type}.md`,
        content: body,
        producedBy: 'lessons',
      }))
    }

    // Quality report
    if (courseResult.qualityReport) {
      artifacts.push(this.artifactRegistry.register({
        courseId,
        type: 'json',
        name: 'quality-report.json',
        content: JSON.stringify(courseResult.qualityReport, null, 2),
        producedBy: 'qa',
      }))
    }

    return artifacts
  }

  private bufferReplacer(_key: string, value: unknown): unknown {
    if (value instanceof Buffer) {
      return { __buffer: true, length: value.byteLength }
    }
    return value
  }

  private emptyResult(input: GenerateCourseInput): CourseResult {
    const now = new Date().toISOString()
    return {
      id: '',
      version: '3.0.0',
      createdAt: now,
      updatedAt: now,
      generatorVersion: '3.0.0',
      provider: 'runtime-adapter',
      model: 'deterministic-fallback',
      runtimeVersion: 'AICF-V3-RC1',
      courseRequestId: '',
      topic: input.topic,
      title: input.title ?? input.topic,
      description: input.description ?? '',
      status: 'failed',
      curriculum: null,
      modules: [],
      lessons: [],
      exercises: [],
      quizzes: [],
      assessments: [],
      caseStudies: [],
      checklists: [],
      templates: [],
      presentation: null,
      guides: [],
      qualityReport: null,
      stages: [],
      zipBuffer: null,
      zipUrl: '',
      totalWordCount: 0,
      totalDurationMs: 0,
      totalCost: 0,
      error: 'pipeline failed before courseResult was produced',
    }
  }

  private emptyManifest(input: GenerateCourseInput): CourseManifest {
    return {
      version: '1.0.0',
      generatedAt: new Date().toISOString(),
      metadata: {
        courseId: '',
        title: input.title ?? input.topic,
        description: input.description ?? '',
        topic: input.topic,
        audience: 'general learners',
        level: 'intermediate',
        locale: 'en-US',
        country: 'Global',
        moduleCount: 0,
        researchDepth: input.researchDepth ?? 'standard',
        mode: input.mode ?? 'balanced',
        status: 'failed',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        generatorVersion: '3.0.0',
        provider: 'runtime-adapter',
        model: 'deterministic-fallback',
        runtimeVersion: 'AICF-V3-RC1',
      },
      modules: [],
      lessons: [],
      artifacts: [],
      statistics: {
        totalModules: 0,
        totalLessons: 0,
        totalWords: 0,
        totalExercises: 0,
        totalQuizzes: 0,
        totalAssessments: 0,
        totalArtifacts: 0,
        totalDurationHours: 0,
        totalSizeBytes: 0,
        qualityScore: 0,
      },
    }
  }

  private makeId(prefix: string): string {
    const ts = Date.now().toString(36)
    const rand = Math.random().toString(36).slice(2, 6)
    return `${prefix}-${ts}-${rand}`
  }
}

/**
 * Singleton CoursePipeline.
 */
let singleton: CoursePipeline | null = null

export function getCoursePipeline(): CoursePipeline {
  if (!singleton) {
    singleton = new CoursePipeline()
  }
  return singleton
}

/**
 * Reset the singleton (for tests).
 */
export function resetCoursePipeline(): void {
  singleton = null
}
